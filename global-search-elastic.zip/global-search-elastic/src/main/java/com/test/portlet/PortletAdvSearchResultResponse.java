package com.test.portlet;

import com.liferay.portal.kernel.search.Document;
import com.liferay.portal.kernel.search.facet.Facet;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.search.searcher.SearchResponse;
import com.liferay.portal.search.web.internal.display.context.PortletRequestThemeDisplaySupplier;
import com.liferay.portal.search.web.internal.display.context.ThemeDisplaySupplier;
import com.liferay.portal.search.web.internal.portlet.shared.search.PortletSharedSearchResponseImpl;
import com.liferay.portal.search.web.internal.portlet.shared.task.PortletSharedRequestHelper;
import com.liferay.portal.search.web.internal.search.request.SearchResponseImpl;
import com.liferay.portal.search.web.internal.search.request.SearchSettingsImpl;
import com.liferay.portal.search.web.portlet.shared.search.PortletSharedSearchResponse;
import com.liferay.portal.search.web.search.request.SearchSettings;

import javax.portlet.PortletPreferences;
import javax.portlet.RenderRequest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

public class PortletAdvSearchResultResponse implements PortletSharedSearchResponse {

    public PortletAdvSearchResultResponse(
            SearchResponse searchResponseImpl) {

        this._searchResponseImpl = searchResponseImpl;
    }

    @Override
    public List<Document> getDocuments() {
        //SearchResponse searchResponse = _searchResponseImpl.getSearchResponse();

        return _searchResponseImpl.getDocuments71();
    }

    @Override
    public Facet getFacet(String name) {
        SearchResponse searchResponse = getSearchResponse();

        return searchResponse.withFacetContextGet(
                facetContext -> facetContext.getFacet(name));
    }

    @Override
    public SearchResponse getFederatedSearchResponse(
            Optional<String> federatedSearchKeyOptional) {

        return _searchResponseImpl;
    }

    @Override
    public String[] getHighlights() {
        return null;
    }

    @Override
    public Optional<String> getKeywordsOptional() {
        return Optional.empty();
    }

    @Override
    public int getPaginationDelta() {
        return 0;
    }

    @Override
    public int getPaginationStart() {
        return 0;
    }

    @Override
    public Optional<String> getParameter(
            String name, RenderRequest renderRequest) {
        return Optional.ofNullable(PortalUtil.getOriginalServletRequest(PortalUtil.getHttpServletRequest(renderRequest))
                .getParameter(name));
    }

    @Override
    public Optional<String[]> getParameterValues(
            String name, RenderRequest renderRequest) {

        return Optional.ofNullable(PortalUtil.getOriginalServletRequest(PortalUtil.getHttpServletRequest(renderRequest))
                .getParameterValues(name));
    }

    @Override
    public Optional<PortletPreferences> getPortletPreferences(
            RenderRequest renderRequest) {

        return Optional.ofNullable(renderRequest.getPreferences());
    }

    @Override
    public String getQueryString() {
        return _searchResponseImpl.getRequestString();
    }

    @Override
    public List<String> getRelatedQueriesSuggestions() {
        return new ArrayList<>();
    }

    @Override
    public SearchResponse getSearchResponse() {
        return _searchResponseImpl;
    }

    @Override
    public SearchSettings getSearchSettings() {
        return null;
    }

    @Override
    public Optional<String> getSpellCheckSuggestionOptional() {
        return Optional.empty();
    }

    @Override
    public ThemeDisplay getThemeDisplay(RenderRequest renderRequest) {
        ThemeDisplaySupplier themeDisplaySupplier =
                new PortletRequestThemeDisplaySupplier(renderRequest);

        return themeDisplaySupplier.getThemeDisplay();
    }

    @Override
    public int getTotalHits() {
        return _searchResponseImpl.getTotalHits();
    }

    private final SearchResponse _searchResponseImpl;
}
