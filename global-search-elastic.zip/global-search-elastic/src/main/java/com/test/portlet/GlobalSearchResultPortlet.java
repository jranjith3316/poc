package com.test.portlet;

import com.liferay.asset.kernel.service.AssetEntryLocalService;
import com.liferay.asset.util.AssetRendererFactoryLookup;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.dao.search.DisplayTerms;
import com.liferay.portal.kernel.dao.search.SearchContainer;
import com.liferay.portal.kernel.language.Language;

import com.liferay.portal.kernel.portlet.LiferayPortletRequest;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;
import com.liferay.portal.kernel.search.Document;
import com.liferay.portal.kernel.search.IndexerRegistry;
import com.liferay.portal.kernel.security.permission.ResourceActions;
import com.liferay.portal.kernel.service.GroupLocalService;
import com.liferay.portal.kernel.service.UserLocalService;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.*;
import com.liferay.portal.search.hits.SearchHits;
import com.liferay.portal.search.legacy.document.DocumentBuilderFactory;
import com.liferay.portal.search.query.*;
import com.liferay.portal.search.searcher.*;
import com.liferay.portal.search.sort.SortOrder;
import com.liferay.portal.search.sort.Sorts;
import com.liferay.portal.search.summary.SummaryBuilderFactory;
import com.liferay.portal.search.web.internal.display.context.PortletURLFactory;
import com.liferay.portal.search.web.internal.display.context.PortletURLFactoryImpl;
import com.liferay.portal.search.web.internal.display.context.SearchResultPreferences;
import com.liferay.portal.search.web.internal.document.DocumentFormPermissionChecker;
import com.liferay.portal.search.web.internal.document.DocumentFormPermissionCheckerImpl;
import com.liferay.portal.search.web.internal.portlet.shared.search.NullPortletURL;
import com.liferay.portal.search.web.internal.portlet.shared.task.PortletSharedRequestHelper;
import com.liferay.portal.search.web.internal.result.display.builder.SearchResultSummaryDisplayBuilder;
import com.liferay.portal.search.web.internal.result.display.context.SearchResultSummaryDisplayContext;
import com.liferay.portal.search.web.internal.search.results.portlet.*;
import com.liferay.portal.search.web.portlet.shared.search.PortletSharedSearchRequest;
import com.liferay.portal.search.web.portlet.shared.search.PortletSharedSearchResponse;
import com.liferay.portal.search.web.search.result.SearchResultImageContributor;
import com.test.constants.GlobalSearchPortletKeys;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import javax.portlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.*;

@Component(
        immediate = true,
        property = {
                "com.liferay.portlet.display-category=category.sample",
                "com.liferay.portlet.header-portlet-css=/css/main.css",
                "com.liferay.portlet.instanceable=true",
                "javax.portlet.display-name=GlobalSearchResult",
                "javax.portlet.init-param.template-path=/",
                "javax.portlet.init-param.view-template=/global_search_result.jsp",
                "javax.portlet.name=" + GlobalSearchPortletKeys.GLOBALSEARCHRESULT,
                "javax.portlet.resource-bundle=content.Language",
                "javax.portlet.security-role-ref=power-user,user"
        },
        service = Portlet.class
)
public class GlobalSearchResultPortlet extends MVCPortlet {

    @Override
    public void render(RenderRequest renderRequest, RenderResponse renderResponse) throws IOException, PortletException {

        HttpServletRequest request = PortalUtil.getHttpServletRequest(renderRequest);
        ThemeDisplay themeDisplay = (ThemeDisplay) renderRequest.getAttribute(WebKeys.THEME_DISPLAY);

        String keyword = PortalUtil.getOriginalServletRequest(request)
                .getParameter("keyword");
        String keyword1 = PortalUtil.getOriginalServletRequest(request)
                .getParameter("keyword1");
        String keyword2 = PortalUtil.getOriginalServletRequest(request)
                .getParameter("keyword2");
        String operand = PortalUtil.getOriginalServletRequest(request)
                .getParameter("operand");
        String title = PortalUtil.getOriginalServletRequest(request)
                .getParameter("title");
        String[] categories = PortalUtil.getOriginalServletRequest(request)
                .getParameterValues( "category");
        String year = PortalUtil.getOriginalServletRequest(request)
                .getParameter( "year");

        long[] categoryIds = categories == null ? new long[]{} : Arrays.stream(categories).filter(c -> !c.isEmpty()).map(Long::valueOf).mapToLong(Long::longValue).toArray();

        System.out.println("In here -> test");

        SearchResponse searchResponse = search(themeDisplay, keyword, keyword1, keyword2, operand, title, categoryIds);


        ////////////////////////////////////////////////////
        PortletSharedSearchResponse portletSharedSearchResponse = convertToPortletSharedSearchResponse(searchResponse);
            //   portletSharedSearchRequest.search(renderRequest);

        SearchResultsPortletDisplayContext searchResultsPortletDisplayContext =
                buildDisplayContext(
                        portletSharedSearchResponse, renderRequest, renderResponse);

        if (searchResultsPortletDisplayContext.isRenderNothing()) {
            renderRequest.setAttribute(
                    WebKeys.PORTLET_CONFIGURATOR_VISIBILITY, Boolean.TRUE);
        }

        renderRequest.setAttribute(
                WebKeys.PORTLET_DISPLAY_CONTEXT,
                searchResultsPortletDisplayContext);

        super.render(renderRequest, renderResponse);
    }

    private PortletSharedSearchResponse convertToPortletSharedSearchResponse(SearchResponse searchResponse) {
        PortletSharedSearchResponse response = new PortletAdvSearchResultResponse(searchResponse);
        return response;
    }

    protected SearchResultsPortletDisplayContext
    createSearchResultsPortletDisplayContext(RenderRequest renderRequest) {

        return new SearchResultsPortletDisplayContext();
    }

    protected HttpServletRequest getHttpServletRequest(
            RenderRequest renderRequest) {

        LiferayPortletRequest liferayPortletRequest =
                _portal.getLiferayPortletRequest(renderRequest);

        return liferayPortletRequest.getHttpServletRequest();
    }

    protected SearchResultsSummariesHolder buildSummaries(
            PortletSharedSearchResponse portletSharedSearchResponse,
            RenderRequest renderRequest, RenderResponse renderResponse)
            throws PortletException {

        try {
            return doBuildSummaries(
                    portletSharedSearchResponse, renderRequest, renderResponse);
        }
        catch (PortletException portletException) {
            throw portletException;
        }
        catch (RuntimeException runtimeException) {
            throw runtimeException;
        }
        catch (Exception exception) {
            throw new PortletException(exception);
        }
    }

    protected SearchResultsSummariesHolder doBuildSummaries(
            PortletSharedSearchResponse portletSharedSearchResponse,
            RenderRequest renderRequest, RenderResponse renderResponse)
            throws Exception {

        SearchResultsPortletPreferences searchResultsPortletPreferences =
                new SearchResultsPortletPreferencesImpl(
                        portletSharedSearchResponse.getPortletPreferences(
                                renderRequest));

        ThemeDisplay themeDisplay = portletSharedSearchResponse.getThemeDisplay(
                renderRequest);

        DocumentFormPermissionChecker documentFormPermissionChecker =
                new DocumentFormPermissionCheckerImpl(themeDisplay);

        SearchResponse searchResponse = getSearchResponse(
                portletSharedSearchResponse, searchResultsPortletPreferences);

        List<Document> documents = searchResponse.getDocuments71();

        SearchResultsSummariesHolder searchResultsSummariesHolder =
                new SearchResultsSummariesHolder(documents.size());

        PortletURLFactory portletURLFactory = getPortletURLFactory(
                renderRequest, renderResponse);

        SearchResultPreferences searchResultPreferences =
                new SearchResultPreferencesImpl(
                        searchResultsPortletPreferences, documentFormPermissionChecker);

        for (Document document : documents) {
            SearchResultSummaryDisplayContext
                    searchResultSummaryDisplayContext = doBuildSummary(
                    document, renderRequest, renderResponse, themeDisplay,
                    portletURLFactory, searchResultsPortletPreferences,
                    searchResultPreferences);

            if (searchResultSummaryDisplayContext != null) {
                searchResultsSummariesHolder.put(
                        document, searchResultSummaryDisplayContext);
            }
        }

        return searchResultsSummariesHolder;
    }
    protected String getCurrentURL(RenderRequest renderRequest) {
        return _portal.getCurrentURL(renderRequest);
    }
    protected SearchResultSummaryDisplayContext doBuildSummary(
            Document document, RenderRequest renderRequest,
            RenderResponse renderResponse, ThemeDisplay themeDisplay,
            PortletURLFactory portletURLFactory,
            SearchResultsPortletPreferences searchResultsPortletPreferences,
            SearchResultPreferences searchResultPreferences)
            throws Exception {

        SearchResultSummaryDisplayBuilder searchResultSummaryDisplayBuilder =
                new SearchResultSummaryDisplayBuilder();

        searchResultSummaryDisplayBuilder.setAssetEntryLocalService(
                assetEntryLocalService
        ).setAssetRendererFactoryLookup(
                assetRendererFactoryLookup
        ).setCurrentURL(
                getCurrentURL(renderRequest)
        ).setDocument(
                document
        ).setDocumentBuilderFactory(
                documentBuilderFactory
        ).setFastDateFormatFactory(
                fastDateFormatFactory
        ).setGroupLocalService(
                groupLocalService
        ).setHighlightEnabled(
                searchResultsPortletPreferences.isHighlightEnabled()
        ).setImageRequested(
                true
        ).setIndexerRegistry(
                indexerRegistry
        ).setLanguage(
                language
        ).setLocale(
                themeDisplay.getLocale()
        ).setPortletURLFactory(
                portletURLFactory
        ).setRenderRequest(
                renderRequest
        ).setRenderResponse(
                renderResponse
        ).setRequest(
                getHttpServletRequest(renderRequest)
        ).setResourceActions(
                resourceActions
        ).setSearchResultImageContributorsStream(
                _searchResultImageContributors.stream()
        ).setSearchResultPreferences(
                searchResultPreferences
        ).setSummaryBuilderFactory(
                summaryBuilderFactory
        ).setThemeDisplay(
                themeDisplay
        ).setUserLocalService(
                userLocalService
        );

        return searchResultSummaryDisplayBuilder.build();
    }


    protected SearchResultsPortletDisplayContext buildDisplayContext(
            PortletSharedSearchResponse portletSharedSearchResponse,
            RenderRequest renderRequest, RenderResponse renderResponse)
            throws PortletException {

        SearchResultsPortletDisplayContext searchResultsPortletDisplayContext =
                createSearchResultsPortletDisplayContext(renderRequest);

        SearchResultsSummariesHolder searchResultsSummariesHolder =
                buildSummaries(
                        portletSharedSearchResponse, renderRequest, renderResponse);

        List<Document> documents = new ArrayList<>(
                searchResultsSummariesHolder.getDocuments());

        searchResultsPortletDisplayContext.setDocuments(documents);

        SearchResultsPortletPreferences searchResultsPortletPreferences =
                new SearchResultsPortletPreferencesImpl(
                        portletSharedSearchResponse.getPortletPreferences(
                                renderRequest));

        SearchResponse searchResponse = getSearchResponse(
                portletSharedSearchResponse, searchResultsPortletPreferences);

        SearchRequest searchRequest = searchResponse.getRequest();

        Optional<String> keywordsOptional = Optional.ofNullable(
                searchRequest.getQueryString());

        searchResultsPortletDisplayContext.setKeywords(
                keywordsOptional.orElse(StringPool.BLANK));

        searchResultsPortletDisplayContext.setRenderNothing(
                isRenderNothing(renderRequest, searchRequest));

        int paginationDelta = Optional.ofNullable(
                searchRequest.getSize()
        ).orElse(
                SearchContainer.DEFAULT_DELTA
        );
        int paginationStart = 0;

        int from = Optional.ofNullable(
                searchRequest.getFrom()
        ).orElse(
                0
        );

        if (from > 0) {
            paginationStart = (from / paginationDelta) + 1;
        }

        searchResultsPortletDisplayContext.setSearchContainer(
                buildSearchContainer(
                        documents, searchResponse.getTotalHits(), paginationStart,
                        searchResultsPortletPreferences.
                                getPaginationStartParameterName(),
                        paginationDelta,
                        searchResultsPortletPreferences.
                                getPaginationDeltaParameterName(),
                        renderRequest));

        searchResultsPortletDisplayContext.setSearchResultsSummariesHolder(
                searchResultsSummariesHolder);
        /*searchResultsPortletDisplayContext.
                setSearchResultSummaryDisplayContexts(
                        searchResultsPortletDisplayContext.
                                translateSearchResultSummaryDisplayContexts(documents));*/
        searchResultsPortletDisplayContext.setTotalHits(
                searchResponse.getTotalHits());

        return searchResultsPortletDisplayContext;
    }

    protected boolean isRenderNothing(
            RenderRequest renderRequest, SearchRequest searchRequest) {

        long assetEntryId = ParamUtil.getLong(renderRequest, "assetEntryId");

        if (assetEntryId != 0) {
            return false;
        }

        if ((searchRequest.getQueryString() == null) &&
                !searchRequest.isEmptySearchEnabled()) {

            return true;
        }

        return false;
    }



    protected SearchContainer<Document> buildSearchContainer(
            List<Document> documents, int totalHits, int paginationStart,
            String paginationStartParameterName, int paginationDelta,
            String paginationDeltaParameterName, RenderRequest renderRequest)
            throws PortletException {

        PortletRequest portletRequest = renderRequest;
        DisplayTerms displayTerms = null;
        DisplayTerms searchTerms = null;
        String curParam = paginationStartParameterName;
        int cur = paginationStart;
        int delta = paginationDelta;
        PortletURL portletURL = getPortletURL(
                renderRequest, paginationStartParameterName);
        List<String> headerNames = null;
        String emptyResultsMessage = null;
        String cssClass = null;

        SearchContainer<Document> searchContainer = new SearchContainer<>(
                portletRequest, displayTerms, searchTerms, curParam, cur, delta,
                portletURL, headerNames, emptyResultsMessage, cssClass);

        searchContainer.setDeltaParam(paginationDeltaParameterName);
        searchContainer.setResults(documents);
        searchContainer.setTotal(totalHits);

        return searchContainer;
    }

    protected PortletURL getPortletURL(
            RenderRequest renderRequest, String paginationStartParameterName) {

        final String urlString = getURLString(
                renderRequest, paginationStartParameterName);

        return new NullPortletURL() {

            @Override
            public String toString() {
                return urlString;
            }

        };
    }

    protected PortletURLFactory getPortletURLFactory(
            RenderRequest renderRequest, RenderResponse renderResponse) {

        return new PortletURLFactoryImpl(renderRequest, renderResponse);
    }

    protected String getURLString(
            RenderRequest renderRequest, String paginationStartParameterName) {

        String urlString = PortalUtil.getOriginalServletRequest(PortalUtil.getHttpServletRequest(renderRequest))
                .getRequestURI();

        return http.removeParameter(urlString, paginationStartParameterName);
    }

    protected SearchResponse getSearchResponse(
            PortletSharedSearchResponse portletSharedSearchResponse,
            SearchResultsPortletPreferences searchResultsPortletPreferences) {

        return portletSharedSearchResponse.getFederatedSearchResponse(
                searchResultsPortletPreferences.getFederatedSearchKeyOptional());
    }

    private SearchResponse search(ThemeDisplay themeDisplay, String keyword, String keyword1, String keyword2, String operand, String title, long[] categoryIds) {
        TermsQuery termQuery = queries.terms("entryClassName");
        termQuery.addValues("com.liferay.journal.model.JournalArticle");

        // MatchQuery matchQuery = queries.match("ddmTemplateKey", "BASIC-WEB-CONTENT");

        BooleanQuery booleanQuery = queries.booleanQuery();
        booleanQuery.addMustQueryClauses(termQuery);

        if (keyword != null && !keyword.isEmpty()) {
            MultiMatchQuery keywordQuery = queries.multiMatch(keyword, new HashSet<>());
            booleanQuery.addMustQueryClauses(keywordQuery);
        } else {

            if (operand != null && !operand.isEmpty()
                    && keyword1 != null && !keyword1.isEmpty()
                    && keyword2 != null && !keyword2.isEmpty()) {


                if (operand.equalsIgnoreCase("OR")) {
                    MultiMatchQuery keyword1Query = queries.multiMatch(keyword1, new HashSet<>());
                    booleanQuery.addMustQueryClauses(keyword1Query);
                    MultiMatchQuery keyword2Query = queries.multiMatch(keyword2, new HashSet<>());
                    booleanQuery.addShouldQueryClauses(keyword2Query);
                } else if (operand.equalsIgnoreCase("AND")) {
                    MultiMatchQuery keyword1Query = queries.multiMatch(keyword1, new HashSet<>());
                    booleanQuery.addMustQueryClauses(keyword1Query);
                    MultiMatchQuery keyword2Query = queries.multiMatch(keyword2, new HashSet<>());
                    booleanQuery.addMustQueryClauses(keyword2Query);
                } else if (operand.equalsIgnoreCase("NOT")) {
                    MultiMatchQuery keyword1Query = queries.multiMatch(keyword1, new HashSet<>());
                    booleanQuery.addMustQueryClauses(keyword1Query);
                    MultiMatchQuery keyword2Query = queries.multiMatch(keyword2, new HashSet<>());
                    booleanQuery.addMustNotQueryClauses(keyword2Query);
                } else {
                    MultiMatchQuery keyword1Query = queries.multiMatch(keyword1, new HashSet<>());
                    booleanQuery.addMustQueryClauses(keyword1Query);
                    MultiMatchQuery keyword2Query = queries.multiMatch(keyword2, new HashSet<>());
                    booleanQuery.addMustQueryClauses(keyword2Query);
                }
            } else {

                if (keyword1 != null && !keyword1.isEmpty()) {
                    MultiMatchQuery keyword1Query = queries.multiMatch(keyword1, new HashSet<>());
                    booleanQuery.addMustQueryClauses(keyword1Query);
                }
                if (keyword2 != null && !keyword2.isEmpty()) {
                    MultiMatchQuery keyword2Query = queries.multiMatch(keyword2, new HashSet<>());
                    booleanQuery.addMustQueryClauses(keyword2Query);
                }
            }
            if (title != null && !title.isEmpty()) {
                MatchQuery matchQuery = queries.match("title_" + themeDisplay.getLanguageId(), title);
                booleanQuery.addMustQueryClauses(matchQuery);
            }
        }
        SearchRequestBuilder searchRequestBuilder = searchRequestBuilderFactory.builder();
        searchRequestBuilder.withSearchContext(searchContext -> {
            searchContext.setCompanyId(themeDisplay.getCompanyId());
            if(categoryIds != null)
                searchContext.setAssetCategoryIds(categoryIds);
            searchContext.setLocale(themeDisplay.getLocale());
        });
        searchRequestBuilder.sorts(sorts.field("displayDate", SortOrder.DESC));
        searchRequestBuilder.emptySearchEnabled(true);

        SearchRequest searchRequest = searchRequestBuilder.query(booleanQuery).build();
        SearchResponse searchResponse = searcher.search(searchRequest);
        System.out.println(searchResponse.getRequestString());
        SearchHits searchHits = searchResponse.getSearchHits();
        searchHits.getSearchHits().forEach( s -> {
            //s.getDocument()
        });
        return searchResponse;
    }

    @Reference
    private AssetEntryLocalService assetEntryLocalService;

    @Reference
    private Queries queries;

    @Reference
    private Sorts sorts;

    @Reference
    protected Searcher searcher;

    @Reference
    protected SearchRequestBuilderFactory searchRequestBuilderFactory;

///////////////////////////////////////////////////////////////////////////


    protected AssetRendererFactoryLookup assetRendererFactoryLookup;

    @Reference
    protected DocumentBuilderFactory documentBuilderFactory;

    @Reference
    protected FastDateFormatFactory fastDateFormatFactory;

    @Reference
    protected GroupLocalService groupLocalService;

    @Reference
    protected Http http;

    @Reference
    protected IndexerRegistry indexerRegistry;

    @Reference
    protected Language language;

    //@Reference
    //protected PortletSharedRequestHelper portletSharedRequestHelper;

    @Reference
    protected PortletSharedSearchRequest portletSharedSearchRequest;

    @Reference
    protected ResourceActions resourceActions;

    @Reference
    protected SummaryBuilderFactory summaryBuilderFactory;

    @Reference
    protected UserLocalService userLocalService;

    @Reference
    private Portal _portal;

    private final Set<SearchResultImageContributor>
            _searchResultImageContributors = new HashSet<>();


}