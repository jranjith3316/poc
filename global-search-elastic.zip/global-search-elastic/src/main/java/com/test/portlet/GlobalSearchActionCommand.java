package com.test.portlet;

import com.liferay.asset.kernel.service.AssetEntryLocalService;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.search.hits.SearchHit;
import com.liferay.portal.search.hits.SearchHits;
import com.liferay.portal.search.query.*;
import com.liferay.portal.search.searcher.*;
import com.liferay.portal.search.sort.SortOrder;
import com.liferay.portal.search.sort.Sorts;
import com.liferay.portal.util.PropsUtil;
import com.test.constants.GlobalSearchPortletKeys;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import java.util.HashSet;

@Component(
        immediate = true,
        property = {
                "javax.portlet.name=" + GlobalSearchPortletKeys.GLOBALSEARCH,
                "mvc.command.name=web/search"
        },
        service = MVCActionCommand.class
)

public class GlobalSearchActionCommand extends BaseMVCActionCommand {
    @Reference
    private AssetEntryLocalService assetEntryLocalService;

    @Reference
    private Queries queries;

    @Reference
    private Sorts sorts;

    @Reference
    protected Searcher searcher;

    @Reference
    protected SearchRequestBuilderFactory searchRequestBuilderFactory;


    @Override
    protected void doProcessAction(ActionRequest actionRequest, ActionResponse actionResponse) throws Exception {

        ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);

        String keyword1 = ParamUtil.getString(actionRequest, "keyword1");
        String keyword2 = ParamUtil.getString(actionRequest, "keyword2");
        String operand = ParamUtil.getString(actionRequest, "operand");
        String title = ParamUtil.getString(actionRequest, "title");
        long[] categoryIds = ParamUtil.getLongValues(actionRequest, "category");
        String year = ParamUtil.getString(actionRequest, "year");


        // must -- and
        // must not -- not
        // should -- or

        // q -> k1 -- done
        // operand - > OR AND
        // q -> k2
        // title   -- done
        // category1 -- done
        // category2 -- done
        // year

        System.out.println("In here -> test");

        TermsQuery termQuery = queries.terms("entryClassName");
        termQuery.addValues("com.liferay.journal.model.JournalArticle");

       // MatchQuery matchQuery = queries.match("ddmTemplateKey", "BASIC-WEB-CONTENT");

        BooleanQuery booleanQuery = queries.booleanQuery();
        booleanQuery.addMustQueryClauses(termQuery);

        if(operand != null && !operand.isEmpty()
                && keyword1 !=null && !keyword1.isEmpty()
                && keyword2 !=null && !keyword2.isEmpty()){

            if(operand.equalsIgnoreCase("OR")){
                MultiMatchQuery keyword1Query = queries.multiMatch(keyword1, new HashSet<>());
                booleanQuery.addMustQueryClauses(keyword1Query);
                MultiMatchQuery keyword2Query = queries.multiMatch(keyword2, new HashSet<>());
                booleanQuery.addShouldQueryClauses(keyword2Query);
            } else if(operand.equalsIgnoreCase("AND")){
                MultiMatchQuery keyword1Query = queries.multiMatch(keyword1, new HashSet<>());
                booleanQuery.addMustQueryClauses(keyword1Query);
                MultiMatchQuery keyword2Query = queries.multiMatch(keyword2, new HashSet<>());
                booleanQuery.addMustQueryClauses(keyword2Query);
            } else if(operand.equalsIgnoreCase("NOT")){
                MultiMatchQuery keyword1Query = queries.multiMatch(keyword1, new HashSet<>());
                booleanQuery.addMustQueryClauses(keyword1Query);
                MultiMatchQuery keyword2Query = queries.multiMatch(keyword2, new HashSet<>());
                booleanQuery.addMustNotQueryClauses(keyword2Query);
            } else {
                MultiMatchQuery keyword1Query = queries.multiMatch(keyword1, new HashSet<>());
                booleanQuery.addMustQueryClauses(keyword1Query);
                MultiMatchQuery keyword2Query = queries.multiMatch(keyword2, new HashSet<>());
                booleanQuery.addMustQueryClauses(keyword2Query);
            }
        } else {

            if (keyword1 != null && !keyword1.isEmpty()) {
                MultiMatchQuery keyword1Query = queries.multiMatch(keyword1, new HashSet<>());
                booleanQuery.addMustQueryClauses(keyword1Query);
            }
            if (keyword2 != null && !keyword2.isEmpty()) {
                MultiMatchQuery keyword2Query = queries.multiMatch(keyword2, new HashSet<>());
                booleanQuery.addMustQueryClauses(keyword2Query);
            }
        }
        if(title !=null && !title.isEmpty()) {
            MatchQuery matchQuery = queries.match("title_" + themeDisplay.getLanguageId(), title);
            booleanQuery.addMustQueryClauses(matchQuery);
        }

        SearchRequestBuilder searchRequestBuilder = searchRequestBuilderFactory.builder();
        searchRequestBuilder.withSearchContext(searchContext -> {
            searchContext.setCompanyId(themeDisplay.getCompanyId());
            if(categoryIds != null && categoryIds[0] != 0)
                searchContext.setAssetCategoryIds(categoryIds);

            searchContext.setLocale(themeDisplay.getLocale());
        });
        searchRequestBuilder.sorts(sorts.field("displayDate", SortOrder.DESC));
        searchRequestBuilder.emptySearchEnabled(true);

        SearchRequest searchRequest = searchRequestBuilder.query(booleanQuery).build();
        SearchResponse searchResponse = searcher.search(searchRequest);
        System.out.println(searchResponse.getRequestString());
        SearchHits searchHits = searchResponse.getSearchHits();
        searchHits.getSearchHits().forEach( s -> {
            //s.getDocument()
        });


    }
}
