package com.test.constants;

/**
 * @author Chirag Sharma
 */
public class GlobalSearchPortletKeys {

	public static final String GLOBALSEARCH =
		"com_test_GlobalSearchPortlet";
	public static final String GLOBALSEARCHRESULT =
			"com_test_GlobalSearchResultPortlet";

}