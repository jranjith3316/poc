/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.model;

import java.io.Serializable;

public class Image implements Serializable {

  private static final long serialVersionUID = 3862008998985867360L;
  private String defaultImage;
  private String name;
  private String url;
  private String legend;
  private String title;
  /**
   * this URL is used when image length is 60
   */
  private String urlForSmallImage;
  /**
   * this URL is used when image length is 200
   */
  private String urlForMediumImage;
  /**
   * this URL is used when image length is 335
   */
  private String urlForLargeImage;
  /**
   * this URL is used when image length is 650
   */
  private String urlForXLargeImage;

  /**
   *
   */
  /**
   * this Name is used when image length is 60
   */
  private String nameForSmallImage;
  /**
   * this Name is used when image length is 200
   */
  private String nameForMediumImage;
  /**
   * this Name is used when image length is 335
   */
  private String nameForLargeImage;
  /**
   * this Name is used when image length is 650
   */
  private String nameForXLargeImage;

  public Image(String name, String url, String title) {
    this.name = name;
    this.url = url;
    this.title = title;
  }

  public Image(String defaultImage, String name, String url, String legend) {
    this.defaultImage = defaultImage;
    this.name = name;
    this.url = url;
    this.legend = legend;
  }

  public Image(String defaultImage, String name, String url, String legend, String title) {
    this.defaultImage = defaultImage;
    this.name = name;
    this.url = url;
    this.legend = legend;
    this.title = title;
  }

  public String getDefaultImage() {
    return defaultImage;
  }

  public void setDefaultImage(String defaultImage) {
    this.defaultImage = defaultImage;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getUrl() {
    return url;
  }

  public void setUrl(String url) {
    this.url = url;
  }

  public String getLegend() {
    return legend;
  }

  public void setLegend(String legend) {
    this.legend = legend;
  }

  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public String getUrlForXLargeImage() {
    return urlForXLargeImage;
  }

  public void setUrlForXLargeImage(String urlForXLargeImage) {
    this.urlForXLargeImage = urlForXLargeImage;
  }

  public String getNameForSmallImage() {
    return nameForSmallImage;
  }

  public void setNameForSmallImage(String nameForSmallImage) {
    this.nameForSmallImage = nameForSmallImage;
  }

  public String getNameForMediumImage() {
    return nameForMediumImage;
  }

  public void setNameForMediumImage(String nameForMediumImage) {
    this.nameForMediumImage = nameForMediumImage;
  }

  public String getNameForLargeImage() {
    return nameForLargeImage;
  }

  public void setNameForLargeImage(String nameForLargeImage) {
    this.nameForLargeImage = nameForLargeImage;
  }

  public String getNameForXLargeImage() {
    return nameForXLargeImage;
  }

  public void setNameForXLargeImage(String nameForXLargeImage) {
    this.nameForXLargeImage = nameForXLargeImage;
  }

  public String getUrlForSmallImage() {
    return urlForSmallImage;
  }

  public void setUrlForSmallImage(String urlForSmallImage) {
    this.urlForSmallImage = urlForSmallImage;
  }

  public String getUrlForMediumImage() {
    return urlForMediumImage;
  }

  public void setUrlForMediumImage(String urlForMediumImage) {
    this.urlForMediumImage = urlForMediumImage;
  }

  public String getUrlForLargeImage() {
    return urlForLargeImage;
  }

  public void setUrlForLargeImage(String urlForLargeImage) {
    this.urlForLargeImage = urlForLargeImage;
  }
}
