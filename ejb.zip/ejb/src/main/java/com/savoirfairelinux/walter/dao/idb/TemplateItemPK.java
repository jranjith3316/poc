/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.idb;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author jsgill
 */
@Embeddable
public class TemplateItemPK implements Serializable {
  @Basic(optional = false)
  @NotNull
  @Size(min = 1, max = 255)
  @Column(name = "TEMPLATEGUID")
  private String templateguid;
  @Basic(optional = false)
  @NotNull
  @Column(name = "COLUMN_ID")
  private short columnId;
  @Basic(optional = false)
  @NotNull
  @Column(name = "ROW_ID")
  private short rowId;
  @Basic(optional = false)
  @NotNull
  @Column(name = "ITEM_ID")
  private short itemId;

  public TemplateItemPK() {
  }

  public TemplateItemPK(String templateguid, short columnId, short rowId, short itemId) {
    this.templateguid = templateguid;
    this.columnId = columnId;
    this.rowId = rowId;
    this.itemId = itemId;
  }

  public String getTemplateguid() {
    return templateguid;
  }

  public void setTemplateguid(String templateguid) {
    this.templateguid = templateguid;
  }

  public short getColumnId() {
    return columnId;
  }

  public void setColumnId(short columnId) {
    this.columnId = columnId;
  }

  public short getRowId() {
    return rowId;
  }

  public void setRowId(short rowId) {
    this.rowId = rowId;
  }

  public short getItemId() {
    return itemId;
  }

  public void setItemId(short itemId) {
    this.itemId = itemId;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (templateguid != null ? templateguid.hashCode() : 0);
    hash += (int) columnId;
    hash += (int) rowId;
    hash += (int) itemId;
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof TemplateItemPK)) {
      return false;
    }
    TemplateItemPK other = (TemplateItemPK) object;
    if ((this.templateguid == null && other.templateguid != null) || (this.templateguid != null && !this.templateguid.equals(other.templateguid))) {
      return false;
    }
    if (this.columnId != other.columnId) {
      return false;
    }
    if (this.rowId != other.rowId) {
      return false;
    }
    if (this.itemId != other.itemId) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.idb.TemplateItemPK[ templateguid=" + templateguid + ", columnId=" + columnId + ", rowId=" + rowId + ", itemId=" + itemId + " ]";
  }

}
