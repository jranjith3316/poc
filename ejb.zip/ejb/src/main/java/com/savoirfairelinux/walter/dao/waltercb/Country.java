package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.globalcustomer.GeographicalCoverage;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import com.savoirfairelinux.walter.dao.DatabaseConstants; 
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Set;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "COUNTRY", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Country.findAll", query = "SELECT c FROM Country c ORDER BY c.description"),
    @NamedQuery(name = "Country.findByCountryId", query = "SELECT c FROM Country c WHERE c.countryId = :countryId"),
    @NamedQuery(name = "Country.findByDescription", query = "SELECT c FROM Country c WHERE c.description = :description"),
    @NamedQuery(name = "Country.findByCountryCode", query = "SELECT c FROM Country c WHERE c.countryCode = :countryCode"),
    @NamedQuery(name = "Country.findByCurrCode", query = "SELECT c FROM Country c WHERE c.currCode = :currCode"),
    @NamedQuery(name = "Country.findByMeasureType", query = "SELECT c FROM Country c WHERE c.measureType = :measureType"),
    @NamedQuery(name = "Country.findByPerDiem", query = "SELECT c FROM Country c WHERE c.perDiem = :perDiem"),
    @NamedQuery(name = "Country.findByDistanceUnit", query = "SELECT c FROM Country c WHERE c.distanceUnit = :distanceUnit"),
    @NamedQuery(name = "Country.findByInternetMaxAmt", query = "SELECT c FROM Country c WHERE c.internetMaxAmt = :internetMaxAmt"),
    @NamedQuery(name = "Country.findByAmtPerDistanceUnit", query = "SELECT c FROM Country c WHERE c.amtPerDistanceUnit = :amtPerDistanceUnit"),
    @NamedQuery(name = "Country.findByIsSupplier", query = "SELECT c FROM Country c WHERE c.isSupplier = :isSupplier"),
    @NamedQuery(name = "Country.findByWebsite", query = "SELECT c FROM Country c WHERE c.website = :website"),
    @NamedQuery(name = "Country.findByWebsiteCountry", query = "SELECT c FROM Country c WHERE c.websiteCountry = :websiteCountry")})
public class Country implements Serializable {
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "country")
    private Set<CountryRegion> countryRegionSet;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "country")
    private Set<CountryState> countryStateSet;
    private static final long serialVersionUID = 1L;

    public static final long CANADA_ID = 2;
    public static final long USA_ID = 3;

    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "COUNTRY_ID")
    private Long countryId;
    @Size(max = 24)
    @Column(name = "DESCRIPTION")
    private String description;
    @Size(max = 2)
    @Column(name = "COUNTRY_CODE")
    private String countryCode;
    @Size(max = 5)
    @Column(name = "CURR_CODE")
    private String currCode;
    @Column(name = "MEASURE_TYPE")
    private Short measureType;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "PER_DIEM")
    private BigDecimal perDiem;
    @Size(max = 3)
    @Column(name = "DISTANCE_UNIT")
    private String distanceUnit;
    @Column(name = "INTERNET_MAX_AMT")
    private BigDecimal internetMaxAmt;
    @Column(name = "AMT_PER_DISTANCE_UNIT")
    private BigDecimal amtPerDistanceUnit;
    @Column(name = "IS_SUPPLIER")
    private Character isSupplier;
    @Size(max = 50)
    @Column(name = "WEBSITE")
    private String website;
    @Size(max = 5)
    @Column(name = "WEBSITE_COUNTRY")
    private String websiteCountry;
    @OneToOne(cascade = CascadeType.ALL, mappedBy = "country", fetch = FetchType.LAZY)
    private CountryEmail countryEmail;
    @ManyToOne
    @JoinColumn(name = "GEOGRAPHICAL_COVERAGE", referencedColumnName = "GEOGRAPHICAL_COVERAGE_ID", nullable = false)
    private GeographicalCoverage geographicalCoverage;
    @Column(name = "PER_DIEM_BONUS")
    private BigDecimal perDiemBonus;
    @Column(name = "CURRENCY")
    private String currency;
    @Column(name = "CARE_TECH_PER_DIEM")
    private BigDecimal careTechPerDiem;
    @Column(name = "CARE_TECH_OUT_ZONE")
    private BigDecimal careTechOutZone;
    @Column(name = "CARE_TECH_NEW_MACHINE")
    private BigDecimal careTechNewMachine;
    @Column(name = "CARE_TECH_PER_DIEM_BONUS")
    private BigDecimal careTechPerDiemBonus;

    public Country() {
    }

    public Country(Long countryId) {
        this.countryId = countryId;
    }

    public Long getCountryId() {
        return countryId;
    }

    public void setCountryId(Long countryId) {
        this.countryId = countryId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getCurrCode() {
        return currCode;
    }

    public void setCurrCode(String currCode) {
        this.currCode = currCode;
    }

    public Short getMeasureType() {
        return measureType;
    }

    public void setMeasureType(Short measureType) {
        this.measureType = measureType;
    }

    public BigDecimal getPerDiem() {
        return perDiem;
    }

    public void setPerDiem(BigDecimal perDiem) {
        this.perDiem = perDiem;
    }

    public String getDistanceUnit() {
        return distanceUnit;
    }

    public void setDistanceUnit(String distanceUnit) {
        this.distanceUnit = distanceUnit;
    }

    public BigDecimal getInternetMaxAmt() {
        return internetMaxAmt;
    }

    public void setInternetMaxAmt(BigDecimal internetMaxAmt) {
        this.internetMaxAmt = internetMaxAmt;
    }

    public BigDecimal getAmtPerDistanceUnit() {
        return amtPerDistanceUnit;
    }

    public void setAmtPerDistanceUnit(BigDecimal amtPerDistanceUnit) {
        this.amtPerDistanceUnit = amtPerDistanceUnit;
    }

    public Character getIsSupplier() {
        return isSupplier;
    }

    public void setIsSupplier(Character isSupplier) {
        this.isSupplier = isSupplier;
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public String getWebsiteCountry() {
        return websiteCountry;
    }

    public void setWebsiteCountry(String websiteCountry) {
        this.websiteCountry = websiteCountry;
    }

    public CountryEmail getCountryEmail() {
        return countryEmail;
    }

    public void setCountryEmail(CountryEmail countryEmail) {
        this.countryEmail = countryEmail;
    }

    public GeographicalCoverage getGeographicalCoverage() {
        return geographicalCoverage;
    }

    public void setGeographicalCoverage(GeographicalCoverage geographicalCoverage) {
        this.geographicalCoverage = geographicalCoverage;
    }

    public BigDecimal getPerDiemBonus() {
        return perDiemBonus;
    }

    public void setPerDiemBonus(BigDecimal perDiemBonus) {
        this.perDiemBonus = perDiemBonus;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getDisplayName() {
        return this.description + " (" + currency + ")";
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (countryId != null ? countryId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Country)) {
            return false;
        }
        Country other = (Country) object;
        if ((this.countryId == null && other.countryId != null) || (this.countryId != null && !this.countryId.equals(other.countryId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.Country[ countryId=" + countryId + " ]";
    }

    @XmlTransient
    public Set<CountryRegion> getCountryRegionSet() {
        return countryRegionSet;
    }

    public void setCountryRegionSet(Set<CountryRegion> countryRegionSet) {
        this.countryRegionSet = countryRegionSet;
    }

    @XmlTransient
    public Set<CountryState> getCountryStateSet() {
        return countryStateSet;
    }

    public void setCountryStateSet(Set<CountryState> countryStateSet) {
        this.countryStateSet = countryStateSet;
    }

    public BigDecimal getCareTechPerDiem() {
        return careTechPerDiem;
    }

    public void setCareTechPerDiem(BigDecimal careTechPerDiem) {
        this.careTechPerDiem = careTechPerDiem;
    }

    public BigDecimal getCareTechOutZone() {
        return careTechOutZone;
    }

    public void setCareTechOutZone(BigDecimal careTechOutZone) {
        this.careTechOutZone = careTechOutZone;
    }

    public BigDecimal getCareTechNewMachine() {
        return careTechNewMachine;
    }

    public void setCareTechNewMachine(BigDecimal careTechNewMachine) {
        this.careTechNewMachine = careTechNewMachine;
    }

    public BigDecimal getCareTechPerDiemBonus() {
        return careTechPerDiemBonus;
    }

    public void setCareTechPerDiemBonus(BigDecimal careTechPerDiemBonus) {
        this.careTechPerDiemBonus = careTechPerDiemBonus;
    }

}
