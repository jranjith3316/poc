/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.walter;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "U_LABEL", catalog = "", schema = DatabaseConstants.WALTER_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "ULabel.findAll", query = "SELECT u FROM ULabel u"),
    @NamedQuery(name = "ULabel.findByLabelId", query = "SELECT u FROM ULabel u WHERE u.labelId = :labelId"),
    @NamedQuery(name = "ULabel.findByLabelRef", query = "SELECT u FROM ULabel u WHERE u.labelRef = :labelRef")})
public class ULabel implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "LABEL_ID")
	@GeneratedValue(generator = "labelId_seq", strategy = GenerationType.SEQUENCE)
	@SequenceGenerator(name = "labelId_seq", sequenceName = "LABEL_ID_SEQ", schema="WALTERCB", allocationSize = 1)
    private Long labelId;
    @Size(max = 100)
    @Column(name = "LABEL_REF")
    private String labelRef;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "uLabel")
    private List<ULabelD> uLabelDList;

    public ULabel() {
    }

    public ULabel(Long labelId) {
        this.labelId = labelId;
    }

    public Long getLabelId() {
        return labelId;
    }

    public void setLabelId(Long labelId) {
        this.labelId = labelId;
    }

    public String getLabelRef() {
        return labelRef;
    }

    public void setLabelRef(String labelRef) {
        this.labelRef = labelRef;
    }

    @XmlTransient
    public List<ULabelD> getULabelDList() {
        return uLabelDList;
    }

    public void setULabelDList(List<ULabelD> uLabelDList) {
        this.uLabelDList = uLabelDList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (labelId != null ? labelId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ULabel)) {
            return false;
        }
        ULabel other = (ULabel) object;
        if ((this.labelId == null && other.labelId != null) || (this.labelId != null && !this.labelId.equals(other.labelId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.ULabel[ labelId=" + labelId + " ]";
    }
    
}
