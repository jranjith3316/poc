/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author mgubaidullin
 */
@Embeddable
public class CntProductPK implements Serializable {
    @Basic(optional = false)
    @NotNull
    @Column(name = "CNT_ID")
    private long cntId;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 255)
    @Column(name = "FRANCHISEGUID")
    private String franchiseguid;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "TRADENAMEGUID")
    private String tradenameguid;

    public CntProductPK() {
    }

    public CntProductPK(long cntId, String franchiseguid, String tradenameguid) {
        this.cntId = cntId;
        this.franchiseguid = franchiseguid;
        this.tradenameguid = tradenameguid;
    }

    public long getCntId() {
        return cntId;
    }

    public void setCntId(long cntId) {
        this.cntId = cntId;
    }

    public String getFranchiseguid() {
        return franchiseguid;
    }

    public void setFranchiseguid(String franchiseguid) {
        this.franchiseguid = franchiseguid;
    }

    public String getTradenameguid() {
        return tradenameguid;
    }

    public void setTradenameguid(String tradenameguid) {
        this.tradenameguid = tradenameguid;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) cntId;
        hash += (franchiseguid != null ? franchiseguid.hashCode() : 0);
        hash += (tradenameguid != null ? tradenameguid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CntProductPK)) {
            return false;
        }
        CntProductPK other = (CntProductPK) object;
        if (this.cntId != other.cntId) {
            return false;
        }
        if ((this.franchiseguid == null && other.franchiseguid != null) || (this.franchiseguid != null && !this.franchiseguid.equals(other.franchiseguid))) {
            return false;
        }
        if ((this.tradenameguid == null && other.tradenameguid != null) || (this.tradenameguid != null && !this.tradenameguid.equals(other.tradenameguid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.CntProductPK[ cntId=" + cntId + ", franchiseguid=" + franchiseguid + ", tradenameguid=" + tradenameguid + " ]";
    }
    
}
