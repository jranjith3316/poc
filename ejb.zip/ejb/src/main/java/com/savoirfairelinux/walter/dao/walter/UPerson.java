/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.walter;

import com.savoirfairelinux.walter.dao.DatabaseConstants;
import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "U_PERSON", catalog = "", schema = DatabaseConstants.WALTER_SCHEMA)
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "UPerson.findAll", query = "SELECT u FROM UPerson u"),
  @NamedQuery(name = "UPerson.findBySubscriberId", query = "SELECT u FROM UPerson u WHERE u.uPersonPK.subscriberId = :subscriberId"),
  @NamedQuery(name = "UPerson.findByUserName", query = "SELECT u FROM UPerson u WHERE u.uPersonPK.userName = :userName"),
  @NamedQuery(name = "UPerson.findByUserType", query = "SELECT u FROM UPerson u WHERE u.userType = :userType"),
  @NamedQuery(name = "UPerson.findByCountryId", query = "SELECT u FROM UPerson u WHERE u.countryId = :countryId"),
  @NamedQuery(name = "UPerson.findBySalesrepUserName", query = "SELECT u FROM UPerson u WHERE u.salesrepUserName = :salesrepUserName"),
  @NamedQuery(name = "UPerson.findByTerrCode", query = "SELECT u FROM UPerson u WHERE u.terrCode = :terrCode"),
  @NamedQuery(name = "UPerson.findByHobbies", query = "SELECT u FROM UPerson u WHERE u.hobbies = :hobbies"),
  @NamedQuery(name = "UPerson.findByResponsibilities", query = "SELECT u FROM UPerson u WHERE u.responsibilities = :responsibilities"),
  @NamedQuery(name = "UPerson.findByRecordType", query = "SELECT u FROM UPerson u WHERE u.recordType = :recordType"),
  @NamedQuery(name = "UPerson.findByJobId", query = "SELECT u FROM UPerson u WHERE u.jobId = :jobId"),
  @NamedQuery(name = "UPerson.findByManagerGroupId", query = "SELECT u FROM UPerson u WHERE u.managerGroupId = :managerGroupId"),
  @NamedQuery(name = "UPerson.findByManagerType", query = "SELECT u FROM UPerson u WHERE u.managerType = :managerType"),
  @NamedQuery(name = "UPerson.findByLevelNumber", query = "SELECT u FROM UPerson u WHERE u.levelNumber = :levelNumber"),
  @NamedQuery(name = "UPerson.findByRegionCode", query = "SELECT u FROM UPerson u WHERE u.regionCode = :regionCode"),
  @NamedQuery(name = "UPerson.findByGlDivCode", query = "SELECT u FROM UPerson u WHERE u.glDivCode = :glDivCode"),
  @NamedQuery(name = "UPerson.findByStateCode", query = "SELECT u FROM UPerson u WHERE u.stateCode = :stateCode"),
  @NamedQuery(name = "UPerson.findBySlogixUserid", query = "SELECT u FROM UPerson u WHERE u.slogixUserid = :slogixUserid"),
  @NamedQuery(name = "UPerson.findByExpApprovalUserName", query = "SELECT u FROM UPerson u WHERE u.expApprovalUserName = :expApprovalUserName"),
  @NamedQuery(name = "UPerson.findByContactid", query = "SELECT u FROM UPerson u WHERE u.contactid = :contactid"),
  @NamedQuery(name = "UPerson.findByCompany", query = "SELECT u FROM UPerson u WHERE u.company = :company"),
  @NamedQuery(name = "UPerson.findByCreationMode", query = "SELECT u FROM UPerson u WHERE u.creationMode = :creationMode"),
  @NamedQuery(name = "UPerson.findByManagerUserName", query = "SELECT u FROM UPerson u WHERE u.managerUserName = :managerUserName"),
  @NamedQuery(name = "UPerson.findByAmtPerDistanceUnit", query = "SELECT u FROM UPerson u WHERE u.amtPerDistanceUnit = :amtPerDistanceUnit"),
  @NamedQuery(name = "UPerson.findByBirthdayVisible", query = "SELECT u FROM UPerson u WHERE u.birthdayVisible = :birthdayVisible")})
public class UPerson implements Serializable {

  private static final long serialVersionUID = 1L;
  @EmbeddedId
  protected UPersonPK uPersonPK;
  @Column(name = "USER_TYPE")
  private String userType;
  @Column(name = "COUNTRY_ID")
  private Integer countryId;
  @Size(max = 256)
  @Column(name = "SALESREP_USER_NAME")
  private String salesrepUserName;
  @Size(max = 10)
  @Column(name = "TERR_CODE")
  private String terrCode;
  @Size(max = 100)
  @Column(name = "HOBBIES")
  private String hobbies;
  @Size(max = 250)
  @Column(name = "RESPONSIBILITIES")
  private String responsibilities;
  @Size(max = 6)
  @Column(name = "RECORD_TYPE")
  private String recordType;
  @Size(max = 10)
  @Column(name = "JOB_ID")
  private String jobId;
  @Column(name = "MANAGER_GROUP_ID")
  private BigInteger managerGroupId;
  @Size(max = 5)
  @Column(name = "MANAGER_TYPE")
  private String managerType;
  @Column(name = "LEVEL_NUMBER")
  private Integer levelNumber;
  @Size(max = 10)
  @Column(name = "REGION_CODE")
  private String regionCode;
  @Size(max = 8)
  @Column(name = "GL_DIV_CODE")
  private String glDivCode;
  @Size(max = 5)
  @Column(name = "STATE_CODE")
  private String stateCode;
  @Size(max = 12)
  @Column(name = "SLOGIX_USERID")
  private String slogixUserid;
  @Size(max = 256)
  @Column(name = "EXP_APPROVAL_USER_NAME")
  private String expApprovalUserName;
  @Size(max = 12)
  @Column(name = "CONTACTID")
  private String contactid;
  @Size(max = 50)
  @Column(name = "COMPANY")
  private String company;
  @Column(name = "CREATION_MODE")
  private Integer creationMode;
  // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
  @Column(name = "AMT_PER_DISTANCE_UNIT")
  private BigDecimal amtPerDistanceUnit;
  @Size(max = 500)
  @Column(name = "DEPARTMENT")
  private String department;
  @Column(name = "HIRE_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date hireDate;
  @Size(max = 256)
  @Column(name = "MANAGER_USER_NAME")
  private String managerUserName;
  @Size(max = 1)
  @Column(name = "BIRTHDAY_VISIBLE")
  private String birthdayVisible;
  @Column(name = "GIVEAWAYS_CREDIT")
  private BigDecimal giveawaysCredit;

  public UPerson() {
  }

  public UPerson(UPersonPK uPersonPK) {
    this.uPersonPK = uPersonPK;
  }

  public UPerson(long subscriberId, String userName) {
    this.uPersonPK = new UPersonPK(subscriberId, userName);
  }

  public UPersonPK getUPersonPK() {
    return uPersonPK;
  }

  public void setUPersonPK(UPersonPK uPersonPK) {
    this.uPersonPK = uPersonPK;
  }

  public String getUserType() {
    return userType;
  }

  public void setUserType(String userType) {
    this.userType = userType;
  }

  public Integer getCountryId() {
    return countryId;
  }

  public void setCountryId(Integer countryId) {
    this.countryId = countryId;
  }

  public String getSalesrepUserName() {
    return salesrepUserName;
  }

  public void setSalesrepUserName(String salesrepUserName) {
    this.salesrepUserName = salesrepUserName;
  }

  public String getTerrCode() {
    return terrCode;
  }

  public void setTerrCode(String terrCode) {
    this.terrCode = terrCode;
  }

  public String getHobbies() {
    return hobbies;
  }

  public void setHobbies(String hobbies) {
    this.hobbies = hobbies;
  }

  public String getResponsibilities() {
    return responsibilities;
  }

  public void setResponsibilities(String responsibilities) {
    this.responsibilities = responsibilities;
  }

  public String getRecordType() {
    return recordType;
  }

  public void setRecordType(String recordType) {
    this.recordType = recordType;
  }

  public String getJobId() {
    return jobId;
  }

  public void setJobId(String jobId) {
    this.jobId = jobId;
  }

  public BigInteger getManagerGroupId() {
    return managerGroupId;
  }

  public void setManagerGroupId(BigInteger managerGroupId) {
    this.managerGroupId = managerGroupId;
  }

  public String getManagerType() {
    return managerType;
  }

  public void setManagerType(String managerType) {
    this.managerType = managerType;
  }

  public Integer getLevelNumber() {
    return levelNumber;
  }

  public void setLevelNumber(Integer levelNumber) {
    this.levelNumber = levelNumber;
  }

  public String getRegionCode() {
    return regionCode;
  }

  public void setRegionCode(String regionCode) {
    this.regionCode = regionCode;
  }

  public String getGlDivCode() {
    return glDivCode;
  }

  public void setGlDivCode(String glDivCode) {
    this.glDivCode = glDivCode;
  }

  public String getStateCode() {
    return stateCode;
  }

  public void setStateCode(String stateCode) {
    this.stateCode = stateCode;
  }

  public String getSlogixUserid() {
    return slogixUserid;
  }

  public void setSlogixUserid(String slogixUserid) {
    this.slogixUserid = slogixUserid;
  }

  public String getExpApprovalUserName() {
    return expApprovalUserName;
  }

  public void setExpApprovalUserName(String expApprovalUserName) {
    this.expApprovalUserName = expApprovalUserName;
  }

  public String getContactid() {
    return contactid;
  }

  public void setContactid(String contactid) {
    this.contactid = contactid;
  }

  public String getCompany() {
    return company;
  }

  public void setCompany(String company) {
    this.company = company;
  }

  public Integer getCreationMode() {
    return creationMode;
  }

  public void setCreationMode(Integer creationMode) {
    this.creationMode = creationMode;
  }

  public BigDecimal getAmtPerDistanceUnit() {
    return amtPerDistanceUnit;
  }

  public void setAmtPerDistanceUnit(BigDecimal amtPerDistanceUnit) {
    this.amtPerDistanceUnit = amtPerDistanceUnit;
  }

  public String getDepartment() {
    return department;
  }

  public void setDepartment(String department) {
    this.department = department;
  }

  public Date getHireDate() {
    return hireDate;
  }

  public void setHireDate(Date hireDate) {
    this.hireDate = hireDate;
  }

  public String getManagerUserName() {
    return managerUserName;
  }

  public void setManagerUserName(String managerUserName) {
    this.managerUserName = managerUserName;
  }

  public String getBirthdayVisible() {
    return birthdayVisible;
  }

  public void setBirthdayVisible(String birthdayVisible) {
    this.birthdayVisible = birthdayVisible;
  }

  public BigDecimal getGiveawaysCredit() {
    return giveawaysCredit;
  }

  public void setGiveawaysCredit(BigDecimal giveawaysCredit) {
    this.giveawaysCredit = giveawaysCredit;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (uPersonPK != null ? uPersonPK.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof UPerson)) {
      return false;
    }
    UPerson other = (UPerson) object;
    if ((this.uPersonPK == null && other.uPersonPK != null) || (this.uPersonPK != null && !this.uPersonPK.equals(other.uPersonPK))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.UPerson[ uPersonPK=" + uPersonPK + " ]";
  }

}
