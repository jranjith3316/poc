/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import java.math.BigInteger;
import java.util.Set;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "CNT_PICTURE", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CntPicture.findAll", query = "SELECT c FROM CntPicture c"),
    @NamedQuery(name = "CntPicture.findByPictureId", query = "SELECT c FROM CntPicture c WHERE c.pictureId = :pictureId"),
    @NamedQuery(name = "CntPicture.findByExtVisible", query = "SELECT c FROM CntPicture c WHERE c.extVisible = :extVisible"),
    @NamedQuery(name = "CntPicture.findByOriginalPicture", query = "SELECT c FROM CntPicture c WHERE c.originalPicture = :originalPicture"),
    @NamedQuery(name = "CntPicture.findByRealFilename", query = "SELECT c FROM CntPicture c WHERE c.realFilename = :realFilename"),
    @NamedQuery(name = "CntPicture.findByMimeType", query = "SELECT c FROM CntPicture c WHERE c.mimeType = :mimeType"),
    @NamedQuery(name = "CntPicture.findByDocSize", query = "SELECT c FROM CntPicture c WHERE c.docSize = :docSize"),
    @NamedQuery(name = "CntPicture.findByType", query = "SELECT c FROM CntPicture c WHERE c.type = :type")})
public class CntPicture implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "PICTURE_ID")
	@GeneratedValue(generator = "CNT_PICTURE_SEQ", strategy = GenerationType.SEQUENCE)
	@SequenceGenerator(name = "CNT_PICTURE_SEQ", sequenceName = "CNT_PICTURE_SEQ", schema = DatabaseConstants.WALTERCB_SCHEMA, allocationSize = 1)
    private Long pictureId;
    @Column(name = "EXT_VISIBLE")
    private Character extVisible;
    @Column(name = "ORIGINAL_PICTURE")
    private Character originalPicture;
    @Size(max = 350)
    @Column(name = "REAL_FILENAME")
    private String realFilename;
    @Size(max = 48)
    @Column(name = "MIME_TYPE")
    private String mimeType;
    @Column(name = "DOC_SIZE")
    private BigInteger docSize;
    @Lob
    @Column(name = "BLOB_CONTENT")
    private byte[] blobContent;
    @Size(max = 1)
    private String type;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "cntPicture", fetch = FetchType.EAGER)
    private Set<CntPictureTxt> cntPictureTxtSet;
    @JoinColumn(name = "CNT_ID", referencedColumnName = "CNT_ID")
    @ManyToOne
    private Cnt cnt;

    public CntPicture() {
    }

    public CntPicture(Long pictureId) {
        this.pictureId = pictureId;
    }

    public Long getPictureId() {
        return pictureId;
    }

    public void setPictureId(Long pictureId) {
        this.pictureId = pictureId;
    }

    public Character getExtVisible() {
        return extVisible;
    }

    public void setExtVisible(Character extVisible) {
        this.extVisible = extVisible;
    }

    public Character getOriginalPicture() {
        return originalPicture;
    }

    public void setOriginalPicture(Character originalPicture) {
        this.originalPicture = originalPicture;
    }

    public String getRealFilename() {
        return realFilename;
    }

    public void setRealFilename(String realFilename) {
        this.realFilename = realFilename;
    }

    public String getMimeType() {
        return mimeType;
    }

    public void setMimeType(String mimeType) {
        this.mimeType = mimeType;
    }

    public BigInteger getDocSize() {
        return docSize;
    }

    public void setDocSize(BigInteger docSize) {
        this.docSize = docSize;
    }

    public  byte[] getBlobContent() {
        return blobContent;
    }

    public void setBlobContent( byte[] blobContent) {
        this.blobContent = blobContent;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @XmlTransient
    public Set<CntPictureTxt> getCntPictureTxtSet() {
        return cntPictureTxtSet;
    }

    public void setCntPictureTxtSet(Set<CntPictureTxt> cntPictureTxtSet) {
        this.cntPictureTxtSet = cntPictureTxtSet;
    }

    public Cnt getCnt() {
        return cnt;
    }

    public void setCnt(Cnt cnt) {
        this.cnt = cnt;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (pictureId != null ? pictureId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof CntPicture)) {
            return false;
        }
        CntPicture other = (CntPicture) object;
        if (this.pictureId == null && other.pictureId == null) {
        	return this == other;
        } else if ((this.pictureId == null && other.pictureId != null) || (this.pictureId != null && !this.pictureId.equals(other.pictureId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.CntPicture[ pictureId=" + pictureId + " ]";
    }
}
