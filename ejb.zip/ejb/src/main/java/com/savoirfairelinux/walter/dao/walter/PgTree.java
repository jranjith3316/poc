/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.walter;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import java.util.Date;
import java.util.Set;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "PG_TREE", catalog = "", schema = DatabaseConstants.WALTER_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "PgTree.findAll", query = "SELECT p FROM PgTree p"),
    @NamedQuery(name = "PgTree.findByPgTreeCode", query = "SELECT p FROM PgTree p WHERE p.pgTreeCode = :pgTreeCode"),
    @NamedQuery(name = "PgTree.findByPgTreeName", query = "SELECT p FROM PgTree p WHERE p.pgTreeName = :pgTreeName"),
    @NamedQuery(name = "PgTree.findByPublishDate", query = "SELECT p FROM PgTree p WHERE p.publishDate = :publishDate")})
public class PgTree implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "PG_TREE_CODE", nullable = false, length = 10)
    private String pgTreeCode;
    @Size(max = 50)
    @Column(name = "PG_TREE_NAME", length = 50)
    private String pgTreeName;
    @Column(name = "PUBLISH_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date publishDate;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "pgTree")
    private Set<PgTreeItem> pgTreeItemSet;

    public PgTree() {
    }

    public PgTree(String pgTreeCode) {
        this.pgTreeCode = pgTreeCode;
    }

    public String getPgTreeCode() {
        return pgTreeCode;
    }

    public void setPgTreeCode(String pgTreeCode) {
        this.pgTreeCode = pgTreeCode;
    }

    public String getPgTreeName() {
        return pgTreeName;
    }

    public void setPgTreeName(String pgTreeName) {
        this.pgTreeName = pgTreeName;
    }

    public Date getPublishDate() {
        return publishDate;
    }

    public void setPublishDate(Date publishDate) {
        this.publishDate = publishDate;
    }

    @XmlTransient
    public Set<PgTreeItem> getPgTreeItemSet() {
        return pgTreeItemSet;
    }

    public void setPgTreeItemSet(Set<PgTreeItem> pgTreeItemSet) {
        this.pgTreeItemSet = pgTreeItemSet;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (pgTreeCode != null ? pgTreeCode.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PgTree)) {
            return false;
        }
        PgTree other = (PgTree) object;
        if ((this.pgTreeCode == null && other.pgTreeCode != null) || (this.pgTreeCode != null && !this.pgTreeCode.equals(other.pgTreeCode))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.walter.PgTree[ pgTreeCode=" + pgTreeCode + " ]";
    }
    
}
