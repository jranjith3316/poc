/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Set;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Idea.findAll", query = "SELECT i FROM Idea i"),
    @NamedQuery(name = "Idea.findByIdeaId", query = "SELECT i FROM Idea i WHERE i.ideaId = :ideaId"),
    @NamedQuery(name = "Idea.findByIdeaRef", query = "SELECT i FROM Idea i WHERE i.ideaRef = :ideaRef"),
    @NamedQuery(name = "Idea.findByProductline", query = "SELECT i FROM Idea i WHERE i.productline = :productline"),
    @NamedQuery(name = "Idea.findByTradename", query = "SELECT i FROM Idea i WHERE i.tradename = :tradename"),
    @NamedQuery(name = "Idea.findByCreatedDate", query = "SELECT i FROM Idea i WHERE i.createdDate = :createdDate"),
    @NamedQuery(name = "Idea.findBySubmitedDate", query = "SELECT i FROM Idea i WHERE i.submitedDate = :submitedDate"),
    @NamedQuery(name = "Idea.findByTranslatedDate", query = "SELECT i FROM Idea i WHERE i.translatedDate = :translatedDate"),
    @NamedQuery(name = "Idea.findByPublishedDate", query = "SELECT i FROM Idea i WHERE i.publishedDate = :publishedDate"),
    @NamedQuery(name = "Idea.findByArchivedDate", query = "SELECT i FROM Idea i WHERE i.archivedDate = :archivedDate"),
    @NamedQuery(name = "Idea.findByInvalidatedDate", query = "SELECT i FROM Idea i WHERE i.invalidatedDate = :invalidatedDate"),
    @NamedQuery(name = "Idea.findByCreatorUserName", query = "SELECT i FROM Idea i WHERE i.creatorUserName = :creatorUserName"),
    @NamedQuery(name = "Idea.findByOriginalLangId", query = "SELECT i FROM Idea i WHERE i.originalLangId = :originalLangId"),
    @NamedQuery(name = "Idea.findByIdeaStatusId", query = "SELECT i FROM Idea i WHERE i.ideaStatusId = :ideaStatusId"),
    @NamedQuery(name = "Idea.findByInvalidatedComment", query = "SELECT i FROM Idea i WHERE i.invalidatedComment = :invalidatedComment"),
    @NamedQuery(name = "Idea.findByArchivedUserName", query = "SELECT i FROM Idea i WHERE i.archivedUserName = :archivedUserName"),
    @NamedQuery(name = "Idea.findByCancelDate", query = "SELECT i FROM Idea i WHERE i.cancelDate = :cancelDate"),
    @NamedQuery(name = "Idea.findByConsideredBy", query = "SELECT i FROM Idea i WHERE i.consideredBy = :consideredBy"),
    @NamedQuery(name = "Idea.findByConsideredDate", query = "SELECT i FROM Idea i WHERE i.consideredDate = :consideredDate"),
    @NamedQuery(name = "Idea.findByDevelopmentBy", query = "SELECT i FROM Idea i WHERE i.developmentBy = :developmentBy"),
    @NamedQuery(name = "Idea.findByDevelopmentDate", query = "SELECT i FROM Idea i WHERE i.developmentDate = :developmentDate"),
    @NamedQuery(name = "Idea.findByLaunchedBy", query = "SELECT i FROM Idea i WHERE i.launchedBy = :launchedBy"),
    @NamedQuery(name = "Idea.findByLaunchedDate", query = "SELECT i FROM Idea i WHERE i.launchedDate = :launchedDate"),
    @NamedQuery(name = "Idea.findByPmUserName", query = "SELECT i FROM Idea i WHERE i.pmUserName = :pmUserName"),
    @NamedQuery(name = "Idea.findByCategoryId", query = "SELECT i FROM Idea i WHERE i.categoryId = :categoryId")})
public class Idea implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "IDEA_ID")
    @GeneratedValue(generator = "IDEA_ID_SEQ", strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "IDEA_ID_SEQ", sequenceName = "IDEA_ID_SEQ", schema = DatabaseConstants.WALTERCB_SCHEMA, allocationSize = 1)
    private Long ideaId;
    @Size(max = 15)
    @Column(name = "IDEA_REF")
    private String ideaRef;
    @Size(max = 255)
    private String productline;
    @Size(max = 255)
    private String tradename;
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;
    @Column(name = "SUBMITED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date submitedDate;
    @Column(name = "TRANSLATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date translatedDate;
    @Column(name = "PUBLISHED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date publishedDate;
    @Column(name = "ARCHIVED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date archivedDate;
    @Column(name = "INVALIDATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date invalidatedDate;
    @Size(max = 256)
    @Column(name = "CREATOR_USER_NAME")
    private String creatorUserName;
    @Column(name = "ORIGINAL_LANG_ID")
    private Long originalLangId;
    @Column(name = "IDEA_STATUS_ID")
    private Integer ideaStatusId;
    @Size(max = 255)
    @Column(name = "INVALIDATED_COMMENT")
    private String invalidatedComment;
    @Size(max = 256)
    @Column(name = "ARCHIVED_USER_NAME")
    private String archivedUserName;
    @Column(name = "CANCEL_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date cancelDate;
    @Size(max = 256)
    @Column(name = "CONSIDERED_BY")
    private String consideredBy;
    @Column(name = "CONSIDERED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date consideredDate;
    @Size(max = 256)
    @Column(name = "DEVELOPMENT_BY")
    private String developmentBy;
    @Column(name = "DEVELOPMENT_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date developmentDate;
    @Size(max = 256)
    @Column(name = "LAUNCHED_BY")
    private String launchedBy;
    @Column(name = "LAUNCHED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date launchedDate;
    @Size(max = 256)
    @Column(name = "PM_USER_NAME")
    private String pmUserName;
    @Column(name = "CATEGORY_ID")
    private Long categoryId;
    @Column(name = "IMAGE_ATTACHED")
    private Integer imageAttached;
    @Column(name = "FILE_ATTACHED")
    private Integer fileAttached;
    @Size(max = 200)
    @Column(name = "ORGANIZATION")
    private String organization;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idea")
    private Set<IdeaTranslate> ideaTranslateSet;
    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true, mappedBy = "idea")
    private Set<IdeaTxt> ideaTxtSet;
    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true, mappedBy = "idea")
    private List<IdeaFile> ideaFileSet;
    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true, mappedBy = "idea")
    private Set<IdeaCounter> ideaCounterSet;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idea")
    private List<IdeaFeedback> ideaFeedbackList;
    @Transient
    private String description;
    @Transient
    private String title;
    @Transient
    private String category;
    @Transient
    private String productName;
    @Transient
    private String status;
    @Transient
    private String comment;
    @Transient
    private Long counter = 1l;

    public Idea() {
    }

    public Idea(Long ideaId) {
        this.ideaId = ideaId;
    }

    public Long getIdeaId() {
        return ideaId;
    }

    public void setIdeaId(Long ideaId) {
        this.ideaId = ideaId;
    }

    public String getIdeaRef() {
        return ideaRef;
    }

    public void setIdeaRef(String ideaRef) {
        this.ideaRef = ideaRef;
    }

    public String getProductline() {
        return productline;
    }

    public void setProductline(String productline) {
        this.productline = productline;
    }

    public String getTradename() {
        return tradename;
    }

    public void setTradename(String tradename) {
        this.tradename = tradename;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Date getSubmitedDate() {
        return submitedDate;
    }

    public void setSubmitedDate(Date submitedDate) {
        this.submitedDate = submitedDate;
    }

    public Date getTranslatedDate() {
        return translatedDate;
    }

    public void setTranslatedDate(Date translatedDate) {
        this.translatedDate = translatedDate;
    }

    public Date getPublishedDate() {
        return publishedDate;
    }

    public void setPublishedDate(Date publishedDate) {
        this.publishedDate = publishedDate;
    }

    public Date getArchivedDate() {
        return archivedDate;
    }

    public void setArchivedDate(Date archivedDate) {
        this.archivedDate = archivedDate;
    }

    public Date getInvalidatedDate() {
        return invalidatedDate;
    }

    public void setInvalidatedDate(Date invalidatedDate) {
        this.invalidatedDate = invalidatedDate;
    }

    public String getCreatorUserName() {
        return creatorUserName;
    }

    public void setCreatorUserName(String creatorUserName) {
        this.creatorUserName = creatorUserName;
    }

    public Long getOriginalLangId() {
        return originalLangId;
    }

    public void setOriginalLangId(Long originalLangId) {
        this.originalLangId = originalLangId;
    }

    public Integer getIdeaStatusId() {
        return ideaStatusId;
    }

    public void setIdeaStatusId(Integer ideaStatusId) {
        this.ideaStatusId = ideaStatusId;
    }

    public String getInvalidatedComment() {
        return invalidatedComment;
    }

    public void setInvalidatedComment(String invalidatedComment) {
        this.invalidatedComment = invalidatedComment;
    }

    public String getArchivedUserName() {
        return archivedUserName;
    }

    public void setArchivedUserName(String archivedUserName) {
        this.archivedUserName = archivedUserName;
    }

    public Date getCancelDate() {
        return cancelDate;
    }

    public void setCancelDate(Date cancelDate) {
        this.cancelDate = cancelDate;
    }

    public String getConsideredBy() {
        return consideredBy;
    }

    public void setConsideredBy(String consideredBy) {
        this.consideredBy = consideredBy;
    }

    public Date getConsideredDate() {
        return consideredDate;
    }

    public void setConsideredDate(Date consideredDate) {
        this.consideredDate = consideredDate;
    }

    public String getDevelopmentBy() {
        return developmentBy;
    }

    public void setDevelopmentBy(String developmentBy) {
        this.developmentBy = developmentBy;
    }

    public Date getDevelopmentDate() {
        return developmentDate;
    }

    public void setDevelopmentDate(Date developmentDate) {
        this.developmentDate = developmentDate;
    }

    public String getLaunchedBy() {
        return launchedBy;
    }

    public void setLaunchedBy(String launchedBy) {
        this.launchedBy = launchedBy;
    }

    public Date getLaunchedDate() {
        return launchedDate;
    }

    public void setLaunchedDate(Date launchedDate) {
        this.launchedDate = launchedDate;
    }

    public String getPmUserName() {
        return pmUserName;
    }

    public void setPmUserName(String pmUserName) {
        this.pmUserName = pmUserName;
    }

    public Long getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Long categoryId) {
        this.categoryId = categoryId;
    }

    public String getOrganization() {
        return organization;
    }

    public void setOrganization(String organization) {
        this.organization = organization;
    }

    @XmlTransient
    public Set<IdeaTranslate> getIdeaTranslateSet() {
        return ideaTranslateSet;
    }

    public void setIdeaTranslateSet(Set<IdeaTranslate> ideaTranslateSet) {
        this.ideaTranslateSet = ideaTranslateSet;
    }

    @XmlTransient
    public Set<IdeaTxt> getIdeaTxtSet() {
        return ideaTxtSet;
    }

    public void setIdeaTxtSet(Set<IdeaTxt> ideaTxtSet) {
        this.ideaTxtSet = ideaTxtSet;
    }

    @XmlTransient
    public List<IdeaFile> getIdeaFileSet() {
        return ideaFileSet;
    }

    public void setIdeaFileSet(List<IdeaFile> ideaFileSet) {
        this.ideaFileSet = ideaFileSet;
    }

    @XmlTransient
    public Set<IdeaCounter> getIdeaCounterSet() {
        return ideaCounterSet;
    }

    public void setIdeaCounterSet(Set<IdeaCounter> ideaCounterSet) {
        this.ideaCounterSet = ideaCounterSet;
    }

    public List<IdeaFeedback> getIdeaFeedbackList() {
        return ideaFeedbackList;
    }

    public void setIdeaFeedbackList(List<IdeaFeedback> ideaFeedbackList) {
        this.ideaFeedbackList = ideaFeedbackList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (ideaId != null ? ideaId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Idea)) {
            return false;
        }
        Idea other = (Idea) object;
        if ((this.ideaId == null && other.ideaId != null) || (this.ideaId != null && !this.ideaId.equals(other.ideaId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.Idea[ ideaId=" + ideaId + " ]";
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public Long getCounter() {
        return counter;
    }

    public void setCounter(Long counter) {
        this.counter = counter;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public Integer getImageAttached() {
        return imageAttached;
    }

    public void setImageAttached(Integer imageAttached) {
        this.imageAttached = imageAttached;
    }

    public Integer getFileAttached() {
        return fileAttached;
    }

    public void setFileAttached(Integer fileAttached) {
        this.fileAttached = fileAttached;
    }

    /**
     * Get IdeaTxt, try user language, fallback to english
     *
     * @param dbLanguageId
     * @return the idea txt
     */
    public IdeaTxt getIdeaTxt(Long dbLanguageId) {
        IdeaTxt ideaEn = null;
        IdeaTxt ideaTxt = null;
        for (IdeaTxt txt : this.getIdeaTxtSet()) {
            if (txt.getIdeaTxtPK().getLangId() == dbLanguageId) {
                ideaTxt = txt;
                break;
            }
            if (txt.getIdeaTxtPK().getLangId() == ULang.ENGLISH_ID) {
                ideaEn = txt;
            }
        }
        if (ideaTxt == null) {
            ideaTxt = ideaEn;
        }
        return ideaTxt;
    }
}
