/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.walterproductivity;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;
import java.util.Set;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "REPORTS", catalog = "", schema = "WALTERPRODUCTIVITY")
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "Reports.findAll", query = "SELECT r FROM Reports r"),
  @NamedQuery(name = "Reports.findById", query = "SELECT r FROM Reports r WHERE r.id = :id"),
  @NamedQuery(name = "Reports.findByCreationDate", query = "SELECT r FROM Reports r WHERE r.creationDate = :creationDate"),
  @NamedQuery(name = "Reports.findByDeviceId", query = "SELECT r FROM Reports r WHERE r.deviceId = :deviceId"),
  @NamedQuery(name = "Reports.findByUpdateDate", query = "SELECT r FROM Reports r WHERE r.updateDate = :updateDate"),
  @NamedQuery(name = "Reports.findByUserId", query = "SELECT r FROM Reports r WHERE r.userId = :userId"),
  @NamedQuery(name = "Reports.findByApplicationId", query = "SELECT r FROM Reports r WHERE r.applicationId = :applicationId"),
  @NamedQuery(name = "Reports.findByCom", query = "SELECT r FROM Reports r WHERE r.com = :com"),
  @NamedQuery(name = "Reports.findByComBackingNumber", query = "SELECT r FROM Reports r WHERE r.comBackingNumber = :comBackingNumber"),
  @NamedQuery(name = "Reports.findByComBackingPadPrice", query = "SELECT r FROM Reports r WHERE r.comBackingPadPrice = :comBackingPadPrice"),
  @NamedQuery(name = "Reports.findByComDiameter", query = "SELECT r FROM Reports r WHERE r.comDiameter = :comDiameter"),
  @NamedQuery(name = "Reports.findByComEndUserPrice", query = "SELECT r FROM Reports r WHERE r.comEndUserPrice = :comEndUserPrice"),
  @NamedQuery(name = "Reports.findByComGrit", query = "SELECT r FROM Reports r WHERE r.comGrit = :comGrit"),
  @NamedQuery(name = "Reports.findByComNumberOfYears", query = "SELECT r FROM Reports r WHERE r.comNumberOfYears = :comNumberOfYears"),
  @NamedQuery(name = "Reports.findByComOtherPowerTools", query = "SELECT r FROM Reports r WHERE r.comOtherPowerTools = :comOtherPowerTools"),
  @NamedQuery(name = "Reports.findByComPowerTools", query = "SELECT r FROM Reports r WHERE r.comPowerTools = :comPowerTools"),
  @NamedQuery(name = "Reports.findByComProductName", query = "SELECT r FROM Reports r WHERE r.comProductName = :comProductName"),
  @NamedQuery(name = "Reports.findByComProductNumber", query = "SELECT r FROM Reports r WHERE r.comProductNumber = :comProductNumber"),
  @NamedQuery(name = "Reports.findByComQuantityBackingPerYear", query = "SELECT r FROM Reports r WHERE r.comQuantityBackingPerYear = :comQuantityBackingPerYear"),
  @NamedQuery(name = "Reports.findByComQuantityDiscPerYear", query = "SELECT r FROM Reports r WHERE r.comQuantityDiscPerYear = :comQuantityDiscPerYear"),
  @NamedQuery(name = "Reports.findByContactAddress1", query = "SELECT r FROM Reports r WHERE r.contactAddress1 = :contactAddress1"),
  @NamedQuery(name = "Reports.findByContactAddress2", query = "SELECT r FROM Reports r WHERE r.contactAddress2 = :contactAddress2"),
  @NamedQuery(name = "Reports.findByContactCity", query = "SELECT r FROM Reports r WHERE r.contactCity = :contactCity"),
  @NamedQuery(name = "Reports.findByContactCountry", query = "SELECT r FROM Reports r WHERE r.contactCountry = :contactCountry"),
  @NamedQuery(name = "Reports.findByContactEmail", query = "SELECT r FROM Reports r WHERE r.contactEmail = :contactEmail"),
  @NamedQuery(name = "Reports.findByContactEnterprise", query = "SELECT r FROM Reports r WHERE r.contactEnterprise = :contactEnterprise"),
  @NamedQuery(name = "Reports.findByContactName", query = "SELECT r FROM Reports r WHERE r.contactName = :contactName"),
  @NamedQuery(name = "Reports.findByContactZip", query = "SELECT r FROM Reports r WHERE r.contactZip = :contactZip"),
  @NamedQuery(name = "Reports.findByMailCopies", query = "SELECT r FROM Reports r WHERE r.mailCopies = :mailCopies"),
  @NamedQuery(name = "Reports.findByMailRecipients", query = "SELECT r FROM Reports r WHERE r.mailRecipients = :mailRecipients"),
  @NamedQuery(name = "Reports.findByMailSubject", query = "SELECT r FROM Reports r WHERE r.mailSubject = :mailSubject"),
  @NamedQuery(name = "Reports.findByMaterialId", query = "SELECT r FROM Reports r WHERE r.materialId = :materialId"),
  @NamedQuery(name = "Reports.findByName", query = "SELECT r FROM Reports r WHERE r.name = :name"),
  @NamedQuery(name = "Reports.findByResellerCompagny", query = "SELECT r FROM Reports r WHERE r.resellerCompagny = :resellerCompagny"),
  @NamedQuery(name = "Reports.findByResellerContact", query = "SELECT r FROM Reports r WHERE r.resellerContact = :resellerContact"),
  @NamedQuery(name = "Reports.findBySaleGenerated", query = "SELECT r FROM Reports r WHERE r.saleGenerated = :saleGenerated"),
  @NamedQuery(name = "Reports.findByShopRate", query = "SELECT r FROM Reports r WHERE r.shopRate = :shopRate"),
  @NamedQuery(name = "Reports.findByStatus", query = "SELECT r FROM Reports r WHERE r.status = :status"),
  @NamedQuery(name = "Reports.findByTimePerDiscChangeover", query = "SELECT r FROM Reports r WHERE r.timePerDiscChangeover = :timePerDiscChangeover"),
  @NamedQuery(name = "Reports.findByUserScreenName", query = "SELECT r FROM Reports r WHERE r.userScreenName = :userScreenName"),
  @NamedQuery(name = "Reports.findByWalEndUserPrice", query = "SELECT r FROM Reports r WHERE r.walEndUserPrice = :walEndUserPrice"),
  @NamedQuery(name = "Reports.findByWalOtherPowerTools", query = "SELECT r FROM Reports r WHERE r.walOtherPowerTools = :walOtherPowerTools"),
  @NamedQuery(name = "Reports.findByWalPowerTools", query = "SELECT r FROM Reports r WHERE r.walPowerTools = :walPowerTools"),
  @NamedQuery(name = "Reports.findByWalProductId", query = "SELECT r FROM Reports r WHERE r.walProductId = :walProductId")})
public class Reports implements Serializable {
  @Column(name = "COM_AVG_TIME_PIECE")
  private Double comAvgTimePiece;
  @Column(name = "COM_DISTANCE")
  private Double comDistance;
  @Column(name = "COM_NB_PIECES")
  private Long comNbPieces;
  @Column(name = "COM_TOTAL_TIME")
  private Double comTotalTime;
  @Size(max = 255)
  @Column(name = "METHOD_ID")
  private String methodId;
  @Column(name = "WAL_AVG_TIME_PIECE")
  private Double walAvgTimePiece;
  @Column(name = "WAL_DISTANCE")
  private Double walDistance;
  @Column(name = "WAL_NB_PIECES")
  private Long walNbPieces;
  @Column(name = "WAL_TOTAL_TIME")
  private Double walTotalTime;
  @Size(max = 255)
  @Column(name = "COM_GRIT")
  private String comGrit;
  private static final long serialVersionUID = 1L;
  @Id
  @Basic(optional = false)
  @NotNull
  @Size(min = 1, max = 255)
  @Column(name = "ID")
  private String id;
  @Column(name = "CREATION_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date creationDate;
  @Size(max = 255)
  @Column(name = "DEVICE_ID")
  private String deviceId;
  @Column(name = "UPDATE_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date updateDate;
  @Column(name = "USER_ID")
  private BigInteger userId;
  @Size(max = 255)
  @Column(name = "APPLICATION_ID")
  private String applicationId;
  @Size(max = 255)
  @Column(name = "COM")
  private String com;
  @Size(max = 255)
  @Column(name = "COM_BACKING_NUMBER")
  private String comBackingNumber;
  // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
  @Column(name = "COM_BACKING_PAD_PRICE")
  private Double comBackingPadPrice;
  @Column(name = "COM_DIAMETER")
  private Double comDiameter;
  @Column(name = "COM_END_USER_PRICE")
  private Double comEndUserPrice;
  @Column(name = "COM_NUMBER_OF_YEARS")
  private Long comNumberOfYears;
  @Size(max = 255)
  @Column(name = "COM_OTHER_POWER_TOOLS")
  private String comOtherPowerTools;
  @Size(max = 255)
  @Column(name = "COM_POWER_TOOLS")
  private String comPowerTools;
  @Size(max = 255)
  @Column(name = "COM_PRODUCT_NAME")
  private String comProductName;
  @Size(max = 255)
  @Column(name = "COM_PRODUCT_NUMBER")
  private String comProductNumber;
  @Column(name = "COM_QUANTITY_BACKING_PER_YEAR")
  private Long comQuantityBackingPerYear;
  @Column(name = "COM_QUANTITY_DISC_PER_YEAR")
  private Long comQuantityDiscPerYear;
  @Size(max = 255)
  @Column(name = "CONTACT_ADDRESS1")
  private String contactAddress1;
  @Size(max = 255)
  @Column(name = "CONTACT_ADDRESS2")
  private String contactAddress2;
  @Size(max = 255)
  @Column(name = "CONTACT_CITY")
  private String contactCity;
  @Size(max = 255)
  @Column(name = "CONTACT_COUNTRY")
  private String contactCountry;
  @Size(max = 255)
  @Column(name = "CONTACT_EMAIL")
  private String contactEmail;
  @Size(max = 255)
  @Column(name = "CONTACT_ENTERPRISE")
  private String contactEnterprise;
  @Size(max = 255)
  @Column(name = "CONTACT_NAME")
  private String contactName;
  @Size(max = 255)
  @Column(name = "CONTACT_ZIP")
  private String contactZip;
  @Lob
  @Column(name = "MAIL_BODY")
  private String mailBody;
  @Size(max = 255)
  @Column(name = "MAIL_COPIES")
  private String mailCopies;
  @Size(max = 255)
  @Column(name = "MAIL_RECIPIENTS")
  private String mailRecipients;
  @Size(max = 255)
  @Column(name = "MAIL_SUBJECT")
  private String mailSubject;
  @Size(max = 255)
  @Column(name = "MATERIAL_ID")
  private String materialId;
  @Size(max = 255)
  @Column(name = "NAME")
  private String name;
  @Size(max = 255)
  @Column(name = "RESELLER_COMPAGNY")
  private String resellerCompagny;
  @Size(max = 255)
  @Column(name = "RESELLER_CONTACT")
  private String resellerContact;
  @Column(name = "SALE_GENERATED")
  private Short saleGenerated;
  @Column(name = "SHOP_RATE")
  private Double shopRate;
  @Basic(optional = false)
  @NotNull
  @Size(min = 1, max = 255)
  @Column(name = "STATUS")
  private String status;
  @Column(name = "TIME_PER_DISC_CHANGEOVER")
  private Long timePerDiscChangeover;
  @Size(max = 255)
  @Column(name = "USER_SCREEN_NAME")
  private String userScreenName;
  @Column(name = "WAL_END_USER_PRICE")
  private Double walEndUserPrice;
  @Size(max = 255)
  @Column(name = "WAL_OTHER_POWER_TOOLS")
  private String walOtherPowerTools;
  @Size(max = 255)
  @Column(name = "WAL_POWER_TOOLS")
  private String walPowerTools;
  @Size(max = 255)
  @Column(name = "WAL_PRODUCT_ID")
  private String walProductId;
  @OneToOne(mappedBy = "reportId")
  private ReportsLostsavings reportsLostsavings;
  @OneToMany(mappedBy = "reportId")
  private Set<Orders> ordersSet;
  @OneToOne(mappedBy = "reportId")
  private ReportsProductivity reportsProductivity;
  @OneToOne(mappedBy = "reportId")
  private ReportsReimbursement reportsReimbursement;

  public Reports() {
  }

  public Reports(String id) {
    this.id = id;
  }

  public Reports(String id, String status) {
    this.id = id;
    this.status = status;
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public Date getCreationDate() {
    return creationDate;
  }

  public void setCreationDate(Date creationDate) {
    this.creationDate = creationDate;
  }

  public String getDeviceId() {
    return deviceId;
  }

  public void setDeviceId(String deviceId) {
    this.deviceId = deviceId;
  }

  public Date getUpdateDate() {
    return updateDate;
  }

  public void setUpdateDate(Date updateDate) {
    this.updateDate = updateDate;
  }

  public BigInteger getUserId() {
    return userId;
  }

  public void setUserId(BigInteger userId) {
    this.userId = userId;
  }

  public String getApplicationId() {
    return applicationId;
  }

  public void setApplicationId(String applicationId) {
    this.applicationId = applicationId;
  }

  public String getCom() {
    return com;
  }

  public void setCom(String com) {
    this.com = com;
  }

  public String getComBackingNumber() {
    return comBackingNumber;
  }

  public void setComBackingNumber(String comBackingNumber) {
    this.comBackingNumber = comBackingNumber;
  }

  public Double getComBackingPadPrice() {
    return comBackingPadPrice;
  }

  public void setComBackingPadPrice(Double comBackingPadPrice) {
    this.comBackingPadPrice = comBackingPadPrice;
  }

  public Double getComDiameter() {
    return comDiameter;
  }

  public void setComDiameter(Double comDiameter) {
    this.comDiameter = comDiameter;
  }

  public Double getComEndUserPrice() {
    return comEndUserPrice;
  }

  public void setComEndUserPrice(Double comEndUserPrice) {
    this.comEndUserPrice = comEndUserPrice;
  }

  public String getComGrit() {
    return comGrit;
  }

  public void setComGrit(String comGrit) {
    this.comGrit = comGrit;
  }

  public Long getComNumberOfYears() {
    return comNumberOfYears;
  }

  public void setComNumberOfYears(Long comNumberOfYears) {
    this.comNumberOfYears = comNumberOfYears;
  }

  public String getComOtherPowerTools() {
    return comOtherPowerTools;
  }

  public void setComOtherPowerTools(String comOtherPowerTools) {
    this.comOtherPowerTools = comOtherPowerTools;
  }

  public String getComPowerTools() {
    return comPowerTools;
  }

  public void setComPowerTools(String comPowerTools) {
    this.comPowerTools = comPowerTools;
  }

  public String getComProductName() {
    return comProductName;
  }

  public void setComProductName(String comProductName) {
    this.comProductName = comProductName;
  }

  public String getComProductNumber() {
    return comProductNumber;
  }

  public void setComProductNumber(String comProductNumber) {
    this.comProductNumber = comProductNumber;
  }

  public Long getComQuantityBackingPerYear() {
    return comQuantityBackingPerYear;
  }

  public void setComQuantityBackingPerYear(Long comQuantityBackingPerYear) {
    this.comQuantityBackingPerYear = comQuantityBackingPerYear;
  }

  public Long getComQuantityDiscPerYear() {
    return comQuantityDiscPerYear;
  }

  public void setComQuantityDiscPerYear(Long comQuantityDiscPerYear) {
    this.comQuantityDiscPerYear = comQuantityDiscPerYear;
  }

  public String getContactAddress1() {
    return contactAddress1;
  }

  public void setContactAddress1(String contactAddress1) {
    this.contactAddress1 = contactAddress1;
  }

  public String getContactAddress2() {
    return contactAddress2;
  }

  public void setContactAddress2(String contactAddress2) {
    this.contactAddress2 = contactAddress2;
  }

  public String getContactCity() {
    return contactCity;
  }

  public void setContactCity(String contactCity) {
    this.contactCity = contactCity;
  }

  public String getContactCountry() {
    return contactCountry;
  }

  public void setContactCountry(String contactCountry) {
    this.contactCountry = contactCountry;
  }

  public String getContactEmail() {
    return contactEmail;
  }

  public void setContactEmail(String contactEmail) {
    this.contactEmail = contactEmail;
  }

  public String getContactEnterprise() {
    return contactEnterprise;
  }

  public void setContactEnterprise(String contactEnterprise) {
    this.contactEnterprise = contactEnterprise;
  }

  public String getContactName() {
    return contactName;
  }

  public void setContactName(String contactName) {
    this.contactName = contactName;
  }

  public String getContactZip() {
    return contactZip;
  }

  public void setContactZip(String contactZip) {
    this.contactZip = contactZip;
  }

  public String getMailBody() {
    return mailBody;
  }

  public void setMailBody(String mailBody) {
    this.mailBody = mailBody;
  }

  public String getMailCopies() {
    return mailCopies;
  }

  public void setMailCopies(String mailCopies) {
    this.mailCopies = mailCopies;
  }

  public String getMailRecipients() {
    return mailRecipients;
  }

  public void setMailRecipients(String mailRecipients) {
    this.mailRecipients = mailRecipients;
  }

  public String getMailSubject() {
    return mailSubject;
  }

  public void setMailSubject(String mailSubject) {
    this.mailSubject = mailSubject;
  }

  public String getMaterialId() {
    return materialId;
  }

  public void setMaterialId(String materialId) {
    this.materialId = materialId;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getResellerCompagny() {
    return resellerCompagny;
  }

  public void setResellerCompagny(String resellerCompagny) {
    this.resellerCompagny = resellerCompagny;
  }

  public String getResellerContact() {
    return resellerContact;
  }

  public void setResellerContact(String resellerContact) {
    this.resellerContact = resellerContact;
  }

  public Short getSaleGenerated() {
    return saleGenerated;
  }

  public void setSaleGenerated(Short saleGenerated) {
    this.saleGenerated = saleGenerated;
  }

  public Double getShopRate() {
    return shopRate;
  }

  public void setShopRate(Double shopRate) {
    this.shopRate = shopRate;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public Long getTimePerDiscChangeover() {
    return timePerDiscChangeover;
  }

  public void setTimePerDiscChangeover(Long timePerDiscChangeover) {
    this.timePerDiscChangeover = timePerDiscChangeover;
  }

  public String getUserScreenName() {
    return userScreenName;
  }

  public void setUserScreenName(String userScreenName) {
    this.userScreenName = userScreenName;
  }

  public Double getWalEndUserPrice() {
    return walEndUserPrice;
  }

  public void setWalEndUserPrice(Double walEndUserPrice) {
    this.walEndUserPrice = walEndUserPrice;
  }

  public String getWalOtherPowerTools() {
    return walOtherPowerTools;
  }

  public void setWalOtherPowerTools(String walOtherPowerTools) {
    this.walOtherPowerTools = walOtherPowerTools;
  }

  public String getWalPowerTools() {
    return walPowerTools;
  }

  public void setWalPowerTools(String walPowerTools) {
    this.walPowerTools = walPowerTools;
  }

  public String getWalProductId() {
    return walProductId;
  }

  public void setWalProductId(String walProductId) {
    this.walProductId = walProductId;
  }

  public ReportsLostsavings getReportsLostsavings() {
    return reportsLostsavings;
  }

  public void setReportsLostsavings(ReportsLostsavings reportsLostsavings) {
    this.reportsLostsavings = reportsLostsavings;
  }

  @XmlTransient
  public Set<Orders> getOrdersSet() {
    return ordersSet;
  }

  public void setOrdersSet(Set<Orders> ordersSet) {
    this.ordersSet = ordersSet;
  }

  public ReportsProductivity getReportsProductivity() {
    return reportsProductivity;
  }

  public void setReportsProductivity(ReportsProductivity reportsProductivity) {
    this.reportsProductivity = reportsProductivity;
  }

  public ReportsReimbursement getReportsReimbursement() {
    return reportsReimbursement;
  }

  public void setReportsReimbursement(ReportsReimbursement reportsReimbursement) {
    this.reportsReimbursement = reportsReimbursement;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (id != null ? id.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof Reports)) {
      return false;
    }
    Reports other = (Reports) object;
    if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.walterproductivity.Reports[ id=" + id + " ]";
  }

  public Double getComAvgTimePiece() {
    return comAvgTimePiece;
  }

  public void setComAvgTimePiece(Double comAvgTimePiece) {
    this.comAvgTimePiece = comAvgTimePiece;
  }

  public Double getComDistance() {
    return comDistance;
  }

  public void setComDistance(Double comDistance) {
    this.comDistance = comDistance;
  }

  public Long getComNbPieces() {
    return comNbPieces;
  }

  public void setComNbPieces(Long comNbPieces) {
    this.comNbPieces = comNbPieces;
  }

  public Double getComTotalTime() {
    return comTotalTime;
  }

  public void setComTotalTime(Double comTotalTime) {
    this.comTotalTime = comTotalTime;
  }

  public String getMethodId() {
    return methodId;
  }

  public void setMethodId(String methodId) {
    this.methodId = methodId;
  }

  public Double getWalAvgTimePiece() {
    return walAvgTimePiece;
  }

  public void setWalAvgTimePiece(Double walAvgTimePiece) {
    this.walAvgTimePiece = walAvgTimePiece;
  }

  public Double getWalDistance() {
    return walDistance;
  }

  public void setWalDistance(Double walDistance) {
    this.walDistance = walDistance;
  }

  public Long getWalNbPieces() {
    return walNbPieces;
  }

  public void setWalNbPieces(Long walNbPieces) {
    this.walNbPieces = walNbPieces;
  }

  public Double getWalTotalTime() {
    return walTotalTime;
  }

  public void setWalTotalTime(Double walTotalTime) {
    this.walTotalTime = walTotalTime;
  }

}
