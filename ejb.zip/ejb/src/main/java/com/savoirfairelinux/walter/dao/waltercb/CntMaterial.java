/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "CNT_MATERIAL", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CntMaterial.findAll", query = "SELECT c FROM CntMaterial c"),
    @NamedQuery(name = "CntMaterial.findByCntId", query = "SELECT c FROM CntMaterial c WHERE c.cntMaterialPK.cntId = :cntId"),
    @NamedQuery(name = "CntMaterial.findByMaterialId", query = "SELECT c FROM CntMaterial c WHERE c.cntMaterialPK.materialId = :materialId")})
public class CntMaterial implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected CntMaterialPK cntMaterialPK;
    @JoinColumn(name = "CNT_ID", referencedColumnName = "CNT_ID", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Cnt cnt;

    public CntMaterial() {
    }

    public CntMaterial(CntMaterialPK cntMaterialPK) {
        this.cntMaterialPK = cntMaterialPK;
    }

    public CntMaterial(long cntId, long materialId) {
        this.cntMaterialPK = new CntMaterialPK(cntId, materialId);
    }

    public CntMaterialPK getCntMaterialPK() {
        return cntMaterialPK;
    }

    public void setCntMaterialPK(CntMaterialPK cntMaterialPK) {
        this.cntMaterialPK = cntMaterialPK;
    }

    public Cnt getCnt() {
        return cnt;
    }

    public void setCnt(Cnt cnt) {
        this.cnt = cnt;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cntMaterialPK != null ? cntMaterialPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CntMaterial)) {
            return false;
        }
        CntMaterial other = (CntMaterial) object;
        if ((this.cntMaterialPK == null && other.cntMaterialPK != null) || (this.cntMaterialPK != null && !this.cntMaterialPK.equals(other.cntMaterialPK))) {
            return false;
        }
        return true;
    }
    
    @PrePersist
    private void prePersist() {
    	if (cnt != null && cntMaterialPK != null) {
    		cntMaterialPK.setCntId(cnt.getCntId());
    	}
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.CntMaterial[ cntMaterialPK=" + cntMaterialPK + " ]";
    }
    
}
