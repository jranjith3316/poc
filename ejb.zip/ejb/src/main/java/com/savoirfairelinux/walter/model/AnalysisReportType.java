/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.model;

import java.io.Serializable;

/**
 *
 * @author jsgill
 */
public class AnalysisReportType implements Serializable{
  private String reportId;
  private String description;

  public AnalysisReportType(String reportId, String description) {
    this.reportId = reportId;
    this.description = description;
  }

  public String getReportId() {
    return reportId;
  }

  public void setReportId(String reportId) {
    this.reportId = reportId;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  @Override
  public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		} else if (this == obj) {
			return true;
		} else if (reportId == ((AnalysisReportType) obj).getReportId()) {
			return true;
		}
		return false;
	}

}
