/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "CNT_FEEDBACK_R", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CntFeedbackR.findAll", query = "SELECT c FROM CntFeedbackR c"),
    @NamedQuery(name = "CntFeedbackR.findByCntId", query = "SELECT c FROM CntFeedbackR c WHERE c.cntFeedbackRPK.cntId = :cntId"),
    @NamedQuery(name = "CntFeedbackR.findByFeedbackId", query = "SELECT c FROM CntFeedbackR c WHERE c.cntFeedbackRPK.feedbackId = :feedbackId"),
    @NamedQuery(name = "CntFeedbackR.findByReplyDesc", query = "SELECT c FROM CntFeedbackR c WHERE c.replyDesc = :replyDesc"),
    @NamedQuery(name = "CntFeedbackR.findByDateCreated", query = "SELECT c FROM CntFeedbackR c WHERE c.dateCreated = :dateCreated")})
public class CntFeedbackR implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected CntFeedbackRPK cntFeedbackRPK;
    @Size(max = 500)
    @Column(name = "REPLY_DESC")
    private String replyDesc;
    @Column(name = "DATE_CREATED")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateCreated;
    @JoinColumn(name = "FEEDBACK_ID", referencedColumnName = "FEEDBACK_ID", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private CntFeedback cntFeedback;
    @JoinColumn(name = "CNT_ID", referencedColumnName = "CNT_ID", insertable=false, updatable=false)
    @ManyToOne
    private Cnt cnt;

    public CntFeedbackR() {
    }

    public CntFeedbackR(CntFeedbackRPK cntFeedbackRPK) {
        this.cntFeedbackRPK = cntFeedbackRPK;
    }

    public CntFeedbackR(long cntId, long feedbackId) {
        this.cntFeedbackRPK = new CntFeedbackRPK(cntId, feedbackId);
    }

    public CntFeedbackRPK getCntFeedbackRPK() {
        return cntFeedbackRPK;
    }

    public void setCntFeedbackRPK(CntFeedbackRPK cntFeedbackRPK) {
        this.cntFeedbackRPK = cntFeedbackRPK;
    }

    public String getReplyDesc() {
        return replyDesc;
    }

    public void setReplyDesc(String replyDesc) {
        this.replyDesc = replyDesc;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public CntFeedback getCntFeedback() {
        return cntFeedback;
    }

    public void setCntFeedback(CntFeedback cntFeedback) {
        this.cntFeedback = cntFeedback;
    }

    public Cnt getCnt() {
        return cnt;
    }

    public void setCnt(Cnt cnt) {
        this.cnt = cnt;
    }
    
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cntFeedbackRPK != null ? cntFeedbackRPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CntFeedbackR)) {
            return false;
        }
        CntFeedbackR other = (CntFeedbackR) object;
        if ((this.cntFeedbackRPK == null && other.cntFeedbackRPK != null) || (this.cntFeedbackRPK != null && !this.cntFeedbackRPK.equals(other.cntFeedbackRPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.CntFeedbackR[ cntFeedbackRPK=" + cntFeedbackRPK + " ]";
    }
    
}
