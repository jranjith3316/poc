/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author mgubaidullin
 */
@Embeddable
public class UTranslatorPK implements Serializable {
    @Basic(optional = false)
    @NotNull
    @Column(name = "SUBSCRIBER_ID")
    private long subscriberId;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 256)
    @Column(name = "USER_NAME")
    private String userName;
    @Basic(optional = false)
    @NotNull
    @Column(name = "LANG_ID")
    private short langId;

    public UTranslatorPK() {
    }

    public UTranslatorPK(long subscriberId, String userName, short langId) {
        this.subscriberId = subscriberId;
        this.userName = userName;
        this.langId = langId;
    }

    public long getSubscriberId() {
        return subscriberId;
    }

    public void setSubscriberId(long subscriberId) {
        this.subscriberId = subscriberId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public short getLangId() {
        return langId;
    }

    public void setLangId(short langId) {
        this.langId = langId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) subscriberId;
        hash += (userName != null ? userName.hashCode() : 0);
        hash += (int) langId;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof UTranslatorPK)) {
            return false;
        }
        UTranslatorPK other = (UTranslatorPK) object;
        if (this.subscriberId != other.subscriberId) {
            return false;
        }
        if ((this.userName == null && other.userName != null) || (this.userName != null && !this.userName.equals(other.userName))) {
            return false;
        }
        if (this.langId != other.langId) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.UTranslatorPK[ subscriberId=" + subscriberId + ", userName=" + userName + ", langId=" + langId + " ]";
    }
    
}
