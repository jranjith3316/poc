/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.tecsys.soap;

/**
 *
 * @author jsgill
 */
public class SoapClient {
//    private String endPoint_;
//    private String serviceName_;
//    private String userName_ = "";
//    private String password_ = "";
//
//  public SoapClient(String endPoint, String serviceName) {
//    super();
//    endPoint_ = endPoint;
//    serviceName_ = serviceName;
//  }
//
//  public String getEndPoint_() {
//    return endPoint_;
//  }
//
//  public void setEndPoint_(String endPoint_) {
//    this.endPoint_ = endPoint_;
//  }
//
//  public String getPassword() {
//    return password_;
//  }
//
//  public void setPassword(String password_) {
//    this.password_ = password_;
//  }
//
//  public String getServiceName() {
//    return serviceName_;
//  }
//
//  public void setServiceName(String serviceName_) {
//    this.serviceName_ = serviceName_;
//  }
//
//  public String getUserName() {
//    return userName_;
//  }
//
//  public void setUserName(String userName_) {
//    this.userName_ = userName_;
//  }
//
//  public Element invokeSoapMethod(String methodName, Element inElement) throws Exception {
//    Response resp = null;
//
//    SOAPMappingRegistry smr = new SOAPMappingRegistry();
//    smr.setDefaultEncodingStyle(Constants.NS_URI_2001_SCHEMA_XSD);
//
//    SOAPHTTPConnection hc = new SOAPHTTPConnection();
//    if (getUserName().equals("") == false) {
//        hc.setUserName(getUserName());
//        hc.setPassword(getPassword());
//    }
//
//    Call call = new Call();
//    call.setTargetObjectURI(serviceName_);
//    call.setMethodName(methodName);
//    call.setSOAPMappingRegistry(smr);
//    call.setSOAPTransport(hc);
//
//    Vector<Parameter> params = new Vector<Parameter>();
//
//    Parameter param = new Parameter(methodName, Element.class, inElement, Constants.NS_URI_LITERAL_XML);
//    params.addElement(param);
//
//    call.setParams(params);
//
//    URL url = new URL(endPoint_);
//
//    resp = call.invoke(url, "");
//
//    if (resp.generatedFault()) {
//        Fault aFault = resp.getFault();
//        String faultString = aFault.getFaultString();
//        throw new Exception(faultString);
//    }
//
//    Parameter ret = resp.getReturnValue();
//    Element outElement = null;
//
//    if (ret != null) {
//        outElement = (Element) ret.getValue();
//    }
//
//    return outElement;
//  }
}