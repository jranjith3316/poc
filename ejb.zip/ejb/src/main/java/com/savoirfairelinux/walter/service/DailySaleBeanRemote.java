/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.service;

import com.liferay.portal.model.User;
import com.savoirfairelinux.walter.dao.walter.UPerson;
import java.util.List;
import javax.ejb.Remote;

/**
 *
 * @author jsgill
 */
@Remote
public interface DailySaleBeanRemote {
  
  public List<UPerson> getMecanicalUserList(long companyId, Integer countryId, String userConnected) throws Exception;
  public List<UPerson> getChemicalUserList(long companyId, Integer countryId, String userConnected) throws Exception;
  
  public boolean isUserReportTo(String userName, String bossName, boolean immediateBoss) throws Exception;
  
}
