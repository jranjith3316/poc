/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.model;

import java.io.Serializable;

/**
 *
 * @author jderuere
 */
public class PrApplication implements Serializable {
    private static final long serialVersionUID = 1L;

    public static final String CUTTING = "FC82683BAB71E656E043C0A8011FE656";
    public static final String GRINDING = "FC2177416194CD2CE043C0A8011FCD2C";
    public static final String BLENDING = "FC831CE581A022B6E043C0A8011F22B6";
    public static final String SANDING = "FC831CE581AA22B6E043C0A8011F22B6";

    private String guid;
    private String name;

    public PrApplication(String guid) {
        this.guid = guid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        this.guid = guid;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof PrApplication)) return false;

        PrApplication that = (PrApplication) o;

        if (!guid.equals(that.guid)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return guid.hashCode();
    }
}
