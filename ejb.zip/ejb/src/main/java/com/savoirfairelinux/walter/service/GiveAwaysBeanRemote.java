/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.service;

import com.savoirfairelinux.walter.dao.waltercb.PromoItem;
import com.savoirfairelinux.walter.dao.waltercb.PromoItemCountry;
import com.savoirfairelinux.walter.dao.waltercb.PromoItemTxt;
import com.savoirfairelinux.walter.dao.waltercb.PromoOrder;
import com.savoirfairelinux.walter.dao.waltercb.PromoOrderItem;
import com.savoirfairelinux.walter.model.PromoItemModel;
import com.savoirfairelinux.walter.model.PromoOrderModel;
import java.util.List;
import javax.ejb.Remote;
import javax.mail.internet.InternetAddress;

/**
 *
 * @author jsgill
 */
@Remote
public interface GiveAwaysBeanRemote {

  public PromoItem getPromoItem(Long itemId);

  public PromoItemCountry getPromoItemCountry(Long itemId, Long countryId);

  public PromoItemTxt getPromoItemTxt(Long itemId, Long langId);

  public void savePromo(PromoItem pi, PromoItemCountry picCA, PromoItemCountry picUSA, PromoItemTxt pitEN, PromoItemTxt pitFR);

  public List<PromoItemModel> getItemList();

  public Boolean getProductNumberExist(String productNumber);

  public List<PromoItemModel> getAvailableProduct(Long countryId, Long langId);

  public PromoOrder addPromoOrderItem(PromoOrder po, PromoItemModel pim, Long countryId );

  public List<PromoOrderModel> getUnsubmittedOrder(String creatorUserName);

  public List<PromoOrderModel> getSubmittedOrder(String creatorUserName);

  public PromoOrder getLastPromoOrder(String creatorUserName);

  public PromoOrder getPromoOrder(Long orderId);

  public Long getNumberItemShoppingCart(Long orderId);

  public Boolean checkItemAlreadyAdded(Long countryId, Long orderId, Long itemId);

  public List<PromoOrderItem> getPromoOrderItem(Long orderId);

  public void deletePromoOrderItem(PromoOrderItem poi);

  public void submitOrder(PromoOrder po, List<InternetAddress> CSRUsers, String productList);
}
