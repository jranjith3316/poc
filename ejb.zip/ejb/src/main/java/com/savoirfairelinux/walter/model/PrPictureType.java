package com.savoirfairelinux.walter.model;

/**
 * @author jderuere
 */
public enum PrPictureType {
    BEFORE, AFTER;
}
