/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import javax.persistence.*;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "ER_TRIAL_TXT", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "ErTrialTxt.findAll", query = "SELECT e FROM ErTrialTxt e"),
    @NamedQuery(name = "ErTrialTxt.findByTrialId", query = "SELECT e FROM ErTrialTxt e WHERE e.erTrialTxtPK.trialId = :trialId"),
    @NamedQuery(name = "ErTrialTxt.findByLangId", query = "SELECT e FROM ErTrialTxt e WHERE e.erTrialTxtPK.langId = :langId"),
    @NamedQuery(name = "ErTrialTxt.findByMechanical", query = "SELECT e FROM ErTrialTxt e WHERE e.mechanical = :mechanical"),
    @NamedQuery(name = "ErTrialTxt.findByTemperature", query = "SELECT e FROM ErTrialTxt e WHERE e.temperature = :temperature"),
    @NamedQuery(name = "ErTrialTxt.findByWaitTime", query = "SELECT e FROM ErTrialTxt e WHERE e.waitTime = :waitTime"),
    @NamedQuery(name = "ErTrialTxt.findByComments", query = "SELECT e FROM ErTrialTxt e WHERE e.comments = :comments"),
    @NamedQuery(name = "ErTrialTxt.findByBrandId", query = "SELECT e FROM ErTrialTxt e WHERE e.brandId = :brandId")})
public class ErTrialTxt implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected ErTrialTxtPK erTrialTxtPK;
    @Size(max = 100)
    @Column(name = "MECHANICAL", length = 100)
    private String mechanical;
    @Size(max = 100)
    @Column(name = "TEMPERATURE", length = 100)
    private String temperature;
    @Size(max = 100)
    @Column(name = "WAIT_TIME", length = 100)
    private String waitTime;
    @Size(max = 1000)
    @Column(name = "COMMENTS", length = 1000)
    private String comments;
    @Column(name = "BRAND_ID")
    private Integer brandId;
    @JoinColumn(name = "TRIAL_ID", referencedColumnName = "TRIAL_ID", nullable = false, insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private ErTrial erTrial;

    public ErTrialTxt() {
    }

    public ErTrialTxt(ErTrialTxtPK erTrialTxtPK) {
        this.erTrialTxtPK = erTrialTxtPK;
    }

    public ErTrialTxt(long trialId, long langId) {
        this.erTrialTxtPK = new ErTrialTxtPK(trialId, langId);
    }

    public ErTrialTxtPK getErTrialTxtPK() {
        return erTrialTxtPK;
    }

    public void setErTrialTxtPK(ErTrialTxtPK erTrialTxtPK) {
        this.erTrialTxtPK = erTrialTxtPK;
    }

    public String getMechanical() {
        return mechanical;
    }

    public void setMechanical(String mechanical) {
        this.mechanical = mechanical;
    }

    public String getTemperature() {
        return temperature;
    }

    public void setTemperature(String temperature) {
        this.temperature = temperature;
    }

    public String getWaitTime() {
        return waitTime;
    }

    public void setWaitTime(String waitTime) {
        this.waitTime = waitTime;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public Integer getBrandId() {
        return brandId;
    }

    public void setBrandId(Integer brandId) {
        this.brandId = brandId;
    }

    public ErTrial getErTrial() {
        return erTrial;
    }

    public void setErTrial(ErTrial erTrial) {
        this.erTrial = erTrial;
    }

    @PrePersist
    private void prePersist() {
        if (erTrialTxtPK == null) {
            erTrialTxtPK = new ErTrialTxtPK(-1, ULang.ENGLISH_ID);
        }
        if (erTrial != null) {
            erTrialTxtPK.setTrialId(erTrial.getTrialId());
        }
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (erTrialTxtPK != null ? erTrialTxtPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ErTrialTxt)) {
            return false;
        }
        ErTrialTxt other = (ErTrialTxt) object;
        if ((this.erTrialTxtPK == null && other.erTrialTxtPK != null) || (this.erTrialTxtPK != null && !this.erTrialTxtPK.equals(other.erTrialTxtPK))) {
            return false;
        }
        if (this.erTrialTxtPK == null && other.erTrialTxtPK == null) {
            return this == other;
        }

        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.ErTrialTxt[ erTrialTxtPK=" + erTrialTxtPK + " ]";
    }
}
