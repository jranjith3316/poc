/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.crossreferenceapp;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "COMPETITOR", catalog = "", schema = "CROSSREFERENCEAPP")
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "Competitor.findAll", query = "SELECT c FROM Competitor c"),
  @NamedQuery(name = "Competitor.findByCompetitorId", query = "SELECT c FROM Competitor c WHERE c.competitorId = :competitorId"),
  @NamedQuery(name = "Competitor.findByName", query = "SELECT c FROM Competitor c WHERE c.name = :name"),
  @NamedQuery(name = "Competitor.findByCreatedUserName", query = "SELECT c FROM Competitor c WHERE c.createdUserName = :createdUserName"),
  @NamedQuery(name = "Competitor.findByCreatedDate", query = "SELECT c FROM Competitor c WHERE c.createdDate = :createdDate"),
  @NamedQuery(name = "Competitor.findByUpdatedUserName", query = "SELECT c FROM Competitor c WHERE c.updatedUserName = :updatedUserName"),
  @NamedQuery(name = "Competitor.findByUpdatedDate", query = "SELECT c FROM Competitor c WHERE c.updatedDate = :updatedDate"),
  @NamedQuery(name = "Competitor.findByDeleteUserName", query = "SELECT c FROM Competitor c WHERE c.deleteUserName = :deleteUserName"),
  @NamedQuery(name = "Competitor.findByDeletedDate", query = "SELECT c FROM Competitor c WHERE c.deletedDate = :deletedDate")})
public class Competitor implements Serializable {
  private static final long serialVersionUID = 1L;
  @Id
  @Basic(optional = false)
  @NotNull
  @Column(name = "COMPETITOR_ID")
  private Long competitorId;
  @Size(max = 150)
  @Column(name = "NAME")
  private String name;
  @Size(max = 255)
  @Column(name = "CREATED_USER_NAME")
  private String createdUserName;
  @Column(name = "CREATED_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date createdDate;
  @Size(max = 255)
  @Column(name = "UPDATED_USER_NAME")
  private String updatedUserName;
  @Column(name = "UPDATED_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date updatedDate;
  @Size(max = 255)
  @Column(name = "DELETE_USER_NAME")
  private String deleteUserName;
  @Column(name = "DELETED_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date deletedDate;

  public Competitor() {
  }

  public Competitor(Long competitorId) {
    this.competitorId = competitorId;
  }

  public Long getCompetitorId() {
    return competitorId;
  }

  public void setCompetitorId(Long competitorId) {
    this.competitorId = competitorId;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getCreatedUserName() {
    return createdUserName;
  }

  public void setCreatedUserName(String createdUserName) {
    this.createdUserName = createdUserName;
  }

  public Date getCreatedDate() {
    return createdDate;
  }

  public void setCreatedDate(Date createdDate) {
    this.createdDate = createdDate;
  }

  public String getUpdatedUserName() {
    return updatedUserName;
  }

  public void setUpdatedUserName(String updatedUserName) {
    this.updatedUserName = updatedUserName;
  }

  public Date getUpdatedDate() {
    return updatedDate;
  }

  public void setUpdatedDate(Date updatedDate) {
    this.updatedDate = updatedDate;
  }

  public String getDeleteUserName() {
    return deleteUserName;
  }

  public void setDeleteUserName(String deleteUserName) {
    this.deleteUserName = deleteUserName;
  }

  public Date getDeletedDate() {
    return deletedDate;
  }

  public void setDeletedDate(Date deletedDate) {
    this.deletedDate = deletedDate;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (competitorId != null ? competitorId.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof Competitor)) {
      return false;
    }
    Competitor other = (Competitor) object;
    if ((this.competitorId == null && other.competitorId != null) || (this.competitorId != null && !this.competitorId.equals(other.competitorId))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.crossreferenceapp.Competitor[ competitorId=" + competitorId + " ]";
  }

}
