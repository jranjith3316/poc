/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.globalcustomer;


import com.savoirfairelinux.walter.dao.DatabaseConstants;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.util.Date;
import java.util.Set;

/**
 *
 * @author jderuere
 */
@Entity
@Table(name = "GA_FEEDBACK", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "GaFeedback.findAll", query = "SELECT c FROM GaFeedback c"),
    @NamedQuery(name = "GaFeedback.findByFeedbackId", query = "SELECT c FROM GaFeedback c WHERE c.feedbackId = :feedbackId"),
    @NamedQuery(name = "GaFeedback.findByFeedbackDesc", query = "SELECT c FROM GaFeedback c WHERE c.feedbackDesc = :feedbackDesc"),
    @NamedQuery(name = "GaFeedback.findByDateCreated", query = "SELECT c FROM GaFeedback c WHERE c.dateCreated = :dateCreated")})
public class GaFeedback implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @GeneratedValue(generator = "GA_FEEDBACK_ID_SEQ", strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "GA_FEEDBACK_ID_SEQ", sequenceName = "GA_FEEDBACK_ID_SEQ", schema = DatabaseConstants.WALTERCB_SCHEMA, allocationSize = 1)
    @Column(name = "FEEDBACK_ID")
    private Long feedbackId;
    @Size(max = 500)
    @Column(name = "FEEDBACK_DESC")
    private String feedbackDesc;
    @Column(name = "DATE_CREATED")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateCreated;
    @Size(max = 256)
    @Column(name = "CONTRIBUTOR")
    private String contributor;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "feedback", fetch = FetchType.EAGER)
    private Set<GaFeedbackR> feedbackReplies;
    @ManyToOne(optional = false)
    @JoinColumn(name = "FACILITY_ID", referencedColumnName = "FACILITY_ID", nullable = false)
    private GaFacility facility;

    public GaFeedback() {
    }

    public GaFeedback(Long feedbackId) {
        this.feedbackId = feedbackId;
    }

    public Long getFeedbackId() {
        return feedbackId;
    }

    public void setFeedbackId(Long feedbackId) {
        this.feedbackId = feedbackId;
    }

    public String getFeedbackDesc() {
        return feedbackDesc;
    }

    public void setFeedbackDesc(String feedbackDesc) {
        this.feedbackDesc = feedbackDesc;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public Set<GaFeedbackR> getFeedbackReplies() {
        return feedbackReplies;
    }

    public void setFeedbackReplies(Set<GaFeedbackR> feedbackReplies) {
        this.feedbackReplies = feedbackReplies;
    }

    public String getContributor() {
        return contributor;
    }

    public void setContributor(String contributor) {
        this.contributor = contributor;
    }

    public GaFacility getFacility() {
        return facility;
    }

    public void setFacility(GaFacility facility) {
        this.facility = facility;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (feedbackId != null ? feedbackId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof GaFeedback)) {
            return false;
        }
        GaFeedback other = (GaFeedback) object;
        if ((this.feedbackId == null && other.feedbackId != null) || (this.feedbackId != null && !this.feedbackId.equals(other.feedbackId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.globalcustomer.GaFeedback[ feedbackId=" + feedbackId + " ]";
    }
}
