/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.walter;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "VG_TREE_TYPE", catalog = "", schema = DatabaseConstants.WALTER_SCHEMA)
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "VgTreeType.findAll", query = "SELECT v FROM VgTreeType v"),
  @NamedQuery(name = "VgTreeType.findByVgTreeCode", query = "SELECT v FROM VgTreeType v WHERE v.vgTreeTypePK.vgTreeCode = :vgTreeCode"),
  @NamedQuery(name = "VgTreeType.findByTypeId", query = "SELECT v FROM VgTreeType v WHERE v.vgTreeTypePK.typeId = :typeId"),
  @NamedQuery(name = "VgTreeType.findByName", query = "SELECT v FROM VgTreeType v WHERE v.name = :name"),
  @NamedQuery(name = "VgTreeType.findByDescription", query = "SELECT v FROM VgTreeType v WHERE v.description = :description"),
  @NamedQuery(name = "VgTreeType.findByUrl", query = "SELECT v FROM VgTreeType v WHERE v.url = :url"),
  @NamedQuery(name = "VgTreeType.findByCreationUserName", query = "SELECT v FROM VgTreeType v WHERE v.creationUserName = :creationUserName"),
  @NamedQuery(name = "VgTreeType.findByCreatedDate", query = "SELECT v FROM VgTreeType v WHERE v.createdDate = :createdDate"),
  @NamedQuery(name = "VgTreeType.findByCancelUserName", query = "SELECT v FROM VgTreeType v WHERE v.cancelUserName = :cancelUserName"),
  @NamedQuery(name = "VgTreeType.findByCancelDate", query = "SELECT v FROM VgTreeType v WHERE v.cancelDate = :cancelDate")})
public class VgTreeType implements Serializable {
  private static final long serialVersionUID = 1L;
  @EmbeddedId
  protected VgTreeTypePK vgTreeTypePK;
  @Size(max = 50)
  @Column(name = "NAME")
  private String name;
  @Size(max = 100)
  @Column(name = "DESCRIPTION")
  private String description;
  @Size(max = 500)
  @Column(name = "URL")
  private String url;
  @Size(max = 256)
  @Column(name = "CREATION_USER_NAME")
  private String creationUserName;
  @Column(name = "CREATED_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date createdDate;
  @Size(max = 256)
  @Column(name = "CANCEL_USER_NAME")
  private String cancelUserName;
  @Column(name = "CANCEL_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date cancelDate;
  @JoinColumn(name = "VG_TREE_CODE", referencedColumnName = "VG_TREE_CODE", insertable = false, updatable = false)
  @ManyToOne(optional = false)
  private VgTree vgTree;

  public VgTreeType() {
  }

  public VgTreeType(VgTreeTypePK vgTreeTypePK) {
    this.vgTreeTypePK = vgTreeTypePK;
  }

  public VgTreeType(String vgTreeCode, short typeId) {
    this.vgTreeTypePK = new VgTreeTypePK(vgTreeCode, typeId);
  }

  public VgTreeTypePK getVgTreeTypePK() {
    return vgTreeTypePK;
  }

  public void setVgTreeTypePK(VgTreeTypePK vgTreeTypePK) {
    this.vgTreeTypePK = vgTreeTypePK;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getUrl() {
    return url;
  }

  public void setUrl(String url) {
    this.url = url;
  }

  public String getCreationUserName() {
    return creationUserName;
  }

  public void setCreationUserName(String creationUserName) {
    this.creationUserName = creationUserName;
  }

  public Date getCreatedDate() {
    return createdDate;
  }

  public void setCreatedDate(Date createdDate) {
    this.createdDate = createdDate;
  }

  public String getCancelUserName() {
    return cancelUserName;
  }

  public void setCancelUserName(String cancelUserName) {
    this.cancelUserName = cancelUserName;
  }

  public Date getCancelDate() {
    return cancelDate;
  }

  public void setCancelDate(Date cancelDate) {
    this.cancelDate = cancelDate;
  }

  public VgTree getVgTree() {
    return vgTree;
  }

  public void setVgTree(VgTree vgTree) {
    this.vgTree = vgTree;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (vgTreeTypePK != null ? vgTreeTypePK.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof VgTreeType)) {
      return false;
    }
    VgTreeType other = (VgTreeType) object;
    if ((this.vgTreeTypePK == null && other.vgTreeTypePK != null) || (this.vgTreeTypePK != null && !this.vgTreeTypePK.equals(other.vgTreeTypePK))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.walter.VgTreeType[ vgTreeTypePK=" + vgTreeTypePK + " ]";
  }
  
}
