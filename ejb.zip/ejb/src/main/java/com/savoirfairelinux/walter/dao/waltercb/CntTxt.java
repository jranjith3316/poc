/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "CNT_TXT", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CntTxt.findAll", query = "SELECT c FROM CntTxt c"),
    @NamedQuery(name = "CntTxt.findById", query = "SELECT c FROM CntTxt c WHERE c.cntTxtPK.cntId = :cntId AND c.cntTxtPK.langId = :langId"),
    @NamedQuery(name = "CntTxt.findByCntId", query = "SELECT c FROM CntTxt c WHERE c.cntTxtPK.cntId = :cntId"),
    @NamedQuery(name = "CntTxt.findByLangId", query = "SELECT c FROM CntTxt c WHERE c.cntTxtPK.langId = :langId"),
    @NamedQuery(name = "CntTxt.findByCustomer", query = "SELECT c FROM CntTxt c WHERE c.customer = :customer"),
    @NamedQuery(name = "CntTxt.findByObjective", query = "SELECT c FROM CntTxt c WHERE c.objective = :objective"),
    @NamedQuery(name = "CntTxt.findByCurrentProcess", query = "SELECT c FROM CntTxt c WHERE c.currentProcess = :currentProcess"),
    @NamedQuery(name = "CntTxt.findByWalterSolution", query = "SELECT c FROM CntTxt c WHERE c.walterSolution = :walterSolution"),
    @NamedQuery(name = "CntTxt.findByKeySaleAdvantage1", query = "SELECT c FROM CntTxt c WHERE c.keySaleAdvantage1 = :keySaleAdvantage1"),
    @NamedQuery(name = "CntTxt.findByKeySaleAdvantage2", query = "SELECT c FROM CntTxt c WHERE c.keySaleAdvantage2 = :keySaleAdvantage2"),
    @NamedQuery(name = "CntTxt.findByKeySaleAdvantage3", query = "SELECT c FROM CntTxt c WHERE c.keySaleAdvantage3 = :keySaleAdvantage3"),
    @NamedQuery(name = "CntTxt.findByKeySaleAdvantage4", query = "SELECT c FROM CntTxt c WHERE c.keySaleAdvantage4 = :keySaleAdvantage4"),
    @NamedQuery(name = "CntTxt.findByKeySaleAdvantage5", query = "SELECT c FROM CntTxt c WHERE c.keySaleAdvantage5 = :keySaleAdvantage5"),
    @NamedQuery(name = "CntTxt.findByCntComment", query = "SELECT c FROM CntTxt c WHERE c.cntComment = :cntComment"),
    @NamedQuery(name = "CntTxt.findByPmComment", query = "SELECT c FROM CntTxt c WHERE c.pmComment = :pmComment"),
    @NamedQuery(name = "CntTxt.findByOtherMaterial", query = "SELECT c FROM CntTxt c WHERE c.otherMaterial = :otherMaterial"),
    @NamedQuery(name = "CntTxt.findByOtherIndustry", query = "SELECT c FROM CntTxt c WHERE c.otherIndustry = :otherIndustry"),
    @NamedQuery(name = "CntTxt.findByOtherActivity", query = "SELECT c FROM CntTxt c WHERE c.otherActivity = :otherActivity"),
    @NamedQuery(name = "CntTxt.findByOtherContaminant", query = "SELECT c FROM CntTxt c WHERE c.otherContaminant = :otherContaminant"),
    @NamedQuery(name = "CntTxt.findByValidationText", query = "SELECT c FROM CntTxt c WHERE c.validationText = :validationText"),
    @NamedQuery(name = "CntTxt.findByOtherCompetitor", query = "SELECT c FROM CntTxt c WHERE c.otherCompetitor = :otherCompetitor"),
    @NamedQuery(name = "CntTxt.findByOtherCompProd", query = "SELECT c FROM CntTxt c WHERE c.otherCompProd = :otherCompProd"),
    @NamedQuery(name = "CntTxt.findByPublishedDate", query = "SELECT c FROM CntTxt c WHERE c.publishedDate = :publishedDate"),
    @NamedQuery(name = "CntTxt.findByOriginalPublishedDate", query = "SELECT c FROM CntTxt c WHERE c.originalPublishedDate = :originalPublishedDate"),
    @NamedQuery(name = "CntTxt.findByTranslatable", query = "SELECT c FROM CntTxt c WHERE c.translatable = :translatable"),
    @NamedQuery(name = "CntTxt.findByExtPublishDate", query = "SELECT c FROM CntTxt c WHERE c.extPublishDate = :extPublishDate"),
    @NamedQuery(name = "CntTxt.findByOtherMachinery", query = "SELECT c FROM CntTxt c WHERE c.otherMachinery = :otherMachinery")})
public class CntTxt implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected CntTxtPK cntTxtPK;
    @Size(max = 150)
    @Column(name = "CUSTOMER")
    private String customer;
    @Size(max = 1100)
    @Column(name = "OBJECTIVE")
    private String objective;
    @Size(max = 1100)
    @Column(name = "CURRENT_PROCESS")
    private String currentProcess;
    @Size(max = 1600)
    @Column(name = "WALTER_SOLUTION")
    private String walterSolution;
    @Size(max = 150)
    @Column(name = "KEY_SALE_ADVANTAGE_1")
    private String keySaleAdvantage1;
    @Size(max = 150)
    @Column(name = "KEY_SALE_ADVANTAGE_2")
    private String keySaleAdvantage2;
    @Size(max = 150)
    @Column(name = "KEY_SALE_ADVANTAGE_3")
    private String keySaleAdvantage3;
    @Size(max = 150)
    @Column(name = "KEY_SALE_ADVANTAGE_4")
    private String keySaleAdvantage4;
    @Size(max = 150)
    @Column(name = "KEY_SALE_ADVANTAGE_5")
    private String keySaleAdvantage5;
    @Size(max = 1100)
    @Column(name = "CNT_COMMENT")
    private String cntComment;
    @Size(max = 1100)
    @Column(name = "PM_COMMENT")
    private String pmComment;
    @Size(max = 40)
    @Column(name = "OTHER_MATERIAL")
    private String otherMaterial;
    @Size(max = 40)
    @Column(name = "OTHER_INDUSTRY")
    private String otherIndustry;
    @Size(max = 40)
    @Column(name = "OTHER_ACTIVITY")
    private String otherActivity;
    @Size(max = 40)
    @Column(name = "OTHER_CONTAMINANT")
    private String otherContaminant;
    @Size(max = 1100)
    @Column(name = "VALIDATION_TEXT")
    private String validationText;
    @Size(max = 40)
    @Column(name = "OTHER_COMPETITOR")
    private String otherCompetitor;
    @Size(max = 40)
    @Column(name = "OTHER_COMP_PROD")
    private String otherCompProd;
    @Column(name = "PUBLISHED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date publishedDate;
    @Column(name = "ORIGINAL_PUBLISHED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date originalPublishedDate;
    @Column(name = "TRANSLATABLE", columnDefinition="char")
    private String translatable;
    @Column(name = "EXT_PUBLISH_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date extPublishDate;
    @Size(max = 40)
    @Column(name = "OTHER_MACHINERY")
    private String otherMachinery;
    @JoinColumn(name = "CNT_ID", referencedColumnName = "CNT_ID", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Cnt cnt;

    public CntTxt() {
    }

    public CntTxt(CntTxtPK cntTxtPK) {
        this.cntTxtPK = cntTxtPK;
    }

    public CntTxt(long cntId, long langId) {
        this.cntTxtPK = new CntTxtPK(cntId, langId);
    }

    public CntTxt(CntTxt englishTxt, long langId) {
    	this.cntTxtPK = new CntTxtPK(englishTxt.getCntTxtPK().getCntId(), langId);
		this.cnt = englishTxt.getCnt();
		this.cntComment = englishTxt.getCntComment();
		this.currentProcess = englishTxt.getCurrentProcess();
		this.keySaleAdvantage1 = englishTxt.getKeySaleAdvantage1();
		this.keySaleAdvantage2 = englishTxt.getKeySaleAdvantage2();
		this.keySaleAdvantage3 = englishTxt.getKeySaleAdvantage3();
		this.keySaleAdvantage4 = englishTxt.getKeySaleAdvantage4();
		this.keySaleAdvantage5 = englishTxt.getKeySaleAdvantage5();
		this.objective = englishTxt.getObjective();
		this.otherActivity = englishTxt.getOtherActivity();
		this.otherCompetitor = englishTxt.getOtherCompetitor();
		this.otherCompProd = englishTxt.getOtherCompProd();
		this.otherContaminant = englishTxt.getOtherContaminant();
		this.otherIndustry = englishTxt.getOtherIndustry();
		this.otherMachinery = englishTxt.getOtherMachinery();
		this.otherMaterial = englishTxt.getOtherMaterial();
		this.walterSolution = englishTxt.getWalterSolution();
		this.pmComment = englishTxt.getPmComment();
		this.validationText = englishTxt.getValidationText();
	}

	public CntTxtPK getCntTxtPK() {
        return cntTxtPK;
    }

    public void setCntTxtPK(CntTxtPK cntTxtPK) {
        this.cntTxtPK = cntTxtPK;
    }

    public String getCustomer() {
        return customer;
    }

    public void setCustomer(String customer) {
        this.customer = customer;
    }

    public String getObjective() {
        return objective;
    }

    public void setObjective(String objective) {
        this.objective = objective;
    }

    public String getCurrentProcess() {
        return currentProcess;
    }

    public void setCurrentProcess(String currentProcess) {
        this.currentProcess = currentProcess;
    }

    public String getWalterSolution() {
        return walterSolution;
    }

    public void setWalterSolution(String walterSolution) {
        this.walterSolution = walterSolution;
    }

    public String getKeySaleAdvantage1() {
        return keySaleAdvantage1;
    }

    public void setKeySaleAdvantage1(String keySaleAdvantage1) {
        this.keySaleAdvantage1 = keySaleAdvantage1;
    }

    public String getKeySaleAdvantage2() {
        return keySaleAdvantage2;
    }

    public void setKeySaleAdvantage2(String keySaleAdvantage2) {
        this.keySaleAdvantage2 = keySaleAdvantage2;
    }

    public String getKeySaleAdvantage3() {
        return keySaleAdvantage3;
    }

    public void setKeySaleAdvantage3(String keySaleAdvantage3) {
        this.keySaleAdvantage3 = keySaleAdvantage3;
    }

    public String getKeySaleAdvantage4() {
        return keySaleAdvantage4;
    }

    public void setKeySaleAdvantage4(String keySaleAdvantage4) {
        this.keySaleAdvantage4 = keySaleAdvantage4;
    }

    public String getKeySaleAdvantage5() {
        return keySaleAdvantage5;
    }

    public void setKeySaleAdvantage5(String keySaleAdvantage5) {
        this.keySaleAdvantage5 = keySaleAdvantage5;
    }

    public String getCntComment() {
        return cntComment;
    }

    public void setCntComment(String cntComment) {
        this.cntComment = cntComment;
    }

    public String getPmComment() {
        return pmComment;
    }

    public void setPmComment(String pmComment) {
        this.pmComment = pmComment;
    }

    public String getOtherMaterial() {
        return otherMaterial;
    }

    public void setOtherMaterial(String otherMaterial) {
        this.otherMaterial = otherMaterial;
    }

    public String getOtherIndustry() {
        return otherIndustry;
    }

    public void setOtherIndustry(String otherIndustry) {
        this.otherIndustry = otherIndustry;
    }

    public String getOtherActivity() {
        return otherActivity;
    }

    public void setOtherActivity(String otherActivity) {
        this.otherActivity = otherActivity;
    }

    public String getOtherContaminant() {
        return otherContaminant;
    }

    public void setOtherContaminant(String otherContaminant) {
        this.otherContaminant = otherContaminant;
    }

    public String getValidationText() {
        return validationText;
    }

    public void setValidationText(String validationText) {
        this.validationText = validationText;
    }

    public String getOtherCompetitor() {
        return otherCompetitor;
    }

    public void setOtherCompetitor(String otherCompetitor) {
        this.otherCompetitor = otherCompetitor;
    }

    public String getOtherCompProd() {
        return otherCompProd;
    }

    public void setOtherCompProd(String otherCompProd) {
        this.otherCompProd = otherCompProd;
    }

    public Date getPublishedDate() {
        return publishedDate;
    }

    public void setPublishedDate(Date publishedDate) {
        this.publishedDate = publishedDate;
    }

    public Date getOriginalPublishedDate() {
        return originalPublishedDate;
    }

    public void setOriginalPublishedDate(Date originalPublishedDate) {
        this.originalPublishedDate = originalPublishedDate;
    }

    public String getTranslatable() {
        return translatable;
    }

    public void setTranslatable(String translatable) {
        this.translatable = translatable;
    }

    public Date getExtPublishDate() {
        return extPublishDate;
    }

    public void setExtPublishDate(Date extPublishDate) {
        this.extPublishDate = extPublishDate;
    }

    public String getOtherMachinery() {
        return otherMachinery;
    }

    public void setOtherMachinery(String otherMachinery) {
        this.otherMachinery = otherMachinery;
    }

    public Cnt getCnt() {
        return cnt;
    }

    public void setCnt(Cnt cnt) {
        this.cnt = cnt;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cntTxtPK != null ? cntTxtPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CntTxt)) {
            return false;
        }
        CntTxt other = (CntTxt) object;
        if ((this.cntTxtPK == null && other.cntTxtPK != null) || (this.cntTxtPK != null && !this.cntTxtPK.equals(other.cntTxtPK))) {
            return false;
        }
        return true;
    }
    
    @PrePersist
    private void prePersist() {
    	if (cnt != null && cntTxtPK != null) {
    		cntTxtPK.setCntId(cnt.getCntId());
    	}
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.CntTxt[ cntTxtPK=" + cntTxtPK + " ]";
    }
    
}
