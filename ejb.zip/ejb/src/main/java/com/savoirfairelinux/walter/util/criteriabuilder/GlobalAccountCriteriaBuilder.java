package com.savoirfairelinux.walter.util.criteriabuilder;

import com.savoirfairelinux.walter.dao.globalcustomer.GlobalAccount;
import com.savoirfairelinux.walter.dao.globalcustomer.UGeographicalCoverage;
import com.savoirfairelinux.walter.dao.waltercb.Country;
import com.savoirfairelinux.walter.dao.waltercb.UIndustry;
import com.savoirfairelinux.walter.model.Franchise;
import com.savoirfairelinux.walter.model.SearchGlobalAccount;
import com.savoirfairelinux.walter.model.Tradename;

import javax.persistence.EntityManager;
import java.util.Date;
import java.util.Map;

public class GlobalAccountCriteriaBuilder extends AbstractCriteriaBuilder<GlobalAccount> {

    private SearchGlobalAccount form;

    public GlobalAccountCriteriaBuilder(EntityManager entityManager, SearchGlobalAccount form) {
        super(entityManager, GlobalAccount.class);
        this.form = form;
    }

    @Override
    protected void initQuery(StringBuilder queryBuilder, Map<String, Object> properties) {
        queryBuilder.append("SELECT acc FROM GlobalAccount acc ");
    }

    @Override
    protected void initJoinQuery(StringBuilder queryBuilder, Map<String, Object> properties) {
        queryBuilder.append(" LEFT OUTER JOIN FETCH acc.industry as ind ");
        queryBuilder.append(" LEFT OUTER JOIN FETCH acc.coverage as cov ");
    }

    @Override
    protected void buildSpecificQuery(StringBuilder queryBuilder, Map<String, Object> properties) {
        queryBuilder.append(" WHERE 1 = 1 ");
        addGlobalAccountIdCriteria(queryBuilder, properties, form.getId());
        addDateCriteria(queryBuilder, properties, form.getDate());
        addLikeCriteria(queryBuilder, "acc.name", form.getName());
        addIndustryCriteria(queryBuilder, properties, form.getIndustry());
        if (form.getTradename() != null) {
            addTradenameCriteria(queryBuilder, properties, form.getTradename());
        } else {
            addFranchiseCriteria(queryBuilder, properties, form.getFranchise());
        }
        addCoverageCriteria(queryBuilder, properties, form.getGeographicalCoverage());
        addCountryCriteria(queryBuilder, properties, form.getCountry());
    }

    @Override
    protected void initOrderByQuery(StringBuilder queryBuilder, Map<String, Object> properties) {    	
    }

    protected void addGlobalAccountIdCriteria(StringBuilder queryBuilder, Map<String, Object> properties, Long globalAccountId) {
        if (globalAccountId != null) {
            queryBuilder.append(" AND acc.globalAccountId = :globalAccountId");
            properties.put("globalAccountId", globalAccountId);
        }
    }

    protected void addTradenameCriteria(StringBuilder queryBuilder, Map<String, Object> properties, Tradename tradename) {
        if (tradename != null) {
            queryBuilder.append(" AND acc IN ( ")
                    .append(" SELECT DISTINCT product.facility.globalAccount FROM GaProduct product ")
                    .append(" WHERE product.franchiseguid = :franchiseId ")
                    .append(" AND product.tradenameguid = :tradenameId) ");
            properties.put("franchiseId", tradename.getFranchise().getFranchiseId());
            properties.put("tradenameId", tradename.getTradenameId());
        }
    }

    protected void addFranchiseCriteria(StringBuilder queryBuilder, Map<String, Object> properties, Franchise franchise) {
        if (franchise != null) {
            queryBuilder.append(" AND acc IN ( ")
                    .append(" SELECT DISTINCT product.facility.globalAccount FROM GaProduct product ")
                    .append(" WHERE product.franchiseguid = :franchiseId) ");
            properties.put("franchiseId", franchise.getFranchiseId());
        }
    }

    protected void addIndustryCriteria(StringBuilder queryBuilder, Map<String, Object> properties, UIndustry industry) {
        if (industry != null) {
            queryBuilder.append(" AND ind.industryId = :industry ");
            properties.put("industry", industry.getUIndustryPK().getIndustryId());
        }
    }

    protected void addCoverageCriteria(StringBuilder queryBuilder, Map<String, Object> properties, UGeographicalCoverage geographicalCoverage) {
        if (geographicalCoverage != null) {
            queryBuilder.append(" AND cov = :coverage ");
            properties.put("coverage", geographicalCoverage.getGeographicalCoverage());
        }
    }

    protected void addCountryCriteria(StringBuilder queryBuilder, Map<String, Object> properties, Country country) {
        if (country != null) {
            queryBuilder.append(" AND acc.country = :country ");
            properties.put("country", country);
        }
    }

    protected void addDateCriteria(StringBuilder queryBuilder, Map<String, Object> properties, Date date) {
        if (date != null) {
            queryBuilder.append(" AND acc.createDate >= :date ");
            queryBuilder.append(" OR acc IN ( ")
                    .append(" SELECT DISTINCT facility.globalAccount FROM GaFacility facility ")
                    .append(" WHERE facility.globalAccount = acc ")
                    .append(" AND facility.createDate >= :date )");
            properties.put("date", date);
        }
    }
}
