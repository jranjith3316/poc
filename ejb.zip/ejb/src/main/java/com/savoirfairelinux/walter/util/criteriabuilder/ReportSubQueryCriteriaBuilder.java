package com.savoirfairelinux.walter.util.criteriabuilder;

import com.savoirfairelinux.walter.dao.waltercb.ULang;
import com.savoirfairelinux.walter.model.SearchReport;

import javax.persistence.EntityManager;
import java.util.Map;

public class ReportSubQueryCriteriaBuilder extends ReportCriteriaBuilder {
		
	public ReportSubQueryCriteriaBuilder(EntityManager entityManager, SearchReport report, ULang lang) {
		super(entityManager, report, lang);
	}

    @Override
    protected void initJoinQuery(StringBuilder queryBuilder, Map<String, Object> properties) {
        queryBuilder.append(" LEFT OUTER JOIN cnt.cntTxtList as txt ");
    }

    @Override
	protected void initOrderByQuery(StringBuilder queryBuilder,	Map<String, Object> properties) {
		// Override because no need of the order by in a subquery
	}
}
