/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.globalcustomer;

import com.savoirfairelinux.walter.dao.DatabaseConstants;
import com.savoirfairelinux.walter.dao.waltercb.Cnt;
import com.savoirfairelinux.walter.dao.waltercb.Country;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.Set;

/**
 *
 * @author jderuere
 */
@Entity
@Table(name = "GLOBAL_ACCOUNT", schema = DatabaseConstants.WALTERCB_SCHEMA)
@NamedQueries({
        @NamedQuery(name = "GlobalAccount.findByName", query = "SELECT ga FROM GlobalAccount ga WHERE ga.name = :name")})
public class GlobalAccount implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(generator = "GA_ID_SEQ", strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "GA_ID_SEQ", sequenceName = "GA_ID_SEQ", schema = DatabaseConstants.WALTERCB_SCHEMA, allocationSize = 1)
    @Column(name = "GLOBAL_ACCOUNT_ID")
    private Long globalAccountId;
    @Column(name = "NAME", unique = true)
    private String name;
    @ManyToOne(optional = false)
    @JoinColumn(name = "GEOGRAPHICAL_COVERAGE", referencedColumnName = "GEOGRAPHICAL_COVERAGE_ID")
    private GeographicalCoverage coverage;
    @ManyToOne
    @JoinColumn(name = "COUNTRY_ID")
    private Country country;
    @Column(name = "WEBSITE")
    private String website;
    @Lob
    @Column(name = "BLOB_CONTENT")
    private byte[] logo;
    @OneToOne(optional = false, cascade = CascadeType.ALL, orphanRemoval = true, mappedBy = "globalAccount", fetch = FetchType.LAZY)
    private GaIndustry industry;
    @Column(name = "CREATE_DATE", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date createDate;
    @Column(name = "GA_CHAMPION", nullable = false)
    private String accountChampion;
    @Fetch(FetchMode.SUBSELECT)
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "globalAccount", orphanRemoval = true, fetch = FetchType.EAGER)
    private Set<GaFacility> facilities;
    @LazyCollection(LazyCollectionOption.EXTRA)
    @ManyToMany(cascade = { CascadeType.PERSIST, CascadeType.MERGE })
    @JoinTable(name = "GA_REPORT", schema = DatabaseConstants.WALTERCB_SCHEMA, joinColumns = { @JoinColumn(name = "GLOBAL_ACCOUNT_ID") }, inverseJoinColumns = { @JoinColumn(name = "CNT_REF") })
    private Set<Cnt> reports;

    @Transient
    private String industryType;
    @Transient
    private String geographicalCoverageName;
    @Transient
    private long linkedReportNumber;

    @PostLoad
    private void postLoad() {
        linkedReportNumber = reports.size();
    }

    public GlobalAccount() {
    }

    public Long getGlobalAccountId() {
        return globalAccountId;
    }

    public void setGlobalAccountId(Long globalAccountId) {
        this.globalAccountId = globalAccountId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public byte[] getLogo() {
        return logo;
    }

    public void setLogo(byte[] logo) {
        this.logo = logo;
    }

    public GaIndustry getIndustry() {
        return industry;
    }

    public void setIndustry(GaIndustry industry) {
        this.industry = industry;
    }

    public GeographicalCoverage getCoverage() {
        return coverage;
    }

    public void setCoverage(GeographicalCoverage coverage) {
        this.coverage = coverage;
    }

    public Country getCountry() {
        return country;
    }

    public void setCountry(Country country) {
        this.country = country;
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getAccountChampion() {
        return accountChampion;
    }

    public void setAccountChampion(String accountChampion) {
        this.accountChampion = accountChampion;
    }

    public Set<GaFacility> getFacilities() {
        return facilities;
    }

    public void setFacilities(Set<GaFacility> facilities) {
        this.facilities = facilities;
    }

    public String getIndustryType() {
        return industryType;
    }

    public void setIndustryType(String industryType) {
        this.industryType = industryType;
    }

    public String getGeographicalCoverageName() {
        return geographicalCoverageName;
    }

    public void setGeographicalCoverageName(String geographicalCoverageName) {
        this.geographicalCoverageName = geographicalCoverageName;
    }

    public long getLinkedReportNumber() {
        return linkedReportNumber;
    }

    public void setLinkedReportNumber(long linkedReportNumber) {
        this.linkedReportNumber = linkedReportNumber;
    }

    public Set<Cnt> getReports() {
        return reports;
    }

    public void setReports(Set<Cnt> reports) {
        this.reports = reports;
    }

    @Override
    public int hashCode() {
        int hash = (globalAccountId != null ? globalAccountId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof GlobalAccount)) {
            return false;
        }
        GlobalAccount other = (GlobalAccount) object;
        if ((this.globalAccountId == null && other.globalAccountId != null) || (this.globalAccountId != null && !this.globalAccountId.equals(other.globalAccountId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.globalcustomer.GlobalAccount[ globalAccountId=" + globalAccountId + " ]";
    }
}
