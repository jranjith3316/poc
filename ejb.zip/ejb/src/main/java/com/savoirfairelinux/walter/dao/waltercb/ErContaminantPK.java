/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;

/**
 *
 * @author mgubaidullin
 */
@Embeddable
public class ErContaminantPK implements Serializable {
    @Basic(optional = false)
    @NotNull
    @Column(name = "ER_ID", nullable = false)
    private long erId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "CONTAMINANT_ID", nullable = false)
    private long contaminantId;

    public ErContaminantPK() {
    }

    public ErContaminantPK(long erId, long contaminantId) {
        this.erId = erId;
        this.contaminantId = contaminantId;
    }

    public long getErId() {
        return erId;
    }

    public void setErId(long erId) {
        this.erId = erId;
    }

    public long getContaminantId() {
        return contaminantId;
    }

    public void setContaminantId(long contaminantId) {
        this.contaminantId = contaminantId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) erId;
        hash += (int) contaminantId;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ErContaminantPK)) {
            return false;
        }
        ErContaminantPK other = (ErContaminantPK) object;
        if (this.erId != other.erId) {
            return false;
        }
        if (this.contaminantId != other.contaminantId) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.ErContaminantPK[ erId=" + erId + ", contaminantId=" + contaminantId + " ]";
    }
    
}
