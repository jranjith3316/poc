/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.jasper.model;

import com.savoirfairelinux.walter.model.GLCode;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 *
 * @author jsgill
 */
public class JasperExpenseRptSearchBean implements Serializable{
  private List<JasperExpenseRptDSearchBean> jasperExpenseRptDSearchBean;

  private String fullUserName;
  private String expenseName;
  private String glCode;
  private String searchDateType;
  private String fromDate, toDate;
  private String keyword;

  public List<JasperExpenseRptDSearchBean> getJasperExpenseRptDSearchBean() {
    return jasperExpenseRptDSearchBean;
  }

  public void setJasperExpenseRptDSearchBean(List<JasperExpenseRptDSearchBean> jasperExpenseRptDSearchBean) {
    this.jasperExpenseRptDSearchBean = jasperExpenseRptDSearchBean;
  }

  public String getFullUserName() {
    return fullUserName;
  }

  public void setFullUserName(String fullUserName) {
    this.fullUserName = fullUserName;
  }

  public String getExpenseName() {
    return expenseName;
  }

  public void setExpenseName(String expenseName) {
    this.expenseName = expenseName;
  }

  public String getGlCode() {
    return glCode;
  }

  public void setGlCode(String glCode) {
    this.glCode = glCode;
  }

  public String getSearchDateType() {
    return searchDateType;
  }

  public void setSearchDateType(String searchDateType) {
    this.searchDateType = searchDateType;
  }

  public String getFromDate() {
    return fromDate;
  }

  public void setFromDate(String fromDate) {
    this.fromDate = fromDate;
  }

  public String getToDate() {
    return toDate;
  }

  public void setToDate(String toDate) {
    this.toDate = toDate;
  }

  public String getKeyword() {
    return keyword;
  }

  public void setKeyword(String keyword) {
    this.keyword = keyword;
  }

}
