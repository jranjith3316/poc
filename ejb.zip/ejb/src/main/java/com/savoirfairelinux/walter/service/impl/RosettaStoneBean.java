package com.savoirfairelinux.walter.service.impl;


import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Logger;
import javax.annotation.security.PermitAll;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import com.savoirfairelinux.walter.dao.waltercb.CbFranchise;
import com.savoirfairelinux.walter.dao.waltercb.CbFranchiseTxt;
import com.savoirfairelinux.walter.dao.waltercb.CbFranchiseTxtPK;
import com.savoirfairelinux.walter.dao.waltercb.CbTradename;
import com.savoirfairelinux.walter.dao.waltercb.CbTradenamePK;
import com.savoirfairelinux.walter.dao.waltercb.CbTradenameTxt;
import com.savoirfairelinux.walter.dao.waltercb.CbTradenameTxtPK;
import com.savoirfairelinux.walter.dao.waltercb.CntCounter;
import com.savoirfairelinux.walter.dao.waltercb.CntCounterPK;
import com.savoirfairelinux.walter.dao.waltercb.ULang;
import com.savoirfairelinux.walter.dao.waltercb.UTradenameShare;
import com.savoirfairelinux.walter.model.Franchise;
import com.savoirfairelinux.walter.model.Tradename;
import com.savoirfairelinux.walter.service.RosettaStoneBeanRemote;


@Stateless(name = "RosettaStoneBean")
@TransactionManagement(TransactionManagementType.CONTAINER)
@PermitAll
@LocalBean
public class RosettaStoneBean implements RosettaStoneBeanRemote{

    @PersistenceContext(unitName = "waltershare")
    EntityManager entityManager;
    @EJB
    SingletonBean singletonBean;
    public static final Logger LOG = Logger.getLogger(RosettaStoneBean.class.getCanonicalName());	

    @Override
    public List<CbFranchiseTxt> getCBFranchiseList() throws Exception {
        List<CbFranchiseTxt> result = null;
        try {
            result = entityManager
                    .createQuery(singletonBean.getRosettaStoneQuery("rosettaStone.franchiseList"), CbFranchiseTxt.class)
                    .getResultList();
        
	    } catch (Exception e) {
	        LOG.severe(e.getMessage());
	        throw new Exception(e.getMessage());
	    }
	    return result;
    }       
            
            
    @Override
	public  String getCBFranchiseToBeTranslated(Short franchiseId) throws Exception {
        String  result = "";
        try {
        	@SuppressWarnings("unchecked")
            List<Object[]> rows = entityManager.createNativeQuery(singletonBean.getRosettaStoneQuery("rosettaStone.franchiseToBeTranslated"))
            							.setParameter("franchiseId", franchiseId)
            							.getResultList();

            for (Object[] row : rows) {

                String langName = (String) row[1];

                if (result.equals("")) {
                    result = langName;
                } else {
                    result = result + ", " + langName;
                }
            }
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }    
    
    
    @Override
    public List<Object[]> getCbTradenameTxt(Short franchsieId, String language) throws Exception {
        List<Object[]> result = null;
        
        try {
            result = entityManager
                    .createNativeQuery(singletonBean.getRosettaStoneQuery("rosettaStone.tradeNameList"))
                    .setParameter("franchiseId", franchsieId)
                    .getResultList();

        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }    
    
    @Override
	public String getCBTradeNameToBeTranslated(Short franchiseId, Long tradenameId) throws Exception {
        String  result = "";
        try {
        	@SuppressWarnings("unchecked")
            List<Object[]> rows = entityManager.createNativeQuery(singletonBean.getRosettaStoneQuery("rosettaStone.tradeNameToBeTranslated"))
            		.setParameter("franchiseId", franchiseId)
            		.setParameter("tradenameId", tradenameId)
                    .getResultList();

            for (Object[] row : rows) {
                
                String langName = (String) row[1];

                if (result.equals("")) {
                	result = langName;
                } else {
                    result = result + ", "+ langName;
                }
            }

        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }      
    
    @Override
	public List<Object[]> getCBFranchiseEdit(Short franchiseId) throws Exception {
		List<Object[]> result = null;
        try {
        	
        	result = entityManager.createNativeQuery(singletonBean.getRosettaStoneQuery("rosettaStone.franchise.edit"))
            		.setParameter("franchiseId", franchiseId)
                    .getResultList();

        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    } 

    @Override
    public CbFranchise setCBFranchise(Short franchiseId, String createdBy) throws Exception {
    	CbFranchise result;
        try {
        	result = new CbFranchise(franchiseId);
        	result.setCreationDate(new Date());
        	result.setDisplay( 'Y' );
            result = entityManager.merge(result);
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }	

    @Override
    public CbFranchiseTxt setCBFranchiseTxt(Short franchiseId, Long langId, String description) throws Exception {
    	//TODO: need to check description is null delete the row else insert/update table
    	CbFranchiseTxt result;
    	CbFranchiseTxtPK cbFranchiseTxtPK = new CbFranchiseTxtPK(franchiseId, langId);
        try {
            result = entityManager.find(CbFranchiseTxt.class, cbFranchiseTxtPK);
            if (result == null) {
                result = new CbFranchiseTxt(cbFranchiseTxtPK);
            }
            result.setDescription(description);
            result = entityManager.merge(result);
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }	    

    @Override
	public Short getCBFranchiseSeq() throws Exception {
    	Short result = 0;
    	Object temp = null;
        try {
        	
        	temp = entityManager.createNativeQuery(singletonBean.getRosettaStoneQuery("rosettaStone.franchise.sequence"))
                    .getSingleResult();
        	result = Short.parseShort(temp.toString());

        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }     
    
    @Override
    public CbTradenameTxt getCBTradeNameTxt(Short franchiseId, long tradenameId ) throws Exception {
        CbTradenameTxt result = null;
        try {
            result = entityManager
                    .createQuery(singletonBean.getRosettaStoneQuery("rosettaStone.tradeName"), CbTradenameTxt.class)
                    .setParameter("franchiseId", franchiseId)
                    .setParameter("tradenameId", tradenameId)
                    .getSingleResult();
        
	    } catch (Exception e) {
	        LOG.severe(e.getMessage());
	        throw new Exception(e.getMessage());
	    }
	    return result;
    }       
        
    @Override
    public List<Object[]> getCBTradeNameEdit(Short franchiseId, long tradenameId ) throws Exception {
		List<Object[]> result = null;
        try {

        	result = entityManager.createNativeQuery(singletonBean.getRosettaStoneQuery("rosettaStone.tradename.edit"))
        			.setParameter("franchiseId", franchiseId)
        			.setParameter("tradenameId", tradenameId)
                    .getResultList();

        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }     

    @Override
    public Long getCBTradeNameIdSeq() throws Exception{
    	Long result = 0L;
    	Object temp = null;
        try {
        	
        	temp = entityManager.createNativeQuery(singletonBean.getRosettaStoneQuery("rosettaStone.tradeName.sequence"))
                    .getSingleResult();
        	result = Long.parseLong(temp.toString());

        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
	public CbTradename setCBTradename(Short franchiseId, Long tradenameId, String createdBy) throws Exception{
		CbTradename result;
        try {
        	result = new CbTradename(tradenameId, franchiseId);
        	result.setCreationDate(new Date());
        	result.setDisplay( 'Y' );
        	result.setCreatedBy(createdBy);
            result = entityManager.merge(result);
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
	}
    @Override
	public CbTradenameTxt setCBTradenameTxt(Short franchiseId, Long tradenameId, Long langId, String description) throws Exception{
		CbTradenameTxt result;
    	CbTradenameTxtPK cbTradenameTxtPK = new CbTradenameTxtPK(tradenameId, franchiseId, langId);
        try {
            result = entityManager.find(CbTradenameTxt.class, cbTradenameTxtPK);
            if (result == null) {
                result = new CbTradenameTxt(cbTradenameTxtPK);
            }
            result.setDescription(description);
            result = entityManager.merge(result);
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
	}
    
    @Override
	public CbTradename deleteCBTradename(Short franchiseId, Long tradenameId) throws Exception{
    	CbTradename result;
    	CbTradenamePK cbTradenamePK = new CbTradenamePK(tradenameId, franchiseId);
        try {
            result = entityManager.find(CbTradename.class, cbTradenamePK);
            if (result == null) {
                result = new CbTradename(cbTradenamePK);
            }
            result.setDisplay('N');
            result = entityManager.merge(result);
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    public List<Object[]> getListTradeShare() throws Exception {
		List<Object[]> result = null;
        try {

        	result = entityManager.createNativeQuery(singletonBean.getRosettaStoneQuery("rosettaStone.tradeShare"))
                    .getResultList();

        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }   

    @Override
    public List<Franchise> getFranchises(String organization) throws Exception {
        List<Franchise> result = new ArrayList<Franchise>();
        String queryKey = organization.equals("walter") ? "rosettaStone.walter.franchises" : "rosettaStone.biocircle.franchises";
        try {
            TypedQuery<Object[]> query = entityManager.createQuery(singletonBean.getRosettaStoneQuery(queryKey), Object[].class);
            List<Object[]> rows = query.getResultList();
            for (Object[] row : rows) {
                String franchiseId = String.valueOf(row[0]);
                String description = String.valueOf(row[1]);
                result.add(new Franchise(franchiseId, description));
            }
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }    
    
    @Override
    @Interceptors({DebugInterceptor.class})
    public List<Tradename> getTradenames(String organization) throws Exception {
        List<Tradename> result = new ArrayList<Tradename>();
        String queryKey = organization.equals("walter") ? "rosettaStone.walter.tradenames" : "rosettaStone.biocircle.tradenames";
        try {
            TypedQuery<Object[]> query =  entityManager.createQuery(singletonBean.getRosettaStoneQuery(queryKey), Object[].class);

            List<Object[]> rows = query.getResultList();
            result = new ArrayList<Tradename>(rows.size());
            for (Object[] row : rows) {
                String tradenameId = String.valueOf(row[0]);
                String franchiseId = String.valueOf(row[1]);
                String franchiseDesc = String.valueOf(row[2]);
                String description = String.valueOf(row[3]);
                result.add(new Tradename(tradenameId, new Franchise(franchiseId, franchiseDesc), description));
            }
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    public UTradenameShare setUTradenameShare(UTradenameShare utradename) throws Exception{
    	UTradenameShare result;
    	// need to check if the relation exist before create it
        try {
            result = entityManager.find(UTradenameShare.class, utradename.getId());
            if (result == null) {
                result = new UTradenameShare(getUTradenameShareSeq());
            }
            result.setCbFranchiseId(utradename.getCbFranchiseId() );
            result.setCbTradenameId(utradename.getCbTradenameId());
            result.setWFranchiseGuid(utradename.getWFranchiseGuid());
            result.setWTradenameGuid(utradename.getWTradenameGuid());
            result = entityManager.merge(result);
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    public BigDecimal getUTradenameShareSeq() throws Exception {
    	BigDecimal result = new BigDecimal(0);
    	Object temp = null;
        try {
        	
        	temp = entityManager.createNativeQuery(singletonBean.getRosettaStoneQuery("rosettaStone.UTradenameShare.sequence"))
                    .getSingleResult();
        	result = result = new BigDecimal(temp.toString());

        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }       

    public void removeUTradenameShare(UTradenameShare utradenameShare) throws Exception{
    	UTradenameShare result;
    	try{
    		result = entityManager.find(UTradenameShare.class, utradenameShare.getId());
    		entityManager.remove(result);
    	
    	}catch (Exception e) {
	        LOG.severe(e.getMessage());
	        throw new Exception(e.getMessage());
	    }
    }

}
