/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants;
import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Size;

/**
 *
 * @author jderuere
 */
@Entity
@Table(name = "DISTRIBUTOR", schema = DatabaseConstants.WALTERCB_SCHEMA)
@NamedQueries({
  @NamedQuery(name = "Distributor.findAll", query = "SELECT d FROM Distributor d")})
public class Distributor implements Serializable {

  private static final long serialVersionUID = 1L;
  @Id
  @GeneratedValue(generator = "DISTRIBUTOR_ID_SEQ", strategy = GenerationType.SEQUENCE)
  @SequenceGenerator(name = "DISTRIBUTOR_ID_SEQ", sequenceName = "DISTRIBUTOR_ID_SEQ", schema = DatabaseConstants.WALTERCB_SCHEMA, allocationSize = 1)
  @Column(name = "ID")
  private Long id;
  @Column(name = "NAME")
  private String name;
  @Column(name = "CUST_NUM", unique = true)
  private String custNum;
  @Column(name = "CONTACT_NAME")
  private String contactName;
  @Column(name = "ADDRESS", nullable = false)
  private String address;
  @Size(max = 40)
  @Column(name = "CITY", nullable = false)
  private String city;
  @Column(name = "PROVINCE")
  private String province;
  @Size(max = 10)
  @Column(name = "POSTAL_CODE")
  private String postalCode;
  @Column(name = "PHONE")
  private String phone;
  @Column(name = "EMAIL")
  private String email;
  @Column(name = "DEPARTMENT")
  private String department;
  @Column(name = "SHIP_NUM")
  private String shipNum;
  @ManyToOne
  @JoinColumn(name = "COUNTRY_ID", nullable = false)
  private Country country;

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getCustNum() {
    return custNum;
  }

  public void setCustNum(String custNum) {
    this.custNum = custNum;
  }

  public String getContactName() {
    return contactName;
  }

  public void setContactName(String contactName) {
    this.contactName = contactName;
  }

  public String getAddress() {
    return address;
  }

  public void setAddress(String address) {
    this.address = address;
  }

  public String getCity() {
    return city;
  }

  public void setCity(String city) {
    this.city = city;
  }

  public String getProvince() {
    return province;
  }

  public void setProvince(String province) {
    this.province = province;
  }

  public String getPostalCode() {
    return postalCode;
  }

  public void setPostalCode(String postalCode) {
    this.postalCode = postalCode;
  }

  public String getPhone() {
    return phone;
  }

  public void setPhone(String phone) {
    this.phone = phone;
  }

  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public String getDepartment() {
    return department;
  }

  public void setDepartment(String department) {
    this.department = department;
  }

  public Country getCountry() {
    return country;
  }

  public void setCountry(Country country) {
    this.country = country;
  }

  public String getDisplayName() {
    return new StringBuilder(name).append(" | ").append(address).append(" | ").append(city).toString();
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (id != null ? id.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof Distributor)) {
      return false;
    }
    Distributor other = (Distributor) object;
    if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.waltercb.Distributor[ id=" + id + " ]";
  }
}
