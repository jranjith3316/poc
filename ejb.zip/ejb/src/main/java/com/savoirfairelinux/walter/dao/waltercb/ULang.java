/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "U_LANG", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "ULang.findAll", query = "SELECT u FROM ULang u ORDER BY u.langName"),
    @NamedQuery(name = "ULang.findAll.orderBy.langId", query = "SELECT u FROM ULang u ORDER BY u.langId"),
    @NamedQuery(name = "ULang.findByLangId", query = "SELECT u FROM ULang u WHERE u.langId = :langId"),
    @NamedQuery(name = "ULang.findByLangName", query = "SELECT u FROM ULang u WHERE u.langName = :langName"),
    @NamedQuery(name = "ULang.findByLangAbbreviation", query = "SELECT u FROM ULang u WHERE u.langAbbreviation = :langAbbreviation"),
    @NamedQuery(name = "ULang.findByHttpAbbreviation", query = "SELECT u FROM ULang u WHERE u.httpAbbreviation = :httpAbbreviation"),
    @NamedQuery(name = "ULang.findByNlsTerritory", query = "SELECT u FROM ULang u WHERE u.nlsTerritory = :nlsTerritory"),
    @NamedQuery(name = "ULang.findByIdbAbbreviation", query = "SELECT u FROM ULang u WHERE u.idbAbbreviation = :idbAbbreviation")})
public class ULang implements Serializable {
	
	public static final long ENGLISH_ID = 1;
	
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "LANG_ID")
    private Long langId;
    @Size(max = 20)
    @Column(name = "LANG_NAME")
    private String langName;
    @Size(max = 3)
    @Column(name = "LANG_ABBREVIATION")
    private String langAbbreviation;
    @Size(max = 5)
    @Column(name = "HTTP_ABBREVIATION")
    private String httpAbbreviation;
    @Size(max = 20)
    @Column(name = "NLS_TERRITORY")
    private String nlsTerritory;
    @Size(max = 3)
    @Column(name = "IDB_ABBREVIATION")
    private String idbAbbreviation;

    public ULang() {
    }

    public ULang(Long langId) {
        this.langId = langId;
    }

    public Long getLangId() {
        return langId;
    }

    public void setLangId(Long langId) {
        this.langId = langId;
    }

    public String getLangName() {
        return langName;
    }

    public void setLangName(String langName) {
        this.langName = langName;
    }

    public String getLangAbbreviation() {
        return langAbbreviation;
    }

    public void setLangAbbreviation(String langAbbreviation) {
        this.langAbbreviation = langAbbreviation;
    }

    public String getHttpAbbreviation() {
        return httpAbbreviation;
    }

    public void setHttpAbbreviation(String httpAbbreviation) {
        this.httpAbbreviation = httpAbbreviation;
    }

    public String getNlsTerritory() {
        return nlsTerritory;
    }

    public void setNlsTerritory(String nlsTerritory) {
        this.nlsTerritory = nlsTerritory;
    }

    public String getIdbAbbreviation() {
        return idbAbbreviation;
    }

    public void setIdbAbbreviation(String idbAbbreviation) {
        this.idbAbbreviation = idbAbbreviation;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (langId != null ? langId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ULang)) {
            return false;
        }
        ULang other = (ULang) object;
        if ((this.langId == null && other.langId != null) || (this.langId != null && !this.langId.equals(other.langId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.ULang[ langId=" + langId + " ]";
    }
    
}
