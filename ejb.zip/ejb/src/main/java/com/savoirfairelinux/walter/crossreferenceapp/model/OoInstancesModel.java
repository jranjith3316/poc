/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.crossreferenceapp.model;

import java.io.Serializable;

/**
 *
 * @author jsgill
 */
public class OoInstancesModel implements Serializable{
  private static final long serialVersionUID = 3511338233023397895L;
  private String instanceguid;
  private String instancename;
  private String instancealternatekey;
  private String classguid;

  public OoInstancesModel() {
  }

  public OoInstancesModel(String instanceguid, String instancename, String instancealternatekey, String classguid) {
    this.instanceguid = instanceguid;
    this.instancename = instancename;
    this.instancealternatekey = instancealternatekey;
    this.classguid = classguid;
  }

  public String getInstanceguid() {
    return instanceguid;
  }

  public void setInstanceguid(String instanceguid) {
    this.instanceguid = instanceguid;
  }

  public String getInstancename() {
    return instancename;
  }

  public void setInstancename(String instancename) {
    this.instancename = instancename;
  }

  public String getInstancealternatekey() {
    return instancealternatekey;
  }

  public void setInstancealternatekey(String instancealternatekey) {
    this.instancealternatekey = instancealternatekey;
  }

  public String getClassguid() {
    return classguid;
  }

  public void setClassguid(String classguid) {
    this.classguid = classguid;
  }

}
