/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import java.util.Set;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "U_COMPETITOR", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "UCompetitor.findAll", query = "SELECT u FROM UCompetitor u ORDER BY u.competitorName"),
    @NamedQuery(name = "UCompetitor.findByCompetitorId", query = "SELECT u FROM UCompetitor u WHERE u.competitorId = :competitorId"),
    @NamedQuery(name = "UCompetitor.findByCompetitorName", query = "SELECT u FROM UCompetitor u WHERE u.competitorName = :competitorName")})
public class UCompetitor implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "COMPETITOR_ID")
    private Long competitorId;
    @Size(max = 100)
    @Column(name = "COMPETITOR_NAME")
    private String competitorName;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "competitor", orphanRemoval = true)
    private Set<UCompetitorBrand> productBrands;

    public UCompetitor() {
    }

    public UCompetitor(Long competitorId) {
        this.competitorId = competitorId;
    }

    public Long getCompetitorId() {
        return competitorId;
    }

    public void setCompetitorId(Long competitorId) {
        this.competitorId = competitorId;
    }

    public String getCompetitorName() {
        return competitorName;
    }

    public void setCompetitorName(String competitorName) {
        this.competitorName = competitorName;
    }

    public Set<UCompetitorBrand> getProductBrands() {
        return productBrands;
    }

    public void setProductBrands(Set<UCompetitorBrand> productBrands) {
        this.productBrands = productBrands;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (competitorId != null ? competitorId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof UCompetitor)) {
            return false;
        }
        UCompetitor other = (UCompetitor) object;
        if (this.getCompetitorId() == null && other.getCompetitorId() == null) {
            return this == other;
        }
        if ((this.competitorId == null && other.competitorId != null) || (this.competitorId != null && !this.competitorId.equals(other.competitorId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.UCompetitor[ competitorId=" + competitorId + " ]";
    }
    
}
