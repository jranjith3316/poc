/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.model;

import java.io.Serializable;

/**
 *
 * @author jsgill
 */
public class AnalysisSolRptCreated implements Serializable{
  String creatorUserName;
  int nbrCreated;

  public AnalysisSolRptCreated(String creatorUserName, int nbrCreated) {
    this.creatorUserName = creatorUserName;
    this.nbrCreated = nbrCreated;
  }

  public String getCreatorUserName() {
    return creatorUserName;
  }

  public void setCreatorUserName(String creatorUserName) {
    this.creatorUserName = creatorUserName;
  }

  public int getNbrCreated() {
    return nbrCreated;
  }

  public void setNbrCreated(int nbrCreated) {
    this.nbrCreated = nbrCreated;
  }
  
  @Override
  public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		} else if (this == obj) {
			return true;
		} else if (creatorUserName == ((AnalysisSolRptCreated) obj).getCreatorUserName()) {
			return true;
		}
		return false;
	}
  
}
