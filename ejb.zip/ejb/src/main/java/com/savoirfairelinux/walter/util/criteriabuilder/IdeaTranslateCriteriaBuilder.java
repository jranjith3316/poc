package com.savoirfairelinux.walter.util.criteriabuilder;

import com.savoirfairelinux.walter.dao.waltercb.IdeaTranslate;

import javax.persistence.EntityManager;
import java.util.Map;

public class IdeaTranslateCriteriaBuilder extends AbstractCriteriaBuilder<IdeaTranslate> {

	private String translatorName;
    private String organization;

	public IdeaTranslateCriteriaBuilder(EntityManager entityManager, String translatorName, String organization) {
		super(entityManager, IdeaTranslate.class);
		this.translatorName = translatorName;
        this.organization = organization;
	}
	
	@Override
	protected void initQuery(StringBuilder queryBuilder, Map<String, Object> properties) {
		queryBuilder.append("SELECT idtr FROM IdeaTranslate idtr ");
	}
	
	@Override
	protected void initJoinQuery(StringBuilder queryBuilder, Map<String, Object> properties) {
		queryBuilder.append(" LEFT OUTER JOIN idtr.idea.ideaTxtSet txt ");
	}
	
	@Override
	protected void initOrderByQuery(StringBuilder queryBuilder,	Map<String, Object> properties) {
		queryBuilder.append(" ORDER BY idtr.idea.createdDate ");
	}

	@Override
	protected void buildSpecificQuery(StringBuilder queryBuilder, Map<String, Object> properties) {
		queryBuilder.append(" WHERE idtr.idea.cancelDate IS NULL ")
			.append(" AND idtr.receivedFromTr IS NULL ")
			.append(" AND idtr.sentToTr IS NOT NULL ")
			.append(" AND idtr.idea.submitedDate IS NOT NULL ")
			.append(" AND idtr.idea.publishedDate IS NULL ");

        if (organization != null) {
            queryBuilder.append(" AND idtr.idea.organization = :organization ");
            properties.put("organization", organization);
        }
		addLikeCriteria(queryBuilder, "idtr.translatorUserName", translatorName != null ? translatorName.toUpperCase() : null);
	}
}
