package com.savoirfairelinux.walter.model;

import com.savoirfairelinux.walter.dao.waltercb.UCompetitor;
import com.savoirfairelinux.walter.dao.waltercb.UCompetitorBrand;
import com.savoirfairelinux.walter.dao.waltercb.UCompetitorProduct;

import java.io.Serializable;
import java.util.Date;

public class SearchProductivityResult implements Serializable {

    private Long id;
    private PrApplication application;
    private UCompetitor competitor;
    private UCompetitorBrand competitorBrand;
    private UCompetitorProduct competitorProduct;
    private Tradename walterTradename;
    private PrWalterProduct walterProduct;
    private Date fromDate;
    private Date toDate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public PrApplication getApplication() {
        return application;
    }

    public void setApplication(PrApplication application) {
        this.application = application;
    }

    public UCompetitor getCompetitor() {
        return competitor;
    }

    public void setCompetitor(UCompetitor competitor) {
        this.competitor = competitor;
    }

    public UCompetitorBrand getCompetitorBrand() {
        return competitorBrand;
    }

    public void setCompetitorBrand(UCompetitorBrand competitorBrand) {
        this.competitorBrand = competitorBrand;
    }

    public UCompetitorProduct getCompetitorProduct() {
        return competitorProduct;
    }

    public void setCompetitorProduct(UCompetitorProduct competitorProduct) {
        this.competitorProduct = competitorProduct;
    }

    public Tradename getWalterTradename() {
        return walterTradename;
    }

    public void setWalterTradename(Tradename walterTradename) {
        this.walterTradename = walterTradename;
    }

    public PrWalterProduct getWalterProduct() {
        return walterProduct;
    }

    public void setWalterProduct(PrWalterProduct walterProduct) {
        this.walterProduct = walterProduct;
    }

    public Date getFromDate() {
        return fromDate;
    }

    public void setFromDate(Date fromDate) {
        this.fromDate = fromDate;
    }

    public Date getToDate() {
        return toDate;
    }

    public void setToDate(Date toDate) {
        this.toDate = toDate;
    }
}
