/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "U_CONTAMINANT", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "UContaminant.findAll", query = "SELECT u FROM UContaminant u"),
    @NamedQuery(name = "UContaminant.findByContaminantId", query = "SELECT u FROM UContaminant u WHERE u.uContaminantPK.contaminantId = :contaminantId"),
    @NamedQuery(name = "UContaminant.findByLangId", query = "SELECT u FROM UContaminant u WHERE u.uContaminantPK.langId = :langId ORDER BY u.contaminantDesc"),
    @NamedQuery(name = "UContaminant.findByContaminantDesc", query = "SELECT u FROM UContaminant u WHERE u.contaminantDesc = :contaminantDesc")})
public class UContaminant implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected UContaminantPK uContaminantPK;
    @Size(max = 100)
    @Column(name = "CONTAMINANT_DESC")
    private String contaminantDesc;

    public UContaminant() {
    }

    public UContaminant(UContaminantPK uContaminantPK) {
        this.uContaminantPK = uContaminantPK;
    }

    public UContaminant(long contaminantId, long langId) {
        this.uContaminantPK = new UContaminantPK(contaminantId, langId);
    }

    public UContaminantPK getUContaminantPK() {
        return uContaminantPK;
    }

    public void setUContaminantPK(UContaminantPK uContaminantPK) {
        this.uContaminantPK = uContaminantPK;
    }

    public String getContaminantDesc() {
        return contaminantDesc;
    }

    public void setContaminantDesc(String contaminantDesc) {
        this.contaminantDesc = contaminantDesc;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (uContaminantPK != null ? uContaminantPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof UContaminant)) {
            return false;
        }
        UContaminant other = (UContaminant) object;
        if ((this.uContaminantPK == null && other.uContaminantPK != null) || (this.uContaminantPK != null && !this.uContaminantPK.equals(other.uContaminantPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.UContaminant[ uContaminantPK=" + uContaminantPK + " ]";
    }
    
}
