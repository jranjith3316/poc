/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.walterproductivity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "REPORTS_PRODUCTIVITY", catalog = "", schema = "WALTERPRODUCTIVITY")
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "ReportsProductivity.findAll", query = "SELECT r FROM ReportsProductivity r"),
  @NamedQuery(name = "ReportsProductivity.findById", query = "SELECT r FROM ReportsProductivity r WHERE r.id = :id"),
  @NamedQuery(name = "ReportsProductivity.findByActive", query = "SELECT r FROM ReportsProductivity r WHERE r.active = :active"),
  @NamedQuery(name = "ReportsProductivity.findByAnnualCuttingRequirements", query = "SELECT r FROM ReportsProductivity r WHERE r.annualCuttingRequirements = :annualCuttingRequirements"),
  @NamedQuery(name = "ReportsProductivity.findByAnnualRemovalRequirements", query = "SELECT r FROM ReportsProductivity r WHERE r.annualRemovalRequirements = :annualRemovalRequirements"),
  @NamedQuery(name = "ReportsProductivity.findByComAnnualBackingPadsCost", query = "SELECT r FROM ReportsProductivity r WHERE r.comAnnualBackingPadsCost = :comAnnualBackingPadsCost"),
  @NamedQuery(name = "ReportsProductivity.findByComAnnualDiscsCost", query = "SELECT r FROM ReportsProductivity r WHERE r.comAnnualDiscsCost = :comAnnualDiscsCost"),
  @NamedQuery(name = "ReportsProductivity.findByComAnnualLaborCost", query = "SELECT r FROM ReportsProductivity r WHERE r.comAnnualLaborCost = :comAnnualLaborCost"),
  @NamedQuery(name = "ReportsProductivity.findByComAnnualOperationCost", query = "SELECT r FROM ReportsProductivity r WHERE r.comAnnualOperationCost = :comAnnualOperationCost"),
  @NamedQuery(name = "ReportsProductivity.findByComAnnualOperationTime", query = "SELECT r FROM ReportsProductivity r WHERE r.comAnnualOperationTime = :comAnnualOperationTime"),
  @NamedQuery(name = "ReportsProductivity.findByComAnnualTotalProdCost", query = "SELECT r FROM ReportsProductivity r WHERE r.comAnnualTotalProdCost = :comAnnualTotalProdCost"),
  @NamedQuery(name = "ReportsProductivity.findByComAnnualTotalTime", query = "SELECT r FROM ReportsProductivity r WHERE r.comAnnualTotalTime = :comAnnualTotalTime"),
  @NamedQuery(name = "ReportsProductivity.findByComAvgTimePerCut", query = "SELECT r FROM ReportsProductivity r WHERE r.comAvgTimePerCut = :comAvgTimePerCut"),
  @NamedQuery(name = "ReportsProductivity.findByComDurability", query = "SELECT r FROM ReportsProductivity r WHERE r.comDurability = :comDurability"),
  @NamedQuery(name = "ReportsProductivity.findByComNumberCutPerDisc", query = "SELECT r FROM ReportsProductivity r WHERE r.comNumberCutPerDisc = :comNumberCutPerDisc"),
  @NamedQuery(name = "ReportsProductivity.findByComRemovalRate", query = "SELECT r FROM ReportsProductivity r WHERE r.comRemovalRate = :comRemovalRate"),
  @NamedQuery(name = "ReportsProductivity.findByComTimePerWheelChangeOver", query = "SELECT r FROM ReportsProductivity r WHERE r.comTimePerWheelChangeOver = :comTimePerWheelChangeOver"),
  @NamedQuery(name = "ReportsProductivity.findByComTotalMaterialRemoved", query = "SELECT r FROM ReportsProductivity r WHERE r.comTotalMaterialRemoved = :comTotalMaterialRemoved"),
  @NamedQuery(name = "ReportsProductivity.findByLaborCostSaving", query = "SELECT r FROM ReportsProductivity r WHERE r.laborCostSaving = :laborCostSaving"),
  @NamedQuery(name = "ReportsProductivity.findByLaborCostSavingPercentage", query = "SELECT r FROM ReportsProductivity r WHERE r.laborCostSavingPercentage = :laborCostSavingPercentage"),
  @NamedQuery(name = "ReportsProductivity.findByProdCostSaving", query = "SELECT r FROM ReportsProductivity r WHERE r.prodCostSaving = :prodCostSaving"),
  @NamedQuery(name = "ReportsProductivity.findByProdCostSavingPercentage", query = "SELECT r FROM ReportsProductivity r WHERE r.prodCostSavingPercentage = :prodCostSavingPercentage"),
  @NamedQuery(name = "ReportsProductivity.findByTotalCostSaving", query = "SELECT r FROM ReportsProductivity r WHERE r.totalCostSaving = :totalCostSaving"),
  @NamedQuery(name = "ReportsProductivity.findByTotalCostSavingPercentage", query = "SELECT r FROM ReportsProductivity r WHERE r.totalCostSavingPercentage = :totalCostSavingPercentage"),
  @NamedQuery(name = "ReportsProductivity.findByWalAnnualDiscConsumption", query = "SELECT r FROM ReportsProductivity r WHERE r.walAnnualDiscConsumption = :walAnnualDiscConsumption"),
  @NamedQuery(name = "ReportsProductivity.findByWalAnnualDiscsCost", query = "SELECT r FROM ReportsProductivity r WHERE r.walAnnualDiscsCost = :walAnnualDiscsCost"),
  @NamedQuery(name = "ReportsProductivity.findByWalAnnualLaborCost", query = "SELECT r FROM ReportsProductivity r WHERE r.walAnnualLaborCost = :walAnnualLaborCost"),
  @NamedQuery(name = "ReportsProductivity.findByWalAnnualOperationCost", query = "SELECT r FROM ReportsProductivity r WHERE r.walAnnualOperationCost = :walAnnualOperationCost"),
  @NamedQuery(name = "ReportsProductivity.findByWalAnnualOperationTime", query = "SELECT r FROM ReportsProductivity r WHERE r.walAnnualOperationTime = :walAnnualOperationTime"),
  @NamedQuery(name = "ReportsProductivity.findByWalAnnualTotalProdCost", query = "SELECT r FROM ReportsProductivity r WHERE r.walAnnualTotalProdCost = :walAnnualTotalProdCost"),
  @NamedQuery(name = "ReportsProductivity.findByWalAnnualTotalTime", query = "SELECT r FROM ReportsProductivity r WHERE r.walAnnualTotalTime = :walAnnualTotalTime"),
  @NamedQuery(name = "ReportsProductivity.findByWalAvgTimePerCut", query = "SELECT r FROM ReportsProductivity r WHERE r.walAvgTimePerCut = :walAvgTimePerCut"),
  @NamedQuery(name = "ReportsProductivity.findByWalBackingPadQuantity", query = "SELECT r FROM ReportsProductivity r WHERE r.walBackingPadQuantity = :walBackingPadQuantity"),
  @NamedQuery(name = "ReportsProductivity.findByWalDurability", query = "SELECT r FROM ReportsProductivity r WHERE r.walDurability = :walDurability"),
  @NamedQuery(name = "ReportsProductivity.findByWalNumberCutPerDisc", query = "SELECT r FROM ReportsProductivity r WHERE r.walNumberCutPerDisc = :walNumberCutPerDisc"),
  @NamedQuery(name = "ReportsProductivity.findByWalRemovalRate", query = "SELECT r FROM ReportsProductivity r WHERE r.walRemovalRate = :walRemovalRate"),
  @NamedQuery(name = "ReportsProductivity.findByWalTimePerWheelChangeOver", query = "SELECT r FROM ReportsProductivity r WHERE r.walTimePerWheelChangeOver = :walTimePerWheelChangeOver"),
  @NamedQuery(name = "ReportsProductivity.findByWalTotalMaterialRemoved", query = "SELECT r FROM ReportsProductivity r WHERE r.walTotalMaterialRemoved = :walTotalMaterialRemoved")})
public class ReportsProductivity implements Serializable {
  @Column(name = "ANN_DIST_REQ_IMP")
  private Double annDistReqImp;
  @Column(name = "ANN_DIST_REQ_METRIC")
  private Double annDistReqMetric;
  @Column(name = "NB_PIECES_DONE")
  private Long nbPiecesDone;
  private static final long serialVersionUID = 1L;
  @Id
  @Basic(optional = false)
  @NotNull
  @Size(min = 1, max = 255)
  @Column(name = "ID")
  private String id;
  @Column(name = "ACTIVE")
  private Short active;
  @Column(name = "ANNUAL_CUTTING_REQUIREMENTS")
  private Long annualCuttingRequirements;
  // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
  @Column(name = "ANNUAL_REMOVAL_REQUIREMENTS")
  private Double annualRemovalRequirements;
  @Column(name = "COM_ANNUAL_BACKING_PADS_COST")
  private Long comAnnualBackingPadsCost;
  @Column(name = "COM_ANNUAL_DISCS_COST")
  private Long comAnnualDiscsCost;
  @Column(name = "COM_ANNUAL_LABOR_COST")
  private Long comAnnualLaborCost;
  @Column(name = "COM_ANNUAL_OPERATION_COST")
  private Long comAnnualOperationCost;
  @Column(name = "COM_ANNUAL_OPERATION_TIME")
  private Long comAnnualOperationTime;
  @Column(name = "COM_ANNUAL_TOTAL_PROD_COST")
  private Long comAnnualTotalProdCost;
  @Column(name = "COM_ANNUAL_TOTAL_TIME")
  private Long comAnnualTotalTime;
  @Column(name = "COM_AVG_TIME_PER_CUT")
  private Double comAvgTimePerCut;
  @Column(name = "COM_DURABILITY")
  private Long comDurability;
  @Column(name = "COM_NUMBER_CUT_PER_DISC")
  private Long comNumberCutPerDisc;
  @Column(name = "COM_REMOVAL_RATE")
  private Long comRemovalRate;
  @Column(name = "COM_TIME_PER_WHEEL_CHANGE_OVER")
  private Long comTimePerWheelChangeOver;
  @Column(name = "COM_TOTAL_MATERIAL_REMOVED")
  private Double comTotalMaterialRemoved;
  @Column(name = "LABOR_COST_SAVING")
  private Long laborCostSaving;
  @Column(name = "LABOR_COST_SAVING_PERCENTAGE")
  private Long laborCostSavingPercentage;
  @Column(name = "PROD_COST_SAVING")
  private Long prodCostSaving;
  @Column(name = "PROD_COST_SAVING_PERCENTAGE")
  private Long prodCostSavingPercentage;
  @Column(name = "TOTAL_COST_SAVING")
  private Long totalCostSaving;
  @Column(name = "TOTAL_COST_SAVING_PERCENTAGE")
  private Long totalCostSavingPercentage;
  @Column(name = "WAL_ANNUAL_DISC_CONSUMPTION")
  private Long walAnnualDiscConsumption;
  @Column(name = "WAL_ANNUAL_DISCS_COST")
  private Long walAnnualDiscsCost;
  @Column(name = "WAL_ANNUAL_LABOR_COST")
  private Long walAnnualLaborCost;
  @Column(name = "WAL_ANNUAL_OPERATION_COST")
  private Long walAnnualOperationCost;
  @Column(name = "WAL_ANNUAL_OPERATION_TIME")
  private Long walAnnualOperationTime;
  @Column(name = "WAL_ANNUAL_TOTAL_PROD_COST")
  private Long walAnnualTotalProdCost;
  @Column(name = "WAL_ANNUAL_TOTAL_TIME")
  private Long walAnnualTotalTime;
  @Column(name = "WAL_AVG_TIME_PER_CUT")
  private Double walAvgTimePerCut;
  @Column(name = "WAL_BACKING_PAD_QUANTITY")
  private Long walBackingPadQuantity;
  @Column(name = "WAL_DURABILITY")
  private Long walDurability;
  @Column(name = "WAL_NUMBER_CUT_PER_DISC")
  private Long walNumberCutPerDisc;
  @Column(name = "WAL_REMOVAL_RATE")
  private Long walRemovalRate;
  @Column(name = "WAL_TIME_PER_WHEEL_CHANGE_OVER")
  private Long walTimePerWheelChangeOver;
  @Column(name = "WAL_TOTAL_MATERIAL_REMOVED")
  private Double walTotalMaterialRemoved;
  @JoinColumn(name = "REPORT_ID", referencedColumnName = "ID")
  @OneToOne
  private Reports reportId;

  public ReportsProductivity() {
  }

  public ReportsProductivity(String id) {
    this.id = id;
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public Short getActive() {
    return active;
  }

  public void setActive(Short active) {
    this.active = active;
  }

  public Long getAnnualCuttingRequirements() {
    return annualCuttingRequirements;
  }

  public void setAnnualCuttingRequirements(Long annualCuttingRequirements) {
    this.annualCuttingRequirements = annualCuttingRequirements;
  }

  public Double getAnnualRemovalRequirements() {
    return annualRemovalRequirements;
  }

  public void setAnnualRemovalRequirements(Double annualRemovalRequirements) {
    this.annualRemovalRequirements = annualRemovalRequirements;
  }

  public Long getComAnnualBackingPadsCost() {
    return comAnnualBackingPadsCost;
  }

  public void setComAnnualBackingPadsCost(Long comAnnualBackingPadsCost) {
    this.comAnnualBackingPadsCost = comAnnualBackingPadsCost;
  }

  public Long getComAnnualDiscsCost() {
    return comAnnualDiscsCost;
  }

  public void setComAnnualDiscsCost(Long comAnnualDiscsCost) {
    this.comAnnualDiscsCost = comAnnualDiscsCost;
  }

  public Long getComAnnualLaborCost() {
    return comAnnualLaborCost;
  }

  public void setComAnnualLaborCost(Long comAnnualLaborCost) {
    this.comAnnualLaborCost = comAnnualLaborCost;
  }

  public Long getComAnnualOperationCost() {
    return comAnnualOperationCost;
  }

  public void setComAnnualOperationCost(Long comAnnualOperationCost) {
    this.comAnnualOperationCost = comAnnualOperationCost;
  }

  public Long getComAnnualOperationTime() {
    return comAnnualOperationTime;
  }

  public void setComAnnualOperationTime(Long comAnnualOperationTime) {
    this.comAnnualOperationTime = comAnnualOperationTime;
  }

  public Long getComAnnualTotalProdCost() {
    return comAnnualTotalProdCost;
  }

  public void setComAnnualTotalProdCost(Long comAnnualTotalProdCost) {
    this.comAnnualTotalProdCost = comAnnualTotalProdCost;
  }

  public Long getComAnnualTotalTime() {
    return comAnnualTotalTime;
  }

  public void setComAnnualTotalTime(Long comAnnualTotalTime) {
    this.comAnnualTotalTime = comAnnualTotalTime;
  }

  public Double getComAvgTimePerCut() {
    return comAvgTimePerCut;
  }

  public void setComAvgTimePerCut(Double comAvgTimePerCut) {
    this.comAvgTimePerCut = comAvgTimePerCut;
  }

  public Long getComDurability() {
    return comDurability;
  }

  public void setComDurability(Long comDurability) {
    this.comDurability = comDurability;
  }

  public Long getComNumberCutPerDisc() {
    return comNumberCutPerDisc;
  }

  public void setComNumberCutPerDisc(Long comNumberCutPerDisc) {
    this.comNumberCutPerDisc = comNumberCutPerDisc;
  }

  public Long getComRemovalRate() {
    return comRemovalRate;
  }

  public void setComRemovalRate(Long comRemovalRate) {
    this.comRemovalRate = comRemovalRate;
  }

  public Long getComTimePerWheelChangeOver() {
    return comTimePerWheelChangeOver;
  }

  public void setComTimePerWheelChangeOver(Long comTimePerWheelChangeOver) {
    this.comTimePerWheelChangeOver = comTimePerWheelChangeOver;
  }

  public Double getComTotalMaterialRemoved() {
    return comTotalMaterialRemoved;
  }

  public void setComTotalMaterialRemoved(Double comTotalMaterialRemoved) {
    this.comTotalMaterialRemoved = comTotalMaterialRemoved;
  }

  public Long getLaborCostSaving() {
    return laborCostSaving;
  }

  public void setLaborCostSaving(Long laborCostSaving) {
    this.laborCostSaving = laborCostSaving;
  }

  public Long getLaborCostSavingPercentage() {
    return laborCostSavingPercentage;
  }

  public void setLaborCostSavingPercentage(Long laborCostSavingPercentage) {
    this.laborCostSavingPercentage = laborCostSavingPercentage;
  }

  public Long getProdCostSaving() {
    return prodCostSaving;
  }

  public void setProdCostSaving(Long prodCostSaving) {
    this.prodCostSaving = prodCostSaving;
  }

  public Long getProdCostSavingPercentage() {
    return prodCostSavingPercentage;
  }

  public void setProdCostSavingPercentage(Long prodCostSavingPercentage) {
    this.prodCostSavingPercentage = prodCostSavingPercentage;
  }

  public Long getTotalCostSaving() {
    return totalCostSaving;
  }

  public void setTotalCostSaving(Long totalCostSaving) {
    this.totalCostSaving = totalCostSaving;
  }

  public Long getTotalCostSavingPercentage() {
    return totalCostSavingPercentage;
  }

  public void setTotalCostSavingPercentage(Long totalCostSavingPercentage) {
    this.totalCostSavingPercentage = totalCostSavingPercentage;
  }

  public Long getWalAnnualDiscConsumption() {
    return walAnnualDiscConsumption;
  }

  public void setWalAnnualDiscConsumption(Long walAnnualDiscConsumption) {
    this.walAnnualDiscConsumption = walAnnualDiscConsumption;
  }

  public Long getWalAnnualDiscsCost() {
    return walAnnualDiscsCost;
  }

  public void setWalAnnualDiscsCost(Long walAnnualDiscsCost) {
    this.walAnnualDiscsCost = walAnnualDiscsCost;
  }

  public Long getWalAnnualLaborCost() {
    return walAnnualLaborCost;
  }

  public void setWalAnnualLaborCost(Long walAnnualLaborCost) {
    this.walAnnualLaborCost = walAnnualLaborCost;
  }

  public Long getWalAnnualOperationCost() {
    return walAnnualOperationCost;
  }

  public void setWalAnnualOperationCost(Long walAnnualOperationCost) {
    this.walAnnualOperationCost = walAnnualOperationCost;
  }

  public Long getWalAnnualOperationTime() {
    return walAnnualOperationTime;
  }

  public void setWalAnnualOperationTime(Long walAnnualOperationTime) {
    this.walAnnualOperationTime = walAnnualOperationTime;
  }

  public Long getWalAnnualTotalProdCost() {
    return walAnnualTotalProdCost;
  }

  public void setWalAnnualTotalProdCost(Long walAnnualTotalProdCost) {
    this.walAnnualTotalProdCost = walAnnualTotalProdCost;
  }

  public Long getWalAnnualTotalTime() {
    return walAnnualTotalTime;
  }

  public void setWalAnnualTotalTime(Long walAnnualTotalTime) {
    this.walAnnualTotalTime = walAnnualTotalTime;
  }

  public Double getWalAvgTimePerCut() {
    return walAvgTimePerCut;
  }

  public void setWalAvgTimePerCut(Double walAvgTimePerCut) {
    this.walAvgTimePerCut = walAvgTimePerCut;
  }

  public Long getWalBackingPadQuantity() {
    return walBackingPadQuantity;
  }

  public void setWalBackingPadQuantity(Long walBackingPadQuantity) {
    this.walBackingPadQuantity = walBackingPadQuantity;
  }

  public Long getWalDurability() {
    return walDurability;
  }

  public void setWalDurability(Long walDurability) {
    this.walDurability = walDurability;
  }

  public Long getWalNumberCutPerDisc() {
    return walNumberCutPerDisc;
  }

  public void setWalNumberCutPerDisc(Long walNumberCutPerDisc) {
    this.walNumberCutPerDisc = walNumberCutPerDisc;
  }

  public Long getWalRemovalRate() {
    return walRemovalRate;
  }

  public void setWalRemovalRate(Long walRemovalRate) {
    this.walRemovalRate = walRemovalRate;
  }

  public Long getWalTimePerWheelChangeOver() {
    return walTimePerWheelChangeOver;
  }

  public void setWalTimePerWheelChangeOver(Long walTimePerWheelChangeOver) {
    this.walTimePerWheelChangeOver = walTimePerWheelChangeOver;
  }

  public Double getWalTotalMaterialRemoved() {
    return walTotalMaterialRemoved;
  }

  public void setWalTotalMaterialRemoved(Double walTotalMaterialRemoved) {
    this.walTotalMaterialRemoved = walTotalMaterialRemoved;
  }

  public Reports getReportId() {
    return reportId;
  }

  public void setReportId(Reports reportId) {
    this.reportId = reportId;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (id != null ? id.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof ReportsProductivity)) {
      return false;
    }
    ReportsProductivity other = (ReportsProductivity) object;
    if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.walterproductivity.ReportsProductivity[ id=" + id + " ]";
  }

  public Double getAnnDistReqImp() {
    return annDistReqImp;
  }

  public void setAnnDistReqImp(Double annDistReqImp) {
    this.annDistReqImp = annDistReqImp;
  }

  public Double getAnnDistReqMetric() {
    return annDistReqMetric;
  }

  public void setAnnDistReqMetric(Double annDistReqMetric) {
    this.annDistReqMetric = annDistReqMetric;
  }

  public Long getNbPiecesDone() {
    return nbPiecesDone;
  }

  public void setNbPiecesDone(Long nbPiecesDone) {
    this.nbPiecesDone = nbPiecesDone;
  }

}
