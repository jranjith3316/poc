/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.walter;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "U_LABEL_D", catalog = "", schema = DatabaseConstants.WALTER_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "ULabelD.findAll", query = "SELECT u FROM ULabelD u"),
    @NamedQuery(name = "ULabelD.findByLabelId", query = "SELECT u FROM ULabelD u WHERE u.uLabelDPK.labelId = :labelId"),
    @NamedQuery(name = "ULabelD.findByLangId", query = "SELECT u FROM ULabelD u WHERE u.uLabelDPK.langId = :langId"),
    @NamedQuery(name = "ULabelD.findByLabelDesc", query = "SELECT u FROM ULabelD u WHERE u.labelDesc = :labelDesc")})
public class ULabelD implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected ULabelDPK uLabelDPK;
    @Size(max = 200)
    @Column(name = "LABEL_DESC")
    private String labelDesc;
    @JoinColumn(name = "LABEL_ID", referencedColumnName = "LABEL_ID", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private ULabel uLabel;

    public ULabelD() {
    }

    public ULabelD(ULabelDPK uLabelDPK) {
        this.uLabelDPK = uLabelDPK;
    }

    public ULabelD(long labelId, long langId) {
        this.uLabelDPK = new ULabelDPK(labelId, langId);
    }

    public ULabelDPK getULabelDPK() {
        return uLabelDPK;
    }

    public void setULabelDPK(ULabelDPK uLabelDPK) {
        this.uLabelDPK = uLabelDPK;
    }

    public String getLabelDesc() {
        return labelDesc;
    }

    public void setLabelDesc(String labelDesc) {
        this.labelDesc = labelDesc;
    }

    public ULabel getULabel() {
        return uLabel;
    }

    public void setULabel(ULabel uLabel) {
        this.uLabel = uLabel;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (uLabelDPK != null ? uLabelDPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ULabelD)) {
            return false;
        }
        ULabelD other = (ULabelD) object;
        if ((this.uLabelDPK == null && other.uLabelDPK != null) || (this.uLabelDPK != null && !this.uLabelDPK.equals(other.uLabelDPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.ULabelD[ uLabelDPK=" + uLabelDPK + " ]";
    }
    
}
