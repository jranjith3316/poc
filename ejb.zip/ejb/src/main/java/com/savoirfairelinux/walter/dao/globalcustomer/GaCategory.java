/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.globalcustomer;

import com.savoirfairelinux.walter.dao.DatabaseConstants;
import javax.persistence.*;

import java.io.Serializable;

/**
 *
 * @author jderuere
 */
@Entity
@Table(name = "GA_CATEGORY", schema = DatabaseConstants.WALTERCB_SCHEMA, uniqueConstraints = @UniqueConstraint(name = "GA_CATEGORY_UNIQUE", columnNames = { "CATEGORY_ID", "FACILITY_ID" }))
public class GaCategory implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(generator = "GA_CATEGORY_ID_SEQ", strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "GA_CATEGORY_ID_SEQ", sequenceName = "GA_CATEGORY_ID_SEQ", schema = DatabaseConstants.WALTERCB_SCHEMA, allocationSize = 1)
    @Column(name = "GA_CATEGORY_ID")
    private Long gaCategoryId;

    @Column(name = "CATEGORY_ID", nullable = false)
    private long categoryId;

    @OneToOne
    @JoinColumn(name = "FACILITY_ID", referencedColumnName = "FACILITY_ID", nullable = false)
    private GaFacility facility;
    
    @Transient
    private String name;

    public GaCategory() {
    }

    public Long getGaCategoryId() {
        return gaCategoryId;
    }

    public void setGaCategoryId(Long gaCategoryId) {
        this.gaCategoryId = gaCategoryId;
    }

    public long getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(long categoryId) {
        this.categoryId = categoryId;
    }

    public GaFacility getFacility() {
        return facility;
    }

    public void setFacility(GaFacility facility) {
        this.facility = facility;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (gaCategoryId != null ? gaCategoryId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof GaCategory)) {
            return false;
        }
        GaCategory other = (GaCategory) object;
        if ((this.gaCategoryId == null && other.gaCategoryId != null) || (this.gaCategoryId != null && !this.gaCategoryId.equals(other.gaCategoryId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.globalcustomer.GaCategory[ gaCategoryId=" + gaCategoryId + " ]";
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
