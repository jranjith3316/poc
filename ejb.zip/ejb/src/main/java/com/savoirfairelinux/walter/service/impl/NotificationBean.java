/*
 * Copyright 2012 Savoir-faire Linux
 *
 * This file is part of Walter-Portal.
 *
 * Walter-Portal is free software: you can redistribute it and/or modify it under the terms of the
 * GNU General Public License as published by the Free Software Foundation, either version 3
 * of the License, or (at your option) any later version.
 *
 * Walter-Portal is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with Walter-Portal.
 * If not, see http://www.gnu.org/licenses/.
 */
package com.savoirfairelinux.walter.service.impl;

import com.liferay.mail.service.MailServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.lar.ExportImportThreadLocal;
import com.liferay.portal.kernel.mail.MailMessage;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.model.Company;
import com.liferay.portal.model.Organization;
import com.liferay.portal.model.User;
import com.liferay.portal.model.VirtualHost;
import com.liferay.portal.service.CompanyLocalServiceUtil;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.liferay.portal.service.VirtualHostLocalServiceUtil;
import com.savoirfairelinux.walter.dao.globalcustomer.GaFeedback;
import com.savoirfairelinux.walter.dao.globalcustomer.GaFeedbackR;
import com.savoirfairelinux.walter.dao.walter.ExpenseRpt;
import com.savoirfairelinux.walter.dao.walter.UPerson;
import com.savoirfairelinux.walter.dao.waltercb.Cnt;
import com.savoirfairelinux.walter.dao.waltercb.CntFeedback;
import com.savoirfairelinux.walter.dao.waltercb.CntTranslate;
import com.savoirfairelinux.walter.dao.waltercb.CntTxt;
import com.savoirfairelinux.walter.dao.waltercb.Er;
import com.savoirfairelinux.walter.dao.waltercb.ErTxt;
import com.savoirfairelinux.walter.dao.waltercb.Idea;
import com.savoirfairelinux.walter.dao.waltercb.IdeaFeedback;
import com.savoirfairelinux.walter.dao.waltercb.IdeaTranslate;
import com.savoirfairelinux.walter.dao.waltercb.IdeaTxt;
import com.savoirfairelinux.walter.dao.waltercb.ProductivityReport;
import com.savoirfairelinux.walter.dao.waltercb.PromoOrder;
import com.savoirfairelinux.walter.dao.waltercb.ULang;
import com.savoirfairelinux.walter.dao.walterproductivity.Orders;
import com.savoirfairelinux.walter.dao.walterproductivity.OrdersDetail;
import com.savoirfairelinux.walter.dao.walterproductivity.Reports;
import com.savoirfairelinux.walter.jasper.exceptions.JasperException;
import com.savoirfairelinux.walter.jasper.model.JasperMobileProductivityReportBean;
import com.savoirfairelinux.walter.model.PrWalterProduct;
import com.savoirfairelinux.walter.service.NotificationBeanRemote;
import com.savoirfairelinux.walter.service.WalterBeanRemote;
import com.savoirfairelinux.walter.service.notification.NotificationTemplate;
import com.savoirfairelinux.walter.service.notification.NotificationUtil;
import com.savoirfairelinux.walter.service.notification.OrganizationProperties;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.annotation.security.PermitAll;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.mail.internet.InternetAddress;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author jbonjean
 *
 */
@Stateless(name = "NotificationBean")
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
@PermitAll
@LocalBean
public class NotificationBean implements NotificationBeanRemote {

  public static final Logger LOGGER = Logger.getLogger(NotificationBean.class.getCanonicalName());
  @PersistenceContext(unitName = "waltershare")
  private EntityManager entityManager;
  @EJB
  private SingletonBean singletonBean;
  @EJB
  private WalterBeanRemote walterBean;
  @EJB
  private ProductivityReportBean productivityReportBean;
  @EJB
  private JasperBean jasperBean;
  private long companyId;

  @PostConstruct
  public void init() {
    try {
      // XXX: workaround to allow EJB to access custom fields values.
      // This could also be solved by the property permissions.custom.attribute.read.check.by.default
      // that can completely disable security on custom fields.
      ExportImportThreadLocal.setLayoutExportInProcess(true);

      // retrieve companyId
      List<Company> companies = CompanyLocalServiceUtil.getCompanies();
      if (companies.isEmpty()) {
        LOGGER.severe("This should not happen, no company found...");
      } else if (companies.size() > 1) {
        LOGGER.warning("We found more than one company, using the first one");
      }
      companyId = companies.get(0).getCompanyId();
    } catch (SystemException ex) {
      LOGGER.log(Level.SEVERE, ex.getMessage());
    }
  }

  /**
   * Wrapper around logger, just to have clean information about notifications
   * sent
   */
  private void logNotificationSent(MailMessage message, NotificationTemplate template) {
    // check if valid data, we don't want a NPE here!
    if (message == null || template == null) {
      return;
    }

    // this is a lot of operations, so avoid them if it's not going
    // to be displayed ;-)
    if (!LOGGER.isLoggable(Level.INFO)) {
      return;
    }

    StringBuffer text = new StringBuffer();
    text.append("Sent notification [");
    text.append(template.name());
    text.append("] to [");

    if (message.getTo() != null) {
      StringBuffer toText = new StringBuffer();
      for (InternetAddress to : message.getTo()) {
        if (toText.length() > 0) {
          toText.append(",");
        }
        toText.append(to.getAddress());
      }
      text.append(toText);
    }
    text.append("] ");

    if (message.getCC() != null) {
      StringBuffer ccText = new StringBuffer();
      for (InternetAddress cc : message.getCC()) {
        if (ccText.length() > 0) {
          ccText.append(",");
        }
        ccText.append(cc.getAddress());
      }
      if (ccText.length() > 0) {
        text.append("CC to [");
        text.append(ccText);
        text.append("] ");
      }
    }
    LOGGER.info(text.toString());
  }

  /**
   * Create a new mail message for management. This method is specific to
   * management because we need a fall-back in case the management user is not
   * found in database
   */
  private MailMessage newManagementNotification(NotificationTemplate template, User user, Organization organization,
          Map<String, String> context) throws Exception {

    InternetAddress from = NotificationUtil.getManagementEmail(organization);
    User management = null;
    InternetAddress to = null;
    Locale locale = null;

    // try to find management user in Liferay database
    try {
      management = UserLocalServiceUtil.getUserByEmailAddress(companyId,
              NotificationUtil.getManagementEmail(organization).getAddress());

      to = new InternetAddress(management.getEmailAddress(), management.getFullName());
      locale = management.getLocale();
    } catch (PortalException e) {
    } catch (SystemException e) {
    } catch (UnsupportedEncodingException e) {
    }

    // if management user not found, we use default values and user locale
    if (management == null) {
      LOGGER.warning("Management user not found for " + user.getEmailAddress());
      to = NotificationUtil.getManagementEmail(organization);
      locale = user.getLocale();
    }
    return newNotification(template, organization, from, to, locale, context);
  }

  /**
   * Create a new mail message, based on a template, context and user locale
   */
  private MailMessage newNotification(NotificationTemplate template, User recipient, Organization organization,
          Map<String, String> context) throws Exception {
    InternetAddress from = NotificationUtil.getManagementEmail(organization);
    InternetAddress to = new InternetAddress(recipient.getEmailAddress(), recipient.getFullName());

    return newNotification(template, organization, from, to, recipient.getLocale(), context);
  }

  /**
   * Create a new mail message, based on a template, context, locale and email
   * addresses. This is the lowest level method
   */
  private MailMessage newNotification(NotificationTemplate template, Organization organization, InternetAddress from,
          InternetAddress to, Locale locale, Map<String, String> context) throws Exception {

    StringBuilder bodyTemplate = new StringBuilder();

    // if it's HTML, we add header and footer
    if (template.isHtml()) {
      bodyTemplate.append(NotificationUtil.readTemplate(NotificationTemplate.HEADER.getBodyTemplateName(), locale));
    }
    VirtualHost host = VirtualHostLocalServiceUtil.getVirtualHost(organization.getCompanyId(), organization.getGroup().getPublicLayoutSet().getLayoutSetId());
    bodyTemplate.append(NotificationUtil.readTemplate(template.getBodyTemplateName(), locale));

    if (template.isHtml()) {
      bodyTemplate.append(NotificationUtil.readTemplate(NotificationTemplate.FOOTER.getBodyTemplateName(), locale));
    }

    String subjectTemplate = NotificationUtil.readTemplate(template.getSubjectTemplateName(), locale);
    OrganizationProperties organizationProperties = NotificationUtil.getOrganizationProperties(organization);

    // we add common tokens here
    context.put("LOGO_URL", NotificationUtil.getLogoURL(organization));
    context.put("SITE_URL", host.getHostname());
    context.put("CSS_CLASS", organizationProperties.getCssClass());
    context.put("ORGANIZATION", organization.getName());

    return new MailMessage(from, to, StringUtil.replace(subjectTemplate, "[$", "$]", context),
            StringUtil.replace(bodyTemplate.toString(), "[$", "$]", context), template.isHtml());
  }

  /**
   * Create a new mail message, based on a template, context, locale and email
   * addresses. Use for Mobile productivity report
   */
  private MailMessage newNotificationMobileProductivityReport(NotificationTemplate template, Organization organization, InternetAddress from,
          InternetAddress to, Locale locale, Map<String, String> context) throws Exception {

    StringBuilder bodyTemplate = new StringBuilder();

    // if it's HTML, we add header and footer
    if (template.isHtml()) {
      bodyTemplate.append(NotificationUtil.readTemplate(NotificationTemplate.HEADER_EXTERNAL.getBodyTemplateName(), locale));
    }
    VirtualHost host = VirtualHostLocalServiceUtil.getVirtualHost(organization.getCompanyId(), organization.getGroup().getPublicLayoutSet().getLayoutSetId());
    bodyTemplate.append(NotificationUtil.readTemplate(template.getBodyTemplateName(), locale));

    if (template.isHtml()) {
      bodyTemplate.append(NotificationUtil.readTemplate(NotificationTemplate.FOOTER_EXTERNAL.getBodyTemplateName(), locale));
    }

    String subjectTemplate = NotificationUtil.readTemplate(template.getSubjectTemplateName(), locale);
    OrganizationProperties organizationProperties = NotificationUtil.getOrganizationProperties(organization);



    return new MailMessage(from, to, StringUtil.replace(subjectTemplate, "[$", "$]", context),
            StringUtil.replace(bodyTemplate.toString(), "[$", "$]", context), template.isHtml());
  }

  /**
   * Send mail notifications when a new report is created. Two messages are
   * sent, one to the creator and one to the management, using a different
   * template. Templates are also different depending on the creator
   * organization.
   */
  @Override
  public void sendNewReportNotification(Cnt report) {
    try {
      User creator = UserLocalServiceUtil.getUserByScreenName(companyId, report.getCreatorUserName());
      Long dbLanguageId = walterBean.getDbLanguageId(creator.getLanguageId());
      int creatorReportCount = getUserCntCount(report.getCreatorUserName());
      Organization organization = NotificationUtil.getOrganization(report.getOrganization(), creator);
      CntTxt cntTxt = getCntTxt(report, dbLanguageId);

      // populate the context for token replacement in template files
      Map<String, String> context = new HashMap<String, String>();
      context.put("REPORT_TITLE", cntTxt.getObjective());
      context.put("CREATOR_REPORT_COUNT", String.valueOf(creatorReportCount));
      context.put("REPORT_ID", String.valueOf(report.getCntId()));
      context.put("CREATOR_NAME", creator.getFullName());

      // ready, create and send the message
      MailMessage message = newNotification(NotificationTemplate.REPORT_SUBMITTED_CREATOR, creator, organization, context);
      MailServiceUtil.sendEmail(message);
      logNotificationSent(message, NotificationTemplate.REPORT_SUBMITTED_CREATOR);

      // send also an email to management
      message = newManagementNotification(NotificationTemplate.REPORT_SUBMITTED_MANAGEMENT, creator, organization, context);
      MailServiceUtil.sendEmail(message);
      logNotificationSent(message, NotificationTemplate.REPORT_SUBMITTED_MANAGEMENT);
    } catch (Exception e) {
      LOGGER.log(Level.SEVERE, e.getMessage());
    }
  }

  /**
   * Send mail notifications to report creator and his manager when a new
   * feedback is created.
   */
  @Override
  public void sendNewFeedbackNotification(CntFeedback feedback) {
    try {
      User feedbackCreator = UserLocalServiceUtil.getUserByScreenName(companyId, feedback.getUserName());
      Cnt report = feedback.getCnt();
      User reportCreator = UserLocalServiceUtil.getUserByScreenName(companyId, report.getCreatorUserName());
      Long dbLanguageId = walterBean.getDbLanguageId(reportCreator.getLanguageId());
      Organization organization = NotificationUtil.getOrganization(report.getOrganization(), reportCreator);
      CntTxt cntTxt = getCntTxt(report, dbLanguageId);

      // populate the context for token replacement in template files
      Map<String, String> context = new HashMap<String, String>();
      context.put("REPORT_TITLE", cntTxt.getObjective());
      context.put("REPORT_ID", String.valueOf(report.getCntId()));
      context.put("REPORT_PUBLICATION_DATE",
              new SimpleDateFormat("yyyy-MM-dd").format(report.getPublicationDate()));
      context.put("FEEDBACK_CREATOR_NAME", feedbackCreator.getFullName());
      context.put("FEEDBACK_CREATOR_COUNTRY", NotificationUtil.getCountry(feedbackCreator));
      context.put("FEEDBACK_DESCRIPTION", feedback.getFeedbackDesc());
      context.put("FEEDBACK_CREATOR_EMAIL", feedbackCreator.getEmailAddress());

      // ready, create and send the message
      MailMessage message = newNotification(NotificationTemplate.REPORT_NEW_FEEDBACK, reportCreator, organization,
              context);

      // if there is a manager, add it as CC
      UPerson creator = walterBean.getUPerson(reportCreator.getScreenName().toUpperCase());
      if (creator != null && creator.getManagerUserName() != null) {
        User manager = UserLocalServiceUtil.getUserByScreenName(companyId, creator.getManagerUserName().toLowerCase());
        InternetAddress cc = new InternetAddress(manager.getEmailAddress(), manager.getFullName());
        message.setCC(cc);
      } else {
        LOGGER.warning("Manager not found for " + reportCreator.getEmailAddress());
      }
      MailServiceUtil.sendEmail(message);
      logNotificationSent(message, NotificationTemplate.REPORT_NEW_FEEDBACK);
    } catch (Exception ex) {
      LOGGER.log(Level.SEVERE, ex.getMessage());
    }
  }

  /**
   * Send mail notifications to facility key contact when a new feedback is
   * created.
   */
  @Override
  public void sendNewFeedbackNotification(GaFeedback feedback) {
    try {
      User contributor = UserLocalServiceUtil.getUserByScreenName(companyId, feedback.getContributor());
      User keyContact = UserLocalServiceUtil.getUserByScreenName(companyId, feedback.getFacility().getKeyContact());
      Organization organization = keyContact.getOrganizations().get(0);

      // populate the context for token replacement in template files
      Map<String, String> context = new HashMap<String, String>();
      context.put("FACILITY_TITLE", feedback.getFacility().getName());
      context.put("FACILITY_ID", String.valueOf(feedback.getFacility().getFacilityId()));
      context.put("FEEDBACK_CREATOR_NAME", contributor.getFullName());
      context.put("FEEDBACK_CREATOR_COUNTRY", NotificationUtil.getCountry(contributor));
      context.put("FEEDBACK_DESCRIPTION", feedback.getFeedbackDesc());
      context.put("FEEDBACK_CREATOR_EMAIL", contributor.getEmailAddress());

      MailMessage message = newNotification(NotificationTemplate.CUSTOMER_FACILITY_FEEDBACK, keyContact, organization, context);
      MailServiceUtil.sendEmail(message);
      logNotificationSent(message, NotificationTemplate.CUSTOMER_FACILITY_FEEDBACK);
    } catch (Exception ex) {
      LOGGER.log(Level.SEVERE, ex.getMessage());
    }
  }

  @Override
  public void sendNewFeedbackReplyNotification(GaFeedbackR feedbackReply) {
    try {
      User contributor = UserLocalServiceUtil.getUserByScreenName(companyId, feedbackReply.getContributor());
      User keyContact = UserLocalServiceUtil.getUserByScreenName(companyId, feedbackReply.getFeedback().getFacility().getKeyContact());
      Organization organization = keyContact.getOrganizations().get(0);

      // populate the context for token replacement in template files
      Map<String, String> context = new HashMap<String, String>();
      context.put("FACILITY_TITLE", feedbackReply.getFeedback().getFacility().getName());
      context.put("FACILITY_ID", String.valueOf(feedbackReply.getFeedback().getFacility().getFacilityId()));
      context.put("FEEDBACK_CREATOR_NAME", contributor.getFullName());
      context.put("FEEDBACK_CREATOR_COUNTRY", NotificationUtil.getCountry(contributor));
      context.put("FEEDBACK_DESCRIPTION", feedbackReply.getReplyDesc());
      context.put("FEEDBACK_CREATOR_EMAIL", contributor.getEmailAddress());

      MailMessage message = newNotification(NotificationTemplate.CUSTOMER_FACILITY_FEEDBACK, keyContact, organization, context);
      MailServiceUtil.sendEmail(message);
      logNotificationSent(message, NotificationTemplate.CUSTOMER_FACILITY_FEEDBACK);
    } catch (Exception ex) {
      LOGGER.log(Level.SEVERE, ex.getMessage());
    }
  }

  /**
   * Send mail notification when a translation is pending
   */
  @Override
  public void sendPendingForTranslationNotification(Cnt report) {
    try {
      User creator = UserLocalServiceUtil.getUserByScreenName(companyId, report.getCreatorUserName());
      Organization organization = NotificationUtil.getOrganization(report.getOrganization(), creator);
      CntTranslate englishTranslation = getTranslation(report, ULang.ENGLISH_ID);
      User translator = UserLocalServiceUtil.getUserByScreenName(companyId, englishTranslation.getTranslatorUserName());
      Long dbLanguageId = walterBean.getDbLanguageId(translator.getLanguageId());
      CntTxt cntTxt = getCntTxt(report, dbLanguageId);

      // populate the context for token replacement in template files
      Map<String, String> context = new HashMap<String, String>();
      context.put("REPORT_TITLE", cntTxt.getObjective());
      context.put("REPORT_ID", String.valueOf(report.getCntId()));
      context.put("CREATOR_NAME", creator.getFullName());

      // ready, create and send the message
      MailMessage message = newNotification(NotificationTemplate.REPORT_TRANSLATION_PENDING, translator, organization, context);
      MailServiceUtil.sendEmail(message);
      logNotificationSent(message, NotificationTemplate.REPORT_TRANSLATION_PENDING);
    } catch (Exception e) {
      LOGGER.log(Level.SEVERE, e.getMessage());
    }
  }

  /**
   * Send mail notification to management when a translation is finished
   */
  @Override
  public void sendTranslationFinishedNotification(Cnt report) {
    try {
      User creator = UserLocalServiceUtil.getUserByScreenName(companyId, report.getCreatorUserName());
      Organization organization = NotificationUtil.getOrganization(report.getOrganization(), creator);
      Long dbLanguageId = walterBean.getDbLanguageId(creator.getLanguageId());
      CntTxt cntTxt = getCntTxt(report, dbLanguageId);

      // populate the context for token replacement in template files
      Map<String, String> context = new HashMap<String, String>();
      context.put("REPORT_TITLE", cntTxt.getObjective());
      context.put("REPORT_ID", String.valueOf(report.getCntId()));
      context.put("CREATOR_NAME", creator.getFullName());

      // ready, create and send the message
      MailMessage message = newManagementNotification(NotificationTemplate.REPORT_TRANSLATION_FINISHED, creator, organization, context);
      MailServiceUtil.sendEmail(message);
      logNotificationSent(message, NotificationTemplate.REPORT_TRANSLATION_FINISHED);
    } catch (Exception e) {
      LOGGER.log(Level.SEVERE, e.getMessage());
    }
  }

  /**
   * Send mail notification to PM when a report is pending for validation
   */
  @Override
  public void sendPendingForValidationNotification(Cnt report) {
    try {
      User creator = UserLocalServiceUtil.getUserByScreenName(companyId, report.getCreatorUserName());
      Organization organization = NotificationUtil.getOrganization(report.getOrganization(), creator);
      User pm = UserLocalServiceUtil.getUserByScreenName(companyId, report.getPmUserName());

      // populate the context for token replacement in template files
      Map<String, String> context = new HashMap<String, String>();
      context.put("REPORT_ID", String.valueOf(report.getCntId()));

      // ready, create and send the message
      MailMessage message = newNotification(NotificationTemplate.REPORT_VALIDATION_PENDING, pm, organization, context);
      MailServiceUtil.sendEmail(message);
      logNotificationSent(message, NotificationTemplate.REPORT_VALIDATION_PENDING);
    } catch (Exception e) {
      LOGGER.log(Level.SEVERE, e.getMessage());
    }
  }

  /**
   * Send mail notification to Management when a report has been validated by
   * the PM
   */
  @Override
  public void sendReportValidatedNotification(Cnt report) {
    try {
      User creator = UserLocalServiceUtil.getUserByScreenName(companyId, report.getCreatorUserName());
      Organization organization = NotificationUtil.getOrganization(report.getOrganization(), creator);

      // populate the context for token replacement in template files
      Map<String, String> context = new HashMap<String, String>();
      context.put("REPORT_ID", String.valueOf(report.getCntId()));

      // ready, create and send the message
      MailMessage message = newManagementNotification(NotificationTemplate.REPORT_VALIDATED, creator, organization, context);
      MailServiceUtil.sendEmail(message);
      logNotificationSent(message, NotificationTemplate.REPORT_VALIDATED);
    } catch (Exception e) {
      LOGGER.log(Level.SEVERE, e.getMessage());
    }
  }

  /**
   * Send mail notifications when a new report is created. Two messages are
   * sent, one to the creator and one to the management, using a different
   * template. Templates are also different depending on the creator
   * organization.
   */
  @Override
  public void sendPendingForTranslationNotification(Idea idea) {
    try {
      User creator = UserLocalServiceUtil.getUserByScreenName(companyId, idea.getCreatorUserName());
      Long dbLanguageId = walterBean.getDbLanguageId(creator.getLanguageId());
      Organization organization = NotificationUtil.getOrganization(idea.getOrganization(), creator);
      IdeaTxt ideaTxt = getIdeaTxt(idea, dbLanguageId);

      IdeaTranslate englishTranslation = getTranslation(idea, ULang.ENGLISH_ID);
      User translator = UserLocalServiceUtil.getUserByScreenName(companyId, englishTranslation.getTranslatorUserName());

      // Populate the context for token replacement in template files
      Map<String, String> context = new HashMap<String, String>();
      context.put("IDEA_TITLE", ideaTxt.getTitle());
      context.put("IDEA_ID", String.valueOf(idea.getIdeaRef()));
      context.put("CREATOR_NAME", creator.getFullName());

      // ready, create and send the message
      MailMessage message = newNotification(NotificationTemplate.IDEA_TRANSLATION_PENDING, translator, organization, context);
      MailServiceUtil.sendEmail(message);
      logNotificationSent(message, NotificationTemplate.IDEA_TRANSLATION_PENDING);
    } catch (Exception e) {
      LOGGER.log(Level.SEVERE, e.getMessage());
    }
  }

  /**
   * Send mail notifications to report creator and his manager when a new
   * feedback is created.
   */
  @Override
  public void sendNewFeedbackNotification(IdeaFeedback feedback) {
    try {
      User feedbackCreator = UserLocalServiceUtil.getUserByScreenName(companyId, feedback.getFeedbackUserName());
      Idea idea = feedback.getIdea();
      User ideaCreator = UserLocalServiceUtil.getUserByScreenName(companyId, idea.getCreatorUserName());
      Long dbLanguageId = walterBean.getDbLanguageId(ideaCreator.getLanguageId());
      Organization organization = NotificationUtil.getOrganization(idea.getOrganization(), ideaCreator);
      IdeaTxt ideaTxt = getIdeaTxt(idea, dbLanguageId);

      // populate the context for token replacement in template files
      Map<String, String> context = new HashMap<String, String>();
      context.put("IDEA_TITLE", ideaTxt.getTitle());
      context.put("IDEA_ID", String.valueOf(idea.getIdeaId()));
      context.put("IDEA_PUBLICATION_DATE", new SimpleDateFormat("yyyy-MM-dd").format(idea.getPublishedDate()));
      context.put("FEEDBACK_CREATOR_NAME", feedbackCreator.getFullName());
      context.put("FEEDBACK_CREATOR_COUNTRY", NotificationUtil.getCountry(feedbackCreator));
      context.put("FEEDBACK_DESCRIPTION", feedback.getFeedbackDescription());
      context.put("FEEDBACK_CREATOR_EMAIL", feedbackCreator.getEmailAddress());

      // ready, create and send the message
      MailMessage message = newNotification(NotificationTemplate.IDEA_NEW_FEEDBACK, ideaCreator, organization, context);

      // if there is a manager, add it as CC
      UPerson creator = walterBean.getUPerson(idea.getCreatorUserName().toUpperCase());
      if (creator != null && creator.getManagerUserName() != null) {
        User manager = UserLocalServiceUtil.getUserByScreenName(companyId, creator.getManagerUserName());
        InternetAddress cc = new InternetAddress(manager.getEmailAddress(), manager.getFullName());
        message.setCC(cc);
      } else {
        LOGGER.warning("Manager not found for " + ideaCreator.getEmailAddress());
      }
      MailServiceUtil.sendEmail(message);
      logNotificationSent(message, NotificationTemplate.IDEA_NEW_FEEDBACK);
    } catch (Exception ex) {
      LOGGER.log(Level.SEVERE, ex.getMessage());
    }
  }

  /**
   * Send mail notifications to report creator and product manager when a new
   * idea is created.
   */
  @Override
  public void sendPublishedNotification(Idea idea) {
    try {
      User creator = UserLocalServiceUtil.getUserByScreenName(companyId, idea.getCreatorUserName());
      User pm = UserLocalServiceUtil.getUserByScreenName(companyId, idea.getPmUserName());

      Long dbLanguageId = walterBean.getDbLanguageId(creator.getLanguageId());
      Organization organization = NotificationUtil.getOrganization(idea.getOrganization(), creator);
      IdeaTxt ideaTxt = getIdeaTxt(idea, dbLanguageId);

      // populate the context for token replacement in template files
      Map<String, String> context = new HashMap<String, String>();
      context.put("CREATOR_NAME", creator.getFullName());
      context.put("IDEA_TITLE", ideaTxt.getTitle());
      context.put("IDEA_ID", String.valueOf(idea.getIdeaId()));

      // ready, create and send the message
      MailMessage message = newNotification(NotificationTemplate.IDEA_PUBLISHED, creator, organization, context);
      MailServiceUtil.sendEmail(message);
      logNotificationSent(message, NotificationTemplate.IDEA_PUBLISHED);

      message = newNotification(NotificationTemplate.IDEA_PUBLISHED, pm, organization, context);
      MailServiceUtil.sendEmail(message);

      logNotificationSent(message, NotificationTemplate.IDEA_PUBLISHED);

    } catch (Exception e) {
      LOGGER.log(Level.SEVERE, e.getMessage());
    }
  }

  /**
   * Send mail notifications 20 days after an new idea is published. Message is
   * sent to the management.
   */
  @Override
  public void sendSoonClosedNotification(Idea idea) {
    try {
      User creator = UserLocalServiceUtil.getUserByScreenName(companyId, idea.getCreatorUserName());
      User productManager = UserLocalServiceUtil.getUserByScreenName(companyId, idea.getPmUserName());
      Long dbLanguageId = walterBean.getDbLanguageId(productManager.getLanguageId());
      Organization organization = NotificationUtil.getOrganization(idea.getOrganization(), productManager);
      IdeaTxt ideaTxt = getIdeaTxt(idea, dbLanguageId);

      // populate the context for token replacement in template files
      Map<String, String> context = new HashMap<String, String>();
      context.put("IDEA_TITLE", ideaTxt.getTitle());
      context.put("IDEA_ID", String.valueOf(idea.getIdeaId()));
      context.put("CREATOR_NAME", creator.getFullName());

      MailMessage message = newNotification(NotificationTemplate.IDEA_SOON_CLOSED, productManager, organization, context);
      MailServiceUtil.sendEmail(message);
      logNotificationSent(message, NotificationTemplate.IDEA_SOON_CLOSED);

      message = newManagementNotification(NotificationTemplate.IDEA_SOON_CLOSED, creator, organization, context);
      MailServiceUtil.sendEmail(message);
      logNotificationSent(message, NotificationTemplate.IDEA_SOON_CLOSED);
    } catch (Exception e) {
      LOGGER.log(Level.SEVERE, e.getMessage());
    }
  }

  /**
   * Send mail notifications 30 days after an new idea is published and every 10
   * days as soon as the status didn't change from "open for discussion".
   * Message is sent to the management.
   */
  @Override
  public void sendClosingNotification(Idea idea) {
    try {
      User creator = UserLocalServiceUtil.getUserByScreenName(companyId, idea.getCreatorUserName());
      User productManager = UserLocalServiceUtil.getUserByScreenName(companyId, idea.getPmUserName());
      Long dbLanguageId = walterBean.getDbLanguageId(productManager.getLanguageId());
      Organization organization = NotificationUtil.getOrganization(idea.getOrganization(), productManager);
      IdeaTxt ideaTxt = getIdeaTxt(idea, dbLanguageId);

      // populate the context for token replacement in template files
      Map<String, String> context = new HashMap<String, String>();
      context.put("IDEA_TITLE", ideaTxt.getTitle());
      context.put("IDEA_ID", String.valueOf(idea.getIdeaId()));
      context.put("CREATOR_NAME", creator.getFullName());

      MailMessage message = newNotification(NotificationTemplate.IDEA_CLOSING, productManager, organization, context);
      MailServiceUtil.sendEmail(message);
      logNotificationSent(message, NotificationTemplate.IDEA_CLOSING);

      message = newManagementNotification(NotificationTemplate.IDEA_CLOSING, creator, organization, context);
      MailServiceUtil.sendEmail(message);
      logNotificationSent(message, NotificationTemplate.IDEA_CLOSING);
    } catch (Exception ex) {
      LOGGER.log(Level.SEVERE, ex.getMessage());
    }
  }

  @Override
  public void sendNewLabReportNotification(Er report) {
    try {
      User creator = UserLocalServiceUtil.getUserByScreenName(companyId, report.getCreatorUserName());
      Long dbLanguageId = walterBean.getDbLanguageId(creator.getLanguageId());
      int creatorReportCount = getUserErCount(report.getCreatorUserName());
      Organization organization = NotificationUtil.getOrganization(report.getOrganization(), creator);
      ErTxt erTxt = getErTxt(report, dbLanguageId);

      // populate the context for token replacement in template files
      Map<String, String> context = new HashMap<String, String>();
      context.put("REPORT_TITLE", erTxt.getCleaningMethod());
      context.put("CREATOR_REPORT_COUNT", String.valueOf(creatorReportCount));
      context.put("REPORT_ID", String.valueOf(report.getErId()));
      context.put("CREATOR_NAME", creator.getFullName());

      // ready, create and send the message
      MailMessage message = newNotification(NotificationTemplate.LAB_REPORT_SUBMITTED_CREATOR, creator, organization, context);
      MailServiceUtil.sendEmail(message);
      logNotificationSent(message, NotificationTemplate.LAB_REPORT_SUBMITTED_CREATOR);

      // send also an email to management
      message = newManagementNotification(NotificationTemplate.LAB_REPORT_SUBMITTED_MANAGEMENT, creator, organization, context);
      MailServiceUtil.sendEmail(message);
      logNotificationSent(message, NotificationTemplate.LAB_REPORT_SUBMITTED_MANAGEMENT);
    } catch (Exception ex) {
      LOGGER.log(Level.SEVERE, ex.getMessage());
    }
  }

  @Override
  public void sendPublishedLabReportNotification(Er report) {
    try {
      User creator = UserLocalServiceUtil.getUserByScreenName(companyId, report.getCreatorUserName());
      Long dbLanguageId = walterBean.getDbLanguageId(creator.getLanguageId());
      Organization organization = NotificationUtil.getOrganization(report.getOrganization(), creator);
      ErTxt erTxt = getErTxt(report, dbLanguageId);

      // populate the context for token replacement in template files
      Map<String, String> context = new HashMap<String, String>();
      context.put("REPORT_TITLE", erTxt.getPartCleanDesc());
      context.put("REPORT_ID", String.valueOf(report.getErId()));
      context.put("CREATOR_NAME", creator.getFullName());

      // ready, create and send the message
      MailMessage message = newNotification(NotificationTemplate.LAB_REPORT_PUBLISHED, creator, organization, context);
      MailServiceUtil.sendEmail(message);
      logNotificationSent(message, NotificationTemplate.LAB_REPORT_PUBLISHED);
    } catch (Exception e) {
      LOGGER.log(Level.SEVERE, e.getMessage());
    }
  }

  @Override
  public void sendPublishedProductivityReportNotification(ProductivityReport report) {
    try {
      User creator = UserLocalServiceUtil.getUserByScreenName(companyId, report.getSaleRepresentative());
      Organization organization = NotificationUtil.getOrganization("walter", creator);

      // populate the context for token replacement in template files
      Map<String, String> context = new HashMap<String, String>();
      context.put("REPORT_TITLE", report.getCompany().getName());
      context.put("REPORT_ID", report.getWalterId());
      context.put("CREATOR_NAME", creator.getFullName());

      // ready, create and send the message
      MailMessage message = newNotification(NotificationTemplate.PRODUCTIVITY_REPORT_PUBLISHED, creator, organization, context);
      MailServiceUtil.sendEmail(message);
      logNotificationSent(message, NotificationTemplate.PRODUCTIVITY_REPORT_PUBLISHED);
    } catch (Exception e) {
      LOGGER.log(Level.SEVERE, e.getMessage());
    }
  }

  @Override
  public void sendSubmitProductivityReportNotification(ProductivityReport report) {
    try {
      User creator = UserLocalServiceUtil.getUserByScreenName(companyId, report.getSaleRepresentative());
      Organization organization = NotificationUtil.getOrganization("walter", creator);

      // populate the context for token replacement in template files
      Map<String, String> context = new HashMap<String, String>();
      context.put("REPORT_TITLE", report.getCompany().getName());
      context.put("CREATOR_NAME", creator.getFullName());

      // ready, create and send the message
      MailMessage message = newNotification(NotificationTemplate.PRODUCTIVITY_REPORT_SUBMITTED, creator, organization, context);
      MailServiceUtil.sendEmail(message);
      logNotificationSent(message, NotificationTemplate.PRODUCTIVITY_REPORT_SUBMITTED);
    } catch (Exception e) {
      LOGGER.log(Level.SEVERE, e.getMessage());
    }
  }

  /**
   * Send email to manager when user submit the expense report
   *
   */
  @Override
  public void sendValidationExpenseReportManagerNotification(ExpenseRpt expenseReport) {
    try {
      User creator = UserLocalServiceUtil.getUserByScreenName(companyId, expenseReport.getCreatorUserName());
      String userManager = ( walterBean.getUPerson(expenseReport.getCreatorUserName()).getManagerUserName() != null) ?      walterBean.getUPerson(expenseReport.getCreatorUserName()).getManagerUserName() :
                           ( walterBean.getUPerson(expenseReport.getCreatorUserName()).getExpApprovalUserName()) != null ?  walterBean.getUPerson(expenseReport.getCreatorUserName()).getExpApprovalUserName() : "";
      User manager = UserLocalServiceUtil.getUserByScreenName(companyId, userManager);

      Organization organization = NotificationUtil.getOrganization("walter", creator);

      // populate the context for token replacement in template files
      Map<String, String> context = new HashMap<String, String>();
      context.put("EXPENSE_RPT_ID", String.valueOf(expenseReport.getExpenseRptId()));
      context.put("CREATOR_NAME", creator.getFullName());

      if (manager != null && !manager.getScreenName().equalsIgnoreCase("psomers")) {
        // ready, create and send the message
        MailMessage message = newNotification(NotificationTemplate.EXPENSE_REPORT_CREATOR_MANAGER, manager, organization, context);
        MailServiceUtil.sendEmail(message);
        logNotificationSent(message, NotificationTemplate.EXPENSE_REPORT_CREATOR_MANAGER);
      }

      if (walterBean.getUPerson(expenseReport.getCreatorUserName()).getExpApprovalUserName() != null && !walterBean.getUPerson(expenseReport.getCreatorUserName()).getExpApprovalUserName().equals("PORTAL") &&
         !walterBean.getUPerson(expenseReport.getCreatorUserName()).getExpApprovalUserName().equals(userManager)){

        User externalApproval = UserLocalServiceUtil.getUserByScreenName(companyId, walterBean.getUPerson(expenseReport.getCreatorUserName()).getExpApprovalUserName());

        MailMessage message2 = newNotification(NotificationTemplate.EXPENSE_REPORT_CREATOR_MANAGER, externalApproval, organization, context);
        MailServiceUtil.sendEmail(message2);
        logNotificationSent(message2, NotificationTemplate.EXPENSE_REPORT_CREATOR_MANAGER);

      }

    } catch (Exception e) {
      LOGGER.log(Level.SEVERE, e.getMessage());
    }
  }

  public void sendExpenseReportAccountingUserNotification(ExpenseRpt expenseReport) {
    try {
      User creator = UserLocalServiceUtil.getUserByScreenName(companyId, expenseReport.getCreatorUserName());
      Organization organization = NotificationUtil.getOrganization("walter", creator);

      // populate the context for token replacement in template files
      Map<String, String> context = new HashMap<String, String>();
      context.put("EXPENSE_RPT_ID", String.valueOf(expenseReport.getExpenseRptId()));
      context.put("EXPENSE_RPT_PERIOD", String.format("%1$tB-%1$tY", new Object[]{expenseReport.getFromDate()}));

      // ready, create and send the message
      MailMessage message = newNotification(NotificationTemplate.EXPENSE_REPORT_ACCOUNTING_CREATOR, creator, organization, context);
      MailServiceUtil.sendEmail(message);
      logNotificationSent(message, NotificationTemplate.EXPENSE_REPORT_ACCOUNTING_CREATOR);
    } catch (Exception e) {
      LOGGER.log(Level.SEVERE, e.getMessage());
    }
  }

  public void sendExpenseReportAccountingUserModificationNotification(ExpenseRpt expenseReport) {
    try {
      User creator = UserLocalServiceUtil.getUserByScreenName(companyId, expenseReport.getCreatorUserName());
      Organization organization = NotificationUtil.getOrganization("walter", creator);

      // populate the context for token replacement in template files
      Map<String, String> context = new HashMap<String, String>();
      context.put("EXPENSE_RPT_ID", String.valueOf(expenseReport.getExpenseRptId()));
//            context.put("EXPENSE_RPT_PERIOD", String.format("%1$tB-%1$tY", new Object[]{expenseReport.getFromDate()}));

      // ready, create and send the message
      MailMessage message = newNotification(NotificationTemplate.EXPENSE_REPORT_ACCOUNTING_CREATOR_MODIFIED, creator, organization, context);
      MailServiceUtil.sendEmail(message);
      logNotificationSent(message, NotificationTemplate.EXPENSE_REPORT_ACCOUNTING_CREATOR_MODIFIED);
    } catch (Exception e) {
      LOGGER.log(Level.SEVERE, e.getMessage());
    }
  }

  public void sendExpenseReportAccountingManagerNotification(ExpenseRpt expenseReport) {
    try {
      User creator = UserLocalServiceUtil.getUserByScreenName(companyId, expenseReport.getCreatorUserName());
      User manager = UserLocalServiceUtil.getUserByScreenName(companyId, walterBean.getUPerson(expenseReport.getCreatorUserName()).getManagerUserName());
      Organization organization = NotificationUtil.getOrganization("walter", creator);

      // populate the context for token replacement in template files
      Map<String, String> context = new HashMap<String, String>();
      context.put("CREATOR_NAME", creator.getFullName());
      context.put("EXPENSE_RPT_ID", String.valueOf(expenseReport.getExpenseRptId()));
//            context.put("EXPENSE_RPT_PERIOD", String.format("%1$tB-%1$tY", new Object[]{expenseReport.getFromDate()}));

      // ready, create and send the message
      MailMessage message = newNotification(NotificationTemplate.EXPENSE_REPORT_ACCOUNTING_MANAGER, manager, organization, context);
      MailServiceUtil.sendEmail(message);
      logNotificationSent(message, NotificationTemplate.EXPENSE_REPORT_ACCOUNTING_MANAGER);
    } catch (Exception e) {
      LOGGER.log(Level.SEVERE, e.getMessage());
    }
  }

  /*
   *
   * send notification to accounting, HR when user is inactivated and have a loan.
   *
   */
  public void sendLoanFoundNotification(String currentUserStr, String userInactivatedString, String loan, List<String> hrUserList, List<String> accountingUserList) {//, List<User> accountingUserList
    try {
      User usrInactivated = UserLocalServiceUtil.getUserByScreenName(companyId, userInactivatedString);
      User currentUser = UserLocalServiceUtil.getUserByScreenName(companyId, currentUserStr);
      Organization organization = NotificationUtil.getOrganization("walter", currentUser);
//            User tt = UserLocalServiceUtil.getUserByScreenName(companyId, "jsgill");
      // populate the context for token replacement in template files
      Map<String, String> context = new HashMap<String, String>();
      context.put("USER_NAME", usrInactivated.getFullName());
      context.put("LOAN_TOTAL", loan);

      for (String user : hrUserList) {
        // ready, create and send the message
        User sendTo = UserLocalServiceUtil.getUserByScreenName(companyId, user);

        MailMessage message = newNotification(NotificationTemplate.LOAN_FOUND_INACTIVE_USER, sendTo, organization, context);
//              message.setSubject(message.getSubject() + " " + user);
        message.setSubject(message.getSubject());
        MailServiceUtil.sendEmail(message);
        logNotificationSent(message, NotificationTemplate.LOAN_FOUND_INACTIVE_USER);
      }

      for (String user : accountingUserList) {
        // ready, create and send the message
        User sendTo = UserLocalServiceUtil.getUserByScreenName(companyId, user);
        MailMessage message = newNotification(NotificationTemplate.LOAN_FOUND_INACTIVE_USER, sendTo, organization, context);
//              message.setSubject(message.getSubject() + " " + user);
        message.setSubject(message.getSubject());
        MailServiceUtil.sendEmail(message);
        logNotificationSent(message, NotificationTemplate.LOAN_FOUND_INACTIVE_USER);
      }

    } catch (Exception e) {
      LOGGER.log(Level.SEVERE, e.getMessage());
    }
  }

  /**
   * send email to CSR when user submit a new order.
   *
   * @param po PromoOrder object
   * @param CSRUsersString list list of all user need to receive the email
   * @param productList list of product user request
   */
  public void sendGiveAwaysCSRNotification(PromoOrder po, List<InternetAddress> toInternetAddress, String productList) {
    try {
      User creator = UserLocalServiceUtil.getUserByScreenName(companyId, po.getCreatorUserName());
      Organization organization = NotificationUtil.getOrganization("walter", creator);

      // populate the context for token replacement in template files
      Map<String, String> context = new HashMap<String, String>();
      context.put("CREATOR_USER_NAME", creator.getFullName());
      context.put("LISTPRODUCT", productList);

      for (InternetAddress to : toInternetAddress) {
        InternetAddress from = NotificationUtil.getManagementEmail(organization);

        MailMessage message = newNotification(NotificationTemplate.GIVEAWAYS_NEW_ORDER, organization, from, to, Locale.ENGLISH, context);

        message.setSubject(message.getSubject());
        MailServiceUtil.sendEmail(message);
        logNotificationSent(message, NotificationTemplate.GIVEAWAYS_NEW_ORDER);
      }

    } catch (Exception e) {
      LOGGER.log(Level.SEVERE, e.getMessage());
    }
  }

  /**
   * Return the ErTxt corresponding to a Er, considering language (Fallback to
   * english if ErTxt is not found in requested language)
   */
  private ErTxt getErTxt(Er report, Long dbLanguageId) {
    ErTxt erEn = null;
    ErTxt erTxt = null;
    for (ErTxt txt : report.getErTxtSet()) {
      if (txt.getErTxtPK().getLangId() == dbLanguageId) {
        erTxt = txt;
        break;
      }
      if (txt.getErTxtPK().getLangId() == ULang.ENGLISH_ID) {
        erEn = txt;
      }
    }
    if (erTxt == null) {
      erTxt = erEn;
    }
    return erTxt;
  }

  /**
   * Set IdeaTxt, try user language, fallback to english
   *
   * @param idea
   * @param dbLanguageId
   * @return
   */
  private IdeaTxt getIdeaTxt(Idea idea, Long dbLanguageId) {
    IdeaTxt ideaEn = null;
    IdeaTxt ideaTxt = null;
    for (IdeaTxt txt : idea.getIdeaTxtSet()) {
      if (txt.getIdeaTxtPK().getLangId() == dbLanguageId) {
        ideaTxt = txt;
        break;
      }
      if (txt.getIdeaTxtPK().getLangId() == ULang.ENGLISH_ID) {
        ideaEn = txt;
      }
    }
    if (ideaTxt == null) {
      ideaTxt = ideaEn;
    }
    return ideaTxt;
  }

  /**
   * Return the CntTxt corresponding to a Cnt, considering language (Fallback to
   * english if CntTxt is not found in requested language)
   */
  private CntTxt getCntTxt(Cnt report, Long dbLanguageId) {
    // set cntTxt, try user language, fallback to english
    CntTxt cntEn = null;
    CntTxt cntTxt = null;
    for (CntTxt txt : report.getCntTxtList()) {
      if (txt.getCntTxtPK().getLangId() == dbLanguageId) {
        cntTxt = txt;
        break;
      }
      if (txt.getCntTxtPK().getLangId() == ULang.ENGLISH_ID) {
        cntEn = txt;
      }
    }
    if (cntTxt == null) {
      cntTxt = cntEn;
    }
    return cntTxt;
  }

  /**
   * Retrieve the translation object from the report in a specific language
   */
  private CntTranslate getTranslation(Cnt report, long langId) {
    List<CntTranslate> translations = report.getCntTranslateList();
    for (CntTranslate translation : translations) {
      if (translation.getCntTranslatePK().getLangId() == langId) {
        return translation;
      }
    }
    return null;
  }

  private int getUserCntCount(String userName) throws Exception {
    try {
      return (entityManager.createQuery(singletonBean.getSolutionReportQuery("solution.report.count.user"), Long.class)
              .setParameter("userName", userName)
              .getSingleResult()).intValue();
    } catch (Exception e) {
      throw new Exception(e.getMessage());
    }
  }

  /**
   * Retrieve the translation object from the idea in a specific language
   */
  private IdeaTranslate getTranslation(Idea idea, long langId) {
    Set<IdeaTranslate> translations = idea.getIdeaTranslateSet();
    for (IdeaTranslate translation : translations) {
      if (translation.getIdeaTranslatePK().getLangId() == langId) {
        return translation;
      }
    }
    return null;
  }

  private int getUserErCount(String userName) throws Exception {
    try {
      return entityManager.createQuery(singletonBean.getLabReportQuery("lab.report.count.user"), Long.class)
              .setParameter("userName", userName)
              .getSingleResult().intValue();
    } catch (Exception e) {
      throw new Exception(e.getMessage());
    }
  }

  public void sendMobileProductivityReportSendEmail() {
    List<Reports> reportsList = productivityReportBean.getMobileProductivityReportReadyEmail();

    try {
      for (Reports report : reportsList) {
        JasperMobileProductivityReportBean jmprb = productivityReportBean.MobileProductivitySendEmail(report);

        if ( jmprb.getWalProductNumber() != null ){

          User reportCreator = UserLocalServiceUtil.getUserById(report.getUserId().longValue());
          Organization organization = NotificationUtil.getOrganization("walter", reportCreator);
          // populate the context for token replacement in template files
          Map<String, String> context = new HashMap<String, String>();
          context.put("CUSTOMER_EMAIL", ( report.getContactEmail() != null ) ? report.getContactEmail() : "");
          context.put("CONTACT", ( report.getContactName()!= null ) ? report.getContactName() : "");
          context.put("SUBJECT", ( report.getMailSubject() != null ) ? report.getMailSubject() : "");
          context.put("ENTERPRISE", ( report.getContactEnterprise()!= null ) ? report.getContactEnterprise() : "");
          context.put("CONTENT", report.getMailBody());

          byte[] bytes = null;

          if (jmprb.getActionNameEn().equals("Cutting")) {
            bytes = jasperBean.printMobileProductivityReportCuttingReport(jmprb, jmprb.getLangId(), companyId, jmprb.getLocale());

          } else if (jmprb.getActionNameEn().equals("Grinding") || jmprb.getActionNameEn().equals("Blending")) {
            bytes = jasperBean.printMobileProductivityReportGrindingReport(jmprb, jmprb.getLangId(), companyId, jmprb.getLocale());

          } else if (jmprb.getActionNameEn().equals("Sanding")) {
            bytes = jasperBean.printMobileProductivityReportSandingReport(jmprb, jmprb.getLangId(), companyId, jmprb.getLocale());
          }

          InternetAddress internetAddressfrom = new InternetAddress(reportCreator.getEmailAddress(), reportCreator.getFirstName() + " " + reportCreator.getLastName());


          String emailStringList = "";//report.getMailRecipients().replace(";", ",");

//          String emailList = "";
//

          if ( report.getMailRecipients() != null && !report.getMailRecipients().equals("") ){
            emailStringList = report.getMailRecipients().replace(";", ",");
          }


          if ( report.getMailCopies() != null && !report.getMailCopies().equals("") ){
            if ( emailStringList != null && !emailStringList.equals("") ){
              emailStringList += ";"+report.getMailCopies();
            } else {
             emailStringList += report.getMailCopies();
            }
          }

          if ( report.getContactEmail()!= null && !report.getContactEmail().equals("") ){
            if ( emailStringList != null && !emailStringList.equals("") ){
              emailStringList += ";"+report.getContactEmail();
            } else {
             emailStringList += report.getContactEmail();
            }
          }

          if ( report.getResellerContact() != null && !report.getResellerContact().equals("") ){
            if ( emailStringList != null && !emailStringList.equals("") ){
              emailStringList += ";" + report.getResellerContact();
            } else {
             emailStringList += report.getResellerContact();
            }
          }

          if ( emailStringList != null && !emailStringList.equals("") ){
            emailStringList += ";"+reportCreator.getEmailAddress();
          } else {
           emailStringList += reportCreator.getEmailAddress();
          }

          emailStringList = emailStringList.replace(";", ",").toLowerCase();
          List<String> emailList = Arrays.asList(emailStringList.split(","));
          List<String> deDupStringList = new ArrayList<String>(new LinkedHashSet<String>(emailList));
          System.out.println("deDupStringList: " + emailStringList);
          System.out.println("deDupStringList: " + deDupStringList.toString().replace("[", "").replace("]", "").replace(", ", ","));

          InternetAddress[] internetAddressto = InternetAddress.parse(deDupStringList.toString().replace("[", "").replace("]", "").replace(", ", ","));

          File outputFile = new File("/tmp/"+report.getContactEnterprise()+".pdf");

          try ( FileOutputStream outputStream = new FileOutputStream(outputFile); ) {
              outputStream.write(bytes);  //write the bytes and your done.

          } catch (Exception e) {
            e.printStackTrace();
          }

          for ( InternetAddress ia : internetAddressto ){
            MailMessage message = newNotificationMobileProductivityReport(NotificationTemplate.MOBILE_PRODUCTIVITY_REPORT, organization, internetAddressfrom, ia, reportCreator.getLocale(), context);
            message.addFileAttachment(outputFile);
            MailServiceUtil.sendEmail(message);
            logNotificationSent(message, NotificationTemplate.MOBILE_PRODUCTIVITY_REPORT);

            report.setStatus("PROCESSED");
            report.setUpdateDate(new Date());
            walterBean.save(report);
          }
        }else {
          report.setStatus("PENDING");
          report.setUpdateDate(new Date());
          walterBean.save(report);
        }
      }
    } catch (JasperException ex) {
      Logger.getLogger(NotificationBean.class.getName()).log(Level.SEVERE, null, ex);
    } catch (FileNotFoundException ex) {
      Logger.getLogger(NotificationBean.class.getName()).log(Level.SEVERE, null, ex);
    } catch (PortalException ex) {
      Logger.getLogger(NotificationBean.class.getName()).log(Level.SEVERE, null, ex);
    } catch (SystemException ex) {
      Logger.getLogger(NotificationBean.class.getName()).log(Level.SEVERE, null, ex);
    } catch (Exception ex) {
      Logger.getLogger(NotificationBean.class.getName()).log(Level.SEVERE, null, ex);
    }
  }


  public void sendMobileProductivityOrderNotification() {
    try {

      List<Orders> ordersList = productivityReportBean.getMobileProductivityOrderEmail();

      for ( Orders orders : ordersList ){
        User reportCreator = UserLocalServiceUtil.getUserById(orders.getUserId().longValue());
        Organization organization = NotificationUtil.getOrganization("walter", reportCreator);
        // populate the context for token replacement in template files
        Map<String, String> context = new HashMap<String, String>();
        context.put("CUSTOMER_EMAIL", ( orders.getContactEmail() != null ) ? orders.getContactEmail() : "");
        context.put("DISTRIBUTOR", ( orders.getResellerCompany() != null ) ? orders.getResellerCompany() : "");
        context.put("SUBJECT", ( orders.getMailSubject() != null ) ? orders.getMailSubject() : "");
        context.put("DISTRIBUTOR_EMAIL", ( orders.getResellerContact() != null ) ? orders.getResellerContact() : "");
        context.put("CONTENT", orders.getMailBody());

        StringBuffer sb = new StringBuffer();
        String country = walterBean.getWebSiteCountryName(reportCreator.getScreenName().toUpperCase());

        BigDecimal total = new BigDecimal(0);

        DecimalFormat formatterFloat = new DecimalFormat("#,###");

        for ( OrdersDetail od : orders.getOrdersDetailSet() ){
          PrWalterProduct prWalterProduct = productivityReportBean.getProductByGuid(od.getWalterProdId(), country, reportCreator.getLocale().getLanguage());

          String productnumber = "";
          if ( prWalterProduct.getProductNumber() != null ){
            productnumber =  prWalterProduct.getProductNumber().substring(0, 2) + "-" + prWalterProduct.getProductNumber().substring(2, 3) + " " + prWalterProduct.getProductNumber().substring(3);

            sb.append(" <tr>");
            sb.append("   <td>"+productnumber+"</td>");//product number
            sb.append("   <td>"+prWalterProduct.getProductName().getDescription()+"</td>");//product Name
            sb.append("   <td align='right'>"+formatterFloat.format(od.getQuantity())+"</td>");//quantity
            sb.append("   <td align='right'>$"+String.format(Locale.ENGLISH,"%,.2f",od.getUnitPrice().setScale(2, RoundingMode.HALF_UP))+"</td>");//unit price
            sb.append("   <td align='right'>$"+String.format(Locale.ENGLISH,"%,.2f",od.getUnitPrice().multiply(new BigDecimal(od.getQuantity())).setScale(2, RoundingMode.HALF_UP))+"</td>");//total
            sb.append(" </tr>");
            total = total.add(od.getUnitPrice().multiply(new BigDecimal(od.getQuantity())));
          }
        }
        sb.append(" <tr>");
        sb.append("   <td colspan=\"3\"></td>");//product number
        sb.append("   <td class='labelBold'>total:</td>");//unit price
        sb.append("   <td align='right'>$"+String.format(Locale.ENGLISH,"%,.2f", total.setScale(2, RoundingMode.HALF_UP))+"</td>");//total
        sb.append(" </tr>");

        context.put("ORDER_LIST", sb.toString());

        // ready, create and send the message
        InternetAddress internetAddressfrom = new InternetAddress(reportCreator.getEmailAddress(), reportCreator.getFirstName() + " " + reportCreator.getLastName());

        String emailStringList = orders.getMailRecipients();
        if ( orders.getContactEmail() != null && !orders.getContactEmail().equals("") ){
          if ( emailStringList != null && !emailStringList.equals("") ){
            emailStringList += ";"+orders.getContactEmail();
          } else {
           emailStringList += orders.getContactEmail();
          }
        }

        if ( orders.getMailCopies() != null && !orders.getMailCopies().equals("") ){
          if ( emailStringList != null && !emailStringList.equals("") ){
            emailStringList += ";"+orders.getMailCopies();
          } else {
           emailStringList += orders.getMailCopies();
          }
        }

        if ( orders.getMailRecipients() != null && !orders.getMailRecipients().equals("") ){
          if ( emailStringList != null && !emailStringList.equals("") ){
            emailStringList += ";"+orders.getMailRecipients();
          } else {
           emailStringList += orders.getMailRecipients();
          }
        }

        if ( orders.getResellerContact() != null && !orders.getResellerContact().equals("") ){
          if ( emailStringList != null && !emailStringList.equals("") ){
            emailStringList += ";"+orders.getResellerContact();
          } else {
           emailStringList += orders.getResellerContact();
          }
        }

        emailStringList = emailStringList.replace(";", ",").toLowerCase();
        List<String> emailList = Arrays.asList(emailStringList.split(","));
        List<String> deDupStringList = new ArrayList<String>(new LinkedHashSet<String>(emailList));
        System.out.println("deDupStringList: " + emailStringList);
        System.out.println("deDupStringList: " + deDupStringList.toString().replace("[", "").replace("]", "").replace(", ", ",").replace(" ", ""));

        InternetAddress[] internetAddressto = InternetAddress.parse(deDupStringList.toString().replace("[", "").replace("]", "").replace(", ", ",").replace(" ", ""));

        for ( InternetAddress ia : internetAddressto ){

          MailMessage message = newNotificationMobileProductivityReport(NotificationTemplate.MOBILE_PRODUCTIVITY_REPORT_ORDER, organization, internetAddressfrom, ia, reportCreator.getLocale(), context);
          MailServiceUtil.sendEmail(message);
          logNotificationSent(message, NotificationTemplate.MOBILE_PRODUCTIVITY_REPORT_ORDER);

          orders.setStatus("PROCESSED");
          orders.setUpdateDate(new Date());
          walterBean.save(orders);
        }

      }
    } catch (Exception e) {
      LOGGER.log(Level.SEVERE, e.getMessage());
    }
  }


}
