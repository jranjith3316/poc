/* 
 * Copyright 2013 Savoir-faire Linux
 * 
 * This file is part of Walter-Portal.
 * 
 * Walter-Portal is free software: you can redistribute it and/or modify it under the terms of the 
 * GNU General Public License as published by the Free Software Foundation, either version 3 
 * of the License, or (at your option) any later version.
 * 
 * Walter-Portal is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with Walter-Portal. 
 * If not, see http://www.gnu.org/licenses/.
 */
package com.savoirfairelinux.walter.jasper.model;

import com.savoirfairelinux.walter.dao.waltercb.Er;
import com.savoirfairelinux.walter.dao.waltercb.ErTrialTxt;
import com.savoirfairelinux.walter.dao.waltercb.ErTxt;

import java.io.Serializable;
import java.util.List;

/**
 * 
 * @author jderuere
 * 
 */
public class JasperLabReportBean implements Serializable {
    private String logoHeader;
    private String logoFooter;
    private String logoISO;
    private String creatorUserName;
    private String contaminant;
    private Er report;
    private ErTxt text;
    private List<ErTrialTxt> trialTexts;
    private List<JasperPictureBean> pictures;

    public String getLogoHeader() {
        return logoHeader;
    }

    public void setLogoHeader(String logoHeader) {
        this.logoHeader = logoHeader;
    }

    public String getLogoFooter() {
        return logoFooter;
    }

    public void setLogoFooter(String logoFooter) {
        this.logoFooter = logoFooter;
    }

    public String getLogoISO() {
        return logoISO;
    }

    public void setLogoISO(String logoISO) {
        this.logoISO = logoISO;
    }

    public String getCreatorUserName() {
        return creatorUserName;
    }

    public void setCreatorUserName(String creatorUserName) {
        this.creatorUserName = creatorUserName;
    }

    public String getContaminant() {
      return contaminant;
    }

    public void setContaminant(String contaminant) {
      this.contaminant = contaminant;
    }    
    
    public Er getReport() {
        return report;
    }

    public void setReport(Er report) {
        this.report = report;
    }

    public ErTxt getText() {
        return text;
    }

    public void setText(ErTxt text) {
        this.text = text;
    }

    public List<ErTrialTxt> getTrialTexts() {
        return trialTexts;
    }

    public void setTrialTexts(List<ErTrialTxt> trialTexts) {
        this.trialTexts = trialTexts;
    }

    public List<JasperPictureBean> getPictures() {
        return pictures;
    }

    public void setPictures(List<JasperPictureBean> pictures) {
        this.pictures = pictures;
    }
}