package com.savoirfairelinux.walter.service;

import java.util.List;

import javax.ejb.Remote;

import com.savoirfairelinux.walter.model.PowerTool;
import com.savoirfairelinux.walter.model.PrWalterProduct;
import com.savoirfairelinux.walter.model.ProductivityCountry;

@Remote
public interface ProductivityReportMobileBeanRemote {
	
	List<PowerTool> getAllPowerTool(String webSiteCountryName);
	PrWalterProduct loadWalterProductPartially(PrWalterProduct product, String languageAbbreviation);
	List<ProductivityCountry> getAllCountries();

}
