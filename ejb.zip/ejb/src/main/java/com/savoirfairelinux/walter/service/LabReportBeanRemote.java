/* 
 * Copyright 2012 Savoir-faire Linux
 * 
 * This file is part of Walter-Portal.
 * 
 * Walter-Portal is free software: you can redistribute it and/or modify it under the terms of the 
 * GNU General Public License as published by the Free Software Foundation, either version 3 
 * of the License, or (at your option) any later version.
 * 
 * Walter-Portal is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with Walter-Portal. 
 * If not, see http://www.gnu.org/licenses/.
 */
package com.savoirfairelinux.walter.service;

import com.savoirfairelinux.walter.dao.waltercb.Er;
import com.savoirfairelinux.walter.dao.waltercb.ErCounter;
import com.savoirfairelinux.walter.dao.waltercb.Country;
import com.savoirfairelinux.walter.dao.waltercb.ULang;
import com.savoirfairelinux.walter.model.Franchise;
import com.savoirfairelinux.walter.model.SearchEr;

import javax.ejb.Remote;
import java.util.List;

/**
 *
 * @author mgubaidullin
 * @author jderuere
 */
@Remote
public interface LabReportBeanRemote {

    public List<Er> search(SearchEr form, String userName, String organization, Long langId) throws Exception;

    public List<Er> getRecentReports(String organization, String userName, Long langId) throws Exception;

    public List<Er> getUnreadReports(String organization, String userName, Long langId) throws Exception;

    public List<Er> getMyUnsubmitReports(String organization, String userName, Long langId) throws Exception;

    public List<Er> getMySubmittedReports(String organization, String userName, Long langId) throws Exception;

    public List<Er> getMyPublishedReports(String organization, String userName, Long langId) throws Exception;

    public List<Er> getMyRequestPublishedReports(String organization, String userName, Long langId) throws Exception;

    public List<Er> getSubmittedReports(String organization, String userName, Long langId) throws Exception;

    public Er save(Er er, Country country, ULang language) throws Exception;

    public Er submit(Er report) throws Exception;

    public void publish(Er report) throws Exception;

    public Er getLabReport(long id, String organization, Long langId, String languageAbbreviation) throws Exception;

    public ErCounter setCounter(Long id, String userName) throws Exception;

    public List<Franchise> getWalterFranchises(String languageAbbreviation) throws Exception;

    public void cancel(Er report) throws Exception;

    public List<String> getCustomers(String organization, Long langId);
}




