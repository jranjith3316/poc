/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.service;

import com.savoirfairelinux.walter.dao.idb.OoBabelMembers;
import com.savoirfairelinux.walter.dao.idb.OoClasses;
import com.savoirfairelinux.walter.dao.idb.OoClassesMembers;
import com.savoirfairelinux.walter.dao.idb.OoInstances;
import com.savoirfairelinux.walter.dao.idb.OoInstancesMembersValues;
import com.savoirfairelinux.walter.dao.idb.TemplateItem;
import com.savoirfairelinux.walter.dao.idb.TemplateTitle;
import com.savoirfairelinux.walter.dao.idb.WalterProductsCountries;
import com.savoirfairelinux.walter.dao.idb.WalterProductsDocuments;
import com.savoirfairelinux.walter.dao.idb.WalterProductsImages;
import com.savoirfairelinux.walter.dao.idb.WalterTvvideos;
import com.savoirfairelinux.walter.dao.waltercb.Cnt;
import com.savoirfairelinux.walter.dao.waltercb.CntTxt;
import com.savoirfairelinux.walter.dao.waltercb.ErTxt;
import com.savoirfairelinux.walter.dao.waltercb.IdeaTxt;
import java.util.List;
import javax.ejb.Remote;

/**
 *
 * @author jsgill
 */
@Remote
public interface ProductDashboardBeanRemote {
  public List<OoClasses> getFranchiseList() throws Exception;
  
  public OoBabelMembers getFranchiseTranslation(String languageAbbreviation, String classguid) throws Exception;
  
  public OoInstances getFranchiseInstance(String classguid) throws Exception;
  
  public List<OoInstances> getTradeName(String franchiseGuid, String countryCode) throws Exception;
  
  public OoBabelMembers getInstanceNameTranslation(String languageAbbreviation, String instanceName, String instanceGuid) throws Exception;

  public OoBabelMembers getProductInfoTranslation(String languageAbbreviation, String countryCode, String fieldSearch, String productGuid) throws Exception;
  
  public WalterProductsCountries getWalterProductCountries(String countryCode, String tradenameGuid) throws Exception;

  public List<WalterProductsImages> getWalterProductImages(String countryCode, String productNumber) throws Exception;
  
  public List<String> getWalterProductRelation(String productNumber, String relationType, String className, String languageAbbreviation) throws Exception;
  
  public List<WalterTvvideos> getWalterProductVideo(WalterProductsCountries wpc, String languageAbbreviation) throws Exception;

  public List<WalterProductsDocuments> getWalterProductDocument(WalterProductsCountries wpc, String languageAbbreviation) throws Exception;
  
  public List<Object[]> getWalterProductListTool(String tradeGuid, String countryCode, String languageAbbreviation) throws Exception;
  
  public List<Object[]> getWalterProductListToolImage(String tradeGuid, String countryCode, String instanceGuid) throws Exception;
  
  public List<TemplateTitle> getWalterProductTemplateTitle(String templateName, short rowId) throws Exception;
  
  public List<TemplateItem> getWalterProductTemplateItem(String templateName, short rowId, short columnId) throws Exception;
  
  public OoClassesMembers getOoClassesMembers(String memberguid) throws Exception;
  
  public WalterProductsDocuments getWalterProductDocument(WalterProductsCountries wpc, String languageAbbreviation, String documentType) throws Exception;
  
  public Object[] getWalterProductMesure(WalterProductsCountries wpc, String memberName, String unitType) throws Exception;
  
  public String getWalterProductMesureUniversal(WalterProductsCountries wpc, String memberName) throws Exception;
  
  public List<WalterProductsCountries> getWalterProductListByTradeGuidToolGuid(String countryCode, String tradenameGuid, String toolGuid, String template) throws Exception;
  
  public List<CntTxt> getSolutionReport(String fanchiseGuid, String tradenameGuid, Long langId);
  
  public List<ErTxt> getLabReport(String fanchiseGuid, String tradenameGuid, Long langId);

  public List<IdeaTxt> getNewIdea(String fanchiseGuid, String tradenameGuid, Long langId);

  public OoInstances getTradeNameInstance(String classguid, String tradeNameguid) throws Exception;

  public List<OoInstances> getActionInstance(String countryCode, String tradenameGuid) throws Exception;
  
  public List<OoInstances> getToolMaterialByFranchiseAction(String countryCode, String franchiseGuid, String actionGuid) throws Exception;
  
  public List<OoInstances> getTradeNameByFranchiseActionTool(String countryCode, String franchiseGuid, String actionGuid, String toolGuid) throws Exception;
}
