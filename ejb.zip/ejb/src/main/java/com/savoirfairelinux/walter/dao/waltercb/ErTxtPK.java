/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;

/**
 *
 * @author mgubaidullin
 */
@Embeddable
public class ErTxtPK implements Serializable {
    @Basic(optional = false)
    @NotNull
    @Column(name = "ER_ID", nullable = false)
    private long erId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "LANG_ID", nullable = false)
    private long langId;

    public ErTxtPK() {
    }

    public ErTxtPK(long erId, long langId) {
        this.erId = erId;
        this.langId = langId;
    }

    public long getErId() {
        return erId;
    }

    public void setErId(long erId) {
        this.erId = erId;
    }

    public long getLangId() {
        return langId;
    }

    public void setLangId(long langId) {
        this.langId = langId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) erId;
        hash += (int) langId;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ErTxtPK)) {
            return false;
        }
        ErTxtPK other = (ErTxtPK) object;
        if (this.erId != other.erId) {
            return false;
        }
        if (this.langId != other.langId) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.ErTxtPK[ erId=" + erId + ", langId=" + langId + " ]";
    }
    
}
