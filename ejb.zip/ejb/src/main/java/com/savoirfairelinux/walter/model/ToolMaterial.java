/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.model;

/**
 *
 * @author jsgill
 */
public class ToolMaterial {
  private String toolMaterialGuid;
  private String description;

  public ToolMaterial(String toolMaterialGuid, String description) {
    this.toolMaterialGuid = toolMaterialGuid;
    this.description = description;
  }

  public String getToolMaterialGuid() {
    return toolMaterialGuid;
  }

  public void setToolMaterialGuid(String toolMaterialGuid) {
    this.toolMaterialGuid = toolMaterialGuid;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }


}
