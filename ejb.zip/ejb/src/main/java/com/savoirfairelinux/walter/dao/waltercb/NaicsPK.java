/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author mgubaidullin
 */
@Embeddable
public class NaicsPK implements Serializable {
    @Basic(optional = false)
    @NotNull
    @Column(name = "COUNTRY_ID")
    private short countryId;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 6)
    @Column(name = "NAICS")
    private String naics;

    public NaicsPK() {
    }

    public NaicsPK(short countryId, String naics) {
        this.countryId = countryId;
        this.naics = naics;
    }

    public short getCountryId() {
        return countryId;
    }

    public void setCountryId(short countryId) {
        this.countryId = countryId;
    }

    public String getNaics() {
        return naics;
    }

    public void setNaics(String naics) {
        this.naics = naics;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) countryId;
        hash += (naics != null ? naics.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof NaicsPK)) {
            return false;
        }
        NaicsPK other = (NaicsPK) object;
        if (this.countryId != other.countryId) {
            return false;
        }
        if ((this.naics == null && other.naics != null) || (this.naics != null && !this.naics.equals(other.naics))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.NaicsPK[ countryId=" + countryId + ", naics=" + naics + " ]";
    }
    
}
