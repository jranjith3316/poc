/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.walter;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "PG_TREE_ITEM", catalog = "", schema = DatabaseConstants.WALTER_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "PgTreeItem.findAll", query = "SELECT p FROM PgTreeItem p"),
    @NamedQuery(name = "PgTreeItem.findByPgTreeCode", query = "SELECT p FROM PgTreeItem p WHERE p.pgTreeItemPK.pgTreeCode = :pgTreeCode"),
    @NamedQuery(name = "PgTreeItem.findByItemId", query = "SELECT p FROM PgTreeItem p WHERE p.pgTreeItemPK.itemId = :itemId"),
    @NamedQuery(name = "PgTreeItem.findByItemParentId", query = "SELECT p FROM PgTreeItem p WHERE p.itemParentId = :itemParentId"),
    @NamedQuery(name = "PgTreeItem.findByFileName", query = "SELECT p FROM PgTreeItem p WHERE p.fileName = :fileName"),
    @NamedQuery(name = "PgTreeItem.findByCreatorUserName", query = "SELECT p FROM PgTreeItem p WHERE p.creatorUserName = :creatorUserName"),
    @NamedQuery(name = "PgTreeItem.findByStyleId", query = "SELECT p FROM PgTreeItem p WHERE p.styleId = :styleId"),
    @NamedQuery(name = "PgTreeItem.findByStyleOverId", query = "SELECT p FROM PgTreeItem p WHERE p.styleOverId = :styleOverId"),
    @NamedQuery(name = "PgTreeItem.findByUrl", query = "SELECT p FROM PgTreeItem p WHERE p.url = :url"),
    @NamedQuery(name = "PgTreeItem.findByOrderBy", query = "SELECT p FROM PgTreeItem p WHERE p.orderBy = :orderBy"),
    @NamedQuery(name = "PgTreeItem.findByImgdir", query = "SELECT p FROM PgTreeItem p WHERE p.imgdir = :imgdir"),
    @NamedQuery(name = "PgTreeItem.findByImgdiropen", query = "SELECT p FROM PgTreeItem p WHERE p.imgdiropen = :imgdiropen"),
    @NamedQuery(name = "PgTreeItem.findByImgitem", query = "SELECT p FROM PgTreeItem p WHERE p.imgitem = :imgitem")})
public class PgTreeItem implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected PgTreeItemPK pgTreeItemPK;
    @Column(name = "ITEM_PARENT_ID")
    private Integer itemParentId;
    @Size(max = 90)
    @Column(name = "FILE_NAME", length = 90)
    private String fileName;
    @Size(max = 256)
    @Column(name = "CREATOR_USER_NAME", length = 256)
    private String creatorUserName;
    @Column(name = "STYLE_ID")
    private Integer styleId;
    @Column(name = "STYLE_OVER_ID")
    private Integer styleOverId;
    @Size(max = 200)
    @Column(length = 200)
    private String url;
    @Column(name = "ORDER_BY")
    private Integer orderBy;
    @Size(max = 100)
    @Column(length = 100)
    private String imgdir;
    @Size(max = 100)
    @Column(length = 100)
    private String imgdiropen;
    @Size(max = 100)
    @Column(length = 100)
    private String imgitem;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "pgTreeItem", fetch= FetchType.LAZY)
    private Set<PgTreeItemTxt> pgTreeItemTxtSet;
    @JoinColumn(name = "PG_TREE_CODE", referencedColumnName = "PG_TREE_CODE", nullable = false, insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private PgTree pgTree;
    @Size(max = 100)
    @Column(name = "COMPANY", length = 100)
    private String company;

    public PgTreeItem() {
    }

    public PgTreeItem(PgTreeItemPK pgTreeItemPK) {
        this.pgTreeItemPK = pgTreeItemPK;
    }

    public PgTreeItem(String pgTreeCode, int itemId) {
        this.pgTreeItemPK = new PgTreeItemPK(pgTreeCode, itemId);
    }

    public PgTreeItemPK getPgTreeItemPK() {
        return pgTreeItemPK;
    }

    public void setPgTreeItemPK(PgTreeItemPK pgTreeItemPK) {
        this.pgTreeItemPK = pgTreeItemPK;
    }

    public Integer getItemParentId() {
        return itemParentId;
    }

    public void setItemParentId(Integer itemParentId) {
        this.itemParentId = itemParentId;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getCreatorUserName() {
        return creatorUserName;
    }

    public void setCreatorUserName(String creatorUserName) {
        this.creatorUserName = creatorUserName;
    }

    public Integer getStyleId() {
        return styleId;
    }

    public void setStyleId(Integer styleId) {
        this.styleId = styleId;
    }

    public Integer getStyleOverId() {
        return styleOverId;
    }

    public void setStyleOverId(Integer styleOverId) {
        this.styleOverId = styleOverId;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Integer getOrderBy() {
        return orderBy;
    }

    public void setOrderBy(Integer orderBy) {
        this.orderBy = orderBy;
    }

    public String getImgdir() {
        return imgdir;
    }

    public void setImgdir(String imgdir) {
        this.imgdir = imgdir;
    }

    public String getImgdiropen() {
        return imgdiropen;
    }

    public void setImgdiropen(String imgdiropen) {
        this.imgdiropen = imgdiropen;
    }

    public String getImgitem() {
        return imgitem;
    }

    public void setImgitem(String imgitem) {
        this.imgitem = imgitem;
    }

    @XmlTransient
    public Set<PgTreeItemTxt> getPgTreeItemTxtSet() {
        return pgTreeItemTxtSet;
    }

    public void setPgTreeItemTxtSet(Set<PgTreeItemTxt> pgTreeItemTxtSet) {
        this.pgTreeItemTxtSet = pgTreeItemTxtSet;
    }

    public PgTree getPgTree() {
        return pgTree;
    }

    public void setPgTree(PgTree pgTree) {
        this.pgTree = pgTree;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }
    
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (pgTreeItemPK != null ? pgTreeItemPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PgTreeItem)) {
            return false;
        }
        PgTreeItem other = (PgTreeItem) object;
        if ((this.pgTreeItemPK == null && other.pgTreeItemPK != null) || (this.pgTreeItemPK != null && !this.pgTreeItemPK.equals(other.pgTreeItemPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.walter.PgTreeItem[ pgTreeItemPK=" + pgTreeItemPK + " ]";
    }
    
}
