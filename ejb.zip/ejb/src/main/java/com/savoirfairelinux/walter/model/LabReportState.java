package com.savoirfairelinux.walter.model;

public enum LabReportState {

	UNSUBMIT,
	SUBMIT,
	PUBLISH;
}
