/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import javax.persistence.*;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "IDEA_CATEGORY", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "IdeaCategory.findAll", query = "SELECT i FROM IdeaCategory i"),
    @NamedQuery(name = "IdeaCategory.findByCatId", query = "SELECT i FROM IdeaCategory i WHERE i.ideaCategoryPK.catId = :catId"),
    @NamedQuery(name = "IdeaCategory.findByLangId", query = "SELECT i FROM IdeaCategory i WHERE i.ideaCategoryPK.langId = :langId"),
    @NamedQuery(name = "IdeaCategory.findByDescription", query = "SELECT i FROM IdeaCategory i WHERE i.description = :description")})
public class IdeaCategory implements Serializable {
    private static final long serialVersionUID = 1L;

    public static final long PRODUCTS_ID = 1;

    @EmbeddedId
    protected IdeaCategoryPK ideaCategoryPK;
    @Size(max = 50)
    private String description;

    public IdeaCategory() {
    }

    public IdeaCategory(IdeaCategoryPK ideaCategoryPK) {
        this.ideaCategoryPK = ideaCategoryPK;
    }

    public IdeaCategory(long catId, long langId) {
        this.ideaCategoryPK = new IdeaCategoryPK(catId, langId);
    }

    public IdeaCategoryPK getIdeaCategoryPK() {
        return ideaCategoryPK;
    }

    public void setIdeaCategoryPK(IdeaCategoryPK ideaCategoryPK) {
        this.ideaCategoryPK = ideaCategoryPK;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (ideaCategoryPK != null ? ideaCategoryPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof IdeaCategory)) {
            return false;
        }
        IdeaCategory other = (IdeaCategory) object;
        if ((this.ideaCategoryPK == null && other.ideaCategoryPK != null) || (this.ideaCategoryPK != null && !this.ideaCategoryPK.equals(other.ideaCategoryPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.IdeaCategory[ ideaCategoryPK=" + ideaCategoryPK + " ]";
    }
    
}
