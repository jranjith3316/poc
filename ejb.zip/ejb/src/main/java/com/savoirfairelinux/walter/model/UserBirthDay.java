/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.model;

import com.liferay.portal.model.User;
import java.util.Date;

/**
 *
 * @author jsgill
 */
public class UserBirthDay {
  private User user;
  private Date birthDay;

  public UserBirthDay(User user, Date birthDay) {
    this.user = user;
    this.birthDay = birthDay;
  }

  public User getUser() {
    return user;
  }

  public void setUser(User user) {
    this.user = user;
  }

  public Date getBirthDay() {
    return birthDay;
  }

  public void setBirthDay(Date birthDay) {
    this.birthDay = birthDay;
  }
          
}
