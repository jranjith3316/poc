package com.savoirfairelinux.walter.model;

import java.io.Serializable;

public class ExpenseMonth implements Serializable {
	
	private int monthId;
	private String description;	


	public ExpenseMonth(int monthId, String description) {
		this.monthId = monthId;
		this.description = description;
	}


	public int getMonthId() {
		return monthId;
	}


	public void setMonthId(int monthId) {
		this.monthId = monthId;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	@Override
	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		} else if (this == obj) {
			return true;
		} else if (monthId == ((ExpenseMonth) obj).getMonthId()) {
			return true;
		}
		return false;
	}
}
