/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "CNT_OPINION", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CntOpinion.findAll", query = "SELECT c FROM CntOpinion c"),
    @NamedQuery(name = "CntOpinion.findByCnt", query = "SELECT c FROM CntOpinion c WHERE c.cnt = :cnt"),
    @NamedQuery(name = "CntOpinion.findByOpinionId", query = "SELECT c FROM CntOpinion c WHERE c.opinionId = :opinionId"),
    @NamedQuery(name = "CntOpinion.findByCreatorUserName", query = "SELECT c FROM CntOpinion c WHERE c.creatorUserName = :creatorUserName"),
    @NamedQuery(name = "CntOpinion.findByDateCreated", query = "SELECT c FROM CntOpinion c WHERE c.dateCreated = :dateCreated"),
    @NamedQuery(name = "CntOpinion.findByRanking", query = "SELECT c FROM CntOpinion c WHERE c.ranking = :ranking")})
public class CntOpinion implements Serializable {
    private static final long serialVersionUID = 1L;
    @ManyToOne
    @JoinColumn(name="CNT_ID")
    private Cnt cnt;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "OPINION_ID")
    @GeneratedValue(generator = "CNT_OPINION_SEQ", strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "CNT_OPINION_SEQ", sequenceName = "CNT_OPINION_SEQ", schema = DatabaseConstants.WALTERCB_SCHEMA, allocationSize=1)
    private Long opinionId;
    @Size(max = 256)
    @Column(name = "CREATOR_USER_NAME")
    private String creatorUserName;
    @Column(name = "DATE_CREATED")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateCreated;
    private Integer ranking;

    public CntOpinion() {
    }

    public CntOpinion(Long opinionId) {
        this.opinionId = opinionId;
    }

    public Cnt getCnt() {
        return cnt;
    }

    public void setCnt(Cnt cnt) {
        this.cnt = cnt;
    }

    public Long getOpinionId() {
        return opinionId;
    }

    public void setOpinionId(Long opinionId) {
        this.opinionId = opinionId;
    }

    public String getCreatorUserName() {
        return creatorUserName;
    }

    public void setCreatorUserName(String creatorUserName) {
        this.creatorUserName = creatorUserName;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public Integer getRanking() {
        return ranking;
    }

    public void setRanking(Integer ranking) {
        this.ranking = ranking;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (opinionId != null ? opinionId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CntOpinion)) {
            return false;
        }
        CntOpinion other = (CntOpinion) object;
        if ((this.opinionId == null && other.opinionId != null) || (this.opinionId != null && !this.opinionId.equals(other.opinionId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.CntOpinion[ opinionId=" + opinionId + " ]";
    }
    
}
