/* 
 * Copyright 2013 Savoir-faire Linux
 * 
 * This file is part of Walter-Portal.
 * 
 * Walter-Portal is free software: you can redistribute it and/or modify it under the terms of the 
 * GNU General Public License as published by the Free Software Foundation, either version 3 
 * of the License, or (at your option) any later version.
 * 
 * Walter-Portal is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with Walter-Portal. 
 * If not, see http://www.gnu.org/licenses/.
 */
package com.savoirfairelinux.walter.jasper.model;

import com.savoirfairelinux.walter.dao.waltercb.CntProduct;

import java.io.InputStream;
import java.io.Serializable;
import java.util.List;

/**
 * 
 * @author jbonjean
 * 
 */
public class JasperSolutionsReportBean implements Serializable {
	private String userName;
	private String label;
	private String jobTitle;
	private String email;
	private String location;
	private String department;
	private String type;
	private String objective;
	private String date;
	private String refNumber;
	private String activity;
	private String material;
	private String customer;
	private String industry;
	private String contaminant;
	private String machinery;
	private String naics;
	private List<CntProduct> products;
	private String currentProcess;
	private String walterSolution;
	private String comment;
	private List<String> keySalesAdvantages;
	private List<JasperFeedbackBean> feedback;
	private String ratingCount;
	private String ratingAverage;
	private InputStream portrait;
	private List<JasperPictureBean> images;
	private String organization;

	public String getRatingCount() {
		return ratingCount;
	}

	public void setRatingCount(String ratingCount) {
		this.ratingCount = ratingCount;
	}

	public String getRatingAverage() {
		return ratingAverage;
	}

	public void setRatingAverage(String ratingAverage) {
		this.ratingAverage = ratingAverage;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getJobTitle() {
		return jobTitle;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getObjective() {
		return objective;
	}

	public void setObjective(String objective) {
		this.objective = objective;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getRefNumber() {
		return refNumber;
	}

	public void setRefNumber(String refNumber) {
		this.refNumber = refNumber;
	}

	public String getActivity() {
		return activity;
	}

	public void setActivity(String activity) {
		this.activity = activity;
	}

	public String getMaterial() {
		return material;
	}

	public void setMaterial(String material) {
		this.material = material;
	}

	public String getCustomer() {
		return customer;
	}

	public void setCustomer(String customer) {
		this.customer = customer;
	}

	public String getIndustry() {
		return industry;
	}

	public void setIndustry(String industry) {
		this.industry = industry;
	}

	public String getContaminant() {
		return contaminant;
	}

	public void setContaminant(String contaminant) {
		this.contaminant = contaminant;
	}

	public String getNaics() {
		return naics;
	}

	public void setNaics(String naics) {
		this.naics = naics;
	}

	public void setProducts(List<CntProduct> products) {
		this.products = products;
	}

	public List<CntProduct> getProducts() {
		return products;
	}

	public String getCurrentProcess() {
		return currentProcess;
	}

	public void setCurrentProcess(String currentProcess) {
		this.currentProcess = currentProcess;
	}

	public String getWalterSolution() {
		return walterSolution;
	}

	public void setWalterSolution(String walterSolution) {
		this.walterSolution = walterSolution;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public List<String> getKeySalesAdvantages() {
		return keySalesAdvantages;
	}

	public void setKeySalesAdvantages(List<String> keySalesAdvantages) {
		this.keySalesAdvantages = keySalesAdvantages;
	}

	public List<JasperFeedbackBean> getFeedback() {
		return feedback;
	}

	public void setFeedback(List<JasperFeedbackBean> feedback) {
		this.feedback = feedback;
	}

	public InputStream getPortrait() {
		return portrait;
	}

	public void setPortrait(InputStream portrait) {
		this.portrait = portrait;
	}

    public List<JasperPictureBean> getImages() {
        return images;
    }

    public void setImages(List<JasperPictureBean> images) {
        this.images = images;
    }

    public String getMachinery() {
		return machinery;
	}

	public void setMachinery(String machinery) {
		this.machinery = machinery;
	}

	public String getOrganization() {
		return organization;
	}

	public void setOrganization(String organization) {
		this.organization = organization;
	}
}
