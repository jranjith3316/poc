/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.service.impl;

import com.savoirfairelinux.walter.dao.walter.PgTreeItem;
import com.savoirfairelinux.walter.dao.walter.PgTreeItemTxt;
import com.savoirfairelinux.walter.dao.waltercb.ULang;
import com.savoirfairelinux.walter.service.PhotoGalleryBeanRemote;

import javax.annotation.security.PermitAll;
import javax.ejb.*;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.*;
import java.util.logging.Logger;

@Stateless(name = "PhotoGalleryBean")
@TransactionManagement(TransactionManagementType.CONTAINER)
@PermitAll
@LocalBean
public class PhotoGalleryBean implements PhotoGalleryBeanRemote {

    @PersistenceContext(unitName = "waltershare")
    EntityManager entityManager;
    public static final Logger LOG = Logger.getLogger(PhotoGalleryBean.class.getCanonicalName());
    @EJB
    WalterBean walterBean;
    @EJB
    SingletonBean singletonBean;

    @Override
    public void deleteItem(Integer itemId) throws Exception {
        try {
            PgTreeItem pgTreeItem = getPhoto(itemId);
            List<PgTreeItemTxt> txts = getTxtForItem(pgTreeItem);
            for (PgTreeItemTxt txt : txts) {
                entityManager.remove(txt);
            }
            entityManager.remove(pgTreeItem);
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
    }

    @Override
    @Interceptors(DebugInterceptor.class)
    public List<PgTreeItem> getImages(Integer itemParentId, String languageAbbreviature, String company) throws Exception {
        HashMap<String, PgTreeItem> result = new HashMap<String, PgTreeItem>();
        Map<String, PgTreeItem> treeMap = null;
        ULang language = walterBean.getULang(languageAbbreviature);
//        Query query = entityManager.createQuery("SELECT p FROM PgTreeItem p LEFT JOIN FETCH p.pgTreeItemTxtSet txt WHERE p.itemParentId = :itemParentId and txt.pgTreeItemTxtPK.langId = :lang and p.company = :company");
        Query query = entityManager.createQuery("SELECT p FROM PgTreeItem p LEFT JOIN FETCH p.pgTreeItemTxtSet txt WHERE p.itemParentId = :itemParentId and p.company = :company");
        try {
            List<PgTreeItem> tempResult = query
                    .setParameter("itemParentId", itemParentId)
                    .setParameter("company", company)
                    //                    .setParameter("lang", language.getLangId().intValue() == 2 ? language.getLangId().intValue() : 1)
                    .getResultList();
            for (PgTreeItem item : tempResult) {
                if (!result.containsKey(item.getPgTreeItemPK().toString())) {
                    result.put(item.getPgTreeItemPK().toString(), item);
                } else {
                    PgTreeItemTxt txtResult = null;
                    for (PgTreeItemTxt txt : item.getPgTreeItemTxtSet()) {
                        if (txt.getPgTreeItemTxtPK().getLangId() == language.getLangId().intValue()) {
                            txtResult = txt;
                        }
                    }
                    if (txtResult != null) {
                        PgTreeItem newItem = item;
                        newItem.getPgTreeItemTxtSet().clear();
                        newItem.getPgTreeItemTxtSet().add(txtResult);
                        result.put(newItem.getPgTreeItemPK().toString(), newItem);
                    }
                }
            }
            // sort result 
            Map<String, PgTreeItem> map = new HashMap<String, PgTreeItem>();
            for (PgTreeItem item : result.values()) {
                if (item.getPgTreeItemTxtSet().iterator().hasNext()) {
                    map.put(item.getPgTreeItemTxtSet().iterator().next().getItemDesc(), item);
                }
            }
            treeMap = new TreeMap<String, PgTreeItem>(map);
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return new ArrayList(treeMap.values());
    }

    @Override
    public PgTreeItem getPhoto(Integer itemId) throws Exception {
        PgTreeItem result = null;
        try {
            Query query = entityManager.createNamedQuery("PgTreeItem.findByItemId", PgTreeItem.class);
            result = (PgTreeItem) query.setParameter("itemId", itemId).getResultList().get(0);
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    public Integer getNextItemId() throws Exception {
        Integer result = 0;
        try {
            Query query = entityManager.createQuery(singletonBean.getPhotoGalleryQuery("photos.max.id"));
            result = (Integer) query.getSingleResult();
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result + 1;
    }

    @Override
    public List<PgTreeItemTxt> getImagesTxt(String languageAbbreviature, String company) throws Exception {
        ULang language = walterBean.getULang(languageAbbreviature);
        List<PgTreeItemTxt> result = null;
        Query query = entityManager.createQuery(singletonBean.getPhotoGalleryQuery("all.photos.txt"));
        try {
            result = query.setParameter("company", company).setParameter("lang", language.getLangId().intValue() == 2 ? language.getLangId().intValue() : 1).getResultList();
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    public List<PgTreeItemTxt> getTxtForItem(PgTreeItem pgTreeItem) throws Exception {
        List<PgTreeItemTxt> result = null;
        try {
            Query query = entityManager.createQuery(singletonBean.getPhotoGalleryQuery("photos.by.itemid"));
            result = query.setParameter("itemId", pgTreeItem.getPgTreeItemPK().getItemId()).getResultList();
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }
}
