/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.walter;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "U_LONGLABEL", catalog = "", schema = DatabaseConstants.WALTER_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "ULonglabel.findAll", query = "SELECT u FROM ULonglabel u"),
    @NamedQuery(name = "ULonglabel.findByLabelId", query = "SELECT u FROM ULonglabel u WHERE u.labelId = :labelId"),
    @NamedQuery(name = "ULonglabel.findByLabelRef", query = "SELECT u FROM ULonglabel u WHERE u.labelRef = :labelRef")})
public class ULonglabel implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "LABEL_ID")
    private Long labelId;
    @Size(max = 100)
    @Column(name = "LABEL_REF")
    private String labelRef;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "uLonglabel")
    private List<ULonglabelD> uLonglabelDList;

    public ULonglabel() {
    }

    public ULonglabel(Long labelId) {
        this.labelId = labelId;
    }

    public Long getLabelId() {
        return labelId;
    }

    public void setLabelId(Long labelId) {
        this.labelId = labelId;
    }

    public String getLabelRef() {
        return labelRef;
    }

    public void setLabelRef(String labelRef) {
        this.labelRef = labelRef;
    }

    @XmlTransient
    public List<ULonglabelD> getULonglabelDList() {
        return uLonglabelDList;
    }

    public void setULonglabelDList(List<ULonglabelD> uLonglabelDList) {
        this.uLonglabelDList = uLonglabelDList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (labelId != null ? labelId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ULonglabel)) {
            return false;
        }
        ULonglabel other = (ULonglabel) object;
        if ((this.labelId == null && other.labelId != null) || (this.labelId != null && !this.labelId.equals(other.labelId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.ULonglabel[ labelId=" + labelId + " ]";
    }
    
}
