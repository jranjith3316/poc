/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.tecsys.soap;

/**
 *
 * @author jsgill
 */
public class Parameter {
  private String paramName;
  private String value;

  public String getParamName() {
    return paramName;
  }

  public void setParamName(String paramName) {
    this.paramName = paramName;
  }

  public String getValue() {
    return value;
  }

  public void setValue(String value) {
    this.value = value;
  }

  public Parameter(String paramName, String value) {
    this.paramName = paramName;
    this.value = value;
  }
}
