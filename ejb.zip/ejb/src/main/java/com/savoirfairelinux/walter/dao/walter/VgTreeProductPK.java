/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.walter;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author jsgill
 */
@Embeddable
public class VgTreeProductPK implements Serializable {
  @Basic(optional = false)
  @NotNull
  @Size(min = 1, max = 10)
  @Column(name = "VG_TREE_CODE")
  private String vgTreeCode;
  @Basic(optional = false)
  @NotNull
  @Column(name = "ITEM_ID")
  private int itemId;
  @Basic(optional = false)
  @NotNull
  @Column(name = "PRODUCT_ID")
  private int productId;

  public VgTreeProductPK() {
  }

  public VgTreeProductPK(String vgTreeCode, int itemId, int productId) {
    this.vgTreeCode = vgTreeCode;
    this.itemId = itemId;
    this.productId = productId;
  }

  public String getVgTreeCode() {
    return vgTreeCode;
  }

  public void setVgTreeCode(String vgTreeCode) {
    this.vgTreeCode = vgTreeCode;
  }

  public int getItemId() {
    return itemId;
  }

  public void setItemId(int itemId) {
    this.itemId = itemId;
  }

  public int getProductId() {
    return productId;
  }

  public void setProductId(int productId) {
    this.productId = productId;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (vgTreeCode != null ? vgTreeCode.hashCode() : 0);
    hash += (int) itemId;
    hash += (int) productId;
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof VgTreeProductPK)) {
      return false;
    }
    VgTreeProductPK other = (VgTreeProductPK) object;
    if ((this.vgTreeCode == null && other.vgTreeCode != null) || (this.vgTreeCode != null && !this.vgTreeCode.equals(other.vgTreeCode))) {
      return false;
    }
    if (this.itemId != other.itemId) {
      return false;
    }
    if (this.productId != other.productId) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.walter.VgTreeProductPK[ vgTreeCode=" + vgTreeCode + ", itemId=" + itemId + ", productId=" + productId + " ]";
  }
  
}
