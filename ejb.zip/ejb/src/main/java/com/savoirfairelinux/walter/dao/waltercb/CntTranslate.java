/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "CNT_TRANSLATE", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CntTranslate.findAll", query = "SELECT c FROM CntTranslate c"),
    @NamedQuery(name = "CntTranslate.findByCntId", query = "SELECT c FROM CntTranslate c WHERE c.cntTranslatePK.cntId = :cntId"),
    @NamedQuery(name = "CntTranslate.findByLangId", query = "SELECT c FROM CntTranslate c WHERE c.cntTranslatePK.langId = :langId"),
    @NamedQuery(name = "CntTranslate.findByTranslatorUserName", query = "SELECT c FROM CntTranslate c WHERE c.translatorUserName = :translatorUserName"),
    @NamedQuery(name = "CntTranslate.findBySentToTr", query = "SELECT c FROM CntTranslate c WHERE c.sentToTr = :sentToTr"),
    @NamedQuery(name = "CntTranslate.findByReceivedFromTr", query = "SELECT c FROM CntTranslate c WHERE c.receivedFromTr = :receivedFromTr"),
    @NamedQuery(name = "CntTranslate.findByExtSentToValid", query = "SELECT c FROM CntTranslate c WHERE c.extSentToValid = :extSentToValid"),
    @NamedQuery(name = "CntTranslate.findByExtReceivedFromValid", query = "SELECT c FROM CntTranslate c WHERE c.extReceivedFromValid = :extReceivedFromValid"),
    @NamedQuery(name = "CntTranslate.findByExtValidatorUserName", query = "SELECT c FROM CntTranslate c WHERE c.extValidatorUserName = :extValidatorUserName"),
    @NamedQuery(name = "CntTranslate.findByFromLangId", query = "SELECT c FROM CntTranslate c WHERE c.fromLangId = :fromLangId")})
public class CntTranslate implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected CntTranslatePK cntTranslatePK;
    @Size(max = 256)
    @Column(name = "TRANSLATOR_USER_NAME")
    private String translatorUserName;
    @Column(name = "SENT_TO_TR")
    @Temporal(TemporalType.TIMESTAMP)
    private Date sentToTr;
    @Column(name = "RECEIVED_FROM_TR")
    @Temporal(TemporalType.TIMESTAMP)
    private Date receivedFromTr;
    @Column(name = "EXT_SENT_TO_VALID")
    @Temporal(TemporalType.TIMESTAMP)
    private Date extSentToValid;
    @Column(name = "EXT_RECEIVED_FROM_VALID")
    @Temporal(TemporalType.TIMESTAMP)
    private Date extReceivedFromValid;
    @Size(max = 256)
    @Column(name = "EXT_VALIDATOR_USER_NAME")
    private String extValidatorUserName;
    @Column(name = "FROM_LANG_ID")
    private Long fromLangId;
    @JoinColumn(name = "CNT_ID", referencedColumnName = "CNT_ID", insertable = false, updatable = false)
    @ManyToOne(optional = false, cascade = CascadeType.MERGE)
    private Cnt cnt;

    public CntTranslate() {
    }

    public CntTranslate(CntTranslatePK cntTranslatePK) {
        this.cntTranslatePK = cntTranslatePK;
    }

    public CntTranslate(long cntId, long langId) {
        this.cntTranslatePK = new CntTranslatePK(cntId, langId);
    }

    public CntTranslatePK getCntTranslatePK() {
        return cntTranslatePK;
    }

    public void setCntTranslatePK(CntTranslatePK cntTranslatePK) {
        this.cntTranslatePK = cntTranslatePK;
    }

    public String getTranslatorUserName() {
        return translatorUserName;
    }

    public void setTranslatorUserName(String translatorUserName) {
        this.translatorUserName = translatorUserName;
    }

    public Date getSentToTr() {
        return sentToTr;
    }

    public void setSentToTr(Date sentToTr) {
        this.sentToTr = sentToTr;
    }

    public Date getReceivedFromTr() {
        return receivedFromTr;
    }

    public void setReceivedFromTr(Date receivedFromTr) {
        this.receivedFromTr = receivedFromTr;
    }

    public Date getExtSentToValid() {
        return extSentToValid;
    }

    public void setExtSentToValid(Date extSentToValid) {
        this.extSentToValid = extSentToValid;
    }

    public Date getExtReceivedFromValid() {
        return extReceivedFromValid;
    }

    public void setExtReceivedFromValid(Date extReceivedFromValid) {
        this.extReceivedFromValid = extReceivedFromValid;
    }

    public String getExtValidatorUserName() {
        return extValidatorUserName;
    }

    public void setExtValidatorUserName(String extValidatorUserName) {
        this.extValidatorUserName = extValidatorUserName;
    }

    public Long getFromLangId() {
        return fromLangId;
    }

    public void setFromLangId(Long fromLangId) {
        this.fromLangId = fromLangId;
    }

    public Cnt getCnt() {
        return cnt;
    }

    public void setCnt(Cnt cnt) {
        this.cnt = cnt;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cntTranslatePK != null ? cntTranslatePK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CntTranslate)) {
            return false;
        }
        CntTranslate other = (CntTranslate) object;
        if ((this.cntTranslatePK == null && other.cntTranslatePK != null) || (this.cntTranslatePK != null && !this.cntTranslatePK.equals(other.cntTranslatePK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.CntTranslate[ cntTranslatePK=" + cntTranslatePK + " ]";
    }
    
}
