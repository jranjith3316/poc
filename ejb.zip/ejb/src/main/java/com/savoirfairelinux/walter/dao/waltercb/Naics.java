/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "NAICS", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Naics.findAll", query = "SELECT n FROM Naics n"),
    @NamedQuery(name = "Naics.findByLangId", query = "SELECT n FROM Naics n WHERE n.naicsPK.countryId = :langId"), // Hack to enable the research by language provide in WalterBean
    @NamedQuery(name = "Naics.findByNaics", query = "SELECT n FROM Naics n WHERE n.naicsPK.naics = :naics"),
    @NamedQuery(name = "Naics.findByNaicsDesc", query = "SELECT n FROM Naics n WHERE n.naicsDesc = :naicsDesc"),
    @NamedQuery(name = "Naics.findByIsVisible", query = "SELECT n FROM Naics n WHERE n.isVisible = :isVisible")})
public class Naics implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected NaicsPK naicsPK;
    @Size(max = 150)
    @Column(name = "NAICS_DESC")
    private String naicsDesc;
    @Size(max = 1)
    @Column(name = "ISVISIBLE")
    private String isVisible;

    public Naics() {
    }

    public Naics(NaicsPK naicsPK) {
        this.naicsPK = naicsPK;
    }

    public Naics(short countryId, String naics) {
        this.naicsPK = new NaicsPK(countryId, naics);
    }

    public NaicsPK getNaicsPK() {
        return naicsPK;
    }

    public void setNaicsPK(NaicsPK naicsPK) {
        this.naicsPK = naicsPK;
    }

    public String getNaicsDesc() {
        return naicsDesc;
    }

    public void setNaicsDesc(String naicsDesc) {
        this.naicsDesc = naicsDesc;
    }

    public String getIsVisible() {
        return isVisible;
    }

    public void setIsVisible(String isVisible) {
        this.isVisible = isVisible;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (naicsPK != null ? naicsPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Naics)) {
            return false;
        }
        Naics other = (Naics) object;
        if ((this.naicsPK == null && other.naicsPK != null) || (this.naicsPK != null && !this.naicsPK.equals(other.naicsPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.Naics[ naicsPK=" + naicsPK + " ]";
    }
    
}
