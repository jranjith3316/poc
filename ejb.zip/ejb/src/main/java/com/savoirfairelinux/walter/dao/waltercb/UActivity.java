/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "U_ACTIVITY", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "UActivity.findAll", query = "SELECT u FROM UActivity u"),
    @NamedQuery(name = "UActivity.findByActivityId", query = "SELECT u FROM UActivity u WHERE u.uActivityPK.activityId = :activityId"),
    @NamedQuery(name = "UActivity.findByLangId", query = "SELECT u FROM UActivity u WHERE u.uActivityPK.langId = :langId ORDER BY u.activityDesc"),
    @NamedQuery(name = "UActivity.findByActivityDesc", query = "SELECT u FROM UActivity u WHERE u.activityDesc = :activityDesc")})
public class UActivity implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected UActivityPK uActivityPK;
    @Size(max = 100)
    @Column(name = "ACTIVITY_DESC")
    private String activityDesc;

    public UActivity() {
    }

    public UActivity(UActivityPK uActivityPK) {
        this.uActivityPK = uActivityPK;
    }

    public UActivity(long activityId, long langId) {
        this.uActivityPK = new UActivityPK(activityId, langId);
    }

    public UActivityPK getUActivityPK() {
        return uActivityPK;
    }

    public void setUActivityPK(UActivityPK uActivityPK) {
        this.uActivityPK = uActivityPK;
    }

    public String getActivityDesc() {
        return activityDesc;
    }

    public void setActivityDesc(String activityDesc) {
        this.activityDesc = activityDesc;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (uActivityPK != null ? uActivityPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof UActivity)) {
            return false;
        }
        UActivity other = (UActivity) object;
        if ((this.uActivityPK == null && other.uActivityPK != null) || (this.uActivityPK != null && !this.uActivityPK.equals(other.uActivityPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.UActivity[ uActivityPK=" + uActivityPK + " ]";
    }
    
}
