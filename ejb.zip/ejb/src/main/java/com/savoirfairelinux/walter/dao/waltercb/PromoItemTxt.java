/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "PROMO_ITEM_TXT", catalog = "", schema = "WALTERcb")
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "PromoItemTxt.findAll", query = "SELECT p FROM PromoItemTxt p"),
  @NamedQuery(name = "PromoItemTxt.findByItemId", query = "SELECT p FROM PromoItemTxt p WHERE p.promoItemTxtPK.itemId = :itemId"),
  @NamedQuery(name = "PromoItemTxt.findByLangId", query = "SELECT p FROM PromoItemTxt p WHERE p.promoItemTxtPK.langId = :langId"),
  @NamedQuery(name = "PromoItemTxt.findByName", query = "SELECT p FROM PromoItemTxt p WHERE p.name = :name"),
  @NamedQuery(name = "PromoItemTxt.findByLogoExtraDesc", query = "SELECT p FROM PromoItemTxt p WHERE p.logoExtraDesc = :logoExtraDesc"),
  @NamedQuery(name = "PromoItemTxt.findByCreatedBy", query = "SELECT p FROM PromoItemTxt p WHERE p.createdBy = :createdBy"),
  @NamedQuery(name = "PromoItemTxt.findByCreatedDate", query = "SELECT p FROM PromoItemTxt p WHERE p.createdDate = :createdDate"),
  @NamedQuery(name = "PromoItemTxt.findByCancelBy", query = "SELECT p FROM PromoItemTxt p WHERE p.cancelBy = :cancelBy"),
  @NamedQuery(name = "PromoItemTxt.findByCancelDate", query = "SELECT p FROM PromoItemTxt p WHERE p.cancelDate = :cancelDate"),
  @NamedQuery(name = "PromoItemTxt.findByLangId1", query = "SELECT p FROM PromoItemTxt p WHERE p.langId1 = :langId1")})
public class PromoItemTxt implements Serializable {
  private static final long serialVersionUID = 1L;
  @EmbeddedId
  protected PromoItemTxtPK promoItemTxtPK;
  @Size(max = 500)
  @Column(name = "NAME")
  private String name;
  @Size(max = 500)
  @Column(name = "LOGO_EXTRA_DESC")
  private String logoExtraDesc;
  @Size(max = 255)
  @Column(name = "CREATED_BY")
  private String createdBy;
  @Column(name = "CREATED_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date createdDate;
  @Size(max = 255)
  @Column(name = "CANCEL_BY")
  private String cancelBy;
  @Column(name = "CANCEL_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date cancelDate;
  @Basic(optional = false)
  @NotNull
  @Column(name = "LANG_ID", insertable = false, updatable = false)
  private long langId1;
  @JoinColumn(name = "ITEM_ID", referencedColumnName = "ITEM_ID", insertable = false, updatable = false)
  @ManyToOne(optional = false)
  private PromoItem promoItem;

  public PromoItemTxt() {
  }

  public PromoItemTxt(PromoItemTxtPK promoItemTxtPK) {
    this.promoItemTxtPK = promoItemTxtPK;
  }

  public PromoItemTxt(PromoItemTxtPK promoItemTxtPK, long langId1) {
    this.promoItemTxtPK = promoItemTxtPK;
    this.langId1 = langId1;
  }

  public PromoItemTxt(long itemId, long langId) {
    this.promoItemTxtPK = new PromoItemTxtPK(itemId, langId);
  }

  public PromoItemTxtPK getPromoItemTxtPK() {
    return promoItemTxtPK;
  }

  public void setPromoItemTxtPK(PromoItemTxtPK promoItemTxtPK) {
    this.promoItemTxtPK = promoItemTxtPK;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getLogoExtraDesc() {
    return logoExtraDesc;
  }

  public void setLogoExtraDesc(String logoExtraDesc) {
    this.logoExtraDesc = logoExtraDesc;
  }

  public String getCreatedBy() {
    return createdBy;
  }

  public void setCreatedBy(String createdBy) {
    this.createdBy = createdBy;
  }

  public Date getCreatedDate() {
    return createdDate;
  }

  public void setCreatedDate(Date createdDate) {
    this.createdDate = createdDate;
  }

  public String getCancelBy() {
    return cancelBy;
  }

  public void setCancelBy(String cancelBy) {
    this.cancelBy = cancelBy;
  }

  public Date getCancelDate() {
    return cancelDate;
  }

  public void setCancelDate(Date cancelDate) {
    this.cancelDate = cancelDate;
  }

  public long getLangId1() {
    return langId1;
  }

  public void setLangId1(long langId1) {
    this.langId1 = langId1;
  }

  public PromoItem getPromoItem() {
    return promoItem;
  }

  public void setPromoItem(PromoItem promoItem) {
    this.promoItem = promoItem;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (promoItemTxtPK != null ? promoItemTxtPK.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof PromoItemTxt)) {
      return false;
    }
    PromoItemTxt other = (PromoItemTxt) object;
    if ((this.promoItemTxtPK == null && other.promoItemTxtPK != null) || (this.promoItemTxtPK != null && !this.promoItemTxtPK.equals(other.promoItemTxtPK))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.waltercb.PromoItemTxt[ promoItemTxtPK=" + promoItemTxtPK + " ]";
  }

}
