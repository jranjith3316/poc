package com.savoirfairelinux.walter.service.impl;

import com.savoirfairelinux.walter.dao.walter.Expense;
import com.savoirfairelinux.walter.dao.walter.ExpenseRpt;
import com.savoirfairelinux.walter.dao.walter.ExpenseRptD;
import com.savoirfairelinux.walter.dao.walter.ExpenseTxt;
import com.savoirfairelinux.walter.dao.walter.Loan;
import com.savoirfairelinux.walter.dao.walter.LoanD;
import com.savoirfairelinux.walter.dao.walter.UPerson;
import com.savoirfairelinux.walter.dao.waltercb.Country;
import com.savoirfairelinux.walter.dao.waltercb.CountryRegion;
import com.savoirfairelinux.walter.dao.waltercb.CountryStateTxt;
import com.savoirfairelinux.walter.model.GLCode;
import com.savoirfairelinux.walter.model.SearchExpenseReport;
import com.savoirfairelinux.walter.service.ExpenseReportBeanRemote;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.security.PermitAll;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

@Stateless(name = "ExpenseReportBean")
@TransactionManagement(TransactionManagementType.CONTAINER)
@PermitAll
@LocalBean
public class ExpenseReportBean implements ExpenseReportBeanRemote {

    public static final Logger LOG = Logger.getLogger(ExpenseReportBean.class.getCanonicalName());
    @PersistenceContext(unitName = "waltershare")
    EntityManager entityManager;
    @EJB
    SingletonBean singletonBean;
    @EJB
    WalterBean walterBean;
    @Override
    public List<ExpenseRpt> getExpenseRptUnsubmittedList(String userName) throws Exception {

        List<ExpenseRpt> result = null;
        try {

            result = entityManager
                    .createQuery(singletonBean.getExpenseReportQuery("expensereport.myExpense.unsubmitted"), ExpenseRpt.class)
                    .setParameter("userName", userName)
                    .getResultList();

        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    public List<ExpenseRpt> getExpenseRptSubmittedList(String userName) throws Exception {

        List<ExpenseRpt> result = null;
        try {

            result = entityManager
                    .createQuery(singletonBean.getExpenseReportQuery("expensereport.myExpense.submitted"), ExpenseRpt.class)
                    .setParameter("userName", userName)
                    .getResultList();

        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    public List<ExpenseRpt> getExpenseRptApprovedList(String userName) throws Exception {

        List<ExpenseRpt> result = null;
        try {

            result = entityManager
                    .createQuery(singletonBean.getExpenseReportQuery("expensereport.myExpense.approved"), ExpenseRpt.class)
                    .setParameter("userName", userName)
                    .getResultList();

        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    public List<ExpenseRpt> getExpenseRptValidatedList(String userName) throws Exception {

        List<ExpenseRpt> result = null;
        try {

            result = entityManager
                    .createQuery(singletonBean.getExpenseReportQuery("expensereport.myExpense.validated"), ExpenseRpt.class)
                    .setParameter("userName", userName)
                    .getResultList();

        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    /**
     * return list of Manager and External approval user list
     */
    @Override
    public List<UPerson> getMgrAndExternalUser(String currentUser){
      List<UPerson> uPersonList = new ArrayList<UPerson>();

        try {

            uPersonList = entityManager
                    .createQuery(singletonBean.getExpenseReportQuery("expensereport.validation.MgrAndExternalUser"), UPerson.class)
                    .setParameter("currentUser", currentUser)
                    .getResultList();

        } catch (Exception e) {
            LOG.severe(e.getMessage());
        }

      return uPersonList;
    }


    @Override
    public List<ExpenseRpt> getExpenseRptMgrUserList(String currentUser, String employeeName, String reportStatus, Long expenseRptId, Date fromDate, Date toDate) throws Exception {

        List<ExpenseRpt> result = null;
        StringBuffer sql = new StringBuffer("");

//        sql.append(" select e"+
//                   "   from ExpenseRpt e"+
//                   "  where e.mgrUserName = '"+currentUser+"'" +
//                   "    and e.cancelDate is null");

        sql.append(" select e"
                + "   from ExpenseRpt e, UPerson person"
                + "  where e.creatorUserName = person.uPersonPK.userName"
                + "    and (person.uPersonPK.userName in (select u.uPersonPK.userName "
                + "                                        from UPerson u"
                + "                                       where (u.expApprovalUserName = '" + currentUser + "'"
                + "                                          or person.managerUserName = '" + currentUser + "')))"
                + "    and e.cancelDate is null");

        if (!employeeName.equals("")) {
            sql.append(" and e.creatorUserName = '" + employeeName + "'");
        }
        if (expenseRptId != 0) {
            sql.append(" and e.expenseRptId like '%" + expenseRptId + "%'");
        }
        if (fromDate != null) {
            sql.append(" and e.fromDate >= to_date('" + String.format("%1$tY-%1$td-%1$tm", fromDate) + "','yyyy-dd-mm')");
        }

        if (toDate != null) {
            sql.append(" and e.fromDate <= to_date('" + String.format("%1$tY-%1$td-%1$tm", toDate) + "','yyyy-dd-mm')");
        }

        if (reportStatus.equals("SUBMITTED")) {
          sql.append("    and e.submitDate is not null");
          sql.append("    and e.mgrValidationDate is null");

        } else if (reportStatus.equals("APPROVED")) {
          sql.append("    and e.submitDate is not null");
          sql.append("    and e.mgrValidationDate is not null"
                  + "    and e.validationDate is null");

        } else if (reportStatus.equals("VALIDATED")) {
          sql.append("    and e.submitDate is not null");
          sql.append("    and e.mgrValidationDate is not null"
                  + "    and e.validationDate is not null");
        }

        try {
            result = entityManager
                    .createQuery(sql.toString(), ExpenseRpt.class)
                    .getResultList();

        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    public BigDecimal getAmtPaid(Long expenseRptId) throws Exception {
        BigDecimal result = new BigDecimal(0);
        Object temp = null;
        try {
            temp = entityManager
                    .createQuery(singletonBean.getExpenseReportQuery("expensereport.amtPaid"), Object.class)
                    .setParameter("expenseRptId", expenseRptId)
                    .getSingleResult();

            result = new BigDecimal(temp.toString());
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    public ExpenseRpt getExpenseRpt(Long expenseRptId) throws Exception {
        ExpenseRpt result;
        try {
            result = entityManager.find(ExpenseRpt.class, expenseRptId);
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;

    }

    @Override
    public Country getCountry(Long countryId) throws Exception {
        Country country = new Country();
        try {
            country = entityManager.find(Country.class, countryId);
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return country;
    }

    @Override
    public List<CountryStateTxt> getCountryStateTxtList(Long countryId, Long langId) throws Exception {
        List<CountryStateTxt> countryStateTxt = null;
        try {

            countryStateTxt = entityManager
                    .createQuery(singletonBean.getExpenseReportQuery("expensereport.userStateList"), CountryStateTxt.class)
                    .setParameter("countryId", countryId)
                    .setParameter("langId", langId)
                    .getResultList();

        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return countryStateTxt;
    }

    @Override
    public CountryStateTxt getCountryStateTxt(Long countryId, String stateCode, Long langId) throws Exception {
        CountryStateTxt countryStateTxt = new CountryStateTxt();
        try {

            countryStateTxt = entityManager
                    .createQuery(singletonBean.getExpenseReportQuery("expensereport.userState"), CountryStateTxt.class)
                    .setParameter("countryId", countryId)
                    .setParameter("stateCode", stateCode)
                    .setParameter("langId", langId)
                    .getSingleResult();

        } catch (Exception e) {
            LOG.severe(e.getMessage());
//            throw new Exception(e.getMessage());
        }
        return countryStateTxt;
    }

    @Override
    public List<ExpenseTxt> getExpenseTypeList(Long countryId, Long langId) throws Exception {
        List<ExpenseTxt> expenseType = null;
        try {

            expenseType = entityManager
                    .createQuery(singletonBean.getExpenseReportQuery("expensereport.expenseTypeList"), ExpenseTxt.class)
                    .setParameter("countryId", countryId)
                    .setParameter("langId", langId)
                    .getResultList();

        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return expenseType;
    }

    @Override
    public ExpenseTxt getExpenseType(Long countryId, Long expenseId, Long langId) throws Exception {
        ExpenseTxt expenseType = null;
        try {

            expenseType = entityManager
                    .createQuery(singletonBean.getExpenseReportQuery("expensereport.expenseType"), ExpenseTxt.class)
                    .setParameter("countryId", countryId)
                    .setParameter("expenseId", expenseId)
                    .setParameter("langId", langId)
                    .getSingleResult();

        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return expenseType;
    }

    @Override
    public BigDecimal getUserAmtPerDistanceUnit(String userName) throws Exception {
        BigDecimal result = BigDecimal.ZERO;
        try {
            UPerson uPerson = walterBean.getUPerson(userName);

            if (uPerson.getAmtPerDistanceUnit() != null && uPerson.getAmtPerDistanceUnit().compareTo(BigDecimal.ZERO) > 0) {
                result = uPerson.getAmtPerDistanceUnit();
            } else {
                Country country = entityManager.find(Country.class, Long.parseLong(uPerson.getCountryId().toString()));
                result = country.getAmtPerDistanceUnit();
            }
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    public BigDecimal getInternetAllowence(String userName) throws Exception {
        BigDecimal result = BigDecimal.ZERO;
        try {
            UPerson uPerson = walterBean.getUPerson(userName);

            Country country = entityManager.find(Country.class, Long.parseLong(uPerson.getCountryId().toString()));
            result = country.getInternetMaxAmt();
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }

        return result;
    }

    @Override
    public BigDecimal getHotelAllowence(String userName) throws Exception {
        BigDecimal result = BigDecimal.ZERO;
        CountryRegion countryRegion = new CountryRegion();
        try {
            UPerson uPerson = walterBean.getUPerson(userName);

            countryRegion = entityManager
                    .createQuery(singletonBean.getExpenseReportQuery("expensereport.userHotelAllowence"), CountryRegion.class)
                    .setParameter("countryId", Long.parseLong(uPerson.getCountryId().toString()))
                    .setParameter("regionCode", uPerson.getRegionCode())
                    .getSingleResult();



        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return countryRegion.getHotelMaxAmt();
    }

    public ExpenseRptD getLastExpenseRptD(long expenseRptId) throws Exception {
      ExpenseRptD result = new ExpenseRptD();
      ExpenseRptD expenseRptD = new ExpenseRptD();
        try {
            expenseRptD = entityManager
                    .createQuery(singletonBean.getExpenseReportQuery("expensereport.LastExpenseRptD"), ExpenseRptD.class)
                    .setParameter("expenseRptId", expenseRptId)
                    .getSingleResult();
        } catch (Exception e) {
            LOG.severe(e.getMessage());
        }
        ExpenseRpt ExpenseRpt = getExpenseRpt(expenseRptId);
        result.setExpenseRpt(ExpenseRpt);

        if (expenseRptD != null) {
          result.setCity(expenseRptD.getCity());
          result.setExpenseDate(expenseRptD.getExpenseDate());
          result.setStateCode(expenseRptD.getStateCode());
        }

        return result;
    }

    public ExpenseRptD getExpenseRptD(long expenseRptId, short lineNum) throws Exception {
        ExpenseRptD result = new ExpenseRptD();
        try {
            ExpenseRptD expenseRptD = entityManager
                    .createQuery(singletonBean.getExpenseReportQuery("expensereport.ExpenseRptD"), ExpenseRptD.class)
                    .setParameter("expenseRptId", expenseRptId)
                    .setParameter("lineNum", lineNum)
                    .getSingleResult();

            if (expenseRptD != null) {
              result = expenseRptD;
            }
//            else {
//              result = getLastExpenseRptD(expenseRptId);
//            }

        } catch (Exception e) {
            LOG.severe(e.getMessage());
            result = getLastExpenseRptD(expenseRptId);
        }
        return result;
    }

    public List<ExpenseRptD> getExpenseRptDList(Long expenseRptId) throws Exception {
        List<ExpenseRptD> expenseRptDList = null;
        try {
            expenseRptDList = entityManager
                    .createQuery(singletonBean.getExpenseReportQuery("expensereport.ExpenseRptDList"), ExpenseRptD.class)
                    .setParameter("expenseRptId", expenseRptId)
                    .getResultList();

        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return expenseRptDList;
    }

    public List<ExpenseRptD> getExpenseRptDList(Long expenseRptId, Long expenseId) throws Exception {
        List<ExpenseRptD> expenseRptDList = null;
        try {
            expenseRptDList = entityManager
                    .createQuery(singletonBean.getExpenseReportQuery("expensereport.Management.ExpenseRptDList"), ExpenseRptD.class)
                    .setParameter("expenseRptId", expenseRptId)
                    .setParameter("expenseId", expenseId)
                    .getResultList();

        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return expenseRptDList;
    }

    public List<ExpenseRptD> getExpenseRptDDeletedList(Long expenseRptId) throws Exception {
        List<ExpenseRptD> expenseRptDList = null;
        try {
            expenseRptDList = entityManager
                    .createQuery(singletonBean.getExpenseReportQuery("expensereport.ExpenseRptDDeletedList"), ExpenseRptD.class)
                    .setParameter("expenseRptId", expenseRptId)
                    .getResultList();

        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return expenseRptDList;
    }

    public void saveExpenseReport(ExpenseRpt expenseRpt) throws Exception {
        try {
          if ( expenseRpt.getPerdiemReport() == null )
            expenseRpt.setPerdiemReport("N");

            expenseRpt = entityManager.merge(expenseRpt);
        } catch (Exception e) {
            System.out.println("error: " + e.getMessage());
        }
    }

    public void saveExpenseReportD(ExpenseRptD expenseRptd) throws Exception {

        //need to  check if linenumber is null or == 0
        if (expenseRptd.getExpenseRptDPK().getLineNum() == 0) {
            expenseRptd.getExpenseRptDPK().setLineNum(getExpenseRptDLineNumber(expenseRptd.getExpenseRptDPK().getExpenseRptId()));
        }

        ExpenseRpt expenseRpt = getExpenseRpt(expenseRptd.getExpenseRpt().getExpenseRptId());

        if (expenseRpt.getMgrValidationDate() != null
                && expenseRpt.getMgrReceptionDate() != null) {
            // manual tax calculation
        } else {
            expenseRptd.setTax1Amt(getTaxAmt(expenseRptd, "TAX1").setScale(2, RoundingMode.HALF_UP));
            expenseRptd.setTax2Amt(getTaxAmt(expenseRptd, "TAX2").setScale(2, RoundingMode.HALF_UP));
            expenseRptd.setTax3Amt(getTaxAmt(expenseRptd, "TAX3").setScale(2, RoundingMode.HALF_UP));
        }

        try {
            expenseRptd = entityManager.merge(expenseRptd);
        } catch (Exception e) {
            System.out.println("error: " + e.getMessage());
        }
    }

    public void deleteExpenseReportD(long expenseRptId, short lineNum) throws Exception {
        try {

            ExpenseRptD expenseRptD = getExpenseRptD(expenseRptId, lineNum);

            entityManager.remove(expenseRptD);

            // if no item found set perdiem report N

            List<ExpenseRptD> erdList = getExpenseRptDList(expenseRptId);

//            System.out.println("try to change perdiem report");
//            System.out.println("erdList: " + erdList.size());

            if ( erdList.size() == 0 ){

              ExpenseRpt er = getExpenseRpt(expenseRptId);
              er.setPerdiemReport("N");
              entityManager.merge(er);

            }


        } catch (Exception e) {
          System.out.println("error: " + e.getMessage());
        }
    }

    @Override
    public List<Object[]> getTaxList(ExpenseRptD expenseRptD) throws Exception {

        List<Object[]> result = null;
        try {
            result = entityManager.createNativeQuery(singletonBean.getExpenseReportQuery("expensereport.taxAmount"))
                    .setParameter("countryId", expenseRptD.getExpenseRpt().getCountryId())
                    .setParameter("stateCode", expenseRptD.getStateCode())
                    .setParameter("expenseDate", expenseRptD.getExpenseDate())
                    .getResultList();

        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;

    }

    @Override
    public BigDecimal getTaxAmt(ExpenseRptD expenseRptD, String taxField) throws Exception {
        BigDecimal result = new BigDecimal(BigInteger.ZERO);

        //'TAX1', ct.countryTaxPK.taxCode, ct.taxRate, ct.taxCalMode
        try {

            Expense expense = entityManager.find(Expense.class, expenseRptD.getExpenseId());

            List<Object[]> rows = getTaxList(expenseRptD);

            String taxCode1 = "";
            BigDecimal taxRate1 = new BigDecimal(BigInteger.ZERO);
            int taxCalMode1 = 1; // 1. calculated on gross amount 2. calculated on gross amount + tax1 3. calculated on gross amount + add tax2 in negative
            BigDecimal rebateRate1 = new BigDecimal(BigInteger.ZERO);

            String taxCode2 = "";
            BigDecimal taxRate2 = new BigDecimal(BigInteger.ZERO);
            int taxCalMode2 = 1;
            BigDecimal rebateRate2 = new BigDecimal(BigInteger.ZERO);

            String taxCode3 = "";
            BigDecimal taxRate3 = new BigDecimal(BigInteger.ZERO);
            int taxCalMode3 = 1;
            BigDecimal rebateRate3 = new BigDecimal(BigInteger.ZERO);

            for (Object[] row : rows) {
                String taxOrder = (String) row[0];
                if (taxOrder.equals("TAX1")) {
                    taxCode1 = (String) row[1];
                    taxRate1 = (BigDecimal) row[2];
                    taxCalMode1 = Integer.parseInt(row[3].toString());
                    rebateRate1 = (BigDecimal) row[4];
                } else if (taxOrder.equals("TAX2")) {
                    taxCode2 = (String) row[1];
                    taxRate2 = (BigDecimal) row[2];
                    taxCalMode2 = Integer.parseInt(row[3].toString());
                    rebateRate2 = (BigDecimal) row[4];
                } else if (taxOrder.equals("TAX3")) {
                    taxCode3 = (String) row[1];
                    taxRate3 = (BigDecimal) row[2];
                    taxCalMode3 = Integer.parseInt(row[3].toString());
                    rebateRate3 = (BigDecimal) row[4];
                }
            }

//            System.out.println("taxField: " + taxField);
//            System.out.println("expenseRptD.getStateCode(): " + expenseRptD.getStateCode());
//            System.out.println("");
//
//            System.out.println("taxCode1: " + taxCode1);
//            System.out.println("taxRate1: " + taxRate1);
//            System.out.println("taxCalMode1: " + taxCalMode1);
//            System.out.println("");
//
//            System.out.println("taxCode2: " + taxCode2);
//            System.out.println("taxRate2: " + taxRate2);
//            System.out.println("taxCalMode2: " + taxCalMode2);
//            System.out.println("");
//
//            System.out.println("taxCode3: " + taxCode3);
//            System.out.println("taxRate3: " + taxRate3);
//            System.out.println("taxCalMode3: " + taxCalMode3);
//            System.out.println("");
//            System.out.println("");
//            System.out.println("");
//            System.out.println("");

            if (taxRate1.compareTo(BigDecimal.ZERO) != 0
                    || taxRate2.compareTo(BigDecimal.ZERO) != 0
                    || taxRate3.compareTo(BigDecimal.ZERO) != 0) {
                BigDecimal total = expenseRptD.getAmtPaid().subtract(expenseRptD.getTipAmt());

                BigDecimal hundred = new BigDecimal(100);

                if (expense.getTaxCalcMethod() != null) {
                    // for MEAL_CA retreive only half of the tax value
                    if (expense.getTaxCalcMethod().equals("MEAL_CA")) {
                        if (taxField.equals("TAX1")) {
                            if (expenseRptD.getStateCode().equals("QC")) {
                                if (taxCalMode1 == 1 && taxCalMode2 == 1) {
                                    result = ((total.multiply(taxRate1)).divide(taxRate1.add(taxRate2).add(hundred), 10, RoundingMode.HALF_UP)).divide(new BigDecimal(2), 10, RoundingMode.HALF_UP);
                                } else {
                                    result = total.subtract((total.multiply(taxRate2)).divide(hundred.add(taxRate2), 10, RoundingMode.HALF_UP)).multiply(taxRate1.divide(hundred.add(taxRate1), 10, RoundingMode.HALF_UP)).divide(new BigDecimal(2), 10, RoundingMode.HALF_UP);
                                }
                            }

                            if (taxCalMode1 == 3) {
                                result = ((total.multiply(taxRate1)).divide(taxRate1.add(hundred), 10, RoundingMode.HALF_UP)).divide(new BigDecimal(2),10,RoundingMode.UP) ;

                            } else if ( expenseRptD.getStateCode().equals("BC")  ){ //for BC only GST 5% are applicable for meal.
                                result = ((total.multiply(taxRate1)).divide(taxRate1.add(hundred), 10, RoundingMode.HALF_UP)).divide(new BigDecimal(2),10,RoundingMode.UP) ;

                            } else {
                                result = ((total.multiply(taxRate1)).divide(taxRate1.add(taxRate2).add(hundred), 10, RoundingMode.HALF_UP)).divide(new BigDecimal(2), 10, RoundingMode.HALF_UP);
                            }
                        }

                        /**
                         *
                         * new tax calculation for Quebec Start in 2019
                         * Before 2018 no tax can be get for meal expense.
                         * In 2019 you can declare maximum of 50% of the total tax.
                         * in 2019 is 50%, in 2020 is 75% in 2021 is 100% of the total tax/2
                         *
                         * example for a total of 1.00$ of tax:
                         * in 2018 will be 0$
                         * in 2019 will be 0.25$
                         * in 2020 will be 0.37$
                         * in 2021 will be 0.50$
                         *
                         ***/
                        if ( taxField.equals("TAX2") && expenseRptD.getStateCode().equals("QC") ) {
                          result = ((total.multiply(taxRate2)).divide(taxRate1.add(taxRate2).add(hundred), 10, RoundingMode.HALF_UP)).divide(new BigDecimal(2), 10, RoundingMode.HALF_UP);

                          /** percent can be done during a range of date **/
                          BigDecimal percent = BigDecimal.ZERO;

                          if ( isBetweenDate("01-JAN-1900", "31-DEC-2018", expenseRptD.getExpenseDate()) ){
                            percent = BigDecimal.ZERO;

                          } else if ( isBetweenDate("01-JAN-2019", "31-DEC-2019", expenseRptD.getExpenseDate()) ) {
                            percent = BigDecimal.valueOf(50);

                          } else if ( isBetweenDate("01-JAN-2020", "31-DEC-2020", expenseRptD.getExpenseDate()) ) {
                            percent = BigDecimal.valueOf(75);

                          } else if ( isBetweenDate("01-JAN-2021", "31-DEC-2999", expenseRptD.getExpenseDate()) ) {
                            percent = BigDecimal.valueOf(100);
                          }

                          result  = result.multiply(percent).divide(new BigDecimal(100));

                        }

                        if ( taxField.equals("TAX2") && (expenseRptD.getStateCode().equals("ON") || expenseRptD.getStateCode().equals("PE")) && taxCalMode2 == 3 ){

                            result = ((total.subtract((total.multiply(taxRate1)).divide(taxRate1.add(hundred), 10, RoundingMode.HALF_UP))).divide(new BigDecimal(2), 10, RoundingMode.HALF_UP)).multiply(taxRate2).divide(hundred, 10, RoundingMode.HALF_UP);
                            result = result.multiply(rebateRate2).divide(hundred);
                            result = result.negate();
                        }

                    } else if (expense.getTaxCalcMethod().equals("GAS_CA")
                            || expense.getTaxCalcMethod().equals("PHONE_CA")
                            || expense.getTaxCalcMethod().equals("INTERNET_CA")) {
                        if (taxField.equals("TAX1")) {
                            if (expenseRptD.getStateCode().equals("QC")) {
                                if (taxCalMode1 == 1 && taxCalMode2 == 1) {
                                    result = ((total.multiply(taxRate1)).divide(taxRate1.add(taxRate2).add(hundred), 10, RoundingMode.HALF_UP));
                                } else {
                                    result = total.subtract((total.multiply(taxRate2)).divide(hundred.add(taxRate2), 10, RoundingMode.HALF_UP)).multiply(taxRate1.divide(hundred.add(taxRate1), 10, RoundingMode.HALF_UP));
                                }
                            } if (taxCalMode1 == 3) {
                                result = ((total.multiply(taxRate1)).divide(taxRate1.add(hundred), 10, RoundingMode.HALF_UP));

                            } else {

                                result = ((total.multiply(taxRate1)).divide(taxRate1.add(taxRate2).add(hundred), 10, RoundingMode.HALF_UP));
                            }
                        } if ( taxField.equals("TAX2") && (expenseRptD.getStateCode().equals("ON") || expenseRptD.getStateCode().equals("PE")) && taxCalMode2 == 3 ){

                            result = (total.subtract((total.multiply(taxRate1)).divide(taxRate1.add(hundred), 10, RoundingMode.HALF_UP))).multiply(taxRate2).divide(hundred, 10, RoundingMode.HALF_UP);
                            result = result.multiply(rebateRate2).divide(hundred);
                            result = result.negate();
                        }
                    } else if (expense.getTaxCalcMethod().equals("AIRPORT_CA")
                            || expense.getTaxCalcMethod().equals("TRAIN_CA")
                            || expense.getTaxCalcMethod().equals("PARKING_CA")
                            || expense.getTaxCalcMethod().equals("CARRENT_CA")) {
                        if (taxField.equals("TAX1")) {
                            if (expenseRptD.getStateCode().equals("QC")) { // return TPS
                                if (taxCalMode1 == 1 && taxCalMode2 == 1) {
                                    result = ((total.multiply(taxRate1)).divide(taxRate1.add(taxRate2).add(hundred), 10, RoundingMode.HALF_UP));
                                } else {
                                    result = total.subtract((total.multiply(taxRate2)).divide(hundred.add(taxRate2), 10, RoundingMode.HALF_UP)).multiply(taxRate1.divide(hundred.add(taxRate1), 10, RoundingMode.HALF_UP));
                                }
                            } if ( (expenseRptD.getStateCode().equals("ON") || expenseRptD.getStateCode().equals("PE")) && taxCalMode2 == 3 ) {
                              result = ((total.multiply(taxRate1)).divide(taxRate1.add(hundred), 10, RoundingMode.HALF_UP));

                            }else {
                                result = ((total.multiply(taxRate1)).divide(taxRate1.add(taxRate2).add(hundred), 10, RoundingMode.HALF_UP));
                            }
                        } else if (taxField.equals("TAX2") && expenseRptD.getStateCode().equals("QC")) { // return TVQ

                           if (taxCalMode1 == 1 && taxCalMode2 == 1) {
                              result = ((total.multiply(taxRate2)).divide(taxRate1.add(taxRate2).add(hundred), 10, RoundingMode.HALF_UP));
                          } else {
                              result = total.subtract((total.multiply(taxRate1)).divide(hundred.add(taxRate1), 10, RoundingMode.HALF_UP)).multiply(taxRate2.divide(hundred.add(taxRate2), 10, RoundingMode.HALF_UP));
                          }

                        }
                    }
                }
            }

        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }

        return result;
    }


    private boolean isBetweenDate(String fromDateStr, String toDateStr, Date expenseDate){
      boolean value = false;
      try {
        // need to use the month in text, bug in number it will return january.
        SimpleDateFormat sdffrom = new SimpleDateFormat("dd-MMM-yyyy");
        SimpleDateFormat sdfto = new SimpleDateFormat("dd-MMM-yyyy");

        Date fromDate = sdffrom.parse(fromDateStr);
        Date toDate = sdfto.parse(toDateStr);

        if ( fromDate.before(expenseDate) && toDate.after(expenseDate) ) {
          value = true;
        }

      } catch (ParseException ex) {
        Logger.getLogger(ExpenseReportBean.class.getName()).log(Level.SEVERE, null, ex);
      }

      return value;
    }


    @Override
    public Short getExpenseRptDLineNumber(Long expenseRptId) throws Exception {
        Short result = 0;
        Integer temp = 0;
        try {
            temp = entityManager
                    .createQuery(singletonBean.getExpenseReportQuery("expensereport.ExpenseRptD.newLineNumber"), Integer.class)
                    .setParameter("expenseRptId", expenseRptId)
                    .getSingleResult();

            result = Short.parseShort(temp.toString());
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;

    }

    @Override
    public List<ExpenseRpt> getExpenseRptApprovedList(long countryId, long expenseRptId) throws Exception {

        List<ExpenseRpt> result = null;
        try {
            result = entityManager
                    .createQuery(singletonBean.getExpenseReportQuery("expensereport.Management.approved"), ExpenseRpt.class)
                    .setParameter("countryId", countryId)
                    .setParameter("expenseRptId", ( expenseRptId != 0 ) ? expenseRptId : null)
                    .getResultList();

        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    public List<ExpenseRpt> getExpenseRptValidatedList(long countryId, long expenseRptId) throws Exception {

        List<ExpenseRpt> result = null;
        try {
            result = entityManager
                    .createQuery(singletonBean.getExpenseReportQuery("expensereport.Management.validated"), ExpenseRpt.class)
                    .setParameter("countryId", countryId)
                    .setParameter("expenseRptId", ( expenseRptId != 0 ) ? expenseRptId : null)
                    .getResultList();

        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    public List<ExpenseRpt> getExpenseRptSubmittedList(long countryId, long expenseRptId) throws Exception {

        List<ExpenseRpt> result = null;
        try {
            result = entityManager
                    .createQuery(singletonBean.getExpenseReportQuery("expensereport.Management.submited"), ExpenseRpt.class)
                    .setParameter("countryId", countryId)
                    .setParameter("expenseRptId", ( expenseRptId != 0 ) ? expenseRptId : null)
                    .getResultList();

        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    public List<Object[]> getExpenseRptTypeList(Long expenseRptId) throws Exception {

        List<Object[]> result = null;
        try {
            result = entityManager
                    .createQuery(singletonBean.getExpenseReportQuery("expensereport.Management.treeExpenseList"))
                    .setParameter("expenseRptId", expenseRptId)
                    .getResultList();

        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    public List<Object[]> getGlCodeTotalList(Long expenseRptId) throws Exception {

        List<Object[]> result = null;
        try {
            result = entityManager
                    .createNativeQuery(singletonBean.getExpenseReportQuery("expensereport.Management.glCodeTotal"))
                    .setParameter("expenseRptId", expenseRptId)
                    .getResultList();

        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    public List<Object[]> getGlCodeTaxList(Long expenseRptId, Long langId) throws Exception {

        List<Object[]> result = null;
        try {
            result = entityManager
                    .createNativeQuery(singletonBean.getExpenseReportQuery("expensereport.Management.glCodeTaxTotal"))
                    .setParameter("expenseRptId", expenseRptId)
                    .setParameter("langId", langId)
                    .getResultList();

        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    public List<ExpenseRptD> getHotelNightList(Long expenseRptId, long countryId) throws Exception {

        List<ExpenseRptD> result = null;
        try {
            result = entityManager
                    .createQuery(singletonBean.getExpenseReportQuery("expensereport.Management.nbrNightHotelPerDiemBonus"), ExpenseRptD.class)
                    .setParameter("expenseRptId", expenseRptId)
                    .setParameter("countryId", countryId)
                    .getResultList();

        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    public List<ExpenseRptD> getCareServiceHotelNightList(Long expenseRptId, long countryId) throws Exception {

        List<ExpenseRptD> result = null;
        try {
            result = entityManager
                    .createQuery(singletonBean.getExpenseReportQuery("expensereport.Management.careService.nbrNightHotelPerDiemBonus"), ExpenseRptD.class)
                    .setParameter("expenseRptId", expenseRptId)
                    .setParameter("countryId", countryId)
                    .getResultList();

        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    public List<GLCode> getGlCodeList(long countryId) throws Exception {

        List<GLCode> glCodeList = new ArrayList<GLCode>();
        List<String> objectList = null;
        try {

            objectList = entityManager
                    .createQuery(singletonBean.getExpenseReportQuery("expensereport.Management.glCodeList"))
                    .setParameter("countryId", (int) countryId)
                    .getResultList();

            for (String valueString : objectList) {
                glCodeList.add(new GLCode(valueString));

            }

        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return glCodeList;
    }

    @Override
    public BigDecimal getPerDiem(Long expenseRptId) throws Exception {
        BigDecimal result = new BigDecimal(0);
        Object temp = null;
        try {
            temp = entityManager
                    .createQuery(singletonBean.getExpenseReportQuery("expensereport.perDiemAMT"), Object.class)
                    .setParameter("expenseRptId", expenseRptId)
                    .getSingleResult();

            result = new BigDecimal(temp.toString());
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    public List<Loan> getLoanList(Integer countryId) throws Exception {
        List<Loan> loanList = new ArrayList<Loan>();

        try {
            loanList = entityManager
                    .createQuery(singletonBean.getExpenseReportQuery("expenseReport.loanList"), Loan.class)
                    .setParameter("countryId", countryId)
                    .getResultList();

        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return loanList;
    }

    @Override
    public List<Object[]> getLoanDetailList(Long loanId) throws Exception {

        List<Object[]> result = null;
        try {
            result = entityManager
                    .createQuery(singletonBean.getExpenseReportQuery("expenseReport.loanDetailList"))
                    .setParameter("loanId", loanId)
                    .getResultList();

        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    public List<Loan> getUserLoanAvailable(String userName, Long expenseRptId) throws Exception {
        List<Loan> result = new ArrayList<Loan>();

        try {
            result = entityManager
                    .createQuery(singletonBean.getExpenseReportQuery("expenseReport.userLoanAvailable"))
                    .setParameter("userName", userName)
                    .setParameter("expenseRptId", expenseRptId)
                    .getResultList();

        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }

        return result;
    }

    @Override
    public LoanD getLoanD(Long loanId, Long expenseRptId) throws Exception {
        LoanD result = new LoanD();

        try {
            result = entityManager
                    .createQuery(singletonBean.getExpenseReportQuery("expenseReport.loanD"), LoanD.class)
                    .setParameter("loanId", loanId)
                    .setParameter("expenseRptId", expenseRptId)
                    .getSingleResult();

        } catch (Exception e) {
            LOG.warning(e.getMessage() + " no loanD found ");
            //throw new Exception(e.getMessage());
        }

        return result;
    }

    public void deleteLoanD(LoanD loanD) throws Exception {
        try {

            LoanD remove = getLoanD(loanD.getLoanDPK().getLoanId(), loanD.getLoanDPK().getExpenseRptId());

            entityManager.remove(remove);
        } catch (Exception e) {
          System.out.println("error: " + e.getMessage());
        }
    }

    @Override
    public BigDecimal getSumLoanPaid(Long expenseRptId) throws Exception {
        BigDecimal result = new BigDecimal(0);
        Object temp = null;
        try {
            temp = entityManager
                    .createQuery(singletonBean.getExpenseReportQuery("expenseReport.sumLoanPaid"), Object.class)
                    .setParameter("expenseRptId", expenseRptId)
                    .getSingleResult();

            result = new BigDecimal(temp.toString());
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    public boolean isModifyByAccounting(Long expenseRptId) throws Exception {
      boolean result = false;
      Object temp = null;
      try {
        temp = entityManager
                .createQuery(singletonBean.getExpenseReportQuery("expenseReport.approuvalModify"), Object.class)
                .setParameter("expenseRptId", expenseRptId)
                .getSingleResult();

        if ( !temp.toString().equals("0") ){
          result = true;
        }

      } catch (Exception e) {
        LOG.severe(e.getMessage());
        throw new Exception(e.getMessage());
      }
      return result;
    }

    @Override
    public boolean isLoanAvailable(String userName) throws Exception {
      boolean result = false;
      Object temp = null;
      try {
        temp = entityManager
                .createQuery(singletonBean.getExpenseReportQuery("expenseReport.loanAvailableForUser"), Object.class)
                .setParameter("userName", userName.toUpperCase())
                .getSingleResult();

        if ( !temp.toString().equals("0") ){
          result = true;
        }

      } catch (Exception e) {
        LOG.severe(e.getMessage());
        throw new Exception(e.getMessage());
      }
      return result;
    }

    @Override
    public float getUserLoanAvailable(String userName) throws Exception {
      float result = 0.00F;
      Object temp = null;
      try {
        temp = entityManager
                .createQuery(singletonBean.getExpenseReportQuery("expenseReport.loanAvailableForUser"), Object.class)
                .setParameter("userName", userName.toUpperCase())
                .getSingleResult();

        if ( temp != null ){
          result =  Float.parseFloat(temp.toString());
        }

      } catch (Exception e) {
        LOG.severe(e.getMessage());
        throw new Exception(e.getMessage());
      }
      return result;
    }

    @Override
    public List<ExpenseTxt> getSearchExpenseTxt(SearchExpenseReport form) throws Exception {
      List<ExpenseTxt> result = new ArrayList<ExpenseTxt>();

      try {

      StringBuilder queryBuilder = new StringBuilder();
      queryBuilder.append(" select et")
                  .append("   from ExpenseRpt er, ExpenseRptD erd, Expense e, ExpenseTxt et")
                  .append("  where er.validationDate is not null")
                  .append("    and er.cancelDate is null")
                  .append("    and er.expenseRptId = erd.expenseRptDPK.expenseRptId")
                  .append("    and erd.apOperation < 3")
                  .append("    and erd.mgrOperation < 3")
                  .append("    and erd.expenseId = e.expenseId")
                  .append("    and e.expenseId = et.expenseTxtPK.expenseId")
                  .append("    and et.expenseTxtPK.langId = (select max(et2.expenseTxtPK.langId)")
                  .append("                                    from ExpenseTxt et2")
                  .append("                                   where et.expenseTxtPK.expenseId = et2.expenseTxtPK.expenseId")
                  .append("                                     and et2.expenseTxtPK.langId in (1, :langId))")
                  .append("    and er.countryId = :countryId ");

      Map<String, Object> properties = new HashMap<String, Object>();

      properties.put("langId", form.getLangId());
      properties.put("countryId", form.getCountryId());

      if (form.getScreenName() != null ){
        queryBuilder.append(" and er.creatorUserName = :userName ");
        properties.put("userName", form.getScreenName().toUpperCase());
      }

      if ( form.getExpenseId() != -1 ){
        queryBuilder.append(" and erd.expenseId = :expenseId ");
        properties.put("expenseId", form.getExpenseId());
      }

      if ( form.getGlCode() != null && form.getGlCode().getGlCode() != null ){
        queryBuilder.append(" and (lower(erd.otherGlCode) like :glCode or lower(e.glCode) like :glCode) ");
        properties.put("glCode", "%"+form.getGlCode().getGlCode()+"%");
      }

      if ( form.getSearchDateType() != null && form.getFromDate() != null && form.getSearchDateType().equals("Expense Date") ){
        queryBuilder.append(" and erd.expenseDate >= :fromDate ");
        properties.put("fromDate", form.getFromDate());
      }

      if ( form.getSearchDateType() != null && form.getToDate() != null && form.getSearchDateType().equals("Expense Date") ){
        queryBuilder.append(" and erd.expenseDate <= :toDate ");
        properties.put("toDate", form.getToDate());
      }

      if ( form.getSearchDateType() != null && form.getFromDate() != null && form.getSearchDateType().equals("Validation Date") ){
        queryBuilder.append(" and er.validationDate >= :fromDate ");
        properties.put("fromDate", form.getFromDate());
      }

      if ( form.getSearchDateType() != null && form.getToDate() != null && form.getSearchDateType().equals("Validation Date") ){
        queryBuilder.append(" and er.validationDate <= :toDate ");
        properties.put("toDate", form.getToDate());
      }

      if ( form.getKeyword() != null && !form.getKeyword().equals("") ){
        queryBuilder.append(" and (lower(erd.detailInfo) like :keyword or lower(erd.otherExpDesc) like :keyword) ");
        properties.put("keyword", "%"+form.getKeyword()+"%");
      }

      if ( form.getIsTraining() != null && form.getIsTraining().equalsIgnoreCase("yes") ){
        queryBuilder.append(" and erd.isFormation = :isTraining ");
        properties.put("isTraining",  "Y");
      }

      queryBuilder.append(" group by et.expenseTxtPK.expenseId, et.expenseTxtPK.langId, et.expenseDesc ");
      queryBuilder.append(" order by et.expenseDesc ");

      TypedQuery<ExpenseTxt> query = entityManager.createQuery(queryBuilder.toString(), ExpenseTxt.class);
      for (Map.Entry<String, Object> entry : properties.entrySet()) {
          query.setParameter(entry.getKey(), entry.getValue());
      }

      result = query.getResultList();

      } catch (Exception e) {
        LOG.severe(e.getMessage());
        throw new Exception(e.getMessage());
      }
      return result;
    }

    @Override
    public List<ExpenseRptD> getSearchExpenseRptD(SearchExpenseReport form) throws Exception {
      List<ExpenseRptD> result = new ArrayList<ExpenseRptD>();

      try {

      StringBuilder queryBuilder = new StringBuilder();

      queryBuilder.append(" select erd")
                  .append("   from ExpenseRpt er, ExpenseRptD erd, Expense e, ExpenseTxt et")
                  .append("  where er.validationDate is not null")
                  .append("    and er.cancelDate is null")
                  .append("    and er.expenseRptId = erd.expenseRptDPK.expenseRptId")
                  .append("    and erd.apOperation < 3")
                  .append("    and erd.mgrOperation < 3")
                  .append("    and erd.expenseId = e.expenseId")
                  .append("    and e.expenseId = et.expenseTxtPK.expenseId")
                  .append("    and et.expenseTxtPK.langId = (select max(et2.expenseTxtPK.langId)")
                  .append("                                    from ExpenseTxt et2")
                  .append("                                   where et.expenseTxtPK.expenseId = et2.expenseTxtPK.expenseId")
                  .append("                                     and et2.expenseTxtPK.langId in (1, :langId))")
                  .append("    and er.countryId = :countryId ");

      Map<String, Object> properties = new HashMap<String, Object>();

      properties.put("langId", form.getLangId());
      properties.put("countryId", form.getCountryId());

      if (form.getScreenName() != null ){
        queryBuilder.append(" and er.creatorUserName = :userName ");
        properties.put("userName", form.getScreenName().toUpperCase());
      }

      if ( form.getExpenseId() != -1 ){
        queryBuilder.append(" and erd.expenseId = :expenseId ");
        properties.put("expenseId", form.getExpenseId());
      }

      if ( form.getGlCode() != null && form.getGlCode().getGlCode() != null ){
        queryBuilder.append(" and (lower(erd.otherGlCode) like :glCode or lower(e.glCode) like :glCode) ");
        properties.put("glCode", "%"+form.getGlCode().getGlCode()+"%");
      }

      if ( form.getSearchDateType() != null && form.getFromDate() != null && form.getSearchDateType().equals("Expense Date") ){
        queryBuilder.append(" and erd.expenseDate >= :fromDate ");
        properties.put("fromDate", form.getFromDate());
      }

      if ( form.getSearchDateType() != null && form.getToDate() != null && form.getSearchDateType().equals("Expense Date") ){
        queryBuilder.append(" and erd.expenseDate <= :toDate ");
        properties.put("toDate", form.getToDate());
      }

      if ( form.getSearchDateType() != null && form.getFromDate() != null && form.getSearchDateType().equals("Validation Date") ){
        queryBuilder.append(" and erd.validationDate >= :fromDate ");
        properties.put("fromDate", form.getFromDate());
      }

      if ( form.getSearchDateType() != null && form.getToDate() != null && form.getSearchDateType().equals("Validation Date") ){
        queryBuilder.append(" and erd.validationDate <= :toDate ");
        properties.put("toDate", form.getToDate());
      }

      if ( form.getKeyword() != null && !form.getKeyword().equals("") ){
        queryBuilder.append(" and (lower(erd.detailInfo) like :keyword or lower(erd.otherExpDesc) like :keyword) ");
        properties.put("keyword", "%"+form.getKeyword()+"%");
      }

      if ( form.getIsTraining() != null && form.getIsTraining().equalsIgnoreCase("yes") ){
        queryBuilder.append(" and erd.isFormation = :isTraining ");
        properties.put("isTraining",  "Y");
      }

      queryBuilder.append(" order by et.expenseDesc, erd.expenseDate, erd.expenseRptDPK.expenseRptId ");

      TypedQuery<ExpenseRptD> query = entityManager.createQuery(queryBuilder.toString(), ExpenseRptD.class);
      for (Map.Entry<String, Object> entry : properties.entrySet()) {
          query.setParameter(entry.getKey(), entry.getValue());
      }

      result = query.getResultList();

      } catch (Exception e) {
        LOG.severe(e.getMessage());
        throw new Exception(e.getMessage());
      }
      return result;
    }

    @Override
    public List<UPerson> getAllUserForCurrentCountry(Long countryId){
      List<UPerson> uPerson = new ArrayList<UPerson>();
      try {
        uPerson = entityManager
                .createQuery(singletonBean.getExpenseReportQuery("expenseReport.user.loanList"), UPerson.class)
                .setParameter("countryId", Integer.parseInt(countryId.toString()))
                .getResultList();

      } catch (Exception e) {
        LOG.warning(e.getMessage() + " uPerson not found by countryId ");
        //throw new Exception(e.getMessage());
      }

      return uPerson;
    }

    @Override
    public BigDecimal getCareTechPerDiem(String userName) throws Exception {
        BigDecimal result = BigDecimal.ZERO;
        try {
            UPerson uPerson = walterBean.getUPerson(userName);

            Country country = entityManager.find(Country.class, Long.parseLong(uPerson.getCountryId().toString()));
            result = country.getCareTechPerDiem();
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }

        return result;
    }

    @Override
    public BigDecimal getCareTechPerDiemBonus(String userName) throws Exception {
        BigDecimal result = BigDecimal.ZERO;
        try {
            UPerson uPerson = walterBean.getUPerson(userName);

            Country country = entityManager.find(Country.class, Long.parseLong(uPerson.getCountryId().toString()));
            result = country.getCareTechPerDiemBonus();
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }

        return result;
    }

    @Override
    public BigDecimal getCareTechOutZone(String userName) throws Exception {
        BigDecimal result = BigDecimal.ZERO;
        try {
            UPerson uPerson = walterBean.getUPerson(userName);

            Country country = entityManager.find(Country.class, Long.parseLong(uPerson.getCountryId().toString()));
            result = country.getCareTechOutZone();
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }

        return result;
    }

    @Override
    public BigDecimal getCareTechNewMachine(String userName) throws Exception {
        BigDecimal result = BigDecimal.ZERO;
        try {
            UPerson uPerson = walterBean.getUPerson(userName);

            Country country = entityManager.find(Country.class, Long.parseLong(uPerson.getCountryId().toString()));
            result = country.getCareTechNewMachine();
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }

        return result;
    }
}
