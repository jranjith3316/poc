package com.savoirfairelinux.walter.model;

import java.io.Serializable;

public class TradenameTxt implements Serializable {

	private Short franchiseId;
	private Long tradenameId;
	private Long langId;
	private String description;

	
	
	public TradenameTxt(Short franchiseId, Long tradenameId, Long langId, String description) {
		this.franchiseId = franchiseId;
		this.tradenameId = tradenameId;
		this.langId = langId;
		this.description = description;
	}

	public Short getFranchiseId() {
		return franchiseId;
	}

	public void setFranchiseId(Short franchiseId) {
		this.franchiseId = franchiseId;
	}

	public Long getTradenameId() {
		return tradenameId;
	}

	public void setTradenameId(Long tradenameId) {
		this.tradenameId = tradenameId;
	}

	public Long getLangId() {
		return langId;
	}

	public void setLangId(Long langId) {
		this.langId = langId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}
