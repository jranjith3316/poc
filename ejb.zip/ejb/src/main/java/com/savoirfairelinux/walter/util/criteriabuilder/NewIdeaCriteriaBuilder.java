package com.savoirfairelinux.walter.util.criteriabuilder;

import com.savoirfairelinux.walter.dao.waltercb.Idea;
import com.savoirfairelinux.walter.dao.waltercb.ULang;
import com.savoirfairelinux.walter.model.IdeaState;
import com.savoirfairelinux.walter.model.SearchNewIdea;
import com.savoirfairelinux.walter.model.WalterOrganization;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Map;
import javax.persistence.EntityManager;

public class NewIdeaCriteriaBuilder extends AbstractCriteriaBuilder<Idea> {

    private SearchNewIdea form;

    public NewIdeaCriteriaBuilder(EntityManager entityManager, SearchNewIdea form, ULang lang) {
        super(entityManager, Idea.class);
        this.form = form;
    }

    @Override
    protected void initQuery(StringBuilder queryBuilder, Map<String, Object> properties) {
        queryBuilder.append("SELECT idea FROM Idea idea ");
    }

    @Override
    protected void initJoinQuery(StringBuilder queryBuilder, Map<String, Object> properties) {
        queryBuilder.append(" LEFT OUTER JOIN FETCH idea.ideaTxtSet txt ");
    }

    @Override
    protected void buildSpecificQuery(StringBuilder queryBuilder, Map<String, Object> properties) {
        queryBuilder.append(" WHERE idea.cancelDate IS NULL ");
        addOrganization2Criteria(queryBuilder, properties, form.getOrganization(), form.getOrganization2());
        addNewIdeaIdCriteria(queryBuilder, properties, form.getId());
        addLikeCriteria(queryBuilder, "idea.creatorUserName", form.getCreatorScreenName() != null ? form.getCreatorScreenName().toUpperCase() : null);
        addStatesCriteria(queryBuilder, properties, form.getStates());
        addCategoryIdCriteria(queryBuilder, properties, form.getCategoryId());
        addCreatedDateCriteria(queryBuilder, properties, form.getCreatedDate());
        addSubmittedDateCriteria(queryBuilder, properties, form.getSubmittedDate());
        addPublishedDateCriteria(queryBuilder, properties, form.getPublishedDate());
        addPublishedDateNullCriteria(queryBuilder, properties, form.isPublishedDateIsNotNull());
    }

    @Override
    protected void initOrderByQuery(StringBuilder queryBuilder, Map<String, Object> properties) {    	
    }

    protected void addOrganization2Criteria(StringBuilder queryBuilder, Map<String, Object> properties, WalterOrganization organization, WalterOrganization organization2) {
        if (organization2 != null) {
            queryBuilder.append(" AND (idea.organization = :organization ")
                    .append(" OR idea IN (")
                    .append(" SELECT idea2 FROM Idea idea2, UTradenameShare tshare ")
                    .append(" WHERE idea2.organization = :organization2 ")
                    .append((organization.equals(WalterOrganization.WALTER) ?
                            "  AND tshare.wFranchiseGuid = idea.productline AND tshare.wTradenameGuid = idea.tradename "
                            : "AND TO_CHAR(tshare.cbFranchiseId) = idea.productline AND TO_CHAR(tshare.cbTradenameId) = idea.tradename " ))
                    .append(" ) )");
            properties.put("organization", organization.getName());
            properties.put("organization2", organization2.getName());
        } else if (organization != null) {
            queryBuilder.append(" AND idea.organization = :organization ");
            properties.put("organization", organization.getName());
        }
    }

    protected void addNewIdeaIdCriteria(StringBuilder queryBuilder, Map<String, Object> properties, Long ideaId) {
        if (ideaId != null) {
            queryBuilder.append(" AND idea.ideaId = :ideaId");
            properties.put("ideaId", ideaId);
        }
    }

    protected void addCreatedDateCriteria(StringBuilder queryBuilder, Map<String, Object> properties, Date createdDate) {
        if (createdDate != null) {
            queryBuilder.append(" AND idea.createdDate >= :date ");
            properties.put("date", createdDate);
        }
    }
    
    protected void addSubmittedDateCriteria(StringBuilder queryBuilder, Map<String, Object> properties, Date submittedDate) {
        if (submittedDate != null) {
            queryBuilder.append(" AND idea.submitedDate >= :date ");
            properties.put("date", submittedDate);
        }
    }

    protected void addPublishedDateCriteria(StringBuilder queryBuilder, Map<String, Object> properties, Date publishedDate) {
        if (publishedDate != null) {
            queryBuilder.append(" AND idea.publishedDate >= :date ");
            properties.put("date", publishedDate);
        }
    }

    protected void addStatesCriteria(StringBuilder queryBuilder, Map<String, Object> properties, IdeaState[] states) {
        if (states != null) {
            Collection<Integer> stateIds = new ArrayList<Integer>();
            for (IdeaState state : states) {
                stateIds.add(state.getId());
            }

            queryBuilder.append(" AND idea.ideaStatusId IN (:states)");
            properties.put("states", stateIds);
        }
    }

    protected void addPublishedDateNullCriteria(StringBuilder queryBuilder, Map<String, Object> properties, Boolean publishedDateIsNotNull) {
        if (publishedDateIsNotNull != null && publishedDateIsNotNull) {
            queryBuilder.append(" AND idea.publishedDate IS NOT NULL ");
        } else if (publishedDateIsNotNull != null && !publishedDateIsNotNull) {
            queryBuilder.append(" AND idea.publishedDate IS NULL ");
        }
    }

    private void addCategoryIdCriteria(StringBuilder queryBuilder, Map<String, Object> properties, Long categoryId) {
        if (categoryId != null) {
            queryBuilder.append(" AND idea.categoryId = :categoryId ");
            properties.put("categoryId", categoryId);
        }
    }
}
