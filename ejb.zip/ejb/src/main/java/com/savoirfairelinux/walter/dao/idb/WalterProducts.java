/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.idb;

import com.savoirfairelinux.walter.dao.DatabaseConstants;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "WALTER_PRODUCTS", catalog = "", schema = DatabaseConstants.IDB_SCHEMA)
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "WalterProducts.findAll", query = "SELECT w FROM WalterProducts w"),
  @NamedQuery(name = "WalterProducts.findByProductguid", query = "SELECT w FROM WalterProducts w WHERE w.productguid = :productguid"),
  @NamedQuery(name = "WalterProducts.findByProductalternatekey", query = "SELECT w FROM WalterProducts w WHERE w.productalternatekey = :productalternatekey"),
  @NamedQuery(name = "WalterProducts.findByProductnumber", query = "SELECT w FROM WalterProducts w WHERE w.productnumber = :productnumber"),
  @NamedQuery(name = "WalterProducts.findByProductstatus", query = "SELECT w FROM WalterProducts w WHERE w.productstatus = :productstatus"),
  @NamedQuery(name = "WalterProducts.findByNewproduct", query = "SELECT w FROM WalterProducts w WHERE w.newproduct = :newproduct"),
  @NamedQuery(name = "WalterProducts.findByNewstartdate", query = "SELECT w FROM WalterProducts w WHERE w.newstartdate = :newstartdate"),
  @NamedQuery(name = "WalterProducts.findByNewenddate", query = "SELECT w FROM WalterProducts w WHERE w.newenddate = :newenddate"),
  @NamedQuery(name = "WalterProducts.findByAdddatetime", query = "SELECT w FROM WalterProducts w WHERE w.adddatetime = :adddatetime"),
  @NamedQuery(name = "WalterProducts.findByDeletedatetime", query = "SELECT w FROM WalterProducts w WHERE w.deletedatetime = :deletedatetime"),
  @NamedQuery(name = "WalterProducts.findByUpdatedatetime", query = "SELECT w FROM WalterProducts w WHERE w.updatedatetime = :updatedatetime"),
  @NamedQuery(name = "WalterProducts.findByEventuser", query = "SELECT w FROM WalterProducts w WHERE w.eventuser = :eventuser"),
  @NamedQuery(name = "WalterProducts.findByProducttype", query = "SELECT w FROM WalterProducts w WHERE w.producttype = :producttype"),
  @NamedQuery(name = "WalterProducts.findByUpdatedatetimestatus", query = "SELECT w FROM WalterProducts w WHERE w.updatedatetimestatus = :updatedatetimestatus")})
public class WalterProducts implements Serializable {
  private static final long serialVersionUID = 1L;
  @Id
  @Basic(optional = false)
  @NotNull
  @Size(min = 1, max = 255)
  @Column(name = "PRODUCTGUID")
  private String productguid;
  @Size(max = 255)
  @Column(name = "PRODUCTALTERNATEKEY")
  private String productalternatekey;
  @Size(max = 255)
  @Column(name = "PRODUCTNUMBER")
  private String productnumber;
  @Size(max = 255)
  @Column(name = "PRODUCTSTATUS")
  private String productstatus;
  @Column(name = "NEWPRODUCT")
  private Long newproduct;
  @Column(name = "NEWSTARTDATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date newstartdate;
  @Column(name = "NEWENDDATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date newenddate;
  @Column(name = "ADDDATETIME")
  @Temporal(TemporalType.TIMESTAMP)
  private Date adddatetime;
  @Column(name = "DELETEDATETIME")
  @Temporal(TemporalType.TIMESTAMP)
  private Date deletedatetime;
  @Column(name = "UPDATEDATETIME")
  @Temporal(TemporalType.TIMESTAMP)
  private Date updatedatetime;
  @Size(max = 255)
  @Column(name = "EVENTUSER")
  private String eventuser;
  @Size(max = 255)
  @Column(name = "PRODUCTTYPE")
  private String producttype;
  @Column(name = "UPDATEDATETIMESTATUS")
  @Temporal(TemporalType.TIMESTAMP)
  private Date updatedatetimestatus;
//  @OneToMany(cascade = CascadeType.ALL, mappedBy = "productguid")
//  private Set<WalterProductsDocuments> walterProductsDocumentsSet;
  @JoinColumn(name = "COMPANYGUID", referencedColumnName = "COMPANYGUID")
  @ManyToOne
  private WalterCompanies companyguid;
  @JoinColumn(name = "PRODUCTGUID", referencedColumnName = "INSTANCEGUID", insertable = false, updatable = false)
    @ManyToOne(optional = false)
  private OoInstances ooInstances;
//  @OneToMany(cascade = CascadeType.ALL, mappedBy = "productguid")
//  private Set<WalterProductsPresentations> walterProductsPresentationsSet;
//  @OneToMany(cascade = CascadeType.ALL, mappedBy = "productguid")
//  private Set<WalterProductsImages> walterProductsImagesSet;
//  @OneToMany(cascade = CascadeType.ALL, mappedBy = "productguid")
//  private Set<WalterTvvideos> walterTvvideosSet;
//  @OneToMany(cascade = CascadeType.ALL, mappedBy = "productguid")
//  private Set<WalterProductsCountries> walterProductsCountriesSet;
//  @OneToMany(cascade = CascadeType.ALL, mappedBy = "productguid")
//  private Set<WalterProductsVersions> walterProductsVersionsSet;

  public WalterProducts() {
  }

  public WalterProducts(String productguid) {
    this.productguid = productguid;
  }

  public String getProductguid() {
    return productguid;
  }

  public void setProductguid(String productguid) {
    this.productguid = productguid;
  }

  public String getProductalternatekey() {
    return productalternatekey;
  }

  public void setProductalternatekey(String productalternatekey) {
    this.productalternatekey = productalternatekey;
  }

  public String getProductnumber() {
    return productnumber;
  }

  public void setProductnumber(String productnumber) {
    this.productnumber = productnumber;
  }

  public String getProductstatus() {
    return productstatus;
  }

  public void setProductstatus(String productstatus) {
    this.productstatus = productstatus;
  }

  public Long getNewproduct() {
    return newproduct;
  }

  public void setNewproduct(Long newproduct) {
    this.newproduct = newproduct;
  }

  public Date getNewstartdate() {
    return newstartdate;
  }

  public void setNewstartdate(Date newstartdate) {
    this.newstartdate = newstartdate;
  }

  public Date getNewenddate() {
    return newenddate;
  }

  public void setNewenddate(Date newenddate) {
    this.newenddate = newenddate;
  }

  public Date getAdddatetime() {
    return adddatetime;
  }

  public void setAdddatetime(Date adddatetime) {
    this.adddatetime = adddatetime;
  }

  public Date getDeletedatetime() {
    return deletedatetime;
  }

  public void setDeletedatetime(Date deletedatetime) {
    this.deletedatetime = deletedatetime;
  }

  public Date getUpdatedatetime() {
    return updatedatetime;
  }

  public void setUpdatedatetime(Date updatedatetime) {
    this.updatedatetime = updatedatetime;
  }

  public String getEventuser() {
    return eventuser;
  }

  public void setEventuser(String eventuser) {
    this.eventuser = eventuser;
  }

  public String getProducttype() {
    return producttype;
  }

  public void setProducttype(String producttype) {
    this.producttype = producttype;
  }

  public Date getUpdatedatetimestatus() {
    return updatedatetimestatus;
  }

  public void setUpdatedatetimestatus(Date updatedatetimestatus) {
    this.updatedatetimestatus = updatedatetimestatus;
  }

//  @XmlTransient
//  public Set<WalterProductsDocuments> getWalterProductsDocumentsSet() {
//    return walterProductsDocumentsSet;
//  }
//
//  public void setWalterProductsDocumentsSet(Set<WalterProductsDocuments> walterProductsDocumentsSet) {
//    this.walterProductsDocumentsSet = walterProductsDocumentsSet;
//  }

  public WalterCompanies getCompanyguid() {
    return companyguid;
  }

  public void setCompanyguid(WalterCompanies companyguid) {
    this.companyguid = companyguid;
  }

  public OoInstances getOoInstances() {
    return ooInstances;
  }

  public void setOoInstances(OoInstances ooInstances) {
    this.ooInstances = ooInstances;
  }

//  @XmlTransient
//  public Set<WalterProductsPresentations> getWalterProductsPresentationsSet() {
//    return walterProductsPresentationsSet;
//  }
//
//  public void setWalterProductsPresentationsSet(Set<WalterProductsPresentations> walterProductsPresentationsSet) {
//    this.walterProductsPresentationsSet = walterProductsPresentationsSet;
//  }
//
//  @XmlTransient
//  public Set<WalterProductsImages> getWalterProductsImagesSet() {
//    return walterProductsImagesSet;
//  }
//
//  public void setWalterProductsImagesSet(Set<WalterProductsImages> walterProductsImagesSet) {
//    this.walterProductsImagesSet = walterProductsImagesSet;
//  }
//
//  @XmlTransient
//  public Set<WalterTvvideos> getWalterTvvideosSet() {
//    return walterTvvideosSet;
//  }
//
//  public void setWalterTvvideosSet(Set<WalterTvvideos> walterTvvideosSet) {
//    this.walterTvvideosSet = walterTvvideosSet;
//  }
//
//  @XmlTransient
//  public Set<WalterProductsCountries> getWalterProductsCountriesSet() {
//    return walterProductsCountriesSet;
//  }
//
//  public void setWalterProductsCountriesSet(Set<WalterProductsCountries> walterProductsCountriesSet) {
//    this.walterProductsCountriesSet = walterProductsCountriesSet;
//  }
//
//  @XmlTransient
//  public Set<WalterProductsVersions> getWalterProductsVersionsSet() {
//    return walterProductsVersionsSet;
//  }
//
//  public void setWalterProductsVersionsSet(Set<WalterProductsVersions> walterProductsVersionsSet) {
//    this.walterProductsVersionsSet = walterProductsVersionsSet;
//  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (productguid != null ? productguid.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof WalterProducts)) {
      return false;
    }
    WalterProducts other = (WalterProducts) object;
    if ((this.productguid == null && other.productguid != null) || (this.productguid != null && !this.productguid.equals(other.productguid))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.idb.WalterProducts[ productguid=" + productguid + " ]";
  }

}
