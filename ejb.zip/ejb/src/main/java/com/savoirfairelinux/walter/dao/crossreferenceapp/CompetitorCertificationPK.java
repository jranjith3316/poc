/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.crossreferenceapp;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author jsgill
 */
@Embeddable
public class CompetitorCertificationPK implements Serializable {
  @Basic(optional = false)
  @NotNull
  @Column(name = "BRAND_ID")
  private long brandId;
  @Basic(optional = false)
  @NotNull
  @Column(name = "COMPETITOR_ID")
  private long competitorId;
  @Basic(optional = false)
  @NotNull
  @Column(name = "PRODUCT_ID")
  private long productId;
  @Basic(optional = false)
  @NotNull
  @Column(name = "COUNTRY_ID")
  private long countryId;
  @Basic(optional = false)
  @NotNull
  @Size(min = 1, max = 255)
  @Column(name = "CERTIFICATION_GUID")
  private String certificationGuid;

  public CompetitorCertificationPK() {
  }

  public CompetitorCertificationPK(long brandId, long competitorId, long productId, long countryId, String certificationGuid) {
    this.brandId = brandId;
    this.competitorId = competitorId;
    this.productId = productId;
    this.countryId = countryId;
    this.certificationGuid = certificationGuid;
  }

  public long getBrandId() {
    return brandId;
  }

  public void setBrandId(long brandId) {
    this.brandId = brandId;
  }

  public long getCompetitorId() {
    return competitorId;
  }

  public void setCompetitorId(long competitorId) {
    this.competitorId = competitorId;
  }

  public long getProductId() {
    return productId;
  }

  public void setProductId(long productId) {
    this.productId = productId;
  }

  public long getCountryId() {
    return countryId;
  }

  public void setCountryId(long countryId) {
    this.countryId = countryId;
  }

  public String getCertificationGuid() {
    return certificationGuid;
  }

  public void setCertificationGuid(String certificationGuid) {
    this.certificationGuid = certificationGuid;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (int) brandId;
    hash += (int) competitorId;
    hash += (int) productId;
    hash += (int) countryId;
    hash += (certificationGuid != null ? certificationGuid.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof CompetitorCertificationPK)) {
      return false;
    }
    CompetitorCertificationPK other = (CompetitorCertificationPK) object;
    if (this.brandId != other.brandId) {
      return false;
    }
    if (this.competitorId != other.competitorId) {
      return false;
    }
    if (this.productId != other.productId) {
      return false;
    }
    if (this.countryId != other.countryId) {
      return false;
    }
    if ((this.certificationGuid == null && other.certificationGuid != null) || (this.certificationGuid != null && !this.certificationGuid.equals(other.certificationGuid))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.crossreferenceapp.CompetitorCertificationPK[ brandId=" + brandId + ", competitorId=" + competitorId + ", productId=" + productId + ", countryId=" + countryId + ", certificationGuid=" + certificationGuid + " ]";
  }

}
