/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.idb;

import com.savoirfairelinux.walter.dao.DatabaseConstants;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "WALTER_FILES", catalog = "", schema = DatabaseConstants.IDB_SCHEMA)
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "WalterFiles.findAll", query = "SELECT w FROM WalterFiles w"),
  @NamedQuery(name = "WalterFiles.findByFileguid", query = "SELECT w FROM WalterFiles w WHERE w.fileguid = :fileguid"),
  @NamedQuery(name = "WalterFiles.findByFilename", query = "SELECT w FROM WalterFiles w WHERE w.filename = :filename"),
  @NamedQuery(name = "WalterFiles.findByDateuploaded", query = "SELECT w FROM WalterFiles w WHERE w.dateuploaded = :dateuploaded"),
  @NamedQuery(name = "WalterFiles.findByFilecontent", query = "SELECT w FROM WalterFiles w WHERE w.filecontent = :filecontent"),
  @NamedQuery(name = "WalterFiles.findByFileformat", query = "SELECT w FROM WalterFiles w WHERE w.fileformat = :fileformat"),
  @NamedQuery(name = "WalterFiles.findByFilesize", query = "SELECT w FROM WalterFiles w WHERE w.filesize = :filesize"),
  @NamedQuery(name = "WalterFiles.findByName", query = "SELECT w FROM WalterFiles w WHERE w.name = :name")})
public class WalterFiles implements Serializable {
  private static final long serialVersionUID = 1L;
  @Id
  @Basic(optional = false)
  @NotNull
  @Size(min = 1, max = 255)
  @Column(name = "FILEGUID")
  private String fileguid;
  @Basic(optional = false)
  @NotNull
  @Size(min = 1, max = 255)
  @Column(name = "FILENAME")
  private String filename;
  @Basic(optional = false)
  @NotNull
  @Column(name = "DATEUPLOADED")
  @Temporal(TemporalType.TIMESTAMP)
  private Date dateuploaded;
  @Size(max = 255)
  @Column(name = "FILECONTENT")
  private String filecontent;
  @Size(max = 255)
  @Column(name = "FILEFORMAT")
  private String fileformat;
  @Size(max = 255)
  @Column(name = "FILESIZE")
  private String filesize;
  @Size(max = 255)
  @Column(name = "NAME")
  private String name;
//  @OneToMany(mappedBy = "fileguid")
//  private Set<WalterProductsDocuments> walterProductsDocumentsSet;
  @JoinColumn(name = "URLGUID", referencedColumnName = "URLGUID")
  @ManyToOne
  private WalterUrl urlguid;
//  @OneToMany(mappedBy = "parentfileguid")
//  private Set<WalterFiles> walterFilesSet;
  @JoinColumn(name = "PARENTFILEGUID", referencedColumnName = "FILEGUID")
  @ManyToOne
  private WalterFiles parentfileguid;
  @JoinColumn(name = "COMPANYGUID", referencedColumnName = "COMPANYGUID")
  @ManyToOne(optional = false)
  private WalterCompanies companyguid;
  @JoinColumn(name = "FILEGUID", referencedColumnName = "INSTANCEGUID", insertable = false, updatable = false)
  @OneToOne(optional = false)
  private OoInstances ooInstances;
//  @OneToMany(mappedBy = "fileguid")
//  private Set<WalterProductsImages> walterProductsImagesSet;

  public WalterFiles() {
  }

  public WalterFiles(String fileguid) {
    this.fileguid = fileguid;
  }

  public WalterFiles(String fileguid, String filename, Date dateuploaded) {
    this.fileguid = fileguid;
    this.filename = filename;
    this.dateuploaded = dateuploaded;
  }

  public String getFileguid() {
    return fileguid;
  }

  public void setFileguid(String fileguid) {
    this.fileguid = fileguid;
  }

  public String getFilename() {
    return filename;
  }

  public void setFilename(String filename) {
    this.filename = filename;
  }

  public Date getDateuploaded() {
    return dateuploaded;
  }

  public void setDateuploaded(Date dateuploaded) {
    this.dateuploaded = dateuploaded;
  }

  public String getFilecontent() {
    return filecontent;
  }

  public void setFilecontent(String filecontent) {
    this.filecontent = filecontent;
  }

  public String getFileformat() {
    return fileformat;
  }

  public void setFileformat(String fileformat) {
    this.fileformat = fileformat;
  }

  public String getFilesize() {
    return filesize;
  }

  public void setFilesize(String filesize) {
    this.filesize = filesize;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

//  @XmlTransient
//  public Set<WalterProductsDocuments> getWalterProductsDocumentsSet() {
//    return walterProductsDocumentsSet;
//  }
//
//  public void setWalterProductsDocumentsSet(Set<WalterProductsDocuments> walterProductsDocumentsSet) {
//    this.walterProductsDocumentsSet = walterProductsDocumentsSet;
//  }

  public WalterUrl getUrlguid() {
    return urlguid;
  }

  public void setUrlguid(WalterUrl urlguid) {
    this.urlguid = urlguid;
  }

//  @XmlTransient
//  public Set<WalterFiles> getWalterFilesSet() {
//    return walterFilesSet;
//  }
//
//  public void setWalterFilesSet(Set<WalterFiles> walterFilesSet) {
//    this.walterFilesSet = walterFilesSet;
//  }

  public WalterFiles getParentfileguid() {
    return parentfileguid;
  }

  public void setParentfileguid(WalterFiles parentfileguid) {
    this.parentfileguid = parentfileguid;
  }

  public WalterCompanies getCompanyguid() {
    return companyguid;
  }

  public void setCompanyguid(WalterCompanies companyguid) {
    this.companyguid = companyguid;
  }

  public OoInstances getOoInstances() {
    return ooInstances;
  }

  public void setOoInstances(OoInstances ooInstances) {
    this.ooInstances = ooInstances;
  }

//  @XmlTransient
//  public Set<WalterProductsImages> getWalterProductsImagesSet() {
//    return walterProductsImagesSet;
//  }
//
//  public void setWalterProductsImagesSet(Set<WalterProductsImages> walterProductsImagesSet) {
//    this.walterProductsImagesSet = walterProductsImagesSet;
//  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (fileguid != null ? fileguid.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof WalterFiles)) {
      return false;
    }
    WalterFiles other = (WalterFiles) object;
    if ((this.fileguid == null && other.fileguid != null) || (this.fileguid != null && !this.fileguid.equals(other.fileguid))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.idb.WalterFiles[ fileguid=" + fileguid + " ]";
  }

}
