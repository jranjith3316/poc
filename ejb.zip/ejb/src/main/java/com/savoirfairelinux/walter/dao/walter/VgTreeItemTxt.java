/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.walter;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "VG_TREE_ITEM_TXT", catalog = "", schema = DatabaseConstants.WALTER_SCHEMA)
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "VgTreeItemTxt.findAll", query = "SELECT v FROM VgTreeItemTxt v"),
  @NamedQuery(name = "VgTreeItemTxt.findByVgTreeCode", query = "SELECT v FROM VgTreeItemTxt v WHERE v.vgTreeItemTxtPK.vgTreeCode = :vgTreeCode"),
  @NamedQuery(name = "VgTreeItemTxt.findByItemId", query = "SELECT v FROM VgTreeItemTxt v WHERE v.vgTreeItemTxtPK.itemId = :itemId"),
  @NamedQuery(name = "VgTreeItemTxt.findByLangId", query = "SELECT v FROM VgTreeItemTxt v WHERE v.vgTreeItemTxtPK.langId = :langId"),
  @NamedQuery(name = "VgTreeItemTxt.findByCreatorUserName", query = "SELECT v FROM VgTreeItemTxt v WHERE v.creatorUserName = :creatorUserName"),
  @NamedQuery(name = "VgTreeItemTxt.findByCreationDate", query = "SELECT v FROM VgTreeItemTxt v WHERE v.creationDate = :creationDate"),
  @NamedQuery(name = "VgTreeItemTxt.findByCancelBy", query = "SELECT v FROM VgTreeItemTxt v WHERE v.cancelBy = :cancelBy"),
  @NamedQuery(name = "VgTreeItemTxt.findByCancelDate", query = "SELECT v FROM VgTreeItemTxt v WHERE v.cancelDate = :cancelDate"),
  @NamedQuery(name = "VgTreeItemTxt.findByImageName", query = "SELECT v FROM VgTreeItemTxt v WHERE v.imageName = :imageName"),
  @NamedQuery(name = "VgTreeItemTxt.findByVideoName", query = "SELECT v FROM VgTreeItemTxt v WHERE v.videoName = :videoName"),
  @NamedQuery(name = "VgTreeItemTxt.findByYoutubeId", query = "SELECT v FROM VgTreeItemTxt v WHERE v.youtubeId = :youtubeId"),
  @NamedQuery(name = "VgTreeItemTxt.findByTitle", query = "SELECT v FROM VgTreeItemTxt v WHERE v.title = :title"),
  @NamedQuery(name = "VgTreeItemTxt.findByDescription", query = "SELECT v FROM VgTreeItemTxt v WHERE v.description = :description"),
  @NamedQuery(name = "VgTreeItemTxt.findByTag", query = "SELECT v FROM VgTreeItemTxt v WHERE v.tag = :tag"),
  @NamedQuery(name = "VgTreeItemTxt.findByVideoPath", query = "SELECT v FROM VgTreeItemTxt v WHERE v.videoPath = :videoPath")})
public class VgTreeItemTxt implements Serializable {
  private static final long serialVersionUID = 1L;
  @EmbeddedId
  protected VgTreeItemTxtPK vgTreeItemTxtPK;
  @Size(max = 256)
  @Column(name = "CREATOR_USER_NAME")
  private String creatorUserName;
  @Column(name = "CREATION_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date creationDate;
  @Size(max = 256)
  @Column(name = "CANCEL_BY")
  private String cancelBy;
  @Column(name = "CANCEL_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date cancelDate;
  @Size(max = 90)
  @Column(name = "IMAGE_NAME")
  private String imageName;
  @Size(max = 90)
  @Column(name = "VIDEO_NAME")
  private String videoName;
  @Size(max = 90)
  @Column(name = "YOUTUBE_ID")
  private String youtubeId;
  @Size(max = 500)
  @Column(name = "TITLE")
  private String title;
  @Size(max = 500)
  @Column(name = "DESCRIPTION")
  private String description;
  @Size(max = 500)
  @Column(name = "TAG")
  private String tag;
  @Size(max = 2000)
  @Column(name = "VIDEO_PATH")
  private String videoPath;
  @JoinColumns({
    @JoinColumn(name = "VG_TREE_CODE", referencedColumnName = "VG_TREE_CODE", insertable = false, updatable = false),
    @JoinColumn(name = "ITEM_ID", referencedColumnName = "ITEM_ID", insertable = false, updatable = false)})
  @ManyToOne(optional = false)
  private VgTreeItem vgTreeItem;

  public VgTreeItemTxt() {
  }

  public VgTreeItemTxt(VgTreeItemTxtPK vgTreeItemTxtPK) {
    this.vgTreeItemTxtPK = vgTreeItemTxtPK;
  }

  public VgTreeItemTxt(String vgTreeCode, int itemId, Integer langId) {
    this.vgTreeItemTxtPK = new VgTreeItemTxtPK(vgTreeCode, itemId, langId);
  }

  public VgTreeItemTxtPK getVgTreeItemTxtPK() {
    return vgTreeItemTxtPK;
  }

  public void setVgTreeItemTxtPK(VgTreeItemTxtPK vgTreeItemTxtPK) {
    this.vgTreeItemTxtPK = vgTreeItemTxtPK;
  }

  public String getCreatorUserName() {
    return creatorUserName;
  }

  public void setCreatorUserName(String creatorUserName) {
    this.creatorUserName = creatorUserName;
  }

  public Date getCreationDate() {
    return creationDate;
  }

  public void setCreationDate(Date creationDate) {
    this.creationDate = creationDate;
  }

  public String getCancelBy() {
    return cancelBy;
  }

  public void setCancelBy(String cancelBy) {
    this.cancelBy = cancelBy;
  }

  public Date getCancelDate() {
    return cancelDate;
  }

  public void setCancelDate(Date cancelDate) {
    this.cancelDate = cancelDate;
  }

  public String getImageName() {
    return imageName;
  }

  public void setImageName(String imageName) {
    this.imageName = imageName;
  }

  public String getVideoName() {
    return videoName;
  }

  public void setVideoName(String videoName) {
    this.videoName = videoName;
  }

  public String getYoutubeId() {
    return youtubeId;
  }

  public void setYoutubeId(String youtubeId) {
    this.youtubeId = youtubeId;
  }

  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getTag() {
    return tag;
  }

  public void setTag(String tag) {
    this.tag = tag;
  }

  public String getVideoPath() {
    return videoPath;
  }

  public void setVideoPath(String videoPath) {
    this.videoPath = videoPath;
  }

  public VgTreeItem getVgTreeItem() {
    return vgTreeItem;
  }

  public void setVgTreeItem(VgTreeItem vgTreeItem) {
    this.vgTreeItem = vgTreeItem;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (vgTreeItemTxtPK != null ? vgTreeItemTxtPK.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof VgTreeItemTxt)) {
      return false;
    }
    VgTreeItemTxt other = (VgTreeItemTxt) object;
    if ((this.vgTreeItemTxtPK == null && other.vgTreeItemTxtPK != null) || (this.vgTreeItemTxtPK != null && !this.vgTreeItemTxtPK.equals(other.vgTreeItemTxtPK))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.walter.VgTreeItemTxt[ vgTreeItemTxtPK=" + vgTreeItemTxtPK + " ]";
  }
  
}
