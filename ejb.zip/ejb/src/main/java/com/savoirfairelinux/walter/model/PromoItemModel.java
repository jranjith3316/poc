/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.model;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 *
 * @author jsgill
 */
public class PromoItemModel implements Serializable {
  private Long itemid;
  private String productNumber;
  private String name;
  private byte[] image;
  private String imageName;
  private BigDecimal listPrice;

  public PromoItemModel(Long itemid, String productNumber, String name, byte[] image, String imageName, BigDecimal listPrice) {
    this.itemid = itemid;
    this.productNumber = productNumber;
    this.name = name;
    this.image = image;
    this.imageName = imageName;
    this.listPrice = listPrice;
  }

  public PromoItemModel(Long itemid, String productNumber, String name) {
    this.itemid = itemid;
    this.productNumber = productNumber;
    this.name = name;
  }

  public Long getItemid() {
    return itemid;
  }

  public void setItemid(Long itemid) {
    this.itemid = itemid;
  }

  public String getProductNumber() {
    return productNumber;
  }

  public void setProductNumber(String productNumber) {
    this.productNumber = productNumber;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public byte[] getImage() {
    return image;
  }

  public void setImage(byte[] image) {
    this.image = image;
  }

  public String getImageName() {
    return imageName;
  }

  public void setImageName(String imageName) {
    this.imageName = imageName;
  }

  public BigDecimal getListPrice() {
    return listPrice;
  }

  public void setListPrice(BigDecimal listPrice) {
    this.listPrice = listPrice;
  }

}
