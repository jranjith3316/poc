/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.walter;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "EXPENSE_RPT_D", catalog = "", schema = DatabaseConstants.WALTER_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "ExpenseRptD.findAll", query = "SELECT e FROM ExpenseRptD e"),
    @NamedQuery(name = "ExpenseRptD.findByExpenseRptId", query = "SELECT e FROM ExpenseRptD e WHERE e.expenseRptDPK.expenseRptId = :expenseRptId"),
    @NamedQuery(name = "ExpenseRptD.findByLineNum", query = "SELECT e FROM ExpenseRptD e WHERE e.expenseRptDPK.lineNum = :lineNum"),
    @NamedQuery(name = "ExpenseRptD.findByExpenseDate", query = "SELECT e FROM ExpenseRptD e WHERE e.expenseDate = :expenseDate"),
    @NamedQuery(name = "ExpenseRptD.findByCity", query = "SELECT e FROM ExpenseRptD e WHERE e.city = :city"),
    @NamedQuery(name = "ExpenseRptD.findByStateCode", query = "SELECT e FROM ExpenseRptD e WHERE e.stateCode = :stateCode"),
    @NamedQuery(name = "ExpenseRptD.findByCountryId", query = "SELECT e FROM ExpenseRptD e WHERE e.countryId = :countryId"),
    @NamedQuery(name = "ExpenseRptD.findByDetailInfo", query = "SELECT e FROM ExpenseRptD e WHERE e.detailInfo = :detailInfo"),
    @NamedQuery(name = "ExpenseRptD.findByTotalAmt", query = "SELECT e FROM ExpenseRptD e WHERE e.totalAmt = :totalAmt"),
    @NamedQuery(name = "ExpenseRptD.findByExpenseId", query = "SELECT e FROM ExpenseRptD e WHERE e.expenseId = :expenseId"),
    @NamedQuery(name = "ExpenseRptD.findByTax1Amt", query = "SELECT e FROM ExpenseRptD e WHERE e.tax1Amt = :tax1Amt"),
    @NamedQuery(name = "ExpenseRptD.findByTax2Amt", query = "SELECT e FROM ExpenseRptD e WHERE e.tax2Amt = :tax2Amt"),
    @NamedQuery(name = "ExpenseRptD.findByTax3Amt", query = "SELECT e FROM ExpenseRptD e WHERE e.tax3Amt = :tax3Amt"),
    @NamedQuery(name = "ExpenseRptD.findByHotelName", query = "SELECT e FROM ExpenseRptD e WHERE e.hotelName = :hotelName"),
    @NamedQuery(name = "ExpenseRptD.findByHotelNbNight", query = "SELECT e FROM ExpenseRptD e WHERE e.hotelNbNight = :hotelNbNight"),
    @NamedQuery(name = "ExpenseRptD.findByOtherExpDesc", query = "SELECT e FROM ExpenseRptD e WHERE e.otherExpDesc = :otherExpDesc"),
    @NamedQuery(name = "ExpenseRptD.findByTipAmt", query = "SELECT e FROM ExpenseRptD e WHERE e.tipAmt = :tipAmt"),
    @NamedQuery(name = "ExpenseRptD.findByOtherGlCode", query = "SELECT e FROM ExpenseRptD e WHERE e.otherGlCode = :otherGlCode"),
    @NamedQuery(name = "ExpenseRptD.findByAmtPaid", query = "SELECT e FROM ExpenseRptD e WHERE e.amtPaid = :amtPaid"),
    @NamedQuery(name = "ExpenseRptD.findByMgrOperation", query = "SELECT e FROM ExpenseRptD e WHERE e.mgrOperation = :mgrOperation"),
    @NamedQuery(name = "ExpenseRptD.findByApOperation", query = "SELECT e FROM ExpenseRptD e WHERE e.apOperation = :apOperation"),
    @NamedQuery(name = "ExpenseRptD.findByDistance", query = "SELECT e FROM ExpenseRptD e WHERE e.distance = :distance"),
    @NamedQuery(name = "ExpenseRptD.findByUserNameExpense", query = "SELECT e FROM ExpenseRptD e WHERE e.userNameExpense = :userNameExpense"),
    @NamedQuery(name = "ExpenseRptD.findByApOperationUserName", query = "SELECT e FROM ExpenseRptD e WHERE e.apOperationUserName = :apOperationUserName"),
    @NamedQuery(name = "ExpenseRptD.findByHotelFromDate", query = "SELECT e FROM ExpenseRptD e WHERE e.hotelFromDate = :hotelFromDate"),
    @NamedQuery(name = "ExpenseRptD.findByHotelToDate", query = "SELECT e FROM ExpenseRptD e WHERE e.hotelToDate = :hotelToDate"),
    @NamedQuery(name = "ExpenseRptD.findByisFormation", query = "SELECT e FROM ExpenseRptD e WHERE e.isFormation = :isFormation")})
public class ExpenseRptD implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected ExpenseRptDPK expenseRptDPK;
    @Column(name = "EXPENSE_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date expenseDate;
    @Size(max = 40)
    @Column(length = 40)
    private String city;
    @Size(max = 5)
    @Column(name = "STATE_CODE", length = 5)
    private String stateCode;
    @Column(name = "COUNTRY_ID")
    private Integer countryId;
    @Size(max = 80)
    @Column(name = "DETAIL_INFO", length = 80)
    private String detailInfo;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "TOTAL_AMT", precision = 12, scale = 2)
    private BigDecimal totalAmt;
    @Column(name = "EXPENSE_ID")
    private Long expenseId;
    @Column(name = "TAX1_AMT", precision = 12, scale = 2)
    private BigDecimal tax1Amt;
    @Column(name = "TAX2_AMT", precision = 12, scale = 2)
    private BigDecimal tax2Amt;
    @Column(name = "TAX3_AMT", precision = 12, scale = 2)
    private BigDecimal tax3Amt;
    @Size(max = 40)
    @Column(name = "HOTEL_NAME", length = 40)
    private String hotelName;
    @Column(name = "HOTEL_NB_NIGHT")
    private Integer hotelNbNight;
    @Size(max = 80)
    @Column(name = "OTHER_EXP_DESC", length = 80)
    private String otherExpDesc;
    @Column(name = "TIP_AMT", precision = 12, scale = 2)
    private BigDecimal tipAmt;
    @Size(max = 10)
    @Column(name = "OTHER_GL_CODE", length = 10)
    private String otherGlCode;
    @Column(name = "AMT_PAID", precision = 12, scale = 2)
    private BigDecimal amtPaid;
    @Column(name = "MGR_OPERATION")
    private Integer mgrOperation;
    @Column(name = "AP_OPERATION")
    private Integer apOperation;
    private Integer distance;
    @Size(max = 256)
    @Column(name = "USER_NAME_EXPENSE", length = 256)
    private String userNameExpense;
    @Column(name = "HOTEL_FROM_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date hotelFromDate;
    @Column(name = "HOTEL_TO_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date hotelToDate;
    @Size(max = 256)
    @Column(name = "AP_OPERATION_USER_NAME", length = 256)
    private String apOperationUserName;
    @Size(max = 1)
    @Column(name="ISFORMATION", length = 1)
    private String isFormation;
    @JoinColumn(name = "EXPENSE_RPT_ID", referencedColumnName = "EXPENSE_RPT_ID", nullable = false, insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private ExpenseRpt expenseRpt;
    @OneToOne(cascade = CascadeType.ALL, mappedBy = "expenseRptD", fetch= FetchType.LAZY)
    private ExpenseRptPd expenseRptPd;
    
    public ExpenseRptD() {
    }

    public ExpenseRptD(ExpenseRptDPK expenseRptDPK) {
        this.expenseRptDPK = expenseRptDPK;
    }

    public ExpenseRptD(long expenseRptId, short lineNum) {
        this.expenseRptDPK = new ExpenseRptDPK(expenseRptId, lineNum);
    }

    public ExpenseRptDPK getExpenseRptDPK() {
        return expenseRptDPK;
    }

    public void setExpenseRptDPK(ExpenseRptDPK expenseRptDPK) {
        this.expenseRptDPK = expenseRptDPK;
    }

    public Date getExpenseDate() {
        return expenseDate;
    }

    public void setExpenseDate(Date expenseDate) {
        this.expenseDate = expenseDate;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getStateCode() {
        return stateCode;
    }

    public void setStateCode(String stateCode) {
        this.stateCode = stateCode;
    }

    public Integer getCountryId() {
        return countryId;
    }

    public void setCountryId(Integer countryId) {
        this.countryId = countryId;
    }

    public String getDetailInfo() {
        return detailInfo;
    }

    public void setDetailInfo(String detailInfo) {
        this.detailInfo = detailInfo;
    }

    public BigDecimal getTotalAmt() {
        return totalAmt;
    }

    public void setTotalAmt(BigDecimal totalAmt) {
        this.totalAmt = totalAmt;
    }

    public Long getExpenseId() {
        return expenseId;
    }

    public void setExpenseId(Long expenseId) {
        this.expenseId = expenseId;
    }

    public BigDecimal getTax1Amt() {
        return tax1Amt;
    }

    public void setTax1Amt(BigDecimal tax1Amt) {
        this.tax1Amt = tax1Amt;
    }

    public BigDecimal getTax2Amt() {
        return tax2Amt;
    }

    public void setTax2Amt(BigDecimal tax2Amt) {
        this.tax2Amt = tax2Amt;
    }

    public BigDecimal getTax3Amt() {
        return tax3Amt;
    }

    public void setTax3Amt(BigDecimal tax3Amt) {
        this.tax3Amt = tax3Amt;
    }

    public String getHotelName() {
        return hotelName;
    }

    public void setHotelName(String hotelName) {
        this.hotelName = hotelName;
    }

    public Integer getHotelNbNight() {
        return hotelNbNight;
    }

    public void setHotelNbNight(Integer hotelNbNight) {
        this.hotelNbNight = hotelNbNight;
    }

    public String getOtherExpDesc() {
        return otherExpDesc;
    }

    public void setOtherExpDesc(String otherExpDesc) {
        this.otherExpDesc = otherExpDesc;
    }

    public BigDecimal getTipAmt() {
        return tipAmt;
    }

    public void setTipAmt(BigDecimal tipAmt) {
        this.tipAmt = tipAmt;
    }

    public String getOtherGlCode() {
        return otherGlCode;
    }

    public void setOtherGlCode(String otherGlCode) {
        this.otherGlCode = otherGlCode;
    }

    public BigDecimal getAmtPaid() {
        return amtPaid;
    }

    public void setAmtPaid(BigDecimal amtPaid) {
        this.amtPaid = amtPaid;
    }

    public Integer getMgrOperation() {
        return mgrOperation;
    }

    public void setMgrOperation(Integer mgrOperation) {
        this.mgrOperation = mgrOperation;
    }

    public Integer getApOperation() {
        return apOperation;
    }

    public void setApOperation(Integer apOperation) {
        this.apOperation = apOperation;
    }

    public Integer getDistance() {
        return distance;
    }

    public void setDistance(Integer distance) {
        this.distance = distance;
    }

    public String getUserNameExpense() {
        return userNameExpense;
    }

    public void setUserNameExpense(String userNameExpense) {
        this.userNameExpense = userNameExpense;
    }

    public String getApOperationUserName() {
        return apOperationUserName;
    }

    public void setApOperationUserName(String apOperationUserName) {
        this.apOperationUserName = apOperationUserName;
    }

    public ExpenseRpt getExpenseRpt() {
        return expenseRpt;
    }

    public void setExpenseRpt(ExpenseRpt expenseRpt) {
        this.expenseRpt = expenseRpt;
    }

    public ExpenseRptPd getExpenseRptPd() {
        return expenseRptPd;
    }

    public void setExpenseRptPd(ExpenseRptPd expenseRptPd) {
        this.expenseRptPd = expenseRptPd;
    }

    public Date getHotelFromDate() {
      return hotelFromDate;
    }

    public void setHotelFromDate(Date hotelFromDate) {
      this.hotelFromDate = hotelFromDate;
    }

    public Date getHotelToDate() {
      return hotelToDate;
    }

    public void setHotelToDate(Date hotelToDate) {
      this.hotelToDate = hotelToDate;
    }

    public String getIsFormation() {
      return isFormation;
    }

    public void setIsFormation(String isFormation) {
      this.isFormation = isFormation;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (expenseRptDPK != null ? expenseRptDPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ExpenseRptD)) {
            return false;
        }
        ExpenseRptD other = (ExpenseRptD) object;
        if ((this.expenseRptDPK == null && other.expenseRptDPK != null) || (this.expenseRptDPK != null && !this.expenseRptDPK.equals(other.expenseRptDPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.walter.ExpenseRptD[ expenseRptDPK=" + expenseRptDPK + " ]";
    }
    
}
