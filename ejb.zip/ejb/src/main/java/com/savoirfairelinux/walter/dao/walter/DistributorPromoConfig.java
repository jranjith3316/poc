/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.walter;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "DISTRIBUTOR_PROMO_CONFIG", catalog = "", schema = "WALTER")
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "DistributorPromoConfig.findAll", query = "SELECT d FROM DistributorPromoConfig d"),
  @NamedQuery(name = "DistributorPromoConfig.findByPromoCode", query = "SELECT d FROM DistributorPromoConfig d WHERE d.promoCode = :promoCode"),
  @NamedQuery(name = "DistributorPromoConfig.findByPromoDesc", query = "SELECT d FROM DistributorPromoConfig d WHERE d.promoDesc = :promoDesc"),
  @NamedQuery(name = "DistributorPromoConfig.findByStartDate", query = "SELECT d FROM DistributorPromoConfig d WHERE d.startDate = :startDate"),
  @NamedQuery(name = "DistributorPromoConfig.findByEndDate", query = "SELECT d FROM DistributorPromoConfig d WHERE d.endDate = :endDate"),
  @NamedQuery(name = "DistributorPromoConfig.findByFileName", query = "SELECT d FROM DistributorPromoConfig d WHERE d.fileName = :fileName"),
  @NamedQuery(name = "DistributorPromoConfig.findByFolderName", query = "SELECT d FROM DistributorPromoConfig d WHERE d.folderName = :folderName"),
  @NamedQuery(name = "DistributorPromoConfig.findByAutoUpdate", query = "SELECT d FROM DistributorPromoConfig d WHERE d.autoUpdate = :autoUpdate"),
  @NamedQuery(name = "DistributorPromoConfig.findByGroupId", query = "SELECT d FROM DistributorPromoConfig d WHERE d.groupId = :groupId"),
  @NamedQuery(name = "DistributorPromoConfig.findByCountry", query = "SELECT d FROM DistributorPromoConfig d WHERE d.country = :country"),
  @NamedQuery(name = "DistributorPromoConfig.findByCancelDate", query = "SELECT d FROM DistributorPromoConfig d WHERE d.cancelDate = :cancelDate"),
  @NamedQuery(name = "DistributorPromoConfig.findByCancelBy", query = "SELECT d FROM DistributorPromoConfig d WHERE d.cancelBy = :cancelBy"),
  @NamedQuery(name = "DistributorPromoConfig.findBySaGroup", query = "SELECT d FROM DistributorPromoConfig d WHERE d.saGroup = :saGroup")})
public class DistributorPromoConfig implements Serializable {
  private static final long serialVersionUID = 1L;
  @Id
  @Basic(optional = false)
  @NotNull
  @Size(min = 1, max = 10)
  @Column(name = "PROMO_CODE")
  private String promoCode;
  @Size(max = 40)
  @Column(name = "PROMO_DESC")
  private String promoDesc;
  @Column(name = "START_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date startDate;
  @Column(name = "END_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date endDate;
  @Size(max = 100)
  @Column(name = "FILE_NAME")
  private String fileName;
  @Size(max = 140)
  @Column(name = "FOLDER_NAME")
  private String folderName;
  @Column(name = "AUTO_UPDATE")
  private Character autoUpdate;
  @Column(name = "GROUP_ID")
  private Long groupId;
  @Size(max = 10)
  @Column(name = "COUNTRY")
  private String country;
  @Column(name = "CANCEL_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date cancelDate;
  @Size(max = 255)
  @Column(name = "CANCEL_BY")
  private String cancelBy;
  @Size(max = 200)
  @Column(name = "SA_GROUP")
  private String saGroup;

  public DistributorPromoConfig() {
  }

  public DistributorPromoConfig(String promoCode) {
    this.promoCode = promoCode;
  }

  public String getPromoCode() {
    return promoCode;
  }

  public void setPromoCode(String promoCode) {
    this.promoCode = promoCode;
  }

  public String getPromoDesc() {
    return promoDesc;
  }

  public void setPromoDesc(String promoDesc) {
    this.promoDesc = promoDesc;
  }

  public Date getStartDate() {
    return startDate;
  }

  public void setStartDate(Date startDate) {
    this.startDate = startDate;
  }

  public Date getEndDate() {
    return endDate;
  }

  public void setEndDate(Date endDate) {
    this.endDate = endDate;
  }

  public String getFileName() {
    return fileName;
  }

  public void setFileName(String fileName) {
    this.fileName = fileName;
  }

  public String getFolderName() {
    return folderName;
  }

  public void setFolderName(String folderName) {
    this.folderName = folderName;
  }

  public Character getAutoUpdate() {
    return autoUpdate;
  }

  public void setAutoUpdate(Character autoUpdate) {
    this.autoUpdate = autoUpdate;
  }

  public Long getGroupId() {
    return groupId;
  }

  public void setGroupId(Long groupId) {
    this.groupId = groupId;
  }

  public String getCountry() {
    return country;
  }

  public void setCountry(String country) {
    this.country = country;
  }

  public Date getCancelDate() {
    return cancelDate;
  }

  public void setCancelDate(Date cancelDate) {
    this.cancelDate = cancelDate;
  }

  public String getCancelBy() {
    return cancelBy;
  }

  public void setCancelBy(String cancelBy) {
    this.cancelBy = cancelBy;
  }

  public String getSaGroup() {
    return saGroup;
  }

  public void setSaGroup(String saGroup) {
    this.saGroup = saGroup;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (promoCode != null ? promoCode.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof DistributorPromoConfig)) {
      return false;
    }
    DistributorPromoConfig other = (DistributorPromoConfig) object;
    if ((this.promoCode == null && other.promoCode != null) || (this.promoCode != null && !this.promoCode.equals(other.promoCode))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.walter.DistributorPromoConfig[ promoCode=" + promoCode + " ]";
  }

}
