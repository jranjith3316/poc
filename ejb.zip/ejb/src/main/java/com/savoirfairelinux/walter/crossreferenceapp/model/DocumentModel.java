/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.crossreferenceapp.model;

import java.io.Serializable;

/**
 *
 * @author jsgill
 */
public class DocumentModel implements Serializable {
  private static final long serialVersionUID = 3511338233023397895L;

  private String url;
  private String documentName;

  public DocumentModel() {
  }

  public DocumentModel(String url, String documentName) {
    this.url = url;
    this.documentName = documentName;
  }

  public String getUrl() {
    return url;
  }

  public void setUrl(String url) {
    this.url = url;
  }

  public String getDocumentName() {
    return documentName;
  }

  public void setDocumentName(String documentName) {
    this.documentName = documentName;
  }



}
