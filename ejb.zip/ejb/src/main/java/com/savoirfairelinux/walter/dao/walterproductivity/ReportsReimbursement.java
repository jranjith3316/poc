/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.walterproductivity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "REPORTS_REIMBURSEMENT", catalog = "", schema = "WALTERPRODUCTIVITY")
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "ReportsReimbursement.findAll", query = "SELECT r FROM ReportsReimbursement r"),
  @NamedQuery(name = "ReportsReimbursement.findById", query = "SELECT r FROM ReportsReimbursement r WHERE r.id = :id"),
  @NamedQuery(name = "ReportsReimbursement.findByActive", query = "SELECT r FROM ReportsReimbursement r WHERE r.active = :active"),
  @NamedQuery(name = "ReportsReimbursement.findByNumberOfDiscs", query = "SELECT r FROM ReportsReimbursement r WHERE r.numberOfDiscs = :numberOfDiscs"),
  @NamedQuery(name = "ReportsReimbursement.findByNumberOfPads", query = "SELECT r FROM ReportsReimbursement r WHERE r.numberOfPads = :numberOfPads"),
  @NamedQuery(name = "ReportsReimbursement.findByPricePerDisc", query = "SELECT r FROM ReportsReimbursement r WHERE r.pricePerDisc = :pricePerDisc"),
  @NamedQuery(name = "ReportsReimbursement.findByReimbursement", query = "SELECT r FROM ReportsReimbursement r WHERE r.reimbursement = :reimbursement")})
public class ReportsReimbursement implements Serializable {
  private static final long serialVersionUID = 1L;
  @Id
  @Basic(optional = false)
  @NotNull
  @Size(min = 1, max = 255)
  @Column(name = "ID")
  private String id;
  @Column(name = "ACTIVE")
  private Short active;
  @Column(name = "NUMBER_OF_DISCS")
  private Long numberOfDiscs;
  @Column(name = "NUMBER_OF_PADS")
  private Long numberOfPads;
  // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
  @Column(name = "PRICE_PER_DISC")
  private Double pricePerDisc;
  @Column(name = "REIMBURSEMENT")
  private Double reimbursement;
  @JoinColumn(name = "REPORT_ID", referencedColumnName = "ID")
  @OneToOne
  private Reports reportId;

  public ReportsReimbursement() {
  }

  public ReportsReimbursement(String id) {
    this.id = id;
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public Short getActive() {
    return active;
  }

  public void setActive(Short active) {
    this.active = active;
  }

  public Long getNumberOfDiscs() {
    return numberOfDiscs;
  }

  public void setNumberOfDiscs(Long numberOfDiscs) {
    this.numberOfDiscs = numberOfDiscs;
  }

  public Long getNumberOfPads() {
    return numberOfPads;
  }

  public void setNumberOfPads(Long numberOfPads) {
    this.numberOfPads = numberOfPads;
  }

  public Double getPricePerDisc() {
    return pricePerDisc;
  }

  public void setPricePerDisc(Double pricePerDisc) {
    this.pricePerDisc = pricePerDisc;
  }

  public Double getReimbursement() {
    return reimbursement;
  }

  public void setReimbursement(Double reimbursement) {
    this.reimbursement = reimbursement;
  }

  public Reports getReportId() {
    return reportId;
  }

  public void setReportId(Reports reportId) {
    this.reportId = reportId;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (id != null ? id.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof ReportsReimbursement)) {
      return false;
    }
    ReportsReimbursement other = (ReportsReimbursement) object;
    if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.walterproductivity.ReportsReimbursement[ id=" + id + " ]";
  }

}
