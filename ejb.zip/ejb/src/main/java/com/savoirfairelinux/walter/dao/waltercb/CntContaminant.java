/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "CNT_CONTAMINANT", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CntContaminant.findAll", query = "SELECT c FROM CntContaminant c"),
    @NamedQuery(name = "CntContaminant.findByCntId", query = "SELECT c FROM CntContaminant c WHERE c.cntContaminantPK.cntId = :cntId"),
    @NamedQuery(name = "CntContaminant.findByContaminantId", query = "SELECT c FROM CntContaminant c WHERE c.cntContaminantPK.contaminantId = :contaminantId")})
public class CntContaminant implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected CntContaminantPK cntContaminantPK;
    
    @JoinColumn(name = "CNT_ID", referencedColumnName = "CNT_ID", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Cnt cnt;

    public CntContaminant() {
    }

    public CntContaminant(CntContaminantPK cntContaminantPK) {
        this.cntContaminantPK = cntContaminantPK;
    }

    public CntContaminant(long cntId, long contaminantId) {
        this.cntContaminantPK = new CntContaminantPK(cntId, contaminantId);
    }

    public CntContaminantPK getCntContaminantPK() {
        return cntContaminantPK;
    }

    public void setCntContaminantPK(CntContaminantPK cntContaminantPK) {
        this.cntContaminantPK = cntContaminantPK;
    }
    
    public Cnt getCnt() {
        return cnt;
    }

    public void setCnt(Cnt cnt) {
        this.cnt = cnt;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cntContaminantPK != null ? cntContaminantPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CntContaminant)) {
            return false;
        }
        CntContaminant other = (CntContaminant) object;
        if ((this.cntContaminantPK == null && other.cntContaminantPK != null) || (this.cntContaminantPK != null && !this.cntContaminantPK.equals(other.cntContaminantPK))) {
            return false;
        }
        return true;
    }
    
    @PrePersist
    private void prePersist() {
    	if (cnt != null && cntContaminantPK != null) {
    		cntContaminantPK.setCntId(cnt.getCntId());
    	}
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.CntContaminant[ cntContaminantPK=" + cntContaminantPK + " ]";
    }
}