/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.idb;

import com.savoirfairelinux.walter.dao.DatabaseConstants;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "OO_BABEL_MEMBERS", catalog = "", schema = DatabaseConstants.IDB_SCHEMA)
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "OoBabelMembers.findAll", query = "SELECT o FROM OoBabelMembers o"),
  @NamedQuery(name = "OoBabelMembers.findByBabelmemberstatus", query = "SELECT o FROM OoBabelMembers o WHERE o.babelmemberstatus = :babelmemberstatus"),
  @NamedQuery(name = "OoBabelMembers.findByAdddatetime", query = "SELECT o FROM OoBabelMembers o WHERE o.adddatetime = :adddatetime"),
  @NamedQuery(name = "OoBabelMembers.findByDeletedatetime", query = "SELECT o FROM OoBabelMembers o WHERE o.deletedatetime = :deletedatetime"),
  @NamedQuery(name = "OoBabelMembers.findByUpdatedatetime", query = "SELECT o FROM OoBabelMembers o WHERE o.updatedatetime = :updatedatetime"),
  @NamedQuery(name = "OoBabelMembers.findByEventuser", query = "SELECT o FROM OoBabelMembers o WHERE o.eventuser = :eventuser"),
  @NamedQuery(name = "OoBabelMembers.findByBabelmemberguid", query = "SELECT o FROM OoBabelMembers o WHERE o.babelmemberguid = :babelmemberguid")})
public class OoBabelMembers implements Serializable {
  private static final long serialVersionUID = 1L;
  @Lob
  @Column(name = "MEMBERVALUE")
  private String membervalue;
  @Size(max = 255)
  @Column(name = "BABELMEMBERSTATUS")
  private String babelmemberstatus;
  @Column(name = "ADDDATETIME")
  @Temporal(TemporalType.TIMESTAMP)
  private Date adddatetime;
  @Column(name = "DELETEDATETIME")
  @Temporal(TemporalType.TIMESTAMP)
  private Date deletedatetime;
  @Column(name = "UPDATEDATETIME")
  @Temporal(TemporalType.TIMESTAMP)
  private Date updatedatetime;
  @Size(max = 255)
  @Column(name = "EVENTUSER")
  private String eventuser;
  @Id
  @Basic(optional = false)
  @NotNull
  @Size(min = 1, max = 255)
  @Column(name = "BABELMEMBERGUID")
  private String babelmemberguid;
  @JoinColumn(name = "FILTER4INSTANCEGUID", referencedColumnName = "INSTANCEGUID")
  @ManyToOne
  private OoInstances filter4instanceguid;
  @JoinColumn(name = "INSTANCEGUID", referencedColumnName = "INSTANCEGUID")
  @ManyToOne(optional = false)
  private OoInstances instanceguid;
  @JoinColumn(name = "LANGUAGEGUID", referencedColumnName = "INSTANCEGUID")
  @ManyToOne(optional = false)
  private OoInstances languageguid;
  @JoinColumn(name = "FILTERINSTANCEGUID", referencedColumnName = "INSTANCEGUID")
  @ManyToOne
  private OoInstances filterinstanceguid;
  @JoinColumn(name = "FILTER2INSTANCEGUID", referencedColumnName = "INSTANCEGUID")
  @ManyToOne
  private OoInstances filter2instanceguid;
  @JoinColumn(name = "FILTER3INSTANCEGUID", referencedColumnName = "INSTANCEGUID")
  @ManyToOne
  private OoInstances filter3instanceguid;
  @JoinColumn(name = "CLASSMEMBERGUID", referencedColumnName = "MEMBERGUID")
  @ManyToOne(optional = false)
  private OoClassesMembers classmemberguid;

  public OoBabelMembers() {
  }

  public OoBabelMembers(String babelmemberguid) {
    this.babelmemberguid = babelmemberguid;
  }

  public String getMembervalue() {
    return membervalue;
  }

  public void setMembervalue(String membervalue) {
    this.membervalue = membervalue;
  }

  public String getBabelmemberstatus() {
    return babelmemberstatus;
  }

  public void setBabelmemberstatus(String babelmemberstatus) {
    this.babelmemberstatus = babelmemberstatus;
  }

  public Date getAdddatetime() {
    return adddatetime;
  }

  public void setAdddatetime(Date adddatetime) {
    this.adddatetime = adddatetime;
  }

  public Date getDeletedatetime() {
    return deletedatetime;
  }

  public void setDeletedatetime(Date deletedatetime) {
    this.deletedatetime = deletedatetime;
  }

  public Date getUpdatedatetime() {
    return updatedatetime;
  }

  public void setUpdatedatetime(Date updatedatetime) {
    this.updatedatetime = updatedatetime;
  }

  public String getEventuser() {
    return eventuser;
  }

  public void setEventuser(String eventuser) {
    this.eventuser = eventuser;
  }

  public String getBabelmemberguid() {
    return babelmemberguid;
  }

  public void setBabelmemberguid(String babelmemberguid) {
    this.babelmemberguid = babelmemberguid;
  }

  public OoInstances getFilter4instanceguid() {
    return filter4instanceguid;
  }

  public void setFilter4instanceguid(OoInstances filter4instanceguid) {
    this.filter4instanceguid = filter4instanceguid;
  }

  public OoInstances getInstanceguid() {
    return instanceguid;
  }

  public void setInstanceguid(OoInstances instanceguid) {
    this.instanceguid = instanceguid;
  }

  public OoInstances getLanguageguid() {
    return languageguid;
  }

  public void setLanguageguid(OoInstances languageguid) {
    this.languageguid = languageguid;
  }

  public OoInstances getFilterinstanceguid() {
    return filterinstanceguid;
  }

  public void setFilterinstanceguid(OoInstances filterinstanceguid) {
    this.filterinstanceguid = filterinstanceguid;
  }

  public OoInstances getFilter2instanceguid() {
    return filter2instanceguid;
  }

  public void setFilter2instanceguid(OoInstances filter2instanceguid) {
    this.filter2instanceguid = filter2instanceguid;
  }

  public OoInstances getFilter3instanceguid() {
    return filter3instanceguid;
  }

  public void setFilter3instanceguid(OoInstances filter3instanceguid) {
    this.filter3instanceguid = filter3instanceguid;
  }

  public OoClassesMembers getClassmemberguid() {
    return classmemberguid;
  }

  public void setClassmemberguid(OoClassesMembers classmemberguid) {
    this.classmemberguid = classmemberguid;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (babelmemberguid != null ? babelmemberguid.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof OoBabelMembers)) {
      return false;
    }
    OoBabelMembers other = (OoBabelMembers) object;
    if ((this.babelmemberguid == null && other.babelmemberguid != null) || (this.babelmemberguid != null && !this.babelmemberguid.equals(other.babelmemberguid))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.idb.OoBabelMembers[ babelmemberguid=" + babelmemberguid + " ]";
  }

}
