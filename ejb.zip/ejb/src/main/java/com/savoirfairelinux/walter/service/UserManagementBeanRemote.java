/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.service;

import com.savoirfairelinux.walter.dao.walter.RecordType;
import com.savoirfairelinux.walter.dao.walter.UPerson;
import com.savoirfairelinux.walter.dao.waltercb.CountryRegionTxt;
import com.savoirfairelinux.walter.dao.waltercb.CountryStateTxt;
import java.util.List;
import javax.ejb.Remote;

/**
 *
 * @author jsgill
 */
@Remote
public interface UserManagementBeanRemote {

  public List<CountryStateTxt> getCountryStateTxtList(Long countryId, Long langId) throws Exception;

  public CountryStateTxt getCountryStateTxt(Long countryId, String stateCode) throws Exception;
  
  public List<String> getDepartmentList() throws Exception;

  public List<RecordType> getRecordType( Long langId) throws Exception;

  public List<CountryRegionTxt> getRegionCode(Long countryId, Long langId) throws Exception;

  public UPerson getUPerson(String userName) throws Exception;
  

}
