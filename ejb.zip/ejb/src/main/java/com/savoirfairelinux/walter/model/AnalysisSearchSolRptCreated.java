/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.model;

import com.liferay.portal.model.User;
import com.savoirfairelinux.walter.dao.waltercb.Country;
import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author jsgill
 */
  public class AnalysisSearchSolRptCreated  implements Serializable{
  Date fromDate;
  Date toDate;
  Country Country;
  String organization;
  String userName;
  String year;

  public Date getFromDate() {
    return fromDate;
  }

  public void setFromDate(Date fromDate) {
    this.fromDate = fromDate;
  }

  public Date getToDate() {
    return toDate;
  }

  public void setToDate(Date toDate) {
    this.toDate = toDate;
  }

  public Country getCountry() {
    return Country;
  }

  public void setCountry(Country Country) {
    this.Country = Country;
  }

  public String getOrganization() {
    return organization;
  }

  public void setOrganization(String organization) {
    this.organization = organization;
  }

  public String getUserName() {
    return userName;
  }

  public void setUserName(String userName) {
    this.userName = userName;
  }

  public String getYear() {
    return year;
  }

  public void setYear(String year) {
    this.year = year;
  }



}
