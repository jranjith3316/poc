/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.service.impl;

import com.savoirfairelinux.walter.dao.walter.Aerosolcalculator;
import com.savoirfairelinux.walter.model.Tradename;
import com.savoirfairelinux.walter.service.AerosolCalculatorBeanRemote;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;
import javax.annotation.security.PermitAll;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author jsgill
 */

@Stateless(name = "AerosolCalculatorBean")
@TransactionManagement(TransactionManagementType.CONTAINER)
@PermitAll
@LocalBean
public class AerosolCalculatorBean implements AerosolCalculatorBeanRemote{

  public static final Logger LOG = Logger.getLogger(SolutionReportBean.class.getCanonicalName());
  @PersistenceContext(unitName = "waltershare")
  EntityManager entityManager;
  @EJB
  SingletonBean singletonBean;
  @EJB
  WalterBean walterBean;

  @Override
  @Interceptors({DebugInterceptor.class})
  public List<Tradename> getTradenames(String languageAbbreviation, String country, String franchiseGuid, String unitName) throws Exception {
    List<Tradename> tradenameList = new ArrayList<Tradename>();

    try {

      List<Object[]> objectList = new ArrayList<Object[]>();
      objectList = entityManager.createNativeQuery(singletonBean.getAerosolCalculatorQuery("walter.tradenames"))
                                .setParameter("franchiseguid", franchiseGuid)
                                .setParameter("countryCode", country)
                                .setParameter("unitName", unitName)
                                .getResultList();

//          wp.productnumber, omv.instancemembervalue, ooFormat.instancename, trade.instancename

      for ( Object[] object : objectList ){
        String productNumber = object[0].toString();
        String size = object[1].toString().replace(",", ".");
        String format = object[2].toString();
        String tradeguid = object[3].toString();
        String tradename = object[4].toString();
        String productguid = object[5].toString();
        BigDecimal listPrice = ( object[6] != null ) ? new BigDecimal(object[6].toString()) : new BigDecimal(BigInteger.ZERO);
        String translation = getWalterTradenamesTranslation(languageAbbreviation, tradeguid);
        if ( translation != null && !translation.equals("") ){
          tradename = translation;
        }

        String description = productNumber + " " + tradename + " " + size + " " + format;

        tradenameList.add(new Tradename(productguid, description, size, format, productNumber, listPrice, tradename));
      }

    } catch (Exception e) {
      LOG.severe(e.getMessage());
    }

    Collections.sort(tradenameList, new Comparator<Tradename>() {
      @Override
      public int compare(Tradename t1, Tradename t2) {
        return t1.getDescription().compareTo(t2.getDescription());
      }
    });

    return tradenameList;
  }

  public String getWalterTradenamesTranslation(String languageAbbreviation, String tradeguid) throws Exception {
    String result = "";
    try {
        result = entityManager.createQuery(singletonBean.getAerosolCalculatorQuery("walter.tradenames.translation"), String.class)
                              .setParameter("languageAbbreviation", languageAbbreviation)
                              .setParameter("tradeguid", tradeguid)
                              .getSingleResult();

    } catch (Exception e) {
        LOG.severe(e.getMessage());
    }
    return result;
  }

  @Override
  public float getProductPrice(String countryCode, String productNumber){
    float price = 0F;

    try {
      Object result = entityManager.createNativeQuery(singletonBean.getAerosolCalculatorQuery("walter.product.listprice"))
                                   .setParameter("countryCode", countryCode)
                                   .setParameter("productnumber", productNumber)
                                   .getSingleResult();

      if ( result != null ){
        price = Float.parseFloat(result.toString());
      }

    } catch (Exception e) {
      LOG.severe(e.getMessage());
    }

    return price;
  }

  public void saveReport(Aerosolcalculator ac){
    try {
      if ( ac.getId() == null || ac.getId() == 0 ){

        long id = 0;

        Object result = entityManager.createNativeQuery(singletonBean.getAerosolCalculatorQuery("walter.aerosol.id"))
                                     .getSingleResult();

        if ( result != null ){
          id = Long.parseLong(result.toString());
        }

        ac.setId(id);

      }

      entityManager.merge(ac);

    } catch (Exception e) {
      LOG.severe(e.getMessage());
    }
  }


  public List<Aerosolcalculator> getReportByUser(String username){
    List<Aerosolcalculator> acList = new ArrayList<>();

    try {
      acList = entityManager.createQuery(singletonBean.getAerosolCalculatorQuery("Aerosolcalculator.byUser"), Aerosolcalculator.class)
                            .setParameter("username", username)
                            .getResultList();

    } catch (Exception e) {
      LOG.severe(e.getMessage());
    }


    return acList;
  }

  public void deleteReport(Aerosolcalculator ac){
    ac.setDeleteDate(new Date());
    entityManager.merge(ac);
  }

  public Aerosolcalculator getAerosolCalculatorById(Long id){
    Aerosolcalculator ac = new Aerosolcalculator();

    try {
      ac = entityManager.createQuery(singletonBean.getAerosolCalculatorQuery("Aerosolcalculator.byId"), Aerosolcalculator.class)
                            .setParameter("id", id)
                            .getSingleResult();

    } catch (Exception e) {
      LOG.severe(e.getMessage());
    }


    return ac;
  }

}
