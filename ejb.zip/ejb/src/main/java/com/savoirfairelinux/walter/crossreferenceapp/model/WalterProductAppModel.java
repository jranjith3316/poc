/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.crossreferenceapp.model;

import java.io.Serializable;
import java.util.List;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@XmlRootElement(name = "walter")
public class WalterProductAppModel implements Serializable {
  private static final long serialVersionUID = 3511338233023397895L;
  private String countryCode;
  private String langCode;
  private List<WalterProductModel> walterProducts;


  public String getCountryCode() {
    return countryCode;
  }

  public void setCountryCode(String countryCode) {
    this.countryCode = countryCode;
  }

  public String getLangCode() {
    return langCode;
  }

  public void setLangCode(String langCode) {
    this.langCode = langCode;
  }

  @XmlElementWrapper
  @XmlElement(name="walterProduct")
  public List<WalterProductModel> getWalterProducts() {
    return walterProducts;
  }

  public void setWalterProducts(List<WalterProductModel> walterProducts) {
    this.walterProducts = walterProducts;
  }

}
//	<field name="walterUpc" class="java.lang.String"/>
//	<field name="walterFormat" class="java.lang.String"/>
//	<field name="walterMetricSize" class="java.lang.String"/>
//	<field name="walterImperialSize" class="java.lang.String"/>
//	<field name="walterMetricTemperature" class="java.lang.String"/>
//	<field name="walterImperialTemperature" class="java.lang.String"/>
//	<field name="walterVoc" class="java.lang.String"/>
//	<field name="walterPH" class="java.lang.String"/>
//	<field name="walterElementFlame" class="java.lang.Boolean"/>
//	<field name="walterElementGasCylinder" class="java.lang.Boolean"/>
//	<field name="walterElementCorrosion" class="java.lang.Boolean"/>
//	<field name="walterElementExclamation" class="java.lang.Boolean"/>
//	<field name="walterElementHealth" class="java.lang.Boolean"/>
//	<field name="walterElementEnvironment" class="java.lang.Boolean"/>
//	<field name="walterElementSkull" class="java.lang.Boolean"/>
//	<field name="walterElementFlameCircle" class="java.lang.Boolean"/>
//	<field name="walterElementExplodingBomb" class="java.lang.Boolean"/>
//	<field name="walterProp65" class="java.lang.String"/>
//	<field name="walterDiluation" class="java.lang.String"/>
//	<field name="walterImageUrl" class="java.lang.String"/>
//	<field name="walterAction" class="java.lang.String"/>