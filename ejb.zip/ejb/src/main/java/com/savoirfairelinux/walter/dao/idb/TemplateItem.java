/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.idb;

import com.savoirfairelinux.walter.dao.DatabaseConstants;
import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "TEMPLATE_ITEM", catalog = "", schema = DatabaseConstants.IDB_SCHEMA)
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "TemplateItem.findAll", query = "SELECT t FROM TemplateItem t"),
  @NamedQuery(name = "TemplateItem.findByTemplateguid", query = "SELECT t FROM TemplateItem t WHERE t.templateItemPK.templateguid = :templateguid"),
  @NamedQuery(name = "TemplateItem.findByColumnId", query = "SELECT t FROM TemplateItem t WHERE t.templateItemPK.columnId = :columnId"),
  @NamedQuery(name = "TemplateItem.findByRowId", query = "SELECT t FROM TemplateItem t WHERE t.templateItemPK.rowId = :rowId"),
  @NamedQuery(name = "TemplateItem.findByItemId", query = "SELECT t FROM TemplateItem t WHERE t.templateItemPK.itemId = :itemId"),
  @NamedQuery(name = "TemplateItem.findByOrderby", query = "SELECT t FROM TemplateItem t WHERE t.orderby = :orderby"),
  @NamedQuery(name = "TemplateItem.findByMemberguid", query = "SELECT t FROM TemplateItem t WHERE t.memberguid = :memberguid"),
  @NamedQuery(name = "TemplateItem.findByUnitguid", query = "SELECT t FROM TemplateItem t WHERE t.unitguid = :unitguid"),
  @NamedQuery(name = "TemplateItem.findByUnitsymbol", query = "SELECT t FROM TemplateItem t WHERE t.unitsymbol = :unitsymbol"),
  @NamedQuery(name = "TemplateItem.findByLink", query = "SELECT t FROM TemplateItem t WHERE t.link = :link"),
  @NamedQuery(name = "TemplateItem.findByMemberguidnull", query = "SELECT t FROM TemplateItem t WHERE t.memberguidnull = :memberguidnull"),
  @NamedQuery(name = "TemplateItem.findByUnitnullguid", query = "SELECT t FROM TemplateItem t WHERE t.unitnullguid = :unitnullguid"),
  @NamedQuery(name = "TemplateItem.findByUnitsymbolnull", query = "SELECT t FROM TemplateItem t WHERE t.unitsymbolnull = :unitsymbolnull"),
  @NamedQuery(name = "TemplateItem.findByLinknull", query = "SELECT t FROM TemplateItem t WHERE t.linknull = :linknull"),
  @NamedQuery(name = "TemplateItem.findByUnitvalue", query = "SELECT t FROM TemplateItem t WHERE t.unitvalue = :unitvalue"),
  @NamedQuery(name = "TemplateItem.findByUnitvaluenull", query = "SELECT t FROM TemplateItem t WHERE t.unitvaluenull = :unitvaluenull"),
  @NamedQuery(name = "TemplateItem.findByUsecolor", query = "SELECT t FROM TemplateItem t WHERE t.usecolor = :usecolor"),
  @NamedQuery(name = "TemplateItem.findByAlign", query = "SELECT t FROM TemplateItem t WHERE t.align = :align"),
  @NamedQuery(name = "TemplateItem.findByAlignnull", query = "SELECT t FROM TemplateItem t WHERE t.alignnull = :alignnull")})
public class TemplateItem implements Serializable {
  private static final long serialVersionUID = 1L;
  @EmbeddedId
  protected TemplateItemPK templateItemPK;
  @Column(name = "ORDERBY")
  private Short orderby;
  @Size(max = 255)
  @Column(name = "MEMBERGUID")
  private String memberguid;
  @Size(max = 50)
  @Column(name = "UNITGUID")
  private String unitguid;
  @Size(max = 10)
  @Column(name = "UNITSYMBOL")
  private String unitsymbol;
  @Size(max = 1)
  @Column(name = "LINK")
  private String link;
  @Size(max = 255)
  @Column(name = "MEMBERGUIDNULL")
  private String memberguidnull;
  @Size(max = 50)
  @Column(name = "UNITNULLGUID")
  private String unitnullguid;
  @Size(max = 10)
  @Column(name = "UNITSYMBOLNULL")
  private String unitsymbolnull;
  @Size(max = 1)
  @Column(name = "LINKNULL")
  private String linknull;
  @Size(max = 5)
  @Column(name = "UNITVALUE")
  private String unitvalue;
  @Size(max = 5)
  @Column(name = "UNITVALUENULL")
  private String unitvaluenull;
  @Size(max = 5)
  @Column(name = "USECOLOR")
  private String usecolor;
  @Size(max = 6)
  @Column(name = "ALIGN")
  private String align;
  @Size(max = 6)
  @Column(name = "ALIGNNULL")
  private String alignnull;
  @JoinColumn(name = "TEMPLATEGUID", referencedColumnName = "TEMPLATEGUID", insertable = false, updatable = false)
  @ManyToOne(optional = false)
  private Template template;

  public TemplateItem() {
  }

  public TemplateItem(TemplateItemPK templateItemPK) {
    this.templateItemPK = templateItemPK;
  }

  public TemplateItem(String templateguid, short columnId, short rowId, short itemId) {
    this.templateItemPK = new TemplateItemPK(templateguid, columnId, rowId, itemId);
  }

  public TemplateItemPK getTemplateItemPK() {
    return templateItemPK;
  }

  public void setTemplateItemPK(TemplateItemPK templateItemPK) {
    this.templateItemPK = templateItemPK;
  }

  public Short getOrderby() {
    return orderby;
  }

  public void setOrderby(Short orderby) {
    this.orderby = orderby;
  }

  public String getMemberguid() {
    return memberguid;
  }

  public void setMemberguid(String memberguid) {
    this.memberguid = memberguid;
  }

  public String getUnitguid() {
    return unitguid;
  }

  public void setUnitguid(String unitguid) {
    this.unitguid = unitguid;
  }

  public String getUnitsymbol() {
    return unitsymbol;
  }

  public void setUnitsymbol(String unitsymbol) {
    this.unitsymbol = unitsymbol;
  }

  public String getLink() {
    return link;
  }

  public void setLink(String link) {
    this.link = link;
  }

  public String getMemberguidnull() {
    return memberguidnull;
  }

  public void setMemberguidnull(String memberguidnull) {
    this.memberguidnull = memberguidnull;
  }

  public String getUnitnullguid() {
    return unitnullguid;
  }

  public void setUnitnullguid(String unitnullguid) {
    this.unitnullguid = unitnullguid;
  }

  public String getUnitsymbolnull() {
    return unitsymbolnull;
  }

  public void setUnitsymbolnull(String unitsymbolnull) {
    this.unitsymbolnull = unitsymbolnull;
  }

  public String getLinknull() {
    return linknull;
  }

  public void setLinknull(String linknull) {
    this.linknull = linknull;
  }

  public String getUnitvalue() {
    return unitvalue;
  }

  public void setUnitvalue(String unitvalue) {
    this.unitvalue = unitvalue;
  }

  public String getUnitvaluenull() {
    return unitvaluenull;
  }

  public void setUnitvaluenull(String unitvaluenull) {
    this.unitvaluenull = unitvaluenull;
  }

  public String getUsecolor() {
    return usecolor;
  }

  public void setUsecolor(String usecolor) {
    this.usecolor = usecolor;
  }

  public String getAlign() {
    return align;
  }

  public void setAlign(String align) {
    this.align = align;
  }

  public String getAlignnull() {
    return alignnull;
  }

  public void setAlignnull(String alignnull) {
    this.alignnull = alignnull;
  }

  public Template getTemplate() {
    return template;
  }

  public void setTemplate(Template template) {
    this.template = template;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (templateItemPK != null ? templateItemPK.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof TemplateItem)) {
      return false;
    }
    TemplateItem other = (TemplateItem) object;
    if ((this.templateItemPK == null && other.templateItemPK != null) || (this.templateItemPK != null && !this.templateItemPK.equals(other.templateItemPK))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.idb.TemplateItem[ templateItemPK=" + templateItemPK + " ]";
  }

}
