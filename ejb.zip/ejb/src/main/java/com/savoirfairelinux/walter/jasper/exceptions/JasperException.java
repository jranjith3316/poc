/* 
 * Copyright 2013 Savoir-faire Linux
 * 
 * This file is part of Walter-Portal.
 * 
 * Walter-Portal is free software: you can redistribute it and/or modify it under the terms of the 
 * GNU General Public License as published by the Free Software Foundation, either version 3 
 * of the License, or (at your option) any later version.
 * 
 * Walter-Portal is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with Walter-Portal. 
 * If not, see http://www.gnu.org/licenses/.
 */
package com.savoirfairelinux.walter.jasper.exceptions;

/**
 * 
 * @author Julien Bonjean
 *
 */
@SuppressWarnings("serial")
public class JasperException extends Exception {
    private static final String MESSAGE = "Exception during PDF generation";

    public JasperException() {
        super(MESSAGE);
    }

    public JasperException(String message) {
        super(message);
    }

    public JasperException(Throwable throwable) {
        super(throwable);
    }
}
