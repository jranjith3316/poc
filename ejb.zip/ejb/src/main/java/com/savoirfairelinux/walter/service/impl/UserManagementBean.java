/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.service.impl;

import com.savoirfairelinux.walter.dao.walter.RecordType;
import com.savoirfairelinux.walter.dao.walter.UPerson;
import com.savoirfairelinux.walter.dao.waltercb.CountryRegionTxt;
import com.savoirfairelinux.walter.dao.waltercb.CountryStateTxt;
import com.savoirfairelinux.walter.service.UserManagementBeanRemote;

import javax.annotation.security.PermitAll;
import javax.ejb.*;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

/**
 *
 * @author jsgill
 */

@Stateless(name = "UserManagementBean")
@TransactionManagement(TransactionManagementType.CONTAINER)
@PermitAll
@LocalBean
public class UserManagementBean implements UserManagementBeanRemote{
  public static final Logger LOG = Logger.getLogger(UserManagementBean.class.getCanonicalName());

  @PersistenceContext(unitName = "waltershare")
  EntityManager entityManager;
  @EJB
  SingletonBean singletonBean;  
  
  @Override
  public List<CountryStateTxt> getCountryStateTxtList(Long countryId, Long langId) throws Exception{
    List<CountryStateTxt> countryStateTxt = null;
    try {

      countryStateTxt = entityManager
                .createQuery(singletonBean.getUserManagementQuery("stateList"), CountryStateTxt.class)
                .setParameter("countryId", countryId)
                .setParameter("langId", langId)
                .getResultList();

    } catch (Exception e) {
        LOG.severe(e.getMessage());
        throw new Exception(e.getMessage());
    }
    return countryStateTxt;
  }

  public CountryStateTxt getCountryStateTxt(Long countryId, String stateCode) throws Exception{
    CountryStateTxt countryStateTxt = new CountryStateTxt();
  
      try {

      countryStateTxt = entityManager
                .createQuery(singletonBean.getUserManagementQuery("CountryStateTxt"), CountryStateTxt.class)
                .setParameter("countryId", countryId)
                .setParameter("stateCode", stateCode)
                .getSingleResult();

    } catch (Exception e) {
        LOG.severe(e.getMessage());
        throw new Exception(e.getMessage());
    }
    
    return countryStateTxt;
  }
  
  
  @Override
  public List<String> getDepartmentList() throws Exception{
    List<String> result = new ArrayList<String>();
    
    result =  entityManager
                .createQuery(singletonBean.getUserManagementQuery("departmentList"), String.class)
                .getResultList();
    return result;
  }

  @Override
  public List<RecordType> getRecordType( Long langId) throws Exception{
    List<RecordType> recordTypeList = null;
    try {

      recordTypeList = entityManager
                .createQuery(singletonBean.getUserManagementQuery("recordTypeList"), RecordType.class)
                .setParameter("langId", langId)
                .getResultList();

    } catch (Exception e) {
        LOG.severe(e.getMessage());
        throw new Exception(e.getMessage());
    }
    return recordTypeList;
  }

  @Override
  public List<CountryRegionTxt> getRegionCode(Long countryId, Long langId) throws Exception{
    List<CountryRegionTxt> countryRegionList = null;
    try {

      countryRegionList = entityManager
                .createQuery(singletonBean.getUserManagementQuery("countryRegionList"), CountryRegionTxt.class)
                .setParameter("langId", langId)
                .setParameter("countryId", countryId)
                .getResultList();

    } catch (Exception e) {
        LOG.severe(e.getMessage());
        throw new Exception(e.getMessage());
    }
    return countryRegionList;
  }

    @Override
    public UPerson getUPerson(String userName) throws Exception{
        UPerson result;
        try{
            result = entityManager.createQuery(singletonBean.getUserManagementQuery("uPerson"), UPerson.class)
                    .setParameter("userName", userName)
                    .getSingleResult();
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    } 
}