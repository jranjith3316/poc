/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.walter;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "RECORD_TYPE", catalog = "", schema = DatabaseConstants.WALTER_SCHEMA)
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "RecordType.findAll", query = "SELECT r FROM RecordType r"),
  @NamedQuery(name = "RecordType.findByRecordType", query = "SELECT r FROM RecordType r WHERE r.recordTypePK.recordType = :recordType"),
  @NamedQuery(name = "RecordType.findByLangId", query = "SELECT r FROM RecordType r WHERE r.recordTypePK.langId = :langId"),
  @NamedQuery(name = "RecordType.findByRecordDesc", query = "SELECT r FROM RecordType r WHERE r.recordDesc = :recordDesc")})
public class RecordType implements Serializable {
  private static final long serialVersionUID = 1L;
  @EmbeddedId
  protected RecordTypePK recordTypePK;
  @Size(max = 40)
  @Column(name = "RECORD_DESC")
  private String recordDesc;

  public RecordType() {
  }

  public RecordType(RecordTypePK recordTypePK) {
    this.recordTypePK = recordTypePK;
  }

  public RecordType(String recordType, long langId) {
    this.recordTypePK = new RecordTypePK(recordType, langId);
  }

  public RecordTypePK getRecordTypePK() {
    return recordTypePK;
  }

  public void setRecordTypePK(RecordTypePK recordTypePK) {
    this.recordTypePK = recordTypePK;
  }

  public String getRecordDesc() {
    return recordDesc;
  }

  public void setRecordDesc(String recordDesc) {
    this.recordDesc = recordDesc;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (recordTypePK != null ? recordTypePK.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof RecordType)) {
      return false;
    }
    RecordType other = (RecordType) object;
    if ((this.recordTypePK == null && other.recordTypePK != null) || (this.recordTypePK != null && !this.recordTypePK.equals(other.recordTypePK))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.walter.RecordType[ recordTypePK=" + recordTypePK + " ]";
  }
  
}
