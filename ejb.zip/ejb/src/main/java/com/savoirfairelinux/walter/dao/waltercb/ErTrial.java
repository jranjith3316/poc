/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import java.util.Set;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "ER_TRIAL", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "ErTrial.findAll", query = "SELECT e FROM ErTrial e"),
    @NamedQuery(name = "ErTrial.findByErId", query = "SELECT e FROM ErTrial e WHERE e.er.erId = :erId"),
    @NamedQuery(name = "ErTrial.findByTrialSeq", query = "SELECT e FROM ErTrial e WHERE e.trialSeq = :trialSeq"),
    @NamedQuery(name = "ErTrial.findByBrandId", query = "SELECT e FROM ErTrial e WHERE e.brandId = :brandId")})
public class ErTrial implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @NotNull
    @Column(name = "TRIAL_ID", nullable = false)
    @GeneratedValue(generator = "TRIAL_ID_SEQ", strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "TRIAL_ID_SEQ", sequenceName = "TRIAL_ID_SEQ", schema = DatabaseConstants.WALTERCB_SCHEMA, allocationSize = 1)
    private Long trialId;
    @NotNull
    @Basic(optional = false)
    @Column(name = "TRIAL_SEQ", nullable = false)
    private long trialSeq;
    @Column(name = "BRAND_ID")
    private Integer brandId;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "erTrial", orphanRemoval = true, fetch = FetchType.EAGER)
    private Set<ErTrialProduct> cleaners;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "erTrial", orphanRemoval = true, fetch = FetchType.EAGER)
    private Set<ErTrialTxt> erTrialTxtSet;
    @JoinColumn(name = "ER_ID", referencedColumnName = "ER_ID", nullable = false)
    @ManyToOne(optional = false)
    private Er er;

    public ErTrial() {
    }

    public ErTrial(Long trialId) {
        this.trialId = trialId;
    }

    public Integer getBrandId() {
        return brandId;
    }

    public void setBrandId(Integer brandId) {
        this.brandId = brandId;
    }

    public Long getTrialId() {
        return trialId;
    }

    public void setTrialId(Long trialId) {
        this.trialId = trialId;
    }

    public long getTrialSeq() {
        return trialSeq;
    }

    public void setTrialSeq(long trialSeq) {
        this.trialSeq = trialSeq;
    }

    public Set<ErTrialProduct> getCleaners() {
        return cleaners;
    }

    public void setCleaners(Set<ErTrialProduct> cleaners) {
        this.cleaners = cleaners;
    }

    @XmlTransient
    public Set<ErTrialTxt> getErTrialTxtSet() {
        return erTrialTxtSet;
    }

    public void setErTrialTxtSet(Set<ErTrialTxt> erTrialTxtSet) {
        this.erTrialTxtSet = erTrialTxtSet;
    }

    public Er getEr() {
        return er;
    }

    public void setEr(Er er) {
        this.er = er;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (trialId != null ? trialId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ErTrial)) {
            return false;
        }
        ErTrial other = (ErTrial) object;
        if ((this.trialId == null && other.trialId != null) || (this.trialId != null && !this.trialId.equals(other.trialId))) {
            return false;
        }
        if (this.trialId == null && other.trialId == null) {
            return this == other;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.ErTrial[ trialId=" + trialId + " ]";
    }
    
}
