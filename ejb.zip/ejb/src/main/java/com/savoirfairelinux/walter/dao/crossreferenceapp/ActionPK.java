/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.crossreferenceapp;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

/**
 *
 * @author jsgill
 */
@Embeddable
public class ActionPK implements Serializable {
  @Basic(optional = false)
  @NotNull
  @Column(name = "ACTION_ID")
  private long actionId;
  @Basic(optional = false)
  @NotNull
  @Column(name = "LANG_ID")
  private long langId;

  public ActionPK() {
  }

  public ActionPK(long actionId, long langId) {
    this.actionId = actionId;
    this.langId = langId;
  }

  public long getActionId() {
    return actionId;
  }

  public void setActionId(long actionId) {
    this.actionId = actionId;
  }

  public long getLangId() {
    return langId;
  }

  public void setLangId(long langId) {
    this.langId = langId;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (int) actionId;
    hash += (int) langId;
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof ActionPK)) {
      return false;
    }
    ActionPK other = (ActionPK) object;
    if (this.actionId != other.actionId) {
      return false;
    }
    if (this.langId != other.langId) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.crossreferenceapp.ActionPK[ actionId=" + actionId + ", langId=" + langId + " ]";
  }

}
