/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "PROMO_ORDER", catalog = "", schema = "WALTERcb")
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "PromoOrder.findAll", query = "SELECT p FROM PromoOrder p"),
  @NamedQuery(name = "PromoOrder.findByOrderId", query = "SELECT p FROM PromoOrder p WHERE p.orderId = :orderId"),
  @NamedQuery(name = "PromoOrder.findByCreatorUserName", query = "SELECT p FROM PromoOrder p WHERE p.creatorUserName = :creatorUserName"),
  @NamedQuery(name = "PromoOrder.findByCreationDate", query = "SELECT p FROM PromoOrder p WHERE p.creationDate = :creationDate"),
  @NamedQuery(name = "PromoOrder.findBySubmitDate", query = "SELECT p FROM PromoOrder p WHERE p.submitDate = :submitDate"),
  @NamedQuery(name = "PromoOrder.findByDeletedDate", query = "SELECT p FROM PromoOrder p WHERE p.deletedDate = :deletedDate")})
public class PromoOrder implements Serializable {
  private static final long serialVersionUID = 1L;
  @Id
  @Basic(optional = false)
  @NotNull
  @Column(name = "ORDER_ID")
  private Long orderId;
  @Size(max = 255)
  @Column(name = "CREATOR_USER_NAME")
  private String creatorUserName;
  @Column(name = "CREATION_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date creationDate;
  @Column(name = "SUBMIT_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date submitDate;
  @Column(name = "DELETED_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date deletedDate;
  @OneToMany(cascade = CascadeType.ALL, mappedBy = "promoOrder")
  private Set<PromoOrderItem> promoOrderItemSet;

  public PromoOrder() {
  }

  public PromoOrder(Long orderId) {
    this.orderId = orderId;
  }

  public Long getOrderId() {
    return orderId;
  }

  public void setOrderId(Long orderId) {
    this.orderId = orderId;
  }

  public String getCreatorUserName() {
    return creatorUserName;
  }

  public void setCreatorUserName(String creatorUserName) {
    this.creatorUserName = creatorUserName;
  }

  public Date getCreationDate() {
    return creationDate;
  }

  public void setCreationDate(Date creationDate) {
    this.creationDate = creationDate;
  }

  public Date getSubmitDate() {
    return submitDate;
  }

  public void setSubmitDate(Date submitDate) {
    this.submitDate = submitDate;
  }

  public Date getDeletedDate() {
    return deletedDate;
  }

  public void setDeletedDate(Date deletedDate) {
    this.deletedDate = deletedDate;
  }

  @XmlTransient
  public Set<PromoOrderItem> getPromoOrderItemSet() {
    return promoOrderItemSet;
  }

  public void setPromoOrderItemSet(Set<PromoOrderItem> promoOrderItemSet) {
    this.promoOrderItemSet = promoOrderItemSet;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (orderId != null ? orderId.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof PromoOrder)) {
      return false;
    }
    PromoOrder other = (PromoOrder) object;
    if ((this.orderId == null && other.orderId != null) || (this.orderId != null && !this.orderId.equals(other.orderId))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.waltercb.PromoOrder[ orderId=" + orderId + " ]";
  }

}
