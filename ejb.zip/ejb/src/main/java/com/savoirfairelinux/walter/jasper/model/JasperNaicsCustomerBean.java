/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.jasper.model;

import java.io.Serializable;

/**
 *
 * @author jsgill
 */
public class JasperNaicsCustomerBean implements Serializable{
  private String companyName;
  private Integer empCount;
  private String address;
  private String city;
  private String postalCode;
  private String telephone;

  public String getCompanyName() {
    return companyName;
  }

  public void setCompanyName(String companyName) {
    this.companyName = companyName;
  }

  public Integer getEmpCount() {
    return empCount;
  }

  public void setEmpCount(Integer empCount) {
    this.empCount = empCount;
  }

  public String getAddress() {
    return address;
  }

  public void setAddress(String address) {
    this.address = address;
  }

  public String getCity() {
    return city;
  }

  public void setCity(String city) {
    this.city = city;
  }

  public String getPostalCode() {
    return postalCode;
  }

  public void setPostalCode(String postalCode) {
    this.postalCode = postalCode;
  }

  public String getTelephone() {
    return telephone;
  }

  public void setTelephone(String telephone) {
    this.telephone = telephone;
  }

}
