/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.idb;

import com.savoirfairelinux.walter.dao.DatabaseConstants;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "OO_CLASSES_MEMBERS", catalog = "", schema = DatabaseConstants.IDB_SCHEMA)
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "OoClassesMembers.findAll", query = "SELECT o FROM OoClassesMembers o"),
  @NamedQuery(name = "OoClassesMembers.findByMemberguid", query = "SELECT o FROM OoClassesMembers o WHERE o.memberguid = :memberguid"),
  @NamedQuery(name = "OoClassesMembers.findByMembername", query = "SELECT o FROM OoClassesMembers o WHERE o.membername = :membername"),
  @NamedQuery(name = "OoClassesMembers.findByMembertype", query = "SELECT o FROM OoClassesMembers o WHERE o.membertype = :membertype"),
  @NamedQuery(name = "OoClassesMembers.findByMembercolumn", query = "SELECT o FROM OoClassesMembers o WHERE o.membercolumn = :membercolumn"),
  @NamedQuery(name = "OoClassesMembers.findByMemberstatus", query = "SELECT o FROM OoClassesMembers o WHERE o.memberstatus = :memberstatus"),
  @NamedQuery(name = "OoClassesMembers.findByAdddatetime", query = "SELECT o FROM OoClassesMembers o WHERE o.adddatetime = :adddatetime"),
  @NamedQuery(name = "OoClassesMembers.findByDeletedatetime", query = "SELECT o FROM OoClassesMembers o WHERE o.deletedatetime = :deletedatetime"),
  @NamedQuery(name = "OoClassesMembers.findByUpdatedatetime", query = "SELECT o FROM OoClassesMembers o WHERE o.updatedatetime = :updatedatetime"),
  @NamedQuery(name = "OoClassesMembers.findByEventuser", query = "SELECT o FROM OoClassesMembers o WHERE o.eventuser = :eventuser"),
  @NamedQuery(name = "OoClassesMembers.findByMembertablename", query = "SELECT o FROM OoClassesMembers o WHERE o.membertablename = :membertablename"),
  @NamedQuery(name = "OoClassesMembers.findByLength", query = "SELECT o FROM OoClassesMembers o WHERE o.length = :length"),
  @NamedQuery(name = "OoClassesMembers.findByUpdatedatetimestatus", query = "SELECT o FROM OoClassesMembers o WHERE o.updatedatetimestatus = :updatedatetimestatus"),
  @NamedQuery(name = "OoClassesMembers.findByMembercolumntype", query = "SELECT o FROM OoClassesMembers o WHERE o.membercolumntype = :membercolumntype"),
  @NamedQuery(name = "OoClassesMembers.findByMembertranslatable", query = "SELECT o FROM OoClassesMembers o WHERE o.membertranslatable = :membertranslatable"),
  @NamedQuery(name = "OoClassesMembers.findByFieldtype", query = "SELECT o FROM OoClassesMembers o WHERE o.fieldtype = :fieldtype"),
  @NamedQuery(name = "OoClassesMembers.findByEntityname", query = "SELECT o FROM OoClassesMembers o WHERE o.entityname = :entityname")})
public class OoClassesMembers implements Serializable {
  private static final long serialVersionUID = 1L;
  @Id
  @Basic(optional = false)
  @NotNull
  @Size(min = 1, max = 255)
  @Column(name = "MEMBERGUID")
  private String memberguid;
  @Size(max = 255)
  @Column(name = "MEMBERNAME")
  private String membername;
  @Column(name = "MEMBERTYPE")
  private Long membertype;
  @Lob
  @Column(name = "MEMBERDEFINITION")
  private String memberdefinition;
  @Size(max = 255)
  @Column(name = "MEMBERCOLUMN")
  private String membercolumn;
  @Size(max = 255)
  @Column(name = "MEMBERSTATUS")
  private String memberstatus;
  @Column(name = "ADDDATETIME")
  @Temporal(TemporalType.TIMESTAMP)
  private Date adddatetime;
  @Column(name = "DELETEDATETIME")
  @Temporal(TemporalType.TIMESTAMP)
  private Date deletedatetime;
  @Column(name = "UPDATEDATETIME")
  @Temporal(TemporalType.TIMESTAMP)
  private Date updatedatetime;
  @Size(max = 255)
  @Column(name = "EVENTUSER")
  private String eventuser;
  @Size(max = 255)
  @Column(name = "MEMBERTABLENAME")
  private String membertablename;
  @Column(name = "LENGTH_")
  private Long length;
  @Lob
  @Column(name = "COMMENT_")
  private String comment;
  @Column(name = "UPDATEDATETIMESTATUS")
  @Temporal(TemporalType.TIMESTAMP)
  private Date updatedatetimestatus;
  @Size(max = 255)
  @Column(name = "MEMBERCOLUMNTYPE")
  private String membercolumntype;
  @Column(name = "MEMBERTRANSLATABLE")
  private Character membertranslatable;
  @Size(max = 255)
  @Column(name = "FIELDTYPE")
  private String fieldtype;
  @Size(max = 255)
  @Column(name = "ENTITYNAME")
  private String entityname;
  @JoinColumn(name = "CLASSGUID", referencedColumnName = "CLASSGUID")
  @ManyToOne(optional = false)
  private OoClasses classguid;
  @JoinColumn(name = "FILTERCLASSGUID", referencedColumnName = "CLASSGUID")
  @ManyToOne
  private OoClasses filterclassguid;
//  @OneToMany(cascade = CascadeType.ALL, mappedBy = "classmemberguid")
//  private Set<OoBabelMembers> ooBabelMembersSet;
//  @OneToMany(cascade = CascadeType.ALL, mappedBy = "intancememberguid")
//  private Set<OoInstancesMembersValues> ooInstancesMembersValuesSet;

  public OoClassesMembers() {
  }

  public OoClassesMembers(String memberguid) {
    this.memberguid = memberguid;
  }

  public String getMemberguid() {
    return memberguid;
  }

  public void setMemberguid(String memberguid) {
    this.memberguid = memberguid;
  }

  public String getMembername() {
    return membername;
  }

  public void setMembername(String membername) {
    this.membername = membername;
  }

  public Long getMembertype() {
    return membertype;
  }

  public void setMembertype(Long membertype) {
    this.membertype = membertype;
  }

  public String getMemberdefinition() {
    return memberdefinition;
  }

  public void setMemberdefinition(String memberdefinition) {
    this.memberdefinition = memberdefinition;
  }

  public String getMembercolumn() {
    return membercolumn;
  }

  public void setMembercolumn(String membercolumn) {
    this.membercolumn = membercolumn;
  }

  public String getMemberstatus() {
    return memberstatus;
  }

  public void setMemberstatus(String memberstatus) {
    this.memberstatus = memberstatus;
  }

  public Date getAdddatetime() {
    return adddatetime;
  }

  public void setAdddatetime(Date adddatetime) {
    this.adddatetime = adddatetime;
  }

  public Date getDeletedatetime() {
    return deletedatetime;
  }

  public void setDeletedatetime(Date deletedatetime) {
    this.deletedatetime = deletedatetime;
  }

  public Date getUpdatedatetime() {
    return updatedatetime;
  }

  public void setUpdatedatetime(Date updatedatetime) {
    this.updatedatetime = updatedatetime;
  }

  public String getEventuser() {
    return eventuser;
  }

  public void setEventuser(String eventuser) {
    this.eventuser = eventuser;
  }

  public String getMembertablename() {
    return membertablename;
  }

  public void setMembertablename(String membertablename) {
    this.membertablename = membertablename;
  }

  public Long getLength() {
    return length;
  }

  public void setLength(Long length) {
    this.length = length;
  }

  public String getComment() {
    return comment;
  }

  public void setComment(String comment) {
    this.comment = comment;
  }

  public Date getUpdatedatetimestatus() {
    return updatedatetimestatus;
  }

  public void setUpdatedatetimestatus(Date updatedatetimestatus) {
    this.updatedatetimestatus = updatedatetimestatus;
  }

  public String getMembercolumntype() {
    return membercolumntype;
  }

  public void setMembercolumntype(String membercolumntype) {
    this.membercolumntype = membercolumntype;
  }

  public Character getMembertranslatable() {
    return membertranslatable;
  }

  public void setMembertranslatable(Character membertranslatable) {
    this.membertranslatable = membertranslatable;
  }

  public String getFieldtype() {
    return fieldtype;
  }

  public void setFieldtype(String fieldtype) {
    this.fieldtype = fieldtype;
  }

  public String getEntityname() {
    return entityname;
  }

  public void setEntityname(String entityname) {
    this.entityname = entityname;
  }

  public OoClasses getClassguid() {
    return classguid;
  }

  public void setClassguid(OoClasses classguid) {
    this.classguid = classguid;
  }

  public OoClasses getFilterclassguid() {
    return filterclassguid;
  }

  public void setFilterclassguid(OoClasses filterclassguid) {
    this.filterclassguid = filterclassguid;
  }

//  @XmlTransient
//  public Set<OoBabelMembers> getOoBabelMembersSet() {
//    return ooBabelMembersSet;
//  }
//
//  public void setOoBabelMembersSet(Set<OoBabelMembers> ooBabelMembersSet) {
//    this.ooBabelMembersSet = ooBabelMembersSet;
//  }
//
//  @XmlTransient
//  public Set<OoInstancesMembersValues> getOoInstancesMembersValuesSet() {
//    return ooInstancesMembersValuesSet;
//  }
//
//  public void setOoInstancesMembersValuesSet(Set<OoInstancesMembersValues> ooInstancesMembersValuesSet) {
//    this.ooInstancesMembersValuesSet = ooInstancesMembersValuesSet;
//  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (memberguid != null ? memberguid.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof OoClassesMembers)) {
      return false;
    }
    OoClassesMembers other = (OoClassesMembers) object;
    if ((this.memberguid == null && other.memberguid != null) || (this.memberguid != null && !this.memberguid.equals(other.memberguid))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.idb.OoClassesMembers[ memberguid=" + memberguid + " ]";
  }

}
