/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

/**
 *
 * @author mgubaidullin
 */
@Embeddable
public class CbTradenameTxtPK implements Serializable {
    @Basic(optional = false)
    @NotNull
    @Column(name = "TRADENAME_ID")
    private long tradenameId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "FRANCHISE_ID")
    private short franchiseId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "LANG_ID")
    private long langId;

    public CbTradenameTxtPK() {
    }

    public CbTradenameTxtPK(long tradenameId, short franchiseId, long langId) {
        this.tradenameId = tradenameId;
        this.franchiseId = franchiseId;
        this.langId = langId;
    }

    public long getTradenameId() {
        return tradenameId;
    }

    public void setTradenameId(long tradenameId) {
        this.tradenameId = tradenameId;
    }

    public short getFranchiseId() {
        return franchiseId;
    }

    public void setFranchiseId(short franchiseId) {
        this.franchiseId = franchiseId;
    }

    public long getLangId() {
        return langId;
    }

    public void setLangId(long langId) {
        this.langId = langId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) tradenameId;
        hash += (int) franchiseId;
        hash += (int) langId;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CbTradenameTxtPK)) {
            return false;
        }
        CbTradenameTxtPK other = (CbTradenameTxtPK) object;
        if (this.tradenameId != other.tradenameId) {
            return false;
        }
        if (this.franchiseId != other.franchiseId) {
            return false;
        }
        if (this.langId != other.langId) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.CbTradenameTxtPK[ tradenameId=" + tradenameId + ", franchiseId=" + franchiseId + ", langId=" + langId + " ]";
    }
    
}
