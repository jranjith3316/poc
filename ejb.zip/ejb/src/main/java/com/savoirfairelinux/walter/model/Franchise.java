package com.savoirfairelinux.walter.model;

import java.io.Serializable;

public class Franchise implements Serializable {

	private String franchiseId;
	private String description;

	public Franchise(String franchiseId, String description) {
		this.franchiseId = franchiseId;
		this.description = description;
	}

	public String getFranchiseId() {
		return franchiseId;
	}

	public void setFranchiseId(String franchiseId) {
		this.franchiseId = franchiseId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

    @Override
    public int hashCode() {
        int hash = (franchiseId != null ? franchiseId.hashCode() : 0);
        return hash;
    }

    @Override
	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		} else if (this == obj) {
			return true;
		} else if (franchiseId.equals(((Franchise) obj).getFranchiseId())) {
			return true;
		}
		return false;
	}
}
