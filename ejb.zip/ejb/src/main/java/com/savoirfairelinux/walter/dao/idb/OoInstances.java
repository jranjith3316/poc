/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.idb;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import java.util.Date;
import java.util.Set;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "OO_INSTANCES", catalog = "", schema = DatabaseConstants.IDB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "OoInstances.findAll", query = "SELECT o FROM OoInstances o"),
    @NamedQuery(name = "OoInstances.findByInstanceguid", query = "SELECT o FROM OoInstances o WHERE o.instanceguid = :instanceguid"),
    @NamedQuery(name = "OoInstances.findByInstancealternatekey", query = "SELECT o FROM OoInstances o WHERE o.instancealternatekey = :instancealternatekey"),
    @NamedQuery(name = "OoInstances.findByInstancename", query = "SELECT o FROM OoInstances o WHERE o.instancename = :instancename"),
    @NamedQuery(name = "OoInstances.findByInstancestatus", query = "SELECT o FROM OoInstances o WHERE o.instancestatus = :instancestatus"),
    @NamedQuery(name = "OoInstances.findByAdddatetime", query = "SELECT o FROM OoInstances o WHERE o.adddatetime = :adddatetime"),
    @NamedQuery(name = "OoInstances.findByDeletedatetime", query = "SELECT o FROM OoInstances o WHERE o.deletedatetime = :deletedatetime"),
    @NamedQuery(name = "OoInstances.findByUpdatedatetime", query = "SELECT o FROM OoInstances o WHERE o.updatedatetime = :updatedatetime"),
    @NamedQuery(name = "OoInstances.findByUpdatedatetimestatus", query = "SELECT o FROM OoInstances o WHERE o.updatedatetimestatus = :updatedatetimestatus")})
public class OoInstances implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    private String instanceguid;
    @Size(max = 255)
    private String instancealternatekey;
    @Size(max = 255)
    private String instancename;
    @Size(max = 255)
    private String instancestatus;
    @Temporal(TemporalType.TIMESTAMP)
    private Date adddatetime;
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedatetime;
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedatetime;
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedatetimestatus;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "instanceguid")
    private Set<OoBabelMembers> ooBabelMembersSet;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "languageguid")
    private Set<OoBabelMembers> ooBabelMembersSet1;
    @OneToMany(mappedBy = "filterinstanceguid")
    private Set<OoBabelMembers> ooBabelMembersSet2;
    @JoinColumn(name = "CLASSGUID", referencedColumnName = "CLASSGUID")
    @ManyToOne(optional = false)
    private OoClasses classguid;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "countryguid")
    private Set<WalterProductsCountries> walterProductsCountriesSet;
    @OneToMany(mappedBy = "presentationguid")
    private Set<WalterProductsCountries> walterProductsCountriesSet1;
    @OneToOne(cascade = CascadeType.ALL, mappedBy = "ooInstances")
    private WalterProductsVersions walterProductsVersions;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "presentationguid")
    private Set<WalterProductsPresentations> walterProductsPresentationsSet;
    
    @OneToMany(mappedBy = "filterinstanceguid")
    private Set<OoInstancesRelationships> ooInstancesRelationshipsSet;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "childinstanceguid")
    private Set<OoInstancesRelationships> ooInstancesRelationshipsSet1;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "parentinstanceguid")
    private Set<OoInstancesRelationships> ooInstancesRelationshipsSet2;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "instanceguid")
    private Set<OoInstancesMembersValues> ooInstancesMembersValuesSet;
    @OneToMany(mappedBy = "instancememberuomguid")
    private Set<OoInstancesMembersValues> ooInstancesMembersValuesSet1;

    public OoInstances() {
    }

    public OoInstances(String instanceguid) {
        this.instanceguid = instanceguid;
    }

    public String getInstanceguid() {
        return instanceguid;
    }

    public void setInstanceguid(String instanceguid) {
        this.instanceguid = instanceguid;
    }

    public String getInstancealternatekey() {
        return instancealternatekey;
    }

    public void setInstancealternatekey(String instancealternatekey) {
        this.instancealternatekey = instancealternatekey;
    }

    public String getInstancename() {
        return instancename;
    }

    public void setInstancename(String instancename) {
        this.instancename = instancename;
    }

    public String getInstancestatus() {
        return instancestatus;
    }

    public void setInstancestatus(String instancestatus) {
        this.instancestatus = instancestatus;
    }

    public Date getAdddatetime() {
        return adddatetime;
    }

    public void setAdddatetime(Date adddatetime) {
        this.adddatetime = adddatetime;
    }

    public Date getDeletedatetime() {
        return deletedatetime;
    }

    public void setDeletedatetime(Date deletedatetime) {
        this.deletedatetime = deletedatetime;
    }

    public Date getUpdatedatetime() {
        return updatedatetime;
    }

    public void setUpdatedatetime(Date updatedatetime) {
        this.updatedatetime = updatedatetime;
    }

    public Date getUpdatedatetimestatus() {
        return updatedatetimestatus;
    }

    public void setUpdatedatetimestatus(Date updatedatetimestatus) {
        this.updatedatetimestatus = updatedatetimestatus;
    }

    @XmlTransient
    public Set<OoBabelMembers> getOoBabelMembersSet() {
        return ooBabelMembersSet;
    }

    public void setOoBabelMembersSet(Set<OoBabelMembers> ooBabelMembersSet) {
        this.ooBabelMembersSet = ooBabelMembersSet;
    }

    @XmlTransient
    public Set<OoBabelMembers> getOoBabelMembersSet1() {
        return ooBabelMembersSet1;
    }

    public void setOoBabelMembersSet1(Set<OoBabelMembers> ooBabelMembersSet1) {
        this.ooBabelMembersSet1 = ooBabelMembersSet1;
    }

    @XmlTransient
    public Set<OoBabelMembers> getOoBabelMembersSet2() {
        return ooBabelMembersSet2;
    }

    public void setOoBabelMembersSet2(Set<OoBabelMembers> ooBabelMembersSet2) {
        this.ooBabelMembersSet2 = ooBabelMembersSet2;
    }

    public OoClasses getClassguid() {
        return classguid;
    }

    public void setClassguid(OoClasses classguid) {
        this.classguid = classguid;
    }

    @XmlTransient
    public Set<WalterProductsCountries> getWalterProductsCountriesSet() {
        return walterProductsCountriesSet;
    }

    public void setWalterProductsCountriesSet(Set<WalterProductsCountries> walterProductsCountriesSet) {
        this.walterProductsCountriesSet = walterProductsCountriesSet;
    }

    @XmlTransient
    public Set<WalterProductsCountries> getWalterProductsCountriesSet1() {
        return walterProductsCountriesSet1;
    }

    public void setWalterProductsCountriesSet1(Set<WalterProductsCountries> walterProductsCountriesSet1) {
        this.walterProductsCountriesSet1 = walterProductsCountriesSet1;
    }

    public WalterProductsVersions getWalterProductsVersions() {
        return walterProductsVersions;
    }

    public void setWalterProductsVersions(WalterProductsVersions walterProductsVersions) {
        this.walterProductsVersions = walterProductsVersions;
    }

    @XmlTransient
    public Set<WalterProductsPresentations> getWalterProductsPresentationsSet() {
        return walterProductsPresentationsSet;
    }

    public void setWalterProductsPresentationsSet(Set<WalterProductsPresentations> walterProductsPresentationsSet) {
        this.walterProductsPresentationsSet = walterProductsPresentationsSet;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (instanceguid != null ? instanceguid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof OoInstances)) {
            return false;
        }
        OoInstances other = (OoInstances) object;
        if ((this.instanceguid == null && other.instanceguid != null) || (this.instanceguid != null && !this.instanceguid.equals(other.instanceguid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.idb.OoInstances[ instanceguid=" + instanceguid + " ]";
    }

    @XmlTransient
    public Set<OoInstancesRelationships> getOoInstancesRelationshipsSet() {
        return ooInstancesRelationshipsSet;
    }

    public void setOoInstancesRelationshipsSet(Set<OoInstancesRelationships> ooInstancesRelationshipsSet) {
        this.ooInstancesRelationshipsSet = ooInstancesRelationshipsSet;
    }

    @XmlTransient
    public Set<OoInstancesRelationships> getOoInstancesRelationshipsSet1() {
        return ooInstancesRelationshipsSet1;
    }

    public void setOoInstancesRelationshipsSet1(Set<OoInstancesRelationships> ooInstancesRelationshipsSet1) {
        this.ooInstancesRelationshipsSet1 = ooInstancesRelationshipsSet1;
    }

    @XmlTransient
    public Set<OoInstancesRelationships> getOoInstancesRelationshipsSet2() {
        return ooInstancesRelationshipsSet2;
    }

    public void setOoInstancesRelationshipsSet2(Set<OoInstancesRelationships> ooInstancesRelationshipsSet2) {
        this.ooInstancesRelationshipsSet2 = ooInstancesRelationshipsSet2;
    }

    @XmlTransient
    public Set<OoInstancesMembersValues> getOoInstancesMembersValuesSet() {
        return ooInstancesMembersValuesSet;
    }

    public void setOoInstancesMembersValuesSet(Set<OoInstancesMembersValues> ooInstancesMembersValuesSet) {
        this.ooInstancesMembersValuesSet = ooInstancesMembersValuesSet;
    }

    @XmlTransient
    public Set<OoInstancesMembersValues> getOoInstancesMembersValuesSet1() {
        return ooInstancesMembersValuesSet1;
    }

    public void setOoInstancesMembersValuesSet1(Set<OoInstancesMembersValues> ooInstancesMembersValuesSet1) {
        this.ooInstancesMembersValuesSet1 = ooInstancesMembersValuesSet1;
    }

}
