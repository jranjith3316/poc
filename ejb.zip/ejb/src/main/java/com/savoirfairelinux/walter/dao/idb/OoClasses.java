/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.idb;

import com.savoirfairelinux.walter.dao.DatabaseConstants;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "OO_CLASSES", catalog = "", schema = DatabaseConstants.IDB_SCHEMA)
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "OoClasses.findAll", query = "SELECT o FROM OoClasses o"),
  @NamedQuery(name = "OoClasses.findByClassguid", query = "SELECT o FROM OoClasses o WHERE o.classguid = :classguid"),
  @NamedQuery(name = "OoClasses.findByClassalternatekey", query = "SELECT o FROM OoClasses o WHERE o.classalternatekey = :classalternatekey"),
  @NamedQuery(name = "OoClasses.findByClassname", query = "SELECT o FROM OoClasses o WHERE o.classname = :classname"),
  @NamedQuery(name = "OoClasses.findByClasstable", query = "SELECT o FROM OoClasses o WHERE o.classtable = :classtable"),
  @NamedQuery(name = "OoClasses.findByClassstatus", query = "SELECT o FROM OoClasses o WHERE o.classstatus = :classstatus"),
  @NamedQuery(name = "OoClasses.findByAdddatetime", query = "SELECT o FROM OoClasses o WHERE o.adddatetime = :adddatetime"),
  @NamedQuery(name = "OoClasses.findByDeletedatetime", query = "SELECT o FROM OoClasses o WHERE o.deletedatetime = :deletedatetime"),
  @NamedQuery(name = "OoClasses.findByUpdatedatetime", query = "SELECT o FROM OoClasses o WHERE o.updatedatetime = :updatedatetime"),
  @NamedQuery(name = "OoClasses.findByEventuser", query = "SELECT o FROM OoClasses o WHERE o.eventuser = :eventuser"),
  @NamedQuery(name = "OoClasses.findByUpdatedatetimestatus", query = "SELECT o FROM OoClasses o WHERE o.updatedatetimestatus = :updatedatetimestatus")})
public class OoClasses implements Serializable {
  private static final long serialVersionUID = 1L;
  @Id
  @Basic(optional = false)
  @NotNull
  @Size(min = 1, max = 255)
  @Column(name = "CLASSGUID")
  private String classguid;
  @Size(max = 255)
  @Column(name = "CLASSALTERNATEKEY")
  private String classalternatekey;
  @Size(max = 255)
  @Column(name = "CLASSNAME")
  private String classname;
  @Lob
  @Column(name = "CLASSDEFINITION")
  private String classdefinition;
  @Size(max = 255)
  @Column(name = "CLASSTABLE")
  private String classtable;
  @Size(max = 255)
  @Column(name = "CLASSSTATUS")
  private String classstatus;
  @Column(name = "ADDDATETIME")
  @Temporal(TemporalType.TIMESTAMP)
  private Date adddatetime;
  @Column(name = "DELETEDATETIME")
  @Temporal(TemporalType.TIMESTAMP)
  private Date deletedatetime;
  @Column(name = "UPDATEDATETIME")
  @Temporal(TemporalType.TIMESTAMP)
  private Date updatedatetime;
  @Size(max = 255)
  @Column(name = "EVENTUSER")
  private String eventuser;
  @Lob
  @Column(name = "COMMENT_")
  private String comment;
  @Column(name = "UPDATEDATETIMESTATUS")
  @Temporal(TemporalType.TIMESTAMP)
  private Date updatedatetimestatus;
//  @OneToMany(mappedBy = "parentclassguid")
//  private Set<OoClasses> ooClassesSet;
  @JoinColumn(name = "PARENTCLASSGUID", referencedColumnName = "CLASSGUID")
  @ManyToOne
  private OoClasses parentclassguid;
//  @OneToMany(cascade = CascadeType.ALL, mappedBy = "classguid")
//  private Set<OoClassesMembers> ooClassesMembersSet;
//  @OneToMany(mappedBy = "filterclassguid")
//  private Set<OoClassesMembers> ooClassesMembersSet1;
//  @OneToMany(cascade = CascadeType.ALL, mappedBy = "classguid")
//  private Set<OoInstances> ooInstancesSet;

  public OoClasses() {
  }

  public OoClasses(String classguid) {
    this.classguid = classguid;
  }

  public String getClassguid() {
    return classguid;
  }

  public void setClassguid(String classguid) {
    this.classguid = classguid;
  }

  public String getClassalternatekey() {
    return classalternatekey;
  }

  public void setClassalternatekey(String classalternatekey) {
    this.classalternatekey = classalternatekey;
  }

  public String getClassname() {
    return classname;
  }

  public void setClassname(String classname) {
    this.classname = classname;
  }

  public String getClassdefinition() {
    return classdefinition;
  }

  public void setClassdefinition(String classdefinition) {
    this.classdefinition = classdefinition;
  }

  public String getClasstable() {
    return classtable;
  }

  public void setClasstable(String classtable) {
    this.classtable = classtable;
  }

  public String getClassstatus() {
    return classstatus;
  }

  public void setClassstatus(String classstatus) {
    this.classstatus = classstatus;
  }

  public Date getAdddatetime() {
    return adddatetime;
  }

  public void setAdddatetime(Date adddatetime) {
    this.adddatetime = adddatetime;
  }

  public Date getDeletedatetime() {
    return deletedatetime;
  }

  public void setDeletedatetime(Date deletedatetime) {
    this.deletedatetime = deletedatetime;
  }

  public Date getUpdatedatetime() {
    return updatedatetime;
  }

  public void setUpdatedatetime(Date updatedatetime) {
    this.updatedatetime = updatedatetime;
  }

  public String getEventuser() {
    return eventuser;
  }

  public void setEventuser(String eventuser) {
    this.eventuser = eventuser;
  }

  public String getComment() {
    return comment;
  }

  public void setComment(String comment) {
    this.comment = comment;
  }

  public Date getUpdatedatetimestatus() {
    return updatedatetimestatus;
  }

  public void setUpdatedatetimestatus(Date updatedatetimestatus) {
    this.updatedatetimestatus = updatedatetimestatus;
  }

//  @XmlTransient
//  public Set<OoClasses> getOoClassesSet() {
//    return ooClassesSet;
//  }
//
//  public void setOoClassesSet(Set<OoClasses> ooClassesSet) {
//    this.ooClassesSet = ooClassesSet;
//  }

  public OoClasses getParentclassguid() {
    return parentclassguid;
  }

  public void setParentclassguid(OoClasses parentclassguid) {
    this.parentclassguid = parentclassguid;
  }

//  @XmlTransient
//  public Set<OoClassesMembers> getOoClassesMembersSet() {
//    return ooClassesMembersSet;
//  }
//
//  public void setOoClassesMembersSet(Set<OoClassesMembers> ooClassesMembersSet) {
//    this.ooClassesMembersSet = ooClassesMembersSet;
//  }
//
//  @XmlTransient
//  public Set<OoClassesMembers> getOoClassesMembersSet1() {
//    return ooClassesMembersSet1;
//  }
//
//  public void setOoClassesMembersSet1(Set<OoClassesMembers> ooClassesMembersSet1) {
//    this.ooClassesMembersSet1 = ooClassesMembersSet1;
//  }
//
//  @XmlTransient
//  public Set<OoInstances> getOoInstancesSet() {
//    return ooInstancesSet;
//  }
//
//  public void setOoInstancesSet(Set<OoInstances> ooInstancesSet) {
//    this.ooInstancesSet = ooInstancesSet;
//  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (classguid != null ? classguid.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof OoClasses)) {
      return false;
    }
    OoClasses other = (OoClasses) object;
    if ((this.classguid == null && other.classguid != null) || (this.classguid != null && !this.classguid.equals(other.classguid))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.idb.OoClasses[ classguid=" + classguid + " ]";
  }

}
