/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.model;

import com.savoirfairelinux.walter.dao.walter.ExpenseTxt;
import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author jsgill
 */
public class SearchExpenseReport implements Serializable  {
  private String ScreenName;
  private long expenseId;
  private GLCode glCode;
  private String searchDateType;
  private Date fromDate, toDate;
  private String keyword;
  private Long countryId;
  private Long langId;
  private String isTraining;

  public String getScreenName() {
    return ScreenName;
  }

  public void setScreenName(String ScreenName) {
    this.ScreenName = ScreenName;
  }

  public long getExpenseId() {
    return expenseId;
  }

  public void setExpenseId(long expenseId) {
    this.expenseId = expenseId;
  }

  public GLCode getGlCode() {
    return glCode;
  }

  public void setGlCode(GLCode glCode) {
    this.glCode = glCode;
  }

  public String getSearchDateType() {
    return searchDateType;
  }

  public void setSearchDateType(String searchDateType) {
    this.searchDateType = searchDateType;
  }

  public Date getFromDate() {
    return fromDate;
  }

  public void setFromDate(Date fromDate) {
    this.fromDate = fromDate;
  }

  public Date getToDate() {
    return toDate;
  }

  public void setToDate(Date toDate) {
    this.toDate = toDate;
  }

  public String getKeyword() {
    return keyword;
  }

  public void setKeyword(String keyword) {
    this.keyword = keyword;
  }

  public Long getCountryId() {
    return countryId;
  }

  public void setCountryId(Long countryId) {
    this.countryId = countryId;
  }

  public Long getLangId() {
    return langId;
  }

  public void setLangId(Long langId) {
    this.langId = langId;
  }

  public String getIsTraining() {
    return isTraining;
  }

  public void setIsTraining(String isTraining) {
    this.isTraining = isTraining;
  }

}
