/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.tecsys.soap;

import java.util.ArrayList;
import java.util.List;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 *
 * @author jsgill
 */
public class WharehouseQTY {

  public Integer findTecsysInfo(String productNumber, String warehouse){
    Integer quantity = 0;

    try{
      SaopClient96 soapClient = new SaopClient96();
      soapClient.setUserName("wsoa");
      soapClient.setPassword("passxxxxxxx");
      soapClient.setViewName("DmsAvailQtySoaJw");

//      System.out.println("productNumber: " + productNumber);
//      System.out.println("warehouse: " + warehouse);

      List<Parameter> paramList = new ArrayList<Parameter>();
      paramList.add(new Parameter("Item", productNumber));
      paramList.add(new Parameter("Warehouse", warehouse));
      soapClient.setParamList(paramList);

      Document doc = soapClient.searchRequest();

      NodeList nodeList =  doc.getElementsByTagName("DmsAvailQtySoaJw");

      if (nodeList != null) {
        int length = nodeList.getLength();
        for (int i = 1; i < length; i++) { //need to start at 1 the first one are the search criteria
          if (nodeList.item(i).getNodeType() == Node.ELEMENT_NODE) {
            Element el = (Element) nodeList.item(i);
            if (el.getNodeName().contains("DmsAvailQtySoaJw")) {

              Element element1 = (Element)nodeList.item(i);
              NodeList nl = element1.getChildNodes();

              for ( int index = 0;index < nl.getLength(); index++  ) {

                if ( nl.item(index).getNodeName().equals("AvailableQuantityToAllocate") ){
                  Element element2 = (Element)nl.item(index);

                  String qtyString =  element2.toString();
                  qtyString = qtyString.replace("</"+element2.getNodeName()+">", "");
                  qtyString = qtyString.replace("<"+element2.getNodeName()+">", "");

                  Float tt = Float.parseFloat(qtyString);

                  quantity = quantity + tt.intValue();
                }
              }

             }
           }
         }
      }

    }catch(Exception e) {
      e.printStackTrace();
    }

    return quantity;
  }




//  public Integer findTecsysInfoCanada(String productNumber){
//    Integer quantity = 0;
//    try {
//      String endpoint = "http://wc-eliteapp.walter.int/prod_751/service/rpcrouter";
//
//      SoapClient client = new SoapClient(endpoint, "urn:MetaEngine");
//      String xmlString;
//      Document xmlDocument;
//      Element inElement;
//      Element outElement;
//
//      // SEARCH SAMPLE
//      // SEARCH CONDITION IS ON CONTAINER NUMBER (BETWEEN <cont> AND </cont>
//      //xmlString = "<wms_container_weight actionToPerform=\"search\" localeName=\"en_US\" userName=\"wsoa\" password=\"passxxxxxxx\"><Criteria><cont>P945</cont></Criteria></wms_container_weight>";
//      xmlString = "<dms_avail_qty_soa_jw actionToPerform=\"search\" localeName=\"en_US\" userName=\"wsoa\" password=\"passxxxxxxx\"><Criteria><item_num>"+productNumber+"</item_num><whse_code>MTL,TOR,EDM,VAN</whse_code></Criteria></dms_avail_qty_soa_jw>";
//      xmlDocument = createXmlDocument(xmlString);
//      inElement = xmlDocument.getDocumentElement();
//
//      outElement = client.invokeSoapMethod("service", inElement);
//      quantity = getWharehouseDTO(outElement);
//    }
//    catch (Exception ex) {
//      LOG.info("findTecsysInfoCanada: " + ex.getMessage());
//    }
//    return quantity;
//  }
//
//  public Integer findTecsysInfoUSA(String productNumber){
//    Integer quantity = 0;
//    try {
//      String endpoint = "http://eliteusapp.jwalterinc.com/prod_751/service/rpcrouter";
//
//      SoapClient client = new SoapClient(endpoint, "urn:MetaEngine");
//      String xmlString;
//      Document xmlDocument;
//      Element inElement;
//      Element outElement;
//
//      // SEARCH SAMPLE
//      // SEARCH CONDITION IS ON CONTAINER NUMBER (BETWEEN <cont> AND </cont>
//      //xmlString = "<wms_container_weight actionToPerform=\"search\" localeName=\"en_US\" userName=\"wsoa\" password=\"passxxxxxxx\"><Criteria><cont>P945</cont></Criteria></wms_container_weight>";
//      xmlString = "<dms_avail_qty_soa_jw actionToPerform=\"search\" localeName=\"en_US\" userName=\"wsoa\" password=\"passxxxxxxx\"><Criteria><item_num>"+productNumber+"</item_num><whse_code>CT</whse_code></Criteria></dms_avail_qty_soa_jw>";
//      xmlDocument = createXmlDocument(xmlString);
//      inElement = xmlDocument.getDocumentElement();
//
//      outElement = client.invokeSoapMethod("service", inElement);
//      quantity = getWharehouseDTO(outElement);
//
//    }
//    catch (Exception ex) {
//      LOG.info("findTecsysInfoUSA: " + ex.getMessage());
//    }
//    return quantity;
//  }
//
//
//  private static Document createXmlDocument(String xmlString) throws IOException, ParserConfigurationException {
//
//    Document document = null;
//
//    InputSource source = new InputSource(new StringReader(xmlString));
//    DocumentBuilderFactory docBuildfactory = DocumentBuilderFactory.newInstance();
//
//    try {
//        DocumentBuilder docBuilder = docBuildfactory.newDocumentBuilder();
//        document = docBuilder.parse(source);
//    }
//    catch (ParserConfigurationException pce) {
//        throw new IOException(pce.getMessage());
//    }
//    catch (IOException ioe) {
//        throw new IOException(ioe.getMessage());
//    }
//    catch (SAXException saxe) {
//        throw new IOException(saxe.getMessage());
//    }
//
//    return document;
//  }
//
//  private static Integer getWharehouseDTO(Element element) {
//    Integer quantity = 0;
//    NodeList list =  element.getElementsByTagName("Row");
//    for (int i=0; i<list.getLength(); i++)
//    {
//      // Get element
//      Element element1 = (Element)list.item(i);
//      NodeList nodelist = element1.getChildNodes();
//
//      for (int j = 0; j < nodelist.getLength(); j++)
//      {
//        if ( nodelist.item(j).getNodeName().equals("available_qty_to_allocate") ){
//          quantity = quantity + Integer.parseInt(nodelist.item(j).getTextContent());
//        }
//      }
//
//    }
//    return quantity;
//  }

}


