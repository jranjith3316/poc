package com.savoirfairelinux.walter.dao.waltercb;

import javax.persistence.*;
import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;

/**
 * @author jderuere
 */
@Entity
@Table(name = "U_TOOL", schema = DatabaseConstants.WALTERCB_SCHEMA)
@NamedQuery(name = "UTool.findAll", query = "SELECT u FROM UTool u ORDER BY u.name")
public class UTool implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(generator = "U_TOOL_ID_SEQ", strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "U_TOOL_ID_SEQ", sequenceName = "U_TOOL_SEQ", schema = DatabaseConstants.WALTERCB_SCHEMA, allocationSize = 1)
    @Column(name = "ID")
    private Long id;
    @Column(name = "NAME")
    private String name;
    @Column(name = "DIAMETER")
    private String diameter;
    @JoinColumn(name = "AMPERAGE")
    private Double amperage;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Double getAmperage() {
        return amperage;
    }

    public void setAmperage(Double amperage) {
        this.amperage = amperage;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDiameter() {
        return diameter;
    }

    public void setDiameter(String diameter) {
        this.diameter = diameter;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof UTool)) {
            return false;
        }
        UTool other = (UTool) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.UTool[ id=" + id + " ]";
    }
}