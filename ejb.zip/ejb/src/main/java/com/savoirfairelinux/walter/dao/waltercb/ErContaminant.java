/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import javax.persistence.*;
import javax.xml.bind.annotation.XmlRootElement;
import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "ER_CONTAMINANT", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "ErContaminant.findAll", query = "SELECT e FROM ErContaminant e"),
    @NamedQuery(name = "ErContaminant.findByErId", query = "SELECT e FROM ErContaminant e WHERE e.erContaminantPK.erId = :erId"),
    @NamedQuery(name = "ErContaminant.findByContaminantId", query = "SELECT e FROM ErContaminant e WHERE e.erContaminantPK.contaminantId = :contaminantId")})
public class ErContaminant implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected ErContaminantPK erContaminantPK;
    @JoinColumn(name = "ER_ID", referencedColumnName = "ER_ID", nullable = false, insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Er er;

    public ErContaminant() {
    }

    public ErContaminant(ErContaminantPK erContaminantPK) {
        this.erContaminantPK = erContaminantPK;
    }

    public ErContaminant(long erId, long contaminantId) {
        this.erContaminantPK = new ErContaminantPK(erId, contaminantId);
    }

    public ErContaminantPK getErContaminantPK() {
        return erContaminantPK;
    }

    public void setErContaminantPK(ErContaminantPK erContaminantPK) {
        this.erContaminantPK = erContaminantPK;
    }

    public Er getEr() {
        return er;
    }

    public void setEr(Er er) {
        this.er = er;
    }

    @PrePersist
    private void prePersist() {
        if (er != null && erContaminantPK != null) {
            erContaminantPK.setErId(er.getErId());
        }
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (erContaminantPK != null ? erContaminantPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ErContaminant)) {
            return false;
        }
        ErContaminant other = (ErContaminant) object;
        if ((this.erContaminantPK == null && other.erContaminantPK != null) || (this.erContaminantPK != null && !this.erContaminantPK.equals(other.erContaminantPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.ErContaminant[ erContaminantPK=" + erContaminantPK + " ]";
    }
    
}
