/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.walter;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "DISTRIBUTOR_LOCATOR_CONFIG", catalog = "", schema = "WALTER")
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "DistributorLocatorConfig.findAll", query = "SELECT d FROM DistributorLocatorConfig d"),
  @NamedQuery(name = "DistributorLocatorConfig.findById", query = "SELECT d FROM DistributorLocatorConfig d WHERE d.id = :id"),
  @NamedQuery(name = "DistributorLocatorConfig.findByCreationDate", query = "SELECT d FROM DistributorLocatorConfig d WHERE d.creationDate = :creationDate"),
  @NamedQuery(name = "DistributorLocatorConfig.findByCreatedBy", query = "SELECT d FROM DistributorLocatorConfig d WHERE d.createdBy = :createdBy"),
  @NamedQuery(name = "DistributorLocatorConfig.findByFileName", query = "SELECT d FROM DistributorLocatorConfig d WHERE d.fileName = :fileName"),
  @NamedQuery(name = "DistributorLocatorConfig.findByFolderName", query = "SELECT d FROM DistributorLocatorConfig d WHERE d.folderName = :folderName"),
  @NamedQuery(name = "DistributorLocatorConfig.findByGroupId", query = "SELECT d FROM DistributorLocatorConfig d WHERE d.groupId = :groupId"),
  @NamedQuery(name = "DistributorLocatorConfig.findByCountry", query = "SELECT d FROM DistributorLocatorConfig d WHERE d.country = :country"),
  @NamedQuery(name = "DistributorLocatorConfig.findByCancelDate", query = "SELECT d FROM DistributorLocatorConfig d WHERE d.cancelDate = :cancelDate"),
  @NamedQuery(name = "DistributorLocatorConfig.findByCancelBy", query = "SELECT d FROM DistributorLocatorConfig d WHERE d.cancelBy = :cancelBy"),
  @NamedQuery(name = "DistributorLocatorConfig.findByAutoUpdate", query = "SELECT d FROM DistributorLocatorConfig d WHERE d.autoUpdate = :autoUpdate")})
public class DistributorLocatorConfig implements Serializable {
  private static final long serialVersionUID = 1L;
  @Id
  @Basic(optional = false)
  @NotNull
  @Column(name = "ID")
  private Long id;
  @Column(name = "CREATION_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date creationDate;
  @Size(max = 255)
  @Column(name = "CREATED_BY")
  private String createdBy;
  @Size(max = 100)
  @Column(name = "FILE_NAME")
  private String fileName;
  @Size(max = 140)
  @Column(name = "FOLDER_NAME")
  private String folderName;
  @Column(name = "GROUP_ID")
  private Long groupId;
  @Size(max = 100)
  @Column(name = "COUNTRY")
  private String country;
  @Column(name = "CANCEL_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date cancelDate;
  @Size(max = 255)
  @Column(name = "CANCEL_BY")
  private String cancelBy;
  @Column(name = "AUTO_UPDATE")
  private Character autoUpdate;

  public DistributorLocatorConfig() {
  }

  public DistributorLocatorConfig(Long id) {
    this.id = id;
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public Date getCreationDate() {
    return creationDate;
  }

  public void setCreationDate(Date creationDate) {
    this.creationDate = creationDate;
  }

  public String getCreatedBy() {
    return createdBy;
  }

  public void setCreatedBy(String createdBy) {
    this.createdBy = createdBy;
  }

  public String getFileName() {
    return fileName;
  }

  public void setFileName(String fileName) {
    this.fileName = fileName;
  }

  public String getFolderName() {
    return folderName;
  }

  public void setFolderName(String folderName) {
    this.folderName = folderName;
  }

  public Long getGroupId() {
    return groupId;
  }

  public void setGroupId(Long groupId) {
    this.groupId = groupId;
  }

  public String getCountry() {
    return country;
  }

  public void setCountry(String country) {
    this.country = country;
  }

  public Date getCancelDate() {
    return cancelDate;
  }

  public void setCancelDate(Date cancelDate) {
    this.cancelDate = cancelDate;
  }

  public String getCancelBy() {
    return cancelBy;
  }

  public void setCancelBy(String cancelBy) {
    this.cancelBy = cancelBy;
  }

  public Character getAutoUpdate() {
    return autoUpdate;
  }

  public void setAutoUpdate(Character autoUpdate) {
    this.autoUpdate = autoUpdate;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (id != null ? id.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof DistributorLocatorConfig)) {
      return false;
    }
    DistributorLocatorConfig other = (DistributorLocatorConfig) object;
    if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.walter.DistributorLocatorConfig[ id=" + id + " ]";
  }

}
