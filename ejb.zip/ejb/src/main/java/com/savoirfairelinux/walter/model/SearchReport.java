package com.savoirfairelinux.walter.model;

import com.savoirfairelinux.walter.dao.waltercb.*;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class SearchReport implements Serializable {

    private Long cntId;
    private ReportType type;
    private ReportState state;
    private String reference;
    private Franchise franchise;
    private Tradename tradename;
    private UIndustry industry;
    private String reporterScreenName;
    private String pmScreenName;
    private UContaminant contaminant;
    private UMaterial material;
    private UActivity activity;
    private UCompetitor competitor;
    private Date fromPublicationDate;
    private Date toPublicationDate;
    private String naics;
    private String keyWord;
    private String customer;
    private BigDecimal fromRatingAvg;
    private BigDecimal toRatingAvg;
    private ULang language;
    private WalterOrganization organization;
    private WalterOrganization organization2;

    public Long getCntId() {
        return cntId;
    }

    public void setCntId(Long cntId) {
        this.cntId = cntId;
    }
    
    public ReportType getType() {
        return type;
    }

    public void setType(ReportType type) {
        this.type = type;
    }

    public ReportState getState() {
        return state;
    }

    public void setState(ReportState state) {
        this.state = state;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public Franchise getFranchise() {
        return franchise;
    }

    public void setFranchise(Franchise franchise) {
        this.franchise = franchise;
    }

    public Tradename getTradename() {
        return tradename;
    }

    public void setTradename(Tradename tradename) {
        this.tradename = tradename;
    }

    public UIndustry getIndustry() {
        return industry;
    }

    public void setIndustry(UIndustry industry) {
        this.industry = industry;
    }

    public String getReporterScreenName() {
        return reporterScreenName;
    }

    public void setReporterScreenName(String reporterScreenName) {
        this.reporterScreenName = reporterScreenName;
    }

    public String getPmScreenName() {
        return pmScreenName;
    }

    public void setPmScreenName(String pmScreenName) {
        this.pmScreenName = pmScreenName;
    }

    public UContaminant getContaminant() {
        return contaminant;
    }

    public void setContaminant(UContaminant contaminant) {
        this.contaminant = contaminant;
    }

    public UMaterial getMaterial() {
        return material;
    }

    public void setMaterial(UMaterial material) {
        this.material = material;
    }

    public UActivity getActivity() {
        return activity;
    }

    public void setActivity(UActivity activity) {
        this.activity = activity;
    }

    public UCompetitor getCompetitor() {
        return competitor;
    }

    public void setCompetitor(UCompetitor competitor) {
        this.competitor = competitor;
    }

    public Date getFromPublicationDate() {
        return fromPublicationDate;
    }

    public void setFromPublicationDate(Date fromPublicationDate) {
        this.fromPublicationDate = fromPublicationDate;
    }

    public Date getToPublicationDate() {
        return toPublicationDate;
    }

    public void setToPublicationDate(Date toPublicationDate) {
        this.toPublicationDate = toPublicationDate;
    }

    public String getNaics() {
        return naics;
    }

    public void setNaics(String naics) {
        this.naics = naics;
    }

    public String getKeyWord() {
        return keyWord;
    }

    public void setKeyWord(String keyWord) {
        this.keyWord = keyWord;
    }

    public String getCustomer() {
        return customer;
    }

    public void setCustomer(String customer) {
        this.customer = customer;
    }

    public BigDecimal getFromRatingAvg() {
        return fromRatingAvg;
    }

    public void setFromRatingAvg(BigDecimal fromRatingAvg) {
        this.fromRatingAvg = fromRatingAvg;
    }

    public BigDecimal getToRatingAvg() {
        return toRatingAvg;
    }

    public void setToRatingAvg(BigDecimal toRatingAvg) {
        this.toRatingAvg = toRatingAvg;
    }

    public ULang getLanguage() {
        return language;
    }

    public void setLanguage(ULang language) {
        this.language = language;
    }

    public WalterOrganization getOrganization() {
        return organization;
    }

    public void setOrganization(WalterOrganization organization) {
        this.organization = organization;
    }

    public WalterOrganization getOrganization2() {
        return organization2;
    }

    public void setOrganization2(WalterOrganization organization2) {
        this.organization2 = organization2;
    }
}
