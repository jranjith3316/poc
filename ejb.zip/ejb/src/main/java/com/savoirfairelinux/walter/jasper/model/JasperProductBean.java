/* 
 * Copyright 2013 Savoir-faire Linux
 * 
 * This file is part of Walter-Portal.
 * 
 * Walter-Portal is free software: you can redistribute it and/or modify it under the terms of the 
 * GNU General Public License as published by the Free Software Foundation, either version 3 
 * of the License, or (at your option) any later version.
 * 
 * Walter-Portal is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with Walter-Portal. 
 * If not, see http://www.gnu.org/licenses/.
 */
package com.savoirfairelinux.walter.jasper.model;

import java.io.Serializable;

/**
 * 
 * @author jbonjean
 *
 */
public class JasperProductBean implements Serializable {
	private String date;
	private String productName;
	private String approvalNumber;
	private String application;
	private String notes;
	
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getApprovalNumber() {
		return approvalNumber;
	}
	public void setApprovalNumber(String approvalNumber) {
		this.approvalNumber = approvalNumber;
	}
	public String getApplication() {
		return application;
	}
	public void setApplication(String application) {
		this.application = application;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
}
