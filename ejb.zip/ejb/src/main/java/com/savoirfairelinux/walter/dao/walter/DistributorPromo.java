/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.walter;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "DISTRIBUTOR_PROMO", catalog = "", schema = "WALTER")
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "DistributorPromo.findAll", query = "SELECT d FROM DistributorPromo d"),
  @NamedQuery(name = "DistributorPromo.findById", query = "SELECT d FROM DistributorPromo d WHERE d.id = :id"),
  @NamedQuery(name = "DistributorPromo.findByPromoCode", query = "SELECT d FROM DistributorPromo d WHERE d.promoCode = :promoCode"),
  @NamedQuery(name = "DistributorPromo.findByPromoDesc", query = "SELECT d FROM DistributorPromo d WHERE d.promoDesc = :promoDesc"),
  @NamedQuery(name = "DistributorPromo.findByStartDate", query = "SELECT d FROM DistributorPromo d WHERE d.startDate = :startDate"),
  @NamedQuery(name = "DistributorPromo.findByEndDate", query = "SELECT d FROM DistributorPromo d WHERE d.endDate = :endDate"),
  @NamedQuery(name = "DistributorPromo.findByCountry", query = "SELECT d FROM DistributorPromo d WHERE d.country = :country"),
  @NamedQuery(name = "DistributorPromo.findByCustNum", query = "SELECT d FROM DistributorPromo d WHERE d.custNum = :custNum")})
public class DistributorPromo implements Serializable {
  private static final long serialVersionUID = 1L;
  @Id
  @Basic(optional = false)
  @NotNull
  @Column(name = "ID", nullable = false)
  private Long id;
  @Size(max = 10)
  @Column(name = "PROMO_CODE")
  private String promoCode;
  @Size(max = 40)
  @Column(name = "PROMO_DESC")
  private String promoDesc;
  @Column(name = "START_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date startDate;
  @Column(name = "END_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date endDate;
  @Size(max = 10)
  @Column(name = "COUNTRY")
  private String country;
  @Size(max = 30)
  @Column(name = "CUST_NUM")
  private String custNum;

  public DistributorPromo() {
  }

  public DistributorPromo(Long id) {
    this.id = id;
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getPromoCode() {
    return promoCode;
  }

  public void setPromoCode(String promoCode) {
    this.promoCode = promoCode;
  }

  public String getPromoDesc() {
    return promoDesc;
  }

  public void setPromoDesc(String promoDesc) {
    this.promoDesc = promoDesc;
  }

  public Date getStartDate() {
    return startDate;
  }

  public void setStartDate(Date startDate) {
    this.startDate = startDate;
  }

  public Date getEndDate() {
    return endDate;
  }

  public void setEndDate(Date endDate) {
    this.endDate = endDate;
  }

  public String getCountry() {
    return country;
  }

  public void setCountry(String country) {
    this.country = country;
  }

  public String getCustNum() {
    return custNum;
  }

  public void setCustNum(String custNum) {
    this.custNum = custNum;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (id != null ? id.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof DistributorPromo)) {
      return false;
    }
    DistributorPromo other = (DistributorPromo) object;
    if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.walter.DistributorPromo[ id=" + id + " ]";
  }

}
