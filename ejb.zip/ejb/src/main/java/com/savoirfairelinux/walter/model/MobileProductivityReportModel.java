/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.model;

import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author jsgill
 */
public class MobileProductivityReportModel implements Serializable {

  private String id;
  private String countryName;
  private String screenname;
  private Date updateDate;
  private String status;
  private String actionName;
  private String com;
  private String comBackingNumber;
  private Double comBackingPadPrice;
  private Double comDiameter;
  private Double comEndUserPrice;
  private String comGrit;
  private String comOtherPowerTools;
  private String comPowerTools;
  private String comProductName;
  private String comProductNumber;
  private Long comQuantityBackingPerYear;
  private Long comQuantityDiscPerYear;
  private String contactEnterprise;
  private String materialDesc;
  private String reportName;
  private String resellerCompagny;
  private Short saleGenerated;
  private Double shopRate;
  private Long timePerDiscChangeover;
  private Double walEndUserPrice;
  private String walOtherPowerTools;
  private String walPowerTools;
  private String walterProductNumber;
  private Double saving;
  private Long numberOfDiscs;
  private Long numberOfPads;
  private Double pricePerDisc;
  private Double reimbursement;

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getCountryName() {
    return countryName;
  }

  public void setCountryName(String countryName) {
    this.countryName = countryName;
  }

  public String getScreenname() {
    return screenname;
  }

  public void setScreenname(String screenname) {
    this.screenname = screenname;
  }

  public Date getUpdateDate() {
    return updateDate;
  }

  public void setUpdateDate(Date updateDate) {
    this.updateDate = updateDate;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public String getActionName() {
    return actionName;
  }

  public void setActionName(String actionName) {
    this.actionName = actionName;
  }

  public String getCom() {
    return com;
  }

  public void setCom(String com) {
    this.com = com;
  }

  public String getComBackingNumber() {
    return comBackingNumber;
  }

  public void setComBackingNumber(String comBackingNumber) {
    this.comBackingNumber = comBackingNumber;
  }

  public Double getComBackingPadPrice() {
    return comBackingPadPrice;
  }

  public void setComBackingPadPrice(Double comBackingPadPrice) {
    this.comBackingPadPrice = comBackingPadPrice;
  }

  public Double getComDiameter() {
    return comDiameter;
  }

  public void setComDiameter(Double comDiameter) {
    this.comDiameter = comDiameter;
  }

  public Double getComEndUserPrice() {
    return comEndUserPrice;
  }

  public void setComEndUserPrice(Double comEndUserPrice) {
    this.comEndUserPrice = comEndUserPrice;
  }

  public String getComGrit() {
    return comGrit;
  }

  public void setComGrit(String comGrit) {
    this.comGrit = comGrit;
  }

  public String getComOtherPowerTools() {
    return comOtherPowerTools;
  }

  public void setComOtherPowerTools(String comOtherPowerTools) {
    this.comOtherPowerTools = comOtherPowerTools;
  }

  public String getComPowerTools() {
    return comPowerTools;
  }

  public void setComPowerTools(String comPowerTools) {
    this.comPowerTools = comPowerTools;
  }

  public String getComProductName() {
    return comProductName;
  }

  public void setComProductName(String comProductName) {
    this.comProductName = comProductName;
  }

  public String getComProductNumber() {
    return comProductNumber;
  }

  public void setComProductNumber(String comProductNumber) {
    this.comProductNumber = comProductNumber;
  }

  public Long getComQuantityBackingPerYear() {
    return comQuantityBackingPerYear;
  }

  public void setComQuantityBackingPerYear(Long comQuantityBackingPerYear) {
    this.comQuantityBackingPerYear = comQuantityBackingPerYear;
  }

  public Long getComQuantityDiscPerYear() {
    return comQuantityDiscPerYear;
  }

  public void setComQuantityDiscPerYear(Long comQuantityDiscPerYear) {
    this.comQuantityDiscPerYear = comQuantityDiscPerYear;
  }

  public String getContactEnterprise() {
    return contactEnterprise;
  }

  public void setContactEnterprise(String contactEnterprise) {
    this.contactEnterprise = contactEnterprise;
  }

  public String getMaterialDesc() {
    return materialDesc;
  }

  public void setMaterialDesc(String materialDesc) {
    this.materialDesc = materialDesc;
  }

  public String getReportName() {
    return reportName;
  }

  public void setReportName(String reportName) {
    this.reportName = reportName;
  }

  public String getResellerCompagny() {
    return resellerCompagny;
  }

  public void setResellerCompagny(String resellerCompagny) {
    this.resellerCompagny = resellerCompagny;
  }

  public Short getSaleGenerated() {
    return saleGenerated;
  }

  public void setSaleGenerated(Short saleGenerated) {
    this.saleGenerated = saleGenerated;
  }

  public Double getShopRate() {
    return shopRate;
  }

  public void setShopRate(Double shopRate) {
    this.shopRate = shopRate;
  }

  public Long getTimePerDiscChangeover() {
    return timePerDiscChangeover;
  }

  public void setTimePerDiscChangeover(Long timePerDiscChangeover) {
    this.timePerDiscChangeover = timePerDiscChangeover;
  }

  public Double getWalEndUserPrice() {
    return walEndUserPrice;
  }

  public void setWalEndUserPrice(Double walEndUserPrice) {
    this.walEndUserPrice = walEndUserPrice;
  }

  public String getWalOtherPowerTools() {
    return walOtherPowerTools;
  }

  public void setWalOtherPowerTools(String walOtherPowerTools) {
    this.walOtherPowerTools = walOtherPowerTools;
  }

  public String getWalPowerTools() {
    return walPowerTools;
  }

  public void setWalPowerTools(String walPowerTools) {
    this.walPowerTools = walPowerTools;
  }

  public String getWalterProductNumber() {
    return walterProductNumber;
  }

  public void setWalterProductNumber(String walterProductNumber) {
    this.walterProductNumber = walterProductNumber;
  }

  public Double getSaving() {
    return saving;
  }

  public void setSaving(Double saving) {
    this.saving = saving;
  }

  public Long getNumberOfDiscs() {
    return numberOfDiscs;
  }

  public void setNumberOfDiscs(Long numberOfDiscs) {
    this.numberOfDiscs = numberOfDiscs;
  }

  public Long getNumberOfPads() {
    return numberOfPads;
  }

  public void setNumberOfPads(Long numberOfPads) {
    this.numberOfPads = numberOfPads;
  }

  public Double getPricePerDisc() {
    return pricePerDisc;
  }

  public void setPricePerDisc(Double pricePerDisc) {
    this.pricePerDisc = pricePerDisc;
  }

  public Double getReimbursement() {
    return reimbursement;
  }

  public void setReimbursement(Double reimbursement) {
    this.reimbursement = reimbursement;
  }


}
