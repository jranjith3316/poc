/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import javax.persistence.*;
import javax.validation.constraints.Size;
import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;

/**
 *
 * @author jderuere
 */
@Entity
@Table(name = "PR_PICTURE_TXT", schema = DatabaseConstants.WALTERCB_SCHEMA)
public class PrPictureTxt implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected PrPictureTxtPK pictureTxtPK;
    @Size(max = 100)
    @Column(name = "PICTURE_TXT")
    private String pictureTxt;
    @JoinColumn(name = "PICTURE_ID", referencedColumnName = "PICTURE_ID", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private PrPicture picture;

    public PrPictureTxt() {
    }

    public PrPictureTxt(PrPictureTxt pictureTxt, long langId) {
    	this.pictureTxtPK = new PrPictureTxtPK(pictureTxt.getPicture().getPictureId(), langId);
    	this.pictureTxt = pictureTxt.getPictureTxt();
    	this.picture = pictureTxt.getPicture();
    }

    public PrPictureTxt(PrPictureTxtPK cntPictureTxtPK) {
        this.pictureTxtPK = cntPictureTxtPK;
    }

    public PrPictureTxt(long pictureId, long langId) {
        this.pictureTxtPK = new PrPictureTxtPK(pictureId, langId);
    }

    public PrPictureTxtPK getPictureTxtPK() {
        return pictureTxtPK;
    }

    public void setPictureTxtPK(PrPictureTxtPK pictureTxtPK) {
        this.pictureTxtPK = pictureTxtPK;
    }

    public String getPictureTxt() {
        return pictureTxt;
    }

    public void setPictureTxt(String pictureTxt) {
        this.pictureTxt = pictureTxt;
    }

    public PrPicture getPicture() {
        return picture;
    }

    public void setPicture(PrPicture picture) {
        this.picture = picture;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (pictureTxtPK != null ? pictureTxtPK.hashCode() : 0);
        return hash;
    }
    
    @PrePersist
    private void prePersist() {
    	if (picture != null && pictureTxtPK != null) {
            pictureTxtPK.setPictureId(picture.getPictureId());
    	}
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PrPictureTxt)) {
            return false;
        }
        PrPictureTxt other = (PrPictureTxt) object;
        if ((this.pictureTxtPK == null && other.pictureTxtPK != null) || (this.pictureTxtPK != null && !this.pictureTxtPK.equals(other.pictureTxtPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.PrPictureTxt[ pictureTxtPK=" + pictureTxtPK + " ]";
    }
}
