package com.savoirfairelinux.walter.util.criteriabuilder;

import com.savoirfairelinux.walter.dao.waltercb.Er;
import com.savoirfairelinux.walter.dao.waltercb.UContaminant;
import com.savoirfairelinux.walter.dao.waltercb.ULang;
import com.savoirfairelinux.walter.model.Franchise;
import com.savoirfairelinux.walter.model.LabReportState;
import com.savoirfairelinux.walter.model.SearchEr;
import com.savoirfairelinux.walter.model.Tradename;
import java.math.BigDecimal;
import java.math.BigInteger;

import javax.persistence.EntityManager;
import java.util.Date;
import java.util.Map;

public class ErCriteriaBuilder extends AbstractCriteriaBuilder<Er> {

    private SearchEr form;

    public ErCriteriaBuilder(EntityManager entityManager, SearchEr form) {
        super(entityManager, Er.class);
        this.form = form;
    }

    @Override
    protected void initQuery(StringBuilder queryBuilder, Map<String, Object> properties) {
        queryBuilder.append("SELECT er FROM Er er ");
    }

    @Override
    protected void initJoinQuery(StringBuilder queryBuilder, Map<String, Object> properties) {
        queryBuilder.append(" LEFT OUTER JOIN FETCH er.erTxtSet as txt ");
    }

    @Override
    protected void buildSpecificQuery(StringBuilder queryBuilder, Map<String, Object> properties) {
        queryBuilder.append(" WHERE er.organization = :organization ")
            .append(" AND er.cancelDate IS NULL ");
        addIdCriteria(queryBuilder, properties, form.getId());
        addLikeCriteria(queryBuilder, "er.erRef", form.getReference());
        addLikeCriteria(queryBuilder, "er.requestedByUserName", form.getRequesterScreenName() != null ? form.getRequesterScreenName().toUpperCase() : null);
        addLikeCriteria(queryBuilder, "er.creatorUserName", form.getCreatorScreenName() != null ? form.getCreatorScreenName().toUpperCase() : null);
        addContaminantCriteria(queryBuilder, properties, form.getContaminant());
        addCustomerCriteria(queryBuilder, properties, form.getCustomer());
        addFromPublicationDateCriteria(queryBuilder, properties, form.getFromPublicationDate());
        addToPublicationDateCriteria(queryBuilder, properties, form.getToPublicationDate());
        addStateCriteria(queryBuilder, properties, form.getState());
        addKeywordCriteria(queryBuilder, properties, form.getKeyWord(), form.getLanguage());
        addTradenameCriteria(queryBuilder, properties, form.getTradename());
        addFranchiseCriteria(queryBuilder, properties, form.getFranchise());
        addOtherCleanerCriteria(queryBuilder, properties, form.getOtherCleaner());
        addPartsIdCriteria(queryBuilder, properties, form.getPartsId());
        properties.put("organization", form.getOrganization().getName());
    }

    @Override
    protected void initOrderByQuery(StringBuilder queryBuilder, Map<String, Object> properties) {    	
    }

    protected void addIdCriteria(StringBuilder queryBuilder, Map<String, Object> properties, Long id) {
        if (id != null) {
            queryBuilder.append(" AND er.erId = :erId");
            properties.put("erId", id);
        }
    }

    protected void addStateCriteria(StringBuilder queryBuilder, Map<String, Object> properties, LabReportState state) {
        if (state != null) {
            switch (state) {
                case UNSUBMIT:
                    queryBuilder.append(" AND er.entryDate IS NOT NULL ")
                        .append(" AND er.sentToWs IS NULL ")
                        .append(" AND er.publishedDate IS NULL ");
                    break;
                case SUBMIT:
                    queryBuilder.append(" AND er.publishedDate IS NULL ")
                            .append(" AND er.entryDate IS NOT NULL ")
                            .append(" AND er.sentToWs IS NOT NULL ");
                    break;
                case PUBLISH:
                    queryBuilder.append(" AND er.publishedDate IS NOT NULL ")
                            .append(" AND er.entryDate IS NOT NULL ");
                    break;
                default:
                    break;
            }
        }
    }

    protected void addFromPublicationDateCriteria(StringBuilder queryBuilder, Map<String, Object> properties, Date fromPublicationDate) {
        if (fromPublicationDate != null) {
            queryBuilder.append(" AND er.publishedDate >= :fromPublicationDate ");
            properties.put("fromPublicationDate", fromPublicationDate);
        }
    }

    protected void addToPublicationDateCriteria(StringBuilder queryBuilder, Map<String, Object> properties, Date toPublicationDate) {
        if (toPublicationDate != null) {
            queryBuilder.append(" AND er.publishedDate <= :toPublicationDate");
            properties.put("toPublicationDate", toPublicationDate);
        }
    }

    protected void addCustomerCriteria(StringBuilder queryBuilder, Map<String, Object> properties, String customer) {
        if (customer != null && !customer.isEmpty()) {
            queryBuilder.append(" AND txt.customerName LIKE :customer ");
            properties.put("customer", customer);
        }
    }

    protected void addPartsIdCriteria(StringBuilder queryBuilder, Map<String, Object> properties, Integer partsId) {
        if (partsId != null) {
            queryBuilder.append(" AND to_char(er.partsId) LIKE :partsId ");
            properties.put("partsId", "%" + new BigDecimal(partsId).toString() + "%");
                        
        }
    }

    protected void addContaminantCriteria(StringBuilder queryBuilder, Map<String, Object> properties, UContaminant contaminant) {
        if (contaminant != null) {
            queryBuilder.append(" AND er.erId IN ( ")
                    .append(" SELECT DISTINCT contaminant.erContaminantPK.erId FROM ErContaminant contaminant ")
                    .append(" WHERE contaminant.erContaminantPK.contaminantId = :contaminant) ");
            properties.put("contaminant", contaminant.getUContaminantPK().getContaminantId());
        }
    }

    protected void addKeywordCriteria(StringBuilder queryBuilder, Map<String, Object> properties, String keyword, ULang language) {
        if (keyword != null && !keyword.isEmpty()) {
            queryBuilder.append(" AND ( UPPER(txt.partCleanDesc) LIKE :keyword ")
                    .append(" OR UPPER(txt.contactName) LIKE :keyword ")
                    .append(" OR UPPER(txt.contactTitle) LIKE :keyword ")
                    .append(" OR UPPER(txt.contaminantDesc) LIKE :keyword ")
                    .append(" OR UPPER(txt.specialApplication) LIKE :keyword ")
                    .append(" OR UPPER(txt.cleaningMethod) LIKE :keyword ")
                    .append(" OR UPPER(txt.observation) LIKE :keyword ")
                    .append(" OR UPPER(txt.otherContaminant) LIKE :keyword ")
//                    .append(" ) ")
//                    .append(" OR er IN ( ")
//                    .append(" SELECT DISTINCT picTxt.erPicture.er FROM ErPictureTxt picTxt ")
//                    .append(" WHERE picTxt.pictureTxt LIKE :keyword ")
//                    .append(" ) ")
//                    .append(" OR er IN ( ")
//                    .append(" SELECT DISTINCT trialTxt.erTrial.er FROM ErTrialTxt trialTxt ")
//                    .append(" WHERE trialTxt.mechanical LIKE :keyword ")
//                    .append(" OR trialTxt.temperature LIKE :keyword ")
//                    .append(" OR trialTxt.waitTime LIKE :keyword ")
//                    .append(" OR trialTxt.comments LIKE :keyword ")
//                    .append(" ) ")
                    .append(" ) ");
            properties.put("keyword", "%" + keyword.toUpperCase() + "%");
        }
    }

    protected void addTradenameCriteria(StringBuilder queryBuilder, Map<String, Object> properties, Tradename tradename) {
        if (tradename != null) {
            queryBuilder.append(" AND er IN ( ")
                    .append(" SELECT DISTINCT product.erTrial.er FROM ErTrialProduct product ")
                    .append(" WHERE product.franchiseguid = :franchiseId ")
                    .append(" AND product.tradenameguid = :tradenameId) ");
            properties.put("franchiseId", tradename.getFranchise().getFranchiseId());
            properties.put("tradenameId", tradename.getTradenameId());
        }
    }

    protected void addFranchiseCriteria(StringBuilder queryBuilder, Map<String, Object> properties, Franchise franchise) {
        if (franchise != null) {
            queryBuilder.append(" AND er IN ( ")
                    .append(" SELECT DISTINCT product.erTrial.er FROM ErTrialProduct product ")
                    .append(" WHERE product.franchiseguid = :franchiseId) ");
            properties.put("franchiseId", franchise.getFranchiseId());
        }
    }

    protected void addOtherCleanerCriteria(StringBuilder queryBuilder, Map<String, Object> properties, String otherCleaner) {
        if (otherCleaner != null && !otherCleaner.isEmpty()) {
            queryBuilder.append(" AND er IN ( ")
                    .append(" SELECT DISTINCT product.erTrial.er FROM ErTrialProduct product ")
                    .append(" WHERE product.otherProduct LIKE :otherProduct) ");
            properties.put("otherProduct", otherCleaner);
        }
    }
}
