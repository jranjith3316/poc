/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import java.util.Date;
import java.util.Set;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "CNT_FEEDBACK", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CntFeedback.findAll", query = "SELECT c FROM CntFeedback c"),
    @NamedQuery(name = "CntFeedback.findByFeedbackId", query = "SELECT c FROM CntFeedback c WHERE c.feedbackId = :feedbackId"),
    @NamedQuery(name = "CntFeedback.findByFeedbackDesc", query = "SELECT c FROM CntFeedback c WHERE c.feedbackDesc = :feedbackDesc"),
    @NamedQuery(name = "CntFeedback.findByRanking", query = "SELECT c FROM CntFeedback c WHERE c.ranking = :ranking"),
    @NamedQuery(name = "CntFeedback.findByDateCreated", query = "SELECT c FROM CntFeedback c WHERE c.dateCreated = :dateCreated"),
    @NamedQuery(name = "CntFeedback.findByDateModified", query = "SELECT c FROM CntFeedback c WHERE c.dateModified = :dateModified"),
    @NamedQuery(name = "CntFeedback.findByUserName", query = "SELECT c FROM CntFeedback c WHERE c.userName = :userName"),
    @NamedQuery(name = "CntFeedback.findByRankBackup", query = "SELECT c FROM CntFeedback c WHERE c.rankBackup = :rankBackup")})
public class CntFeedback implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @GeneratedValue(generator = "FEEDBACK_ID_SEQ", strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "FEEDBACK_ID_SEQ", sequenceName = "FEEDBACK_ID_SEQ", schema = DatabaseConstants.WALTERCB_SCHEMA, allocationSize = 1)
    @Column(name = "FEEDBACK_ID")
    private Long feedbackId;
    @Size(max = 500)
    @Column(name = "FEEDBACK_DESC")
    private String feedbackDesc;
    private Short ranking;
    @Column(name = "DATE_CREATED")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateCreated;
    @Column(name = "DATE_MODIFIED")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateModified;
    @Size(max = 256)
    @Column(name = "USER_NAME")
    private String userName;
    @Column(name = "RANK_BACKUP")
    private Short rankBackup;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "cntFeedback")
    private Set<CntFeedbackR> cntFeedbackRSet;
    @JoinColumn(name = "CNT_ID", referencedColumnName = "CNT_ID")
    @ManyToOne
    private Cnt cnt;

    public CntFeedback() {
    }

    public CntFeedback(Long feedbackId) {
        this.feedbackId = feedbackId;
    }

    public Long getFeedbackId() {
        return feedbackId;
    }

    public void setFeedbackId(Long feedbackId) {
        this.feedbackId = feedbackId;
    }

    public String getFeedbackDesc() {
        return feedbackDesc;
    }

    public void setFeedbackDesc(String feedbackDesc) {
        this.feedbackDesc = feedbackDesc;
    }

    public Short getRanking() {
        return ranking;
    }

    public void setRanking(Short ranking) {
        this.ranking = ranking;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public Date getDateModified() {
        return dateModified;
    }

    public void setDateModified(Date dateModified) {
        this.dateModified = dateModified;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public Short getRankBackup() {
        return rankBackup;
    }

    public void setRankBackup(Short rankBackup) {
        this.rankBackup = rankBackup;
    }

    @XmlTransient
    public Set<CntFeedbackR> getCntFeedbackRSet() {
        return cntFeedbackRSet;
    }

    public void setCntFeedbackRSet(Set<CntFeedbackR> cntFeedbackRSet) {
        this.cntFeedbackRSet = cntFeedbackRSet;
    }

    public Cnt getCnt() {
        return cnt;
    }

    public void setCnt(Cnt cnt) {
        this.cnt = cnt;
    }


    @Override
    public int hashCode() {
        int hash = 0;
        hash += (feedbackId != null ? feedbackId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CntFeedback)) {
            return false;
        }
        CntFeedback other = (CntFeedback) object;
        if ((this.feedbackId == null && other.feedbackId != null) || (this.feedbackId != null && !this.feedbackId.equals(other.feedbackId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.CntFeedback[ feedbackId=" + feedbackId + " ]";
    }
}
