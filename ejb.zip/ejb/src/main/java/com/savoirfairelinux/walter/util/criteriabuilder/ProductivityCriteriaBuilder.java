package com.savoirfairelinux.walter.util.criteriabuilder;

import com.savoirfairelinux.walter.dao.waltercb.ProductivityReport;
import com.savoirfairelinux.walter.dao.waltercb.UCompetitor;
import com.savoirfairelinux.walter.dao.waltercb.UCompetitorBrand;
import com.savoirfairelinux.walter.dao.waltercb.UCompetitorProduct;
import com.savoirfairelinux.walter.model.PrApplication;
import com.savoirfairelinux.walter.model.PrWalterProduct;
import com.savoirfairelinux.walter.model.ProductivityReportState;
import com.savoirfairelinux.walter.model.SearchProductivityReport;
import com.savoirfairelinux.walter.model.Tradename;
import java.util.Date;
import java.util.Map;
import javax.persistence.EntityManager;

public class ProductivityCriteriaBuilder extends AbstractCriteriaBuilder<ProductivityReport> {

    private SearchProductivityReport form;

    public ProductivityCriteriaBuilder(EntityManager entityManager, SearchProductivityReport form) {
        super(entityManager, ProductivityReport.class);
        this.form = form;
    }

    @Override
    protected void initQuery(StringBuilder queryBuilder, Map<String, Object> properties) {
        queryBuilder.append("SELECT pr FROM ProductivityReport pr ");
    }

    @Override
    protected void initJoinQuery(StringBuilder queryBuilder, Map<String, Object> properties) {
    }

    @Override
    protected void buildSpecificQuery(StringBuilder queryBuilder, Map<String, Object> properties) {
        queryBuilder.append(" WHERE 1 = 1 ");
        addIdCriteria(queryBuilder, properties, form.getId());
        addApplicationCriteria(queryBuilder, properties, form.getApplication());
        addLikeCriteria(queryBuilder, "pr.saleRepresentative", form.getCreatorScreenName() != null ? form.getCreatorScreenName().toUpperCase() : null);
        addCompetitorCriteria(queryBuilder, properties, form.getCompetitor());
        addCompetitorBrandCriteria(queryBuilder, properties, form.getCompetitorBrand());
        addCompetitorProductCriteria(queryBuilder, properties, form.getCompetitorProduct());
        addFromPublicationDateCriteria(queryBuilder, properties, form.getFromDate());
        addToPublicationDateCriteria(queryBuilder, properties, form.getToDate());
        addStateCriteria(queryBuilder, properties, form.getState());
        addWalterProductCriteria(queryBuilder, properties, form.getWalterProduct());
        addTradenameCriteria(queryBuilder, properties, form.getWalterTradename());
    }

    @Override
    protected void initOrderByQuery(StringBuilder queryBuilder, Map<String, Object> properties) {
    }

    protected void addIdCriteria(StringBuilder queryBuilder, Map<String, Object> properties, Long id) {
        if (id != null) {
            queryBuilder.append(" AND pr.id = :id");
            properties.put("id", id);
        }
    }

    protected void addApplicationCriteria(StringBuilder queryBuilder, Map<String, Object> properties, PrApplication application) {
        if (application != null) {
            queryBuilder.append(" AND pr.applicationGUID = :applicationGUID ");
            properties.put("applicationGUID", application.getGuid());
        }
    }

    protected void addStateCriteria(StringBuilder queryBuilder, Map<String, Object> properties, ProductivityReportState state) {
        if (state != null) {
            switch (state) {
                case UNSUBMIT:
                    queryBuilder.append(" AND pr.createDate IS NOT NULL ")
                        .append(" AND pr.submitDate IS NULL ")
                        .append(" AND pr.publishDate IS NULL ");
                    break;
                case SUBMIT:
                    queryBuilder.append(" AND pr.submitDate IS NOT NULL ")
                            .append(" AND pr.publishDate IS NULL ");
                    break;
                case PUBLISH:
                    queryBuilder.append(" AND pr.publishDate IS NOT NULL ");
                    break;
                default:
                    break;
            }
        }
    }

    protected void addFromPublicationDateCriteria(StringBuilder queryBuilder, Map<String, Object> properties, Date fromPublicationDate) {
        if (fromPublicationDate != null) {
            queryBuilder.append(" AND pr.publishDate >= :fromPublicationDate ");
            properties.put("fromPublicationDate", fromPublicationDate);
        }
    }

    protected void addToPublicationDateCriteria(StringBuilder queryBuilder, Map<String, Object> properties, Date toPublicationDate) {
        if (toPublicationDate != null) {
            queryBuilder.append(" AND pr.publishDate <= :toPublicationDate");
            properties.put("toPublicationDate", toPublicationDate);
        }
    }

    protected void addCompetitorProductCriteria(StringBuilder queryBuilder, Map<String, Object> properties, UCompetitorProduct product) {
        if (product != null) {
            queryBuilder.append(" AND pr.competitorProduct = :competitorProduct ");
            properties.put("competitorProduct", product);
        }
    }

    protected void addCompetitorBrandCriteria(StringBuilder queryBuilder, Map<String, Object> properties, UCompetitorBrand brand) {
        if (brand != null) {
            queryBuilder.append(" AND pr.competitorProduct.brand = :brand ");
            properties.put("brand", brand);
        }
    }

    protected void addCompetitorCriteria(StringBuilder queryBuilder, Map<String, Object> properties, UCompetitor competitor) {
        if (competitor != null) {
            queryBuilder.append(" AND pr.competitorProduct.brand.competitor = :competitor ");
            properties.put("competitor", competitor);
        }
    }

    protected void addWalterProductCriteria(StringBuilder queryBuilder, Map<String, Object> properties, PrWalterProduct product) {
        if (product != null) {
            queryBuilder.append(" AND pr.walterProductNumber = :productNumber ");
            properties.put("productNumber", product.getProductNumber());
        }
    }

    protected void addTradenameCriteria(StringBuilder queryBuilder, Map<String, Object> properties, Tradename tradename) {
        if (tradename != null) {
            queryBuilder.append(" AND pr.walterProductNumber IN ( ")
                    .append("SELECT wpc.productguid.productnumber FROM WalterProductsCountries wpc, OoInstances trade")
                    .append(" WHERE wpc.productguid.productstatus         = 'Active'")
                    .append(" AND wpc.productguid.producttype             in ('Product','Kit')")
                    .append(" AND wpc.topublish                           = 'Y'")
                    .append(" AND wpc.productguid.deletedatetime IS NULL")
                    .append(" AND wpc.deletedatetime IS NULL")
                    .append(" AND trade.instanceguid = wpc.tradenameguid ")
                    .append(" AND trade.instanceguid = :tradenameId ) ");
            properties.put("tradenameId", tradename.getTradenameId());
        }
    }

}
