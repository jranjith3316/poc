/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.idb;

import com.savoirfairelinux.walter.dao.DatabaseConstants;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "WALTER_TVVIDEOS", catalog = "", schema = DatabaseConstants.IDB_SCHEMA)
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "WalterTvvideos.findAll", query = "SELECT w FROM WalterTvvideos w"),
  @NamedQuery(name = "WalterTvvideos.findByTvvideoguid", query = "SELECT w FROM WalterTvvideos w WHERE w.tvvideoguid = :tvvideoguid"),
  @NamedQuery(name = "WalterTvvideos.findByTvvideoname", query = "SELECT w FROM WalterTvvideos w WHERE w.tvvideoname = :tvvideoname"),
  @NamedQuery(name = "WalterTvvideos.findByTvvideotype", query = "SELECT w FROM WalterTvvideos w WHERE w.tvvideotype = :tvvideotype"),
  @NamedQuery(name = "WalterTvvideos.findByTvvideoformat", query = "SELECT w FROM WalterTvvideos w WHERE w.tvvideoformat = :tvvideoformat"),
  @NamedQuery(name = "WalterTvvideos.findByTvvideourltext", query = "SELECT w FROM WalterTvvideos w WHERE w.tvvideourltext = :tvvideourltext"),
  @NamedQuery(name = "WalterTvvideos.findByTvvideodurationnonedited", query = "SELECT w FROM WalterTvvideos w WHERE w.tvvideodurationnonedited = :tvvideodurationnonedited"),
  @NamedQuery(name = "WalterTvvideos.findByTvvideodurationedited", query = "SELECT w FROM WalterTvvideos w WHERE w.tvvideodurationedited = :tvvideodurationedited"),
  @NamedQuery(name = "WalterTvvideos.findByTvvideoratio", query = "SELECT w FROM WalterTvvideos w WHERE w.tvvideoratio = :tvvideoratio"),
  @NamedQuery(name = "WalterTvvideos.findByTvvideoreporter", query = "SELECT w FROM WalterTvvideos w WHERE w.tvvideoreporter = :tvvideoreporter"),
  @NamedQuery(name = "WalterTvvideos.findByTvvideoeditor", query = "SELECT w FROM WalterTvvideos w WHERE w.tvvideoeditor = :tvvideoeditor"),
  @NamedQuery(name = "WalterTvvideos.findByTvvideocountry", query = "SELECT w FROM WalterTvvideos w WHERE w.tvvideocountry = :tvvideocountry"),
  @NamedQuery(name = "WalterTvvideos.findByTvvideoreportercountry", query = "SELECT w FROM WalterTvvideos w WHERE w.tvvideoreportercountry = :tvvideoreportercountry"),
  @NamedQuery(name = "WalterTvvideos.findByTvvideooriginallanguage", query = "SELECT w FROM WalterTvvideos w WHERE w.tvvideooriginallanguage = :tvvideooriginallanguage"),
  @NamedQuery(name = "WalterTvvideos.findByTvvideomaincustomer", query = "SELECT w FROM WalterTvvideos w WHERE w.tvvideomaincustomer = :tvvideomaincustomer"),
  @NamedQuery(name = "WalterTvvideos.findByTvvideocustomer", query = "SELECT w FROM WalterTvvideos w WHERE w.tvvideocustomer = :tvvideocustomer"),
  @NamedQuery(name = "WalterTvvideos.findByTvvideostatus", query = "SELECT w FROM WalterTvvideos w WHERE w.tvvideostatus = :tvvideostatus"),
  @NamedQuery(name = "WalterTvvideos.findByTvvideoimageurl", query = "SELECT w FROM WalterTvvideos w WHERE w.tvvideoimageurl = :tvvideoimageurl"),
  @NamedQuery(name = "WalterTvvideos.findByTvvideoimagename", query = "SELECT w FROM WalterTvvideos w WHERE w.tvvideoimagename = :tvvideoimagename"),
  @NamedQuery(name = "WalterTvvideos.findByTvvideopreviewurl", query = "SELECT w FROM WalterTvvideos w WHERE w.tvvideopreviewurl = :tvvideopreviewurl"),
  @NamedQuery(name = "WalterTvvideos.findByTvvideopreviewfilename", query = "SELECT w FROM WalterTvvideos w WHERE w.tvvideopreviewfilename = :tvvideopreviewfilename"),
  @NamedQuery(name = "WalterTvvideos.findByTvvideoauthorizationdocumentur", query = "SELECT w FROM WalterTvvideos w WHERE w.tvvideoauthorizationdocumentur = :tvvideoauthorizationdocumentur"),
  @NamedQuery(name = "WalterTvvideos.findByAdddatetime", query = "SELECT w FROM WalterTvvideos w WHERE w.adddatetime = :adddatetime"),
  @NamedQuery(name = "WalterTvvideos.findByDeletedatetime", query = "SELECT w FROM WalterTvvideos w WHERE w.deletedatetime = :deletedatetime"),
  @NamedQuery(name = "WalterTvvideos.findByUpdatedatetime", query = "SELECT w FROM WalterTvvideos w WHERE w.updatedatetime = :updatedatetime"),
  @NamedQuery(name = "WalterTvvideos.findByEventuser", query = "SELECT w FROM WalterTvvideos w WHERE w.eventuser = :eventuser"),
  @NamedQuery(name = "WalterTvvideos.findByTvvideoorderby", query = "SELECT w FROM WalterTvvideos w WHERE w.tvvideoorderby = :tvvideoorderby"),
  @NamedQuery(name = "WalterTvvideos.findByTvvideofilename", query = "SELECT w FROM WalterTvvideos w WHERE w.tvvideofilename = :tvvideofilename"),
  @NamedQuery(name = "WalterTvvideos.findByTvvideowebdisplay", query = "SELECT w FROM WalterTvvideos w WHERE w.tvvideowebdisplay = :tvvideowebdisplay"),
  @NamedQuery(name = "WalterTvvideos.findByTvvideourl", query = "SELECT w FROM WalterTvvideos w WHERE w.tvvideourl = :tvvideourl"),
  @NamedQuery(name = "WalterTvvideos.findByUpdatedatetimestatus", query = "SELECT w FROM WalterTvvideos w WHERE w.updatedatetimestatus = :updatedatetimestatus")})
public class WalterTvvideos implements Serializable {
  private static final long serialVersionUID = 1L;
  @Id
  @Basic(optional = false)
  @NotNull
  @Size(min = 1, max = 255)
  @Column(name = "TVVIDEOGUID")
  private String tvvideoguid;
  @Size(max = 255)
  @Column(name = "TVVIDEONAME")
  private String tvvideoname;
  @Lob
  @Column(name = "TVVIDEOSHORTDESCRIPTION")
  private String tvvideoshortdescription;
  @Lob
  @Column(name = "TVVIDEOLONGDESCRIPTION")
  private String tvvideolongdescription;
  @Size(max = 255)
  @Column(name = "TVVIDEOTYPE")
  private String tvvideotype;
  @Size(max = 255)
  @Column(name = "TVVIDEOFORMAT")
  private String tvvideoformat;
  @Size(max = 255)
  @Column(name = "TVVIDEOURLTEXT")
  private String tvvideourltext;
  @Column(name = "TVVIDEODURATIONNONEDITED")
  private Long tvvideodurationnonedited;
  @Column(name = "TVVIDEODURATIONEDITED")
  private Long tvvideodurationedited;
  @Size(max = 255)
  @Column(name = "TVVIDEORATIO")
  private String tvvideoratio;
  @Size(max = 255)
  @Column(name = "TVVIDEOREPORTER")
  private String tvvideoreporter;
  @Size(max = 255)
  @Column(name = "TVVIDEOEDITOR")
  private String tvvideoeditor;
  @Size(max = 255)
  @Column(name = "TVVIDEOCOUNTRY")
  private String tvvideocountry;
  @Column(name = "TVVIDEOREPORTERCOUNTRY")
  private Long tvvideoreportercountry;
  @Column(name = "TVVIDEOORIGINALLANGUAGE")
  private Long tvvideooriginallanguage;
  @Column(name = "TVVIDEOMAINCUSTOMER")
  private Long tvvideomaincustomer;
  @Column(name = "TVVIDEOCUSTOMER")
  private Long tvvideocustomer;
  @Lob
  @Column(name = "TVVIDEOSUBTITLES")
  private String tvvideosubtitles;
  @Size(max = 255)
  @Column(name = "TVVIDEOSTATUS")
  private String tvvideostatus;
  @Size(max = 255)
  @Column(name = "TVVIDEOIMAGEURL")
  private String tvvideoimageurl;
  @Size(max = 255)
  @Column(name = "TVVIDEOIMAGENAME")
  private String tvvideoimagename;
  @Size(max = 255)
  @Column(name = "TVVIDEOPREVIEWURL")
  private String tvvideopreviewurl;
  @Size(max = 255)
  @Column(name = "TVVIDEOPREVIEWFILENAME")
  private String tvvideopreviewfilename;
  @Size(max = 255)
  @Column(name = "TVVIDEOAUTHORIZATIONDOCUMENTUR")
  private String tvvideoauthorizationdocumentur;
  @Column(name = "ADDDATETIME")
  @Temporal(TemporalType.TIMESTAMP)
  private Date adddatetime;
  @Column(name = "DELETEDATETIME")
  @Temporal(TemporalType.TIMESTAMP)
  private Date deletedatetime;
  @Column(name = "UPDATEDATETIME")
  @Temporal(TemporalType.TIMESTAMP)
  private Date updatedatetime;
  @Size(max = 255)
  @Column(name = "EVENTUSER")
  private String eventuser;
  @Column(name = "TVVIDEOORDERBY")
  private Long tvvideoorderby;
  @Size(max = 255)
  @Column(name = "TVVIDEOFILENAME")
  private String tvvideofilename;
  @Size(max = 255)
  @Column(name = "TVVIDEOWEBDISPLAY")
  private String tvvideowebdisplay;
  @Size(max = 1024)
  @Column(name = "TVVIDEOURL")
  private String tvvideourl;
  @Column(name = "UPDATEDATETIMESTATUS")
  @Temporal(TemporalType.TIMESTAMP)
  private Date updatedatetimestatus;
//  @OneToMany(cascade = CascadeType.ALL, mappedBy = "walterTvvideos")
//  private Set<WalterTvvideosfilesurls> walterTvvideosfilesurlsSet;
  @JoinColumn(name = "URLGUID", referencedColumnName = "URLGUID")
  @ManyToOne
  private WalterUrl urlguid;
  @JoinColumn(name = "PRODUCTVERSIONGUID", referencedColumnName = "PRODUCTVERSIONGUID")
  @ManyToOne
  private WalterProductsVersions productversionguid;
  @JoinColumn(name = "PRODUCTCOUNTRYGUID", referencedColumnName = "PRODUCTCOUNTRYGUID")
  @ManyToOne(optional = false)
  private WalterProductsCountries productcountryguid;
  @JoinColumn(name = "PRODUCTGUID", referencedColumnName = "PRODUCTGUID")
  @ManyToOne(optional = false)
  private WalterProducts productguid;
  @JoinColumn(name = "COUNTRYGUID", referencedColumnName = "INSTANCEGUID")
  @ManyToOne(optional = false)
  private OoInstances countryguid;
  @JoinColumn(name = "TVVIDEOGUID", referencedColumnName = "INSTANCEGUID", insertable = false, updatable = false)
  @OneToOne(optional = false)
  private OoInstances ooInstances;
  @JoinColumn(name = "LANGUAGEGUID", referencedColumnName = "INSTANCEGUID")
  @ManyToOne(optional = false)
  private OoInstances languageguid;

  public WalterTvvideos() {
  }

  public WalterTvvideos(String tvvideoguid) {
    this.tvvideoguid = tvvideoguid;
  }

  public String getTvvideoguid() {
    return tvvideoguid;
  }

  public void setTvvideoguid(String tvvideoguid) {
    this.tvvideoguid = tvvideoguid;
  }

  public String getTvvideoname() {
    return tvvideoname;
  }

  public void setTvvideoname(String tvvideoname) {
    this.tvvideoname = tvvideoname;
  }

  public String getTvvideoshortdescription() {
    return tvvideoshortdescription;
  }

  public void setTvvideoshortdescription(String tvvideoshortdescription) {
    this.tvvideoshortdescription = tvvideoshortdescription;
  }

  public String getTvvideolongdescription() {
    return tvvideolongdescription;
  }

  public void setTvvideolongdescription(String tvvideolongdescription) {
    this.tvvideolongdescription = tvvideolongdescription;
  }

  public String getTvvideotype() {
    return tvvideotype;
  }

  public void setTvvideotype(String tvvideotype) {
    this.tvvideotype = tvvideotype;
  }

  public String getTvvideoformat() {
    return tvvideoformat;
  }

  public void setTvvideoformat(String tvvideoformat) {
    this.tvvideoformat = tvvideoformat;
  }

  public String getTvvideourltext() {
    return tvvideourltext;
  }

  public void setTvvideourltext(String tvvideourltext) {
    this.tvvideourltext = tvvideourltext;
  }

  public Long getTvvideodurationnonedited() {
    return tvvideodurationnonedited;
  }

  public void setTvvideodurationnonedited(Long tvvideodurationnonedited) {
    this.tvvideodurationnonedited = tvvideodurationnonedited;
  }

  public Long getTvvideodurationedited() {
    return tvvideodurationedited;
  }

  public void setTvvideodurationedited(Long tvvideodurationedited) {
    this.tvvideodurationedited = tvvideodurationedited;
  }

  public String getTvvideoratio() {
    return tvvideoratio;
  }

  public void setTvvideoratio(String tvvideoratio) {
    this.tvvideoratio = tvvideoratio;
  }

  public String getTvvideoreporter() {
    return tvvideoreporter;
  }

  public void setTvvideoreporter(String tvvideoreporter) {
    this.tvvideoreporter = tvvideoreporter;
  }

  public String getTvvideoeditor() {
    return tvvideoeditor;
  }

  public void setTvvideoeditor(String tvvideoeditor) {
    this.tvvideoeditor = tvvideoeditor;
  }

  public String getTvvideocountry() {
    return tvvideocountry;
  }

  public void setTvvideocountry(String tvvideocountry) {
    this.tvvideocountry = tvvideocountry;
  }

  public Long getTvvideoreportercountry() {
    return tvvideoreportercountry;
  }

  public void setTvvideoreportercountry(Long tvvideoreportercountry) {
    this.tvvideoreportercountry = tvvideoreportercountry;
  }

  public Long getTvvideooriginallanguage() {
    return tvvideooriginallanguage;
  }

  public void setTvvideooriginallanguage(Long tvvideooriginallanguage) {
    this.tvvideooriginallanguage = tvvideooriginallanguage;
  }

  public Long getTvvideomaincustomer() {
    return tvvideomaincustomer;
  }

  public void setTvvideomaincustomer(Long tvvideomaincustomer) {
    this.tvvideomaincustomer = tvvideomaincustomer;
  }

  public Long getTvvideocustomer() {
    return tvvideocustomer;
  }

  public void setTvvideocustomer(Long tvvideocustomer) {
    this.tvvideocustomer = tvvideocustomer;
  }

  public String getTvvideosubtitles() {
    return tvvideosubtitles;
  }

  public void setTvvideosubtitles(String tvvideosubtitles) {
    this.tvvideosubtitles = tvvideosubtitles;
  }

  public String getTvvideostatus() {
    return tvvideostatus;
  }

  public void setTvvideostatus(String tvvideostatus) {
    this.tvvideostatus = tvvideostatus;
  }

  public String getTvvideoimageurl() {
    return tvvideoimageurl;
  }

  public void setTvvideoimageurl(String tvvideoimageurl) {
    this.tvvideoimageurl = tvvideoimageurl;
  }

  public String getTvvideoimagename() {
    return tvvideoimagename;
  }

  public void setTvvideoimagename(String tvvideoimagename) {
    this.tvvideoimagename = tvvideoimagename;
  }

  public String getTvvideopreviewurl() {
    return tvvideopreviewurl;
  }

  public void setTvvideopreviewurl(String tvvideopreviewurl) {
    this.tvvideopreviewurl = tvvideopreviewurl;
  }

  public String getTvvideopreviewfilename() {
    return tvvideopreviewfilename;
  }

  public void setTvvideopreviewfilename(String tvvideopreviewfilename) {
    this.tvvideopreviewfilename = tvvideopreviewfilename;
  }

  public String getTvvideoauthorizationdocumentur() {
    return tvvideoauthorizationdocumentur;
  }

  public void setTvvideoauthorizationdocumentur(String tvvideoauthorizationdocumentur) {
    this.tvvideoauthorizationdocumentur = tvvideoauthorizationdocumentur;
  }

  public Date getAdddatetime() {
    return adddatetime;
  }

  public void setAdddatetime(Date adddatetime) {
    this.adddatetime = adddatetime;
  }

  public Date getDeletedatetime() {
    return deletedatetime;
  }

  public void setDeletedatetime(Date deletedatetime) {
    this.deletedatetime = deletedatetime;
  }

  public Date getUpdatedatetime() {
    return updatedatetime;
  }

  public void setUpdatedatetime(Date updatedatetime) {
    this.updatedatetime = updatedatetime;
  }

  public String getEventuser() {
    return eventuser;
  }

  public void setEventuser(String eventuser) {
    this.eventuser = eventuser;
  }

  public Long getTvvideoorderby() {
    return tvvideoorderby;
  }

  public void setTvvideoorderby(Long tvvideoorderby) {
    this.tvvideoorderby = tvvideoorderby;
  }

  public String getTvvideofilename() {
    return tvvideofilename;
  }

  public void setTvvideofilename(String tvvideofilename) {
    this.tvvideofilename = tvvideofilename;
  }

  public String getTvvideowebdisplay() {
    return tvvideowebdisplay;
  }

  public void setTvvideowebdisplay(String tvvideowebdisplay) {
    this.tvvideowebdisplay = tvvideowebdisplay;
  }

  public String getTvvideourl() {
    return tvvideourl;
  }

  public void setTvvideourl(String tvvideourl) {
    this.tvvideourl = tvvideourl;
  }

  public Date getUpdatedatetimestatus() {
    return updatedatetimestatus;
  }

  public void setUpdatedatetimestatus(Date updatedatetimestatus) {
    this.updatedatetimestatus = updatedatetimestatus;
  }

//  @XmlTransient
//  public Set<WalterTvvideosfilesurls> getWalterTvvideosfilesurlsSet() {
//    return walterTvvideosfilesurlsSet;
//  }
//
//  public void setWalterTvvideosfilesurlsSet(Set<WalterTvvideosfilesurls> walterTvvideosfilesurlsSet) {
//    this.walterTvvideosfilesurlsSet = walterTvvideosfilesurlsSet;
//  }

  public WalterUrl getUrlguid() {
    return urlguid;
  }

  public void setUrlguid(WalterUrl urlguid) {
    this.urlguid = urlguid;
  }

  public WalterProductsVersions getProductversionguid() {
    return productversionguid;
  }

  public void setProductversionguid(WalterProductsVersions productversionguid) {
    this.productversionguid = productversionguid;
  }

  public WalterProductsCountries getProductcountryguid() {
    return productcountryguid;
  }

  public void setProductcountryguid(WalterProductsCountries productcountryguid) {
    this.productcountryguid = productcountryguid;
  }

  public WalterProducts getProductguid() {
    return productguid;
  }

  public void setProductguid(WalterProducts productguid) {
    this.productguid = productguid;
  }

  public OoInstances getCountryguid() {
    return countryguid;
  }

  public void setCountryguid(OoInstances countryguid) {
    this.countryguid = countryguid;
  }

  public OoInstances getOoInstances() {
    return ooInstances;
  }

  public void setOoInstances(OoInstances ooInstances) {
    this.ooInstances = ooInstances;
  }

  public OoInstances getLanguageguid() {
    return languageguid;
  }

  public void setLanguageguid(OoInstances languageguid) {
    this.languageguid = languageguid;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (tvvideoguid != null ? tvvideoguid.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof WalterTvvideos)) {
      return false;
    }
    WalterTvvideos other = (WalterTvvideos) object;
    if ((this.tvvideoguid == null && other.tvvideoguid != null) || (this.tvvideoguid != null && !this.tvvideoguid.equals(other.tvvideoguid))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.idb.WalterTvvideos[ tvvideoguid=" + tvvideoguid + " ]";
  }

}
