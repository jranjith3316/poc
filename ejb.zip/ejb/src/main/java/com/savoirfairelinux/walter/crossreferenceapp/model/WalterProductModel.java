/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.crossreferenceapp.model;

import java.io.Serializable;
import java.util.List;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;

/**
 *
 * @author jsgill
 */
public class WalterProductModel implements Serializable {
  private static final long serialVersionUID = 3511338233023397895L;
  private String tradename;
  private String description;
  private String productNumber;
  private String upc;
  private String format;
  private String metricSize;
  private String imperialSize;
  private String metricTemperature;
  private String imperialTemperature;
  private String voc;
  private String ph;
  private DocumentModel msdsDocument;
  private DocumentModel tdsDocument;
  private boolean elementFlame;
  private boolean elementGasCylinder;
  private boolean elementCorrosion;
  private boolean elementExclamation;
  private boolean elementHealth;
  private boolean elementEnvironment;
  private boolean elementSkull;
  private boolean elementFlameCircle;
  private boolean elementExplodingBomb;
  private String prop65;
  private String diluation;
  private List<String> materials;
  private List<HazardModel> physicalHazards;
  private List<HazardModel> healthHazards;
  private List<HazardModel> environmentalHazards;
  private List<String> certifications;
  private String imageUrl;
  private String action;
  private List<String> applications;

  public String getTradename() {
    return tradename;
  }

  public void setTradename(String tradename) {
    this.tradename = tradename;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getProductNumber() {
    return productNumber;
  }

  public void setProductNumber(String productNumber) {
    this.productNumber = productNumber;
  }

  public String getUpc() {
    return upc;
  }

  public void setUpc(String upc) {
    this.upc = upc;
  }

  public String getFormat() {
    return format;
  }

  public void setFormat(String format) {
    this.format = format;
  }

  public String getMetricSize() {
    return metricSize;
  }

  public void setMetricSize(String metricSize) {
    this.metricSize = metricSize;
  }

  public String getImperialSize() {
    return imperialSize;
  }

  public void setImperialSize(String imperialSize) {
    this.imperialSize = imperialSize;
  }

  public String getMetricTemperature() {
    return metricTemperature;
  }

  public void setMetricTemperature(String metricTemperature) {
    this.metricTemperature = metricTemperature;
  }

  public String getImperialTemperature() {
    return imperialTemperature;
  }

  public void setImperialTemperature(String imperialTemperature) {
    this.imperialTemperature = imperialTemperature;
  }

  public String getVoc() {
    return voc;
  }

  public void setVoc(String voc) {
    this.voc = voc;
  }

  public String getPh() {
    return ph;
  }

  public void setPh(String ph) {
    this.ph = ph;
  }

  public DocumentModel getMsdsDocument() {
    return msdsDocument;
  }

  public void setMsdsDocument(DocumentModel msdsDocument) {
    this.msdsDocument = msdsDocument;
  }

  public DocumentModel getTdsDocument() {
    return tdsDocument;
  }

  public void setTdsDocument(DocumentModel tdsDocument) {
    this.tdsDocument = tdsDocument;
  }

  public String getProp65() {
    return prop65;
  }

  public void setProp65(String prop65) {
    this.prop65 = prop65;
  }

  public String getDiluation() {
    return diluation;
  }

  public void setDiluation(String diluation) {
    this.diluation = diluation;
  }

  public boolean isElementFlame() {
    return elementFlame;
  }

  public void setElementFlame(boolean elementFlame) {
    this.elementFlame = elementFlame;
  }

  public boolean isElementGasCylinder() {
    return elementGasCylinder;
  }

  public void setElementGasCylinder(boolean elementGasCylinder) {
    this.elementGasCylinder = elementGasCylinder;
  }

  public boolean isElementCorrosion() {
    return elementCorrosion;
  }

  public void setElementCorrosion(boolean elementCorrosion) {
    this.elementCorrosion = elementCorrosion;
  }

  public boolean isElementExclamation() {
    return elementExclamation;
  }

  public void setElementExclamation(boolean elementExclamation) {
    this.elementExclamation = elementExclamation;
  }

  public boolean isElementHealth() {
    return elementHealth;
  }

  public void setElementHealth(boolean elementHealth) {
    this.elementHealth = elementHealth;
  }

  public boolean isElementEnvironment() {
    return elementEnvironment;
  }

  public void setElementEnvironment(boolean elementEnvironment) {
    this.elementEnvironment = elementEnvironment;
  }

  public boolean isElementSkull() {
    return elementSkull;
  }

  public void setElementSkull(boolean elementSkull) {
    this.elementSkull = elementSkull;
  }

  public boolean isElementFlameCircle() {
    return elementFlameCircle;
  }

  public void setElementFlameCircle(boolean elementFlameCircle) {
    this.elementFlameCircle = elementFlameCircle;
  }

  public boolean isElementExplodingBomb() {
    return elementExplodingBomb;
  }

  public void setElementExplodingBomb(boolean elementExplodingBomb) {
    this.elementExplodingBomb = elementExplodingBomb;
  }

  @XmlElementWrapper
  @XmlElement(name="material")
  public List<String> getMaterials() {
    return materials;
  }

  public void setMaterials(List<String> materials) {
    this.materials = materials;
  }

  @XmlElementWrapper
  @XmlElement(name="physicalHazard")
  public List<HazardModel> getPhysicalHazards() {
    return physicalHazards;
  }

  public void setPhysicalHazards(List<HazardModel> physicalHazards) {
    this.physicalHazards = physicalHazards;
  }

  @XmlElementWrapper
  @XmlElement(name="healthHazard")
  public List<HazardModel> getHealthHazards() {
    return healthHazards;
  }

  public void setHealthHazards(List<HazardModel> healthHazards) {
    this.healthHazards = healthHazards;
  }

  @XmlElementWrapper
  @XmlElement(name="environmentalHazard")
  public List<HazardModel> getEnvironmentalHazards() {
    return environmentalHazards;
  }

  public void setEnvironmentalHazards(List<HazardModel> environmentalHazards) {
    this.environmentalHazards = environmentalHazards;
  }

  @XmlElementWrapper
  @XmlElement(name="certification")
  public List<String> getCertifications() {
    return certifications;
  }

  public void setCertifications(List<String> certifications) {
    this.certifications = certifications;
  }

  public String getImageUrl() {
    return imageUrl;
  }

  public void setImageUrl(String imageUrl) {
    this.imageUrl = imageUrl;
  }

  public String getAction() {
    return action;
  }

  public void setAction(String action) {
    this.action = action;
  }

  @XmlElementWrapper
  @XmlElement(name="application")
  public List<String> getApplications() {
    return applications;
  }

  public void setApplications(List<String> applications) {
    this.applications = applications;
  }

}
