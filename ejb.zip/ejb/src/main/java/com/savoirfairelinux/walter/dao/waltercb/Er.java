/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.model.LabReportState;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Set;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "ER", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Er.findAll", query = "SELECT e FROM Er e"),
    @NamedQuery(name = "Er.findByErId", query = "SELECT e FROM Er e WHERE e.erId = :erId"),
    @NamedQuery(name = "Er.findByCreatorUserName", query = "SELECT e FROM Er e WHERE e.creatorUserName = :creatorUserName"),
    @NamedQuery(name = "Er.findByEntryDate", query = "SELECT e FROM Er e WHERE e.entryDate = :entryDate"),
    @NamedQuery(name = "Er.findByPublished", query = "SELECT e FROM Er e WHERE e.published = :published"),
    @NamedQuery(name = "Er.findByCancelDate", query = "SELECT e FROM Er e WHERE e.cancelDate = :cancelDate"),
    @NamedQuery(name = "Er.findByOriginalLangId", query = "SELECT e FROM Er e WHERE e.originalLangId = :originalLangId"),
    @NamedQuery(name = "Er.findByExpectingImg", query = "SELECT e FROM Er e WHERE e.expectingImg = :expectingImg"),
    @NamedQuery(name = "Er.findByErRef", query = "SELECT e FROM Er e WHERE e.erRef = :erRef"),
    @NamedQuery(name = "Er.findBySentToWs", query = "SELECT e FROM Er e WHERE e.sentToWs = :sentToWs"),
    @NamedQuery(name = "Er.findByPublishedDate", query = "SELECT e FROM Er e WHERE e.publishedDate = :publishedDate"),
    @NamedQuery(name = "Er.findByRequestedByUserName", query = "SELECT e FROM Er e WHERE e.requestedByUserName = :requestedByUserName")})
public class Er implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "ER_ID", nullable = false)
    @GeneratedValue(generator = "ER_ID_SEQ", strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "ER_ID_SEQ", sequenceName = "ER_ID_SEQ", schema = DatabaseConstants.WALTERCB_SCHEMA, allocationSize = 1)
    private Long erId;
    @Size(max = 256)
    @Column(name = "CREATOR_USER_NAME", length = 256)
    private String creatorUserName;
    @Column(name = "ENTRY_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date entryDate;
    @Column(name = "PUBLISHED")
    private String published;
    @Column(name = "CANCEL_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date cancelDate;
    @Column(name = "ORIGINAL_LANG_ID")
    private Long originalLangId;
    @Column(name = "EXPECTING_IMG")
    private String expectingImg;
    @Size(max = 20)
    @Column(name = "ER_REF", length = 20)
    private String erRef;
    @Column(name = "SENT_TO_WS")
    @Temporal(TemporalType.TIMESTAMP)
    private Date sentToWs;
    @Column(name = "PUBLISHED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date publishedDate;
    @Size(max = 256)
    @Column(name = "REQUESTED_BY_USER_NAME", length = 256)
    private String requestedByUserName;
    @Size(max = 100)
    private String organization;
    @Column(name = "IMAGE_ATTACHED")
    private Integer imageAttached;
    @Column(name = "FILE_ATTACHED")
    private Integer fileAttached;
    @Size(max = 40)
    @Column(name = "ADDRESS")
    private String address;
    @Size(max = 10)
    @Column(name = "POSTAL_CODE")
    private String postalCode;
    @Size(max = 40)
    @Column(name = "CITY")
    private String city;
    @Column(name = "PARTS_ID", precision = 22, scale = 6)
    private BigDecimal partsId;
    @Transient
    private String title;
    @Transient
    private String customer;
    @Transient
    private String contactName;
    @Transient
    private int read;
    @Transient
    private Long counter;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "er", orphanRemoval = true)
    private Set<ErCcRecipient> erCcRecipientSet;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "er", orphanRemoval = true)
    private Set<ErContaminant> erContaminantSet;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "er", orphanRemoval = true)
    private List<ErPicture> erPictureList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "er", orphanRemoval = true)
    private Set<ErTrial> erTrialSet;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "er", orphanRemoval = true)
    private Set<ErCounter> erCounterSet;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "er", orphanRemoval = true)
    private Set<ErTxt> erTxtSet;

    public Er() {
    }

    public Er(Long erId) {
        this.erId = erId;
    }

    public Long getErId() {
        return erId;
    }

    public void setErId(Long erId) {
        this.erId = erId;
    }

    public String getCreatorUserName() {
        return creatorUserName;
    }

    public void setCreatorUserName(String creatorUserName) {
        this.creatorUserName = creatorUserName;
    }

    public Date getEntryDate() {
        return entryDate;
    }

    public void setEntryDate(Date entryDate) {
        this.entryDate = entryDate;
    }

    public String getPublished() {
        return published;
    }

    public void setPublished(String published) {
        this.published = published;
    }

    public Date getCancelDate() {
        return cancelDate;
    }

    public void setCancelDate(Date cancelDate) {
        this.cancelDate = cancelDate;
    }

    public Long getOriginalLangId() {
        return originalLangId;
    }

    public void setOriginalLangId(Long originalLangId) {
        this.originalLangId = originalLangId;
    }

    public String getExpectingImg() {
        return expectingImg;
    }

    public void setExpectingImg(String expectingImg) {
        this.expectingImg = expectingImg;
    }

    public String getErRef() {
        return erRef;
    }

    public void setErRef(String erRef) {
        this.erRef = erRef;
    }

    public Date getSentToWs() {
        return sentToWs;
    }

    public void setSentToWs(Date sentToWs) {
        this.sentToWs = sentToWs;
    }

    public Date getPublishedDate() {
        return publishedDate;
    }

    public void setPublishedDate(Date publishedDate) {
        this.publishedDate = publishedDate;
    }

    public String getRequestedByUserName() {
        return requestedByUserName;
    }

    public void setRequestedByUserName(String requestedByUserName) {
        this.requestedByUserName = requestedByUserName;
    }

    public String getOrganization() {
        return organization;
    }

    public void setOrganization(String organization) {
        this.organization = organization;
    }

    public Integer getImageAttached() {
        return imageAttached;
    }

    public void setImageAttached(Integer imageAttached) {
        this.imageAttached = imageAttached;
    }

    public Integer getFileAttached() {
        return fileAttached;
    }

    public void setFileAttached(Integer fileAttached) {
        this.fileAttached = fileAttached;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public BigDecimal getPartsId() {
        return partsId;
    }

    public void setPartsId(BigDecimal partsId) {
        this.partsId = partsId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getRead() {
        return read;
    }

    public void setRead(int read) {
        this.read = read;
    }

    public Long getCounter() {
        return counter;
    }

    public void setCounter(Long counter) {
        this.counter = counter;
    }

    public String getCustomer() {
        return customer;
    }

    public void setCustomer(String customer) {
        this.customer = customer;
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    @XmlTransient
    public Set<ErCcRecipient> getErCcRecipientSet() {
        return erCcRecipientSet;
    }

    public void setErCcRecipientSet(Set<ErCcRecipient> erCcRecipientSet) {
        this.erCcRecipientSet = erCcRecipientSet;
    }

    @XmlTransient
    public Set<ErContaminant> getErContaminantSet() {
        return erContaminantSet;
    }

    public void setErContaminantSet(Set<ErContaminant> erContaminantSet) {
        this.erContaminantSet = erContaminantSet;
    }

    @XmlTransient
    public List<ErPicture> getErPictureList() {
        return erPictureList;
    }

    public void setErPictureList(List<ErPicture> erPictureList) {
        this.erPictureList = erPictureList;
    }

    @XmlTransient
    public Set<ErTrial> getErTrialSet() {
        return erTrialSet;
    }

    public void setErTrialSet(Set<ErTrial> erTrialSet) {
        this.erTrialSet = erTrialSet;
    }

    @XmlTransient
    public Set<ErCounter> getErCounterSet() {
        return erCounterSet;
    }

    public void setErCounterSet(Set<ErCounter> erCounterSet) {
        this.erCounterSet = erCounterSet;
    }

    @XmlTransient
    public Set<ErTxt> getErTxtSet() {
        return erTxtSet;
    }

    public void setErTxtSet(Set<ErTxt> erTxtSet) {
        this.erTxtSet = erTxtSet;
    }

    public LabReportState getState() {
        LabReportState state = LabReportState.UNSUBMIT;
        if (entryDate == null) {
            state = LabReportState.UNSUBMIT;
        } else if (publishedDate == null && sentToWs != null) {
            state = LabReportState.SUBMIT;
        } else if (publishedDate != null) {
            state = LabReportState.PUBLISH;
        }
        return state;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (erId != null ? erId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Er)) {
            return false;
        }
        Er other = (Er) object;
        if ((this.erId == null && other.erId != null) || (this.erId != null && !this.erId.equals(other.erId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.Er[ erId=" + erId + " ]";
    }
}
