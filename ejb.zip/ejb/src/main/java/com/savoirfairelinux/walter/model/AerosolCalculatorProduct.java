/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.model;

import java.io.Serializable;

/**
 *
 * @author jsgill
 */
public class AerosolCalculatorProduct implements Serializable {

  String productnumber;
  String productNumberKit;
  float startingKitLiquidMetric;
  float startingKitLiquidImperial;
  String aerosolProductNumber;
  int aerosolQty;
  float aerosolSizeMetric;
  float aerosolSizeImperial;

  public AerosolCalculatorProduct(String productnumber, String productNumberKit, float startingKitLiquidMetric, float startingKitLiquidImperial, String aerosolProductNumber, int aerosolQty, float aerosolSizeMetric, float aerosolSizeImperial) {
    this.productnumber = productnumber;
    this.productNumberKit = productNumberKit;
    this.startingKitLiquidMetric = startingKitLiquidMetric;
    this.startingKitLiquidImperial = startingKitLiquidImperial;
    this.aerosolProductNumber = aerosolProductNumber;
    this.aerosolQty = aerosolQty;
    this.aerosolSizeMetric = aerosolSizeMetric;
    this.aerosolSizeImperial = aerosolSizeImperial;
  }

  public String getProductnumber() {
    return productnumber;
  }

  public void setProductnumber(String productnumber) {
    this.productnumber = productnumber;
  }

  public String getProductNumberKit() {
    return productNumberKit;
  }

  public void setProductNumberKit(String productNumberKit) {
    this.productNumberKit = productNumberKit;
  }

  public float getStartingKitLiquidMetric() {
    return startingKitLiquidMetric;
  }

  public void setStartingKitLiquidMetric(float startingKitLiquidMetric) {
    this.startingKitLiquidMetric = startingKitLiquidMetric;
  }

  public float getStartingKitLiquidImperial() {
    return startingKitLiquidImperial;
  }

  public void setStartingKitLiquidImperial(float startingKitLiquidImperial) {
    this.startingKitLiquidImperial = startingKitLiquidImperial;
  }

  public String getAerosolProductNumber() {
    return aerosolProductNumber;
  }

  public void setAerosolProductNumber(String aerosolProductNumber) {
    this.aerosolProductNumber = aerosolProductNumber;
  }

  public int getAerosolQty() {
    return aerosolQty;
  }

  public void setAerosolQty(int aerosolQty) {
    this.aerosolQty = aerosolQty;
  }

  public float getAerosolSizeMetric() {
    return aerosolSizeMetric;
  }

  public void setAerosolSizeMetric(float aerosolSizeMetric) {
    this.aerosolSizeMetric = aerosolSizeMetric;
  }

  public float getAerosolSizeImperial() {
    return aerosolSizeImperial;
  }

  public void setAerosolSizeImperial(float aerosolSizeImperial) {
    this.aerosolSizeImperial = aerosolSizeImperial;
  }


}
