/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.jasper.model;

import java.io.Serializable;

/**
 *
 * @author jsgill
 */
public class JasperExpenseRptDBean implements Serializable {
  private String expenseDate;
  private String state;
  private String city;
  private String expenseType;
  private String detail;
  private int numberNight;
  private String subtotal;
  private String tax1;
  private String tax2;
  private String tax3;
  private String tips;
  private String total;
  private String deletedBy;

  public JasperExpenseRptDBean(String expenseDate, String state, String city, String expenseType, String detail, int numberNight, String total) {
    this.expenseDate = expenseDate;
    this.state = state;
    this.city = city;
    this.expenseType = expenseType;
    this.detail = detail;
    this.numberNight = numberNight;
    this.total = total;
  }

  public String getExpenseDate() {
    return expenseDate;
  }

  public void setExpenseDate(String expenseDate) {
    this.expenseDate = expenseDate;
  }

  public String getState() {
    return state;
  }

  public void setState(String state) {
    this.state = state;
  }

  public String getCity() {
    return city;
  }

  public void setCity(String city) {
    this.city = city;
  }

  public String getExpenseType() {
    return expenseType;
  }

  public void setExpenseType(String expenseType) {
    this.expenseType = expenseType;
  }

  public String getDetail() {
    return detail;
  }

  public void setDetail(String detail) {
    this.detail = detail;
  }

  public int getNumberNight() {
    return numberNight;
  }

  public void setNumberNight(int numberNight) {
    this.numberNight = numberNight;
  }

  public String getSubtotal() {
    return subtotal;
  }

  public void setSubtotal(String subtotal) {
    this.subtotal = subtotal;
  }

  public String getTax1() {
    return tax1;
  }

  public void setTax1(String tax1) {
    this.tax1 = tax1;
  }

  public String getTax2() {
    return tax2;
  }

  public void setTax2(String tax2) {
    this.tax2 = tax2;
  }

  public String getTax3() {
    return tax3;
  }

  public void setTax3(String tax3) {
    this.tax3 = tax3;
  }

  public String getTips() {
    return tips;
  }

  public void setTips(String tips) {
    this.tips = tips;
  }

  public String getTotal() {
    return total;
  }

  public void setTotal(String total) {
    this.total = total;
  }

  public String getDeletedBy() {
    return deletedBy;
  }

  public void setDeletedBy(String deletedBy) {
    this.deletedBy = deletedBy;
  }

}
