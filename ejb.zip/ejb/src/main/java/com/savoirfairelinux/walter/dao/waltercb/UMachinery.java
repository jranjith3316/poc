/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "U_MACHINERY", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "UMachinery.findAll", query = "SELECT u FROM UMachinery u"),
    @NamedQuery(name = "UMachinery.findByMachineryId", query = "SELECT u FROM UMachinery u WHERE u.uMachineryPK.machineryId = :machineryId"),
    @NamedQuery(name = "UMachinery.findByLangId", query = "SELECT u FROM UMachinery u WHERE u.uMachineryPK.langId = :langId ORDER BY u.machineryDesc"),
    @NamedQuery(name = "UMachinery.findByMachineryDesc", query = "SELECT u FROM UMachinery u WHERE u.machineryDesc = :machineryDesc")})
public class UMachinery implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected UMachineryPK uMachineryPK;
    @Size(max = 100)
    @Column(name = "MACHINERY_DESC")
    private String machineryDesc;

    public UMachinery() {
    }

    public UMachinery(UMachineryPK uMachineryPK) {
        this.uMachineryPK = uMachineryPK;
    }

    public UMachinery(long machineryId, short langId) {
        this.uMachineryPK = new UMachineryPK(machineryId, langId);
    }

    public UMachineryPK getUMachineryPK() {
        return uMachineryPK;
    }

    public void setUMachineryPK(UMachineryPK uMachineryPK) {
        this.uMachineryPK = uMachineryPK;
    }

    public String getMachineryDesc() {
        return machineryDesc;
    }

    public void setMachineryDesc(String machineryDesc) {
        this.machineryDesc = machineryDesc;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (uMachineryPK != null ? uMachineryPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof UMachinery)) {
            return false;
        }
        UMachinery other = (UMachinery) object;
        if ((this.uMachineryPK == null && other.uMachineryPK != null) || (this.uMachineryPK != null && !this.uMachineryPK.equals(other.uMachineryPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.UMachinery[ uMachineryPK=" + uMachineryPK + " ]";
    }
    
}
