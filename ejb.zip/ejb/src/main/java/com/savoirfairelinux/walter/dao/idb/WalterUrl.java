/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.idb;

import com.savoirfairelinux.walter.dao.DatabaseConstants;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "WALTER_URL", catalog = "", schema = DatabaseConstants.IDB_SCHEMA)
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "WalterUrl.findAll", query = "SELECT w FROM WalterUrl w"),
  @NamedQuery(name = "WalterUrl.findByUrlguid", query = "SELECT w FROM WalterUrl w WHERE w.urlguid = :urlguid"),
  @NamedQuery(name = "WalterUrl.findByUrl", query = "SELECT w FROM WalterUrl w WHERE w.url = :url"),
  @NamedQuery(name = "WalterUrl.findByDocumentType", query = "SELECT w FROM WalterUrl w WHERE w.documentType = :documentType"),
  @NamedQuery(name = "WalterUrl.findByAdddatetime", query = "SELECT w FROM WalterUrl w WHERE w.adddatetime = :adddatetime"),
  @NamedQuery(name = "WalterUrl.findByDeletedatetime", query = "SELECT w FROM WalterUrl w WHERE w.deletedatetime = :deletedatetime"),
  @NamedQuery(name = "WalterUrl.findByUpdatedatetime", query = "SELECT w FROM WalterUrl w WHERE w.updatedatetime = :updatedatetime"),
  @NamedQuery(name = "WalterUrl.findByWidth", query = "SELECT w FROM WalterUrl w WHERE w.width = :width"),
  @NamedQuery(name = "WalterUrl.findByHeight", query = "SELECT w FROM WalterUrl w WHERE w.height = :height")})
public class WalterUrl implements Serializable {
  private static final long serialVersionUID = 1L;
  @Id
  @Basic(optional = false)
  @NotNull
  @Size(min = 1, max = 255)
  @Column(name = "URLGUID")
  private String urlguid;
  @Size(max = 255)
  @Column(name = "URL")
  private String url;
  @Size(max = 255)
  @Column(name = "DOCUMENT_TYPE")
  private String documentType;
  @Column(name = "ADDDATETIME")
  @Temporal(TemporalType.TIMESTAMP)
  private Date adddatetime;
  @Column(name = "DELETEDATETIME")
  @Temporal(TemporalType.TIMESTAMP)
  private Date deletedatetime;
  @Column(name = "UPDATEDATETIME")
  @Temporal(TemporalType.TIMESTAMP)
  private Date updatedatetime;
  @Column(name = "WIDTH")
  private Short width;
  @Column(name = "HEIGHT")
  private Short height;
//  @OneToMany(mappedBy = "urlguid")
//  private Set<WalterProductsDocuments> walterProductsDocumentsSet;
//  @OneToMany(mappedBy = "urlguid")
//  private Set<WalterFiles> walterFilesSet;
//  @OneToMany(mappedBy = "urlguid")
//  private Set<WalterProductsImages> walterProductsImagesSet;
//  @OneToMany(mappedBy = "urlguid")
//  private Set<WalterTvvideos> walterTvvideosSet;
//  @OneToMany(mappedBy = "parenturlguid")
//  private Set<WalterUrl> walterUrlSet;
  @JoinColumn(name = "PARENTURLGUID", referencedColumnName = "URLGUID")
  @ManyToOne
  private WalterUrl parenturlguid;
  @JoinColumn(name = "COMPANYGUID", referencedColumnName = "COMPANYGUID")
  @ManyToOne(optional = false)
  private WalterCompanies companyguid;
  @JoinColumn(name = "URLGUID", referencedColumnName = "INSTANCEGUID", insertable = false, updatable = false)
  @OneToOne(optional = false)
  private OoInstances ooInstances;
  @JoinColumn(name = "PRODUCTLINEGUID", referencedColumnName = "INSTANCEGUID")
  @ManyToOne
  private OoInstances productlineguid;
  @JoinColumn(name = "COUNTRYGUID", referencedColumnName = "INSTANCEGUID")
  @ManyToOne(optional = false)
  private OoInstances countryguid;
  @JoinColumn(name = "LANGUAGEGUID", referencedColumnName = "INSTANCEGUID")
  @ManyToOne
  private OoInstances languageguid;

  public WalterUrl() {
  }

  public WalterUrl(String urlguid) {
    this.urlguid = urlguid;
  }

  public String getUrlguid() {
    return urlguid;
  }

  public void setUrlguid(String urlguid) {
    this.urlguid = urlguid;
  }

  public String getUrl() {
    return url;
  }

  public void setUrl(String url) {
    this.url = url;
  }

  public String getDocumentType() {
    return documentType;
  }

  public void setDocumentType(String documentType) {
    this.documentType = documentType;
  }

  public Date getAdddatetime() {
    return adddatetime;
  }

  public void setAdddatetime(Date adddatetime) {
    this.adddatetime = adddatetime;
  }

  public Date getDeletedatetime() {
    return deletedatetime;
  }

  public void setDeletedatetime(Date deletedatetime) {
    this.deletedatetime = deletedatetime;
  }

  public Date getUpdatedatetime() {
    return updatedatetime;
  }

  public void setUpdatedatetime(Date updatedatetime) {
    this.updatedatetime = updatedatetime;
  }

  public Short getWidth() {
    return width;
  }

  public void setWidth(Short width) {
    this.width = width;
  }

  public Short getHeight() {
    return height;
  }

  public void setHeight(Short height) {
    this.height = height;
  }

//  @XmlTransient
//  public Set<WalterProductsDocuments> getWalterProductsDocumentsSet() {
//    return walterProductsDocumentsSet;
//  }
//
//  public void setWalterProductsDocumentsSet(Set<WalterProductsDocuments> walterProductsDocumentsSet) {
//    this.walterProductsDocumentsSet = walterProductsDocumentsSet;
//  }
//
//  @XmlTransient
//  public Set<WalterFiles> getWalterFilesSet() {
//    return walterFilesSet;
//  }
//
//  public void setWalterFilesSet(Set<WalterFiles> walterFilesSet) {
//    this.walterFilesSet = walterFilesSet;
//  }
//
//  @XmlTransient
//  public Set<WalterProductsImages> getWalterProductsImagesSet() {
//    return walterProductsImagesSet;
//  }
//
//  public void setWalterProductsImagesSet(Set<WalterProductsImages> walterProductsImagesSet) {
//    this.walterProductsImagesSet = walterProductsImagesSet;
//  }
//
//  @XmlTransient
//  public Set<WalterTvvideos> getWalterTvvideosSet() {
//    return walterTvvideosSet;
//  }
//
//  public void setWalterTvvideosSet(Set<WalterTvvideos> walterTvvideosSet) {
//    this.walterTvvideosSet = walterTvvideosSet;
//  }
//
//  @XmlTransient
//  public Set<WalterUrl> getWalterUrlSet() {
//    return walterUrlSet;
//  }
//
//  public void setWalterUrlSet(Set<WalterUrl> walterUrlSet) {
//    this.walterUrlSet = walterUrlSet;
//  }

  public WalterUrl getParenturlguid() {
    return parenturlguid;
  }

  public void setParenturlguid(WalterUrl parenturlguid) {
    this.parenturlguid = parenturlguid;
  }

  public WalterCompanies getCompanyguid() {
    return companyguid;
  }

  public void setCompanyguid(WalterCompanies companyguid) {
    this.companyguid = companyguid;
  }

  public OoInstances getOoInstances() {
    return ooInstances;
  }

  public void setOoInstances(OoInstances ooInstances) {
    this.ooInstances = ooInstances;
  }

  public OoInstances getProductlineguid() {
    return productlineguid;
  }

  public void setProductlineguid(OoInstances productlineguid) {
    this.productlineguid = productlineguid;
  }

  public OoInstances getCountryguid() {
    return countryguid;
  }

  public void setCountryguid(OoInstances countryguid) {
    this.countryguid = countryguid;
  }

  public OoInstances getLanguageguid() {
    return languageguid;
  }

  public void setLanguageguid(OoInstances languageguid) {
    this.languageguid = languageguid;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (urlguid != null ? urlguid.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof WalterUrl)) {
      return false;
    }
    WalterUrl other = (WalterUrl) object;
    if ((this.urlguid == null && other.urlguid != null) || (this.urlguid != null && !this.urlguid.equals(other.urlguid))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.idb.WalterUrl[ urlguid=" + urlguid + " ]";
  }

}
