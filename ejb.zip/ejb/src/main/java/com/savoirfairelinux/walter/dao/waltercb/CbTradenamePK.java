/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

/**
 *
 * @author mgubaidullin
 */
@Embeddable
public class CbTradenamePK implements Serializable {
    @Basic(optional = false)
    @NotNull
    @Column(name = "TRADENAME_ID")
    private long tradenameId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "FRANCHISE_ID")
    private short franchiseId;

    public CbTradenamePK() {
    }

    public CbTradenamePK(long tradenameId, short franchiseId) {
        this.tradenameId = tradenameId;
        this.franchiseId = franchiseId;
    }

    public long getTradenameId() {
        return tradenameId;
    }

    public void setTradenameId(long tradenameId) {
        this.tradenameId = tradenameId;
    }

    public short getFranchiseId() {
        return franchiseId;
    }

    public void setFranchiseId(short franchiseId) {
        this.franchiseId = franchiseId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) tradenameId;
        hash += (int) franchiseId;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CbTradenamePK)) {
            return false;
        }
        CbTradenamePK other = (CbTradenamePK) object;
        if (this.tradenameId != other.tradenameId) {
            return false;
        }
        if (this.franchiseId != other.franchiseId) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.CbTradenamePK[ tradenameId=" + tradenameId + ", franchiseId=" + franchiseId + " ]";
    }
    
}
