/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.service.impl;

import com.liferay.portal.kernel.workflow.WorkflowConstants;
import com.savoirfairelinux.walter.dao.walter.DistributorLocator;
import com.savoirfairelinux.walter.dao.walter.DistributorLocatorConfig;
import com.savoirfairelinux.walter.dao.walter.DistributorPromoConfig;
import com.savoirfairelinux.walter.service.DistributorLocatorBeanRemote;
import com.savoirfairelinux.walter.util.CSV;
import com.savoirfairelinux.walter.util.UploadDistributorLocator;
import com.walter.liferay.portal.kernel.repository.model.FileEntrySoap;
import com.walter.liferay.portal.model.UserSoap;
import com.walter.liferay.portal.service.ServiceContext;
import com.walter.liferay.portal.service.http.UserServiceSoap;
import com.walter.liferay.portal.service.http.UserServiceSoapServiceLocator;
import com.walter.liferay.portlet.documentlibrary.model.DLFolderSoap;
import com.walter.liferay.portlet.documentlibrary.service.http.DLAppServiceSoap;
import com.walter.liferay.portlet.documentlibrary.service.http.DLAppServiceSoapServiceLocator;
import com.walter.liferay.portlet.documentlibrary.service.http.DLFolderServiceSoap;
import com.walter.liferay.portlet.documentlibrary.service.http.DLFolderServiceSoapServiceLocator;
import java.io.IOException;
import java.net.URL;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.security.PermitAll;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author jsgill
 */
@Stateless(name = "DistributorLocatorBean")
@TransactionManagement(TransactionManagementType.CONTAINER)
@PermitAll
@LocalBean
public class DistributorLocatorBean implements DistributorLocatorBeanRemote {

  public static final Logger LOG = Logger.getLogger(DistributorLocatorBeanRemote.class.getCanonicalName());
  @PersistenceContext(unitName = "waltershare")
  EntityManager entityManager;
  @EJB
  SingletonBean singletonBean;
  @EJB
  WalterBean walterBean;

  @Override
  public List<DistributorLocator> getAll() {

    List<DistributorLocator> result = null;
    try {

      result = entityManager.createNamedQuery("DistributorLocator.findAll", DistributorLocator.class)
              .getResultList();

    } catch (Exception e) {
      LOG.severe(e.getMessage());
    }
    return result;
  }

  @Override
  public List<DistributorLocator> getDistributorList(String keyword, String country, boolean missingGeo) {
    List<DistributorLocator> result = null;
    try {

      String sql = singletonBean.getDistributorLocator("distributor.seach");

      if (missingGeo == true) {
        sql += " and (dl.latitude is null or dl.longitude is null or dl.latitude = 0 or dl.longitude = 0)";
      }
//      else if (missingGeo == false) {
//        sql += " and (dl.latitude is not null or dl.longitude is not null)";
//      }

      result = entityManager.createQuery(sql, DistributorLocator.class)
              .setParameter("keyword", "%" + keyword.toLowerCase() + "%")
              .setParameter("country", "%" + country + "%")
              .getResultList();

    } catch (Exception e) {
      LOG.severe(e.getMessage());
    }
    return result;
  }

  @Override
  public List<DistributorLocator> getDistributorPromo(String promoCode, String country, String saGroup) {
    List<DistributorLocator> resultTotal = new ArrayList<>();
    List<DistributorLocator> result1 = new ArrayList<>();
    List<DistributorLocator> result2 = new ArrayList<>();
    List<DistributorLocator> result3 = new ArrayList<>();
    try {
      result1 = entityManager.createQuery(singletonBean.getDistributorLocator("distributorPromo.getList"), DistributorLocator.class)
                                 .setParameter("promoCode", promoCode.toLowerCase() + "%")
                                 .setParameter("country", country)
                                 .getResultList();

      result2 = entityManager.createQuery(singletonBean.getDistributorLocator("distributorPromo.getList2"), DistributorLocator.class)
                                 .setParameter("promoCode", promoCode.toLowerCase() + "%")
                                 .setParameter("country", country)
                                 .getResultList();

      if ( saGroup != null ){

        List<String> saGroupList = new ArrayList<String>(Arrays.asList(saGroup.split(",")));

        System.out.println("get value");
        result3 = entityManager.createQuery(singletonBean.getDistributorLocator("distributorPromo.getListSaGroup"), DistributorLocator.class)
                              .setParameter("saGR", saGroupList)
                              .setParameter("country", country)
                              .getResultList();
      }

      resultTotal.addAll(result1);
      resultTotal.addAll(result2);
      resultTotal.addAll(result3);

      removeDuplicate(resultTotal);

    } catch (Exception e) {
      LOG.severe("getDistributorPromo: " + e.getMessage());
    }
    return resultTotal;
  }

  public static <DistributorLocator> void removeDuplicate(List <DistributorLocator> list) {
    Set <DistributorLocator> set = new HashSet <DistributorLocator>();
    List<DistributorLocator> newList = new ArrayList <DistributorLocator>();
    for (Iterator <DistributorLocator>iter = list.iterator();    iter.hasNext(); ) {
       Object element = iter.next();
       if (set.add((DistributorLocator) element))
          newList.add((DistributorLocator) element);
       }
       list.clear();
       list.addAll(newList);
    }

  public List<DistributorLocatorConfig> getDistributorConfig() {
    List<DistributorLocatorConfig> distributorLocatorConfigs = new ArrayList<>();

    try {

      distributorLocatorConfigs = entityManager.createQuery(singletonBean.getDistributorLocator("DistributorLocatorConfig.all"), DistributorLocatorConfig.class)
              .getResultList();

    } catch (Exception e) {
      LOG.severe(e.getMessage());
    }

    return distributorLocatorConfigs;
  }

  public Long getNextDistributorConfigId() {
    Long id = 0L;

    try {

      id = entityManager.createQuery(singletonBean.getDistributorLocator("DistributorLocatorConfig.nextId"), Long.class)
              .getSingleResult();

    } catch (Exception e) {
      LOG.severe(e.getMessage());
    }

    return id;
  }

//  @Schedule(hour = "*", minute = "*", second = "*/60", persistent = false)
  @Override
  public void createDistributorLocator() {

    CSV csv = null;

    List<DistributorLocatorConfig> distributorLocatorConfigs = getDistributorConfig();

    for ( DistributorLocatorConfig dlc : distributorLocatorConfigs ){
      String[] countryList = dlc.getCountry().replace("\"", "").split(",");

      csv = updateCSV(countryList);
      uploadLiferay("distributorLocator%40walter.com", "wlt5977", dlc.getGroupId(), dlc.getFolderName(), dlc.getFileName(), csv);

    }

  }

/**
 * Create the CSV for all promo code.
 */
  @Override
  public void createPromoCSVFile() {
    CSV csv = null;

    List<DistributorPromoConfig> distributorLocatorConfigs = getPromoExport();

    for ( DistributorPromoConfig dpc : distributorLocatorConfigs ){
      csv = updateCSV(dpc.getPromoCode(), "Canada", dpc.getSaGroup());
      uploadLiferay("distributorLocator%40walter.com", "wlt5977", dpc.getGroupId(), dpc.getFolderName(), dpc.getFileName(), csv);

    }


  }


  public void saveDistributorConfig(DistributorLocatorConfig distributorLocatorConfig) {

    if ( distributorLocatorConfig.getId() == null ){
      distributorLocatorConfig.setId(getNextDistributorConfigId());
      distributorLocatorConfig.setCreationDate(new Date());
    }

    entityManager.merge(distributorLocatorConfig);
  }


  /**
   * Upload distributorLocator for Canada and USA
   */
  private CSV updateCSV(String[] countryList) {
    List<DistributorLocator> distributorLocatorList = new ArrayList<>();
    CSV csv= null;

    for (String country : countryList) {
      List<DistributorLocator> dlListTemp = getDistributorList("", country, false);
      distributorLocatorList.addAll(dlListTemp);
    }

    csv = createCSV(distributorLocatorList);

    return csv;
  }


  /**
   * Upload distributorLocator for promotion
   */
  private CSV updateCSV(String promoCode, String country, String saGroup) {
    List<DistributorLocator> distributorLocatorList = new ArrayList<>();
    CSV csv= null;

    distributorLocatorList = getDistributorPromo(promoCode, country, saGroup);

    csv = createCSV(distributorLocatorList);

    return csv;
  }


  private CSV createCSV(List<DistributorLocator> distributorLocatorList) {
    String columnName = "\"Fcilty_typ\",\"State\",\"Fcilty_nam\",\"Shp_num_an\",\"Shp_centre\",\"Street_add\",\"Locality\",\"Postcode\",\"Country\",\"Phone\",\"Fax\",\"email\",\"website\",\"Hrs_of_bus\",\"Display_wd\",\"Fcilty_typ_2\",\"Xcoord\",\"Ycoord\",\"uuid\",\"result\"";

    CSV csv = null;
    try {

      csv = new CSV("export1.csv", "", columnName, ',', '"');

      for (DistributorLocator dl : distributorLocatorList) {

        List<String> stList = new ArrayList<>();

        stList.add("");
        stList.add((dl.getState() != null) ? dl.getState() : "");
        stList.add((dl.getFacilityName() != null) ? dl.getFacilityName() : "");
        stList.add((dl.getCustNum() != null) ? dl.getCustNum() : "");
        stList.add((dl.getShipNum() != null) ? dl.getShipNum() : "");
        stList.add((dl.getAddress() != null) ? dl.getAddress() : "");
        stList.add((dl.getCity() != null) ? dl.getCity() : "");
        stList.add((dl.getPostalCode() != null) ? dl.getPostalCode() : "");
        stList.add((dl.getCountry() != null) ? dl.getCountry() : "");
        stList.add((dl.getPhone() != null) ? dl.getPhone() : "");
        stList.add((dl.getFax() != null) ? dl.getFax() : "");
        stList.add((dl.getEmail() != null) ? dl.getEmail() : "");
        stList.add((dl.getWebsite()!= null) ? dl.getWebsite() : "");
        stList.add("");
        stList.add("");
        stList.add("");
        stList.add((dl.getLongitude() != null) ? dl.getLongitude().toString() : "");
        stList.add((dl.getLatitude() != null) ? dl.getLatitude().toString() : "");
        stList.add(dl.getUuid());

        csv.writeLine(stList);

      }
      csv.saveFile();
      csv.closeFile();
    } catch (IOException ex) {
      LOG.getLogger(UploadDistributorLocator.class.getName()).log(Level.SEVERE, null, ex);
    }
    return csv;
  }

  private void uploadLiferay(String username, String password, long groupId, String folderName, String fileName, CSV csv) {
    try {
      UserServiceSoapServiceLocator locatorUser = new UserServiceSoapServiceLocator();
      String login = username;
      UserServiceSoap userSoap = locatorUser.getPortal_UserService(_getURL(login, password, "Portal_UserService"));
      UserSoap soapUserModel = userSoap.getCurrentUser();

      DLFolderServiceSoapServiceLocator folderLocator = new DLFolderServiceSoapServiceLocator();
      DLFolderServiceSoap dlSoap = folderLocator.getPortlet_DL_DLFolderService(_getURL(login, password, "Portlet_DL_DLFolderService"));
      DLFolderSoap dlfolder = dlSoap.getFolder(groupId, 0, folderName);

      DLAppServiceSoapServiceLocator serviceLocator = new DLAppServiceSoapServiceLocator();
      DLAppServiceSoap dls = serviceLocator.getPortlet_DL_DLAppService(_getURL(login, password, "Portlet_DL_DLAppService"));

      byte[] bytes = csv.getBaos().toByteArray();

      ServiceContext serviceContext = new ServiceContext();
      serviceContext.setWorkflowAction(WorkflowConstants.ACTION_PUBLISH);
      serviceContext.setAddGuestPermissions(true);
      serviceContext.setScopeGroupId(dlfolder.getGroupId());//   ScopeGroupId(dlfolder.getGroupId());
      serviceContext.setCompanyId(soapUserModel.getCompanyId());
      serviceContext.setUserId(soapUserModel.getUserId());

      FileEntrySoap fileExist = null;

      try {
        fileExist = dls.getFileEntry(dlfolder.getGroupId(), dlfolder.getFolderId(), fileName);
      } catch (RemoteException rmi) {
        // check if file exist udate else add
      }

      if (fileExist != null && fileExist.getFileEntryId() != 0) {
        dls.updateFileEntry(fileExist.getFileEntryId(), fileName, "text/csv", fileName, "", fileExist.getVersion(), false, bytes, serviceContext);
      } else {
        FileEntrySoap newFile = dls.addFileEntry(dlfolder.getRepositoryId(), dlfolder.getFolderId(), fileName, "text/csv", fileName, "", null, bytes, serviceContext);
      }

    } catch (Exception e) {
      System.out.println("catch exception e.getMessage():" + e.getMessage());
    }
  }

  private static URL _getURL(String remoteUser, String password, String serviceName) throws Exception {
    String url = "https://" + remoteUser + ":" + password + "@walter.com:8443/api/axis/" + serviceName;

    return new URL(url);
  }


  public List<DistributorPromoConfig> getDistributorPromoConfig(){
    List<DistributorPromoConfig> distributorPromoConfigList = new ArrayList<>();

    try{

      distributorPromoConfigList = entityManager.createQuery(singletonBean.getDistributorLocator("DistributorPromoConfig.all"), DistributorPromoConfig.class)
                                                .getResultList();



    } catch (Exception e) {
      LOG.severe("getDistributorPromoConfig: " + e.getMessage());
    }

    return distributorPromoConfigList;
  }

  @Override
  public List<String> getPromoCodeList(String country){
    List<String> promoCodeList = new ArrayList<>();

    try{
      promoCodeList = entityManager.createQuery(singletonBean.getDistributorLocator("DistributorPromoConfig.getPromoCode"), String.class)
                                   .setParameter("country", country)
                                   .getResultList();
    } catch (Exception e) {
      LOG.severe("getPromoCodeList: " + e.getMessage());
    }

    return promoCodeList;
  }

  public List<DistributorPromoConfig> getPromoExport(){
    List<DistributorPromoConfig> distributorPromoConfigList = new ArrayList<>();

    try{
      distributorPromoConfigList = entityManager.createQuery(singletonBean.getDistributorLocator("DistributorPromoConfig.getActiveExport"), DistributorPromoConfig.class)
                                                .getResultList();
    } catch (Exception e) {
      LOG.severe("getPromoExport: " + e.getMessage());
    }

    return distributorPromoConfigList;
  }


  public void deleteDistributorLocator(DistributorLocator dl){
    try{

//      entityManager.createNativeQuery(singletonBean.getDistributorLocator("DistributorLocator.deleteEntry"))
//                   .setParameter("uuid", dl.getUuid())
//                   .executeUpdate();
      DistributorLocator dlDelete = entityManager.createNamedQuery("DistributorLocator.findByUuid", DistributorLocator.class)
                                                 .setParameter("uuid", dl.getUuid())
                                                 .getSingleResult();

      entityManager.remove(dlDelete);

    } catch( Exception e ){
      e.printStackTrace();
      LOG.severe("deleteDistributorLocator: " + e.getMessage());
    }
  }
}
