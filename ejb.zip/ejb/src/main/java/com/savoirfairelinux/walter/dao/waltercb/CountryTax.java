/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "COUNTRY_TAX", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CountryTax.findAll", query = "SELECT c FROM CountryTax c"),
    @NamedQuery(name = "CountryTax.findByCountryId", query = "SELECT c FROM CountryTax c WHERE c.countryTaxPK.countryId = :countryId"),
    @NamedQuery(name = "CountryTax.findByTaxCode", query = "SELECT c FROM CountryTax c WHERE c.countryTaxPK.taxCode = :taxCode"),
    @NamedQuery(name = "CountryTax.findByStartDate", query = "SELECT c FROM CountryTax c WHERE c.countryTaxPK.startDate = :startDate"),
    @NamedQuery(name = "CountryTax.findByTaxRate", query = "SELECT c FROM CountryTax c WHERE c.taxRate = :taxRate"),
    @NamedQuery(name = "CountryTax.findByGlCode", query = "SELECT c FROM CountryTax c WHERE c.glCode = :glCode"),
    @NamedQuery(name = "CountryTax.findByTaxCalMode", query = "SELECT c FROM CountryTax c WHERE c.taxCalMode = :taxCalMode")})
public class CountryTax implements Serializable {
  @Column(name = "REBATE_RATES")
  private BigDecimal rebateRates;
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected CountryTaxPK countryTaxPK;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "TAX_RATE")
    private BigDecimal taxRate;
    @Size(max = 10)
    @Column(name = "GL_CODE")
    private String glCode;
    @Size(max = 1)
    @Column(name = "TAX_CAL_MODE")
    private String taxCalMode;

    public CountryTax() {
    }

    public CountryTax(CountryTaxPK countryTaxPK) {
        this.countryTaxPK = countryTaxPK;
    }

    public CountryTax(short countryId, String taxCode, Date startDate) {
        this.countryTaxPK = new CountryTaxPK(countryId, taxCode, startDate);
    }

    public CountryTaxPK getCountryTaxPK() {
        return countryTaxPK;
    }

    public void setCountryTaxPK(CountryTaxPK countryTaxPK) {
        this.countryTaxPK = countryTaxPK;
    }

    public BigDecimal getTaxRate() {
        return taxRate;
    }

    public void setTaxRate(BigDecimal taxRate) {
        this.taxRate = taxRate;
    }

    public String getGlCode() {
        return glCode;
    }

    public void setGlCode(String glCode) {
        this.glCode = glCode;
    }

    public String getTaxCalMode() {
        return taxCalMode;
    }

    public void setTaxCalMode(String taxCalMode) {
        this.taxCalMode = taxCalMode;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (countryTaxPK != null ? countryTaxPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CountryTax)) {
            return false;
        }
        CountryTax other = (CountryTax) object;
        if ((this.countryTaxPK == null && other.countryTaxPK != null) || (this.countryTaxPK != null && !this.countryTaxPK.equals(other.countryTaxPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.CountryTax[ countryTaxPK=" + countryTaxPK + " ]";
    }

  public BigDecimal getRebateRates() {
    return rebateRates;
  }

  public void setRebateRates(BigDecimal rebateRates) {
    this.rebateRates = rebateRates;
  }
    
}
