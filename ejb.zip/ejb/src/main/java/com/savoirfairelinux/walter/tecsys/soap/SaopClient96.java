/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.tecsys.soap;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import org.w3c.dom.Document;

/**
 *
 * @author jsgill
 */
public class SaopClient96 {

  private String url = "https://lxwstapp1.tecsys.cloud/walter_96x_prod/ws/DmsWebService";
  private String wsURL = "http://ws.dms.tecsys.com/";
  private String wscURL = "wsclient.dms.tecsys.com";
  private String userName;
  private String password;
  private String viewName;
  private List<Parameter> paramList;

  public String getUrl() {
    return url;
  }

  public void setUrl(String url) {
    this.url = url;
  }

  public String getWsURL() {
    return wsURL;
  }

  public void setWsURL(String wsURL) {
    this.wsURL = wsURL;
  }

  public String getWscURL() {
    return wscURL;
  }

  public void setWscURL(String wscURL) {
    this.wscURL = wscURL;
  }

  public String getUserName() {
    return userName;
  }

  public void setUserName(String userName) {
    this.userName = userName;
  }

  public String getPassword() {
    return password;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  public String getViewName() {
    return viewName;
  }

  public void setViewName(String viewName) {
    this.viewName = viewName;
  }

  public List<Parameter> getParamList() {
    return paramList;
  }

  public void setParamList(List<Parameter> paramList) {
    this.paramList = paramList;
  }

  public Document searchRequest() {
    Document doc = null;
    try {

      SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory.newInstance();
      SOAPConnection soapConnection = soapConnectionFactory.createConnection();

      SOAPMessage soapResponse = soapConnection.call(createSOAPRequest(), url);
      SOAPPart soapPart = soapResponse.getSOAPPart();
      // SOAP Envelope
      SOAPEnvelope envelope = soapPart.getEnvelope();
      doc = envelope.getOwnerDocument();
//      soapResponse.writeTo(System.out);

    } catch (SOAPException ex) {
      Logger.getLogger(SaopClient96.class.getName()).log(Level.SEVERE, null, ex);
    } catch (UnsupportedOperationException ex) {
      Logger.getLogger(SaopClient96.class.getName()).log(Level.SEVERE, null, ex);
    } catch (Exception ex) {
      Logger.getLogger(SaopClient96.class.getName()).log(Level.SEVERE, null, ex);
    }
    return doc;
  }

  private SOAPMessage createSOAPRequest() throws Exception {
    MessageFactory messageFactory = MessageFactory.newInstance();
    SOAPMessage soapMessage = messageFactory.createMessage();
    SOAPPart soapPart = soapMessage.getSOAPPart();
    // SOAP Envelope
    SOAPEnvelope envelope = soapPart.getEnvelope();
//    envelope.addNamespaceDeclaration("example", serverURI);
    envelope.addNamespaceDeclaration("ws", getWsURL());
    envelope.addNamespaceDeclaration("wsc", getWscURL());

    SOAPBody soapBody = envelope.getBody();

    SOAPElement soapBodyElem = soapBody.addChildElement("search", "wsc");

    SOAPElement argElement = soapBodyElem.addChildElement("arg0","");

    SOAPElement soapBodyElem1 = argElement.addChildElement("userName");
    soapBodyElem1.addTextNode(getUserName());
    SOAPElement soapBodyElem2 = argElement.addChildElement("password");
    soapBodyElem2.addTextNode(getPassword());

    SOAPElement criteriaElement = argElement.addChildElement("criteria");

    SOAPElement viewNameElement = criteriaElement.addChildElement(getViewName());

    for (Parameter param : getParamList()) {
      SOAPElement param1Element = viewNameElement.addChildElement(param.getParamName());
      param1Element.addTextNode(param.getValue());
    }

    MimeHeaders headers = soapMessage.getMimeHeaders();
//    headers.addHeader("SOAPAction", serverURI + "VerifyEmail");

    soapMessage.saveChanges();

    /* Print the request message */
//    System.out.println("Request SOAP Message:");
//    soapMessage.writeTo(System.out);
//    System.out.println("");
//    System.out.println("------");

    return soapMessage;
  }
}
