/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import java.math.BigInteger;
import java.util.Set;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "IDEA_FILE", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "IdeaFile.findAll", query = "SELECT i FROM IdeaFile i"),
    @NamedQuery(name = "IdeaFile.findByIdeaId", query = "SELECT i FROM IdeaFile i WHERE i.idea.ideaId = :ideaId"),
    @NamedQuery(name = "IdeaFile.findByFileId", query = "SELECT i FROM IdeaFile i WHERE i.fileId = :fileId"),
    @NamedQuery(name = "IdeaFile.findByExtVisible", query = "SELECT i FROM IdeaFile i WHERE i.extVisible = :extVisible"),
    @NamedQuery(name = "IdeaFile.findByOriginalFile", query = "SELECT i FROM IdeaFile i WHERE i.originalFile = :originalFile"),
    @NamedQuery(name = "IdeaFile.findByType", query = "SELECT i FROM IdeaFile i WHERE i.type = :type")})
public class IdeaFile implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "FILE_ID")
    @GeneratedValue(generator = "IDEA_FILE_SEQ", strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "IDEA_FILE_SEQ", sequenceName = "IDEA_FILE_SEQ", schema = DatabaseConstants.WALTERCB_SCHEMA, allocationSize = 1)
    private Long fileId;
    @Column(name = "EXT_VISIBLE")
    private Character extVisible;
    @Column(name = "ORIGINAL_FILE")
    private Character originalFile;
    @Size(max = 256)
    @Deprecated
    private String filetype;
    @Size(max = 350)
    @Column(name = "REAL_FILENAME")
    private String realFilename;
    @Size(max = 48)
    @Column(name = "MIME_TYPE")
    private String mimeType;
    @Column(name = "DOC_SIZE")
    private BigInteger docSize;
    @Lob
    @Column(name = "BLOB_CONTENT")
    private byte[] blobContent;
    @Size(max = 1)
    @Column(name = "TYPE")
    private String type;
    @JoinColumn(name = "IDEA_ID", referencedColumnName = "IDEA_ID")
    @ManyToOne(optional = false)
    private Idea idea;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "ideaFile", fetch = FetchType.EAGER)
    private Set<IdeaFileTxt> ideaFileTxtSet;

    public IdeaFile() {
    }

    public Long getFileId() {
        return fileId;
    }

    public void setFileId(Long fileId) {
        this.fileId = fileId;
    }

    public Character getExtVisible() {
        return extVisible;
    }

    public void setExtVisible(Character extVisible) {
        this.extVisible = extVisible;
    }

    public Character getOriginalFile() {
        return originalFile;
    }

    public void setOriginalFile(Character originalFile) {
        this.originalFile = originalFile;
    }

    public String getFiletype() {
        return filetype;
    }

    public void setFiletype(String filetype) {
        this.filetype = filetype;
    }

    public byte[] getBlobContent() {
        return blobContent;
    }

    public void setBlobContent(byte[] blobContent) {
        this.blobContent = blobContent;
    }

    public Idea getIdea() {
        return idea;
    }

    public void setIdea(Idea idea) {
        this.idea = idea;
    }

    public String getRealFilename() {
        return realFilename;
    }

    public void setRealFilename(String realFilename) {
        this.realFilename = realFilename;
    }

    public String getMimeType() {
        return mimeType;
    }

    public void setMimeType(String mimeType) {
        this.mimeType = mimeType;
    }

    public BigInteger getDocSize() {
        return docSize;
    }

    public void setDocSize(BigInteger docSize) {
        this.docSize = docSize;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @XmlTransient
    public Set<IdeaFileTxt> getIdeaFileTxtSet() {
        return ideaFileTxtSet;
    }

    public void setIdeaFileTxtSet(Set<IdeaFileTxt> ideaFileTxtSet) {
        this.ideaFileTxtSet = ideaFileTxtSet;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (fileId != null ? fileId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof IdeaFile)) {
            return false;
        }
        IdeaFile other = (IdeaFile) object;
        if ((this.fileId == null && other.fileId != null) || (this.fileId != null && !this.fileId.equals(other.fileId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.IdeaFile[ fileId=" + fileId + " ]";
    }
}
