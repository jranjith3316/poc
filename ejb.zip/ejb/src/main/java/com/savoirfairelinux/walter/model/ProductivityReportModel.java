/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.model;

import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author jsgill
 */
public class ProductivityReportModel implements Serializable {

  private Integer id;
  private Date publishDate;
  private Float compAnnualRemMaterial;
  private Float compLabourCost;
  private Float compPrice;
  private Float compProductCost;
  private Float hourlyLaborRate;
  private Float walterLabourCost;
  private Float walterPrice;
  private Float walterProductCost;
  private Integer compAnnualCutsNumber;
  private Integer compManHoursRequired;
  private Integer walterManHoursRequired;
  private Integer walterWheelsQuantity;
  private Integer yearlyUsage;
  private String applicatonName;
  private String comments;
  private String company;
  private String competitorName;
  private String compModelNumber;
  private String compProductName;
  private String material;
  private String saleRep;
  private String walterProductNumber;

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Date getPublishDate() {
    return publishDate;
  }

  public void setPublishDate(Date publishDate) {
    this.publishDate = publishDate;
  }

  public Float getCompAnnualRemMaterial() {
    return compAnnualRemMaterial;
  }

  public void setCompAnnualRemMaterial(Float compAnnualRemMaterial) {
    this.compAnnualRemMaterial = compAnnualRemMaterial;
  }

  public Float getCompLabourCost() {
    return compLabourCost;
  }

  public void setCompLabourCost(Float compLabourCost) {
    this.compLabourCost = compLabourCost;
  }

  public Float getCompPrice() {
    return compPrice;
  }

  public void setCompPrice(Float compPrice) {
    this.compPrice = compPrice;
  }

  public Float getCompProductCost() {
    return compProductCost;
  }

  public void setCompProductCost(Float compProductCost) {
    this.compProductCost = compProductCost;
  }

  public Float getHourlyLaborRate() {
    return hourlyLaborRate;
  }

  public void setHourlyLaborRate(Float hourlyLaborRate) {
    this.hourlyLaborRate = hourlyLaborRate;
  }

  public Float getWalterLabourCost() {
    return walterLabourCost;
  }

  public void setWalterLabourCost(Float walterLabourCost) {
    this.walterLabourCost = walterLabourCost;
  }

  public Float getWalterPrice() {
    return walterPrice;
  }

  public void setWalterPrice(Float walterPrice) {
    this.walterPrice = walterPrice;
  }

  public Float getWalterProductCost() {
    return walterProductCost;
  }

  public void setWalterProductCost(Float walterProductCost) {
    this.walterProductCost = walterProductCost;
  }

  public Integer getCompAnnualCutsNumber() {
    return compAnnualCutsNumber;
  }

  public void setCompAnnualCutsNumber(Integer compAnnualCutsNumber) {
    this.compAnnualCutsNumber = compAnnualCutsNumber;
  }

  public Integer getCompManHoursRequired() {
    return compManHoursRequired;
  }

  public void setCompManHoursRequired(Integer compManHoursRequired) {
    this.compManHoursRequired = compManHoursRequired;
  }

  public Integer getWalterManHoursRequired() {
    return walterManHoursRequired;
  }

  public void setWalterManHoursRequired(Integer walterManHoursRequired) {
    this.walterManHoursRequired = walterManHoursRequired;
  }

  public Integer getWalterWheelsQuantity() {
    return walterWheelsQuantity;
  }

  public void setWalterWheelsQuantity(Integer walterWheelsQuantity) {
    this.walterWheelsQuantity = walterWheelsQuantity;
  }

  public Integer getYearlyUsage() {
    return yearlyUsage;
  }

  public void setYearlyUsage(Integer yearlyUsage) {
    this.yearlyUsage = yearlyUsage;
  }

  public String getApplicatonName() {
    return applicatonName;
  }

  public void setApplicatonName(String applicatonName) {
    this.applicatonName = applicatonName;
  }

  public String getComments() {
    return comments;
  }

  public void setComments(String comments) {
    this.comments = comments;
  }

  public String getCompany() {
    return company;
  }

  public void setCompany(String company) {
    this.company = company;
  }

  public String getCompetitorName() {
    return competitorName;
  }

  public void setCompetitorName(String competitorName) {
    this.competitorName = competitorName;
  }

  public String getCompModelNumber() {
    return compModelNumber;
  }

  public void setCompModelNumber(String compModelNumber) {
    this.compModelNumber = compModelNumber;
  }

  public String getCompProductName() {
    return compProductName;
  }

  public void setCompProductName(String compProductName) {
    this.compProductName = compProductName;
  }

  public String getMaterial() {
    return material;
  }

  public void setMaterial(String material) {
    this.material = material;
  }

  public String getSaleRep() {
    return saleRep;
  }

  public void setSaleRep(String saleRep) {
    this.saleRep = saleRep;
  }

  public String getWalterProductNumber() {
    return walterProductNumber;
  }

  public void setWalterProductNumber(String walterProductNumber) {
    this.walterProductNumber = walterProductNumber;
  }

}
