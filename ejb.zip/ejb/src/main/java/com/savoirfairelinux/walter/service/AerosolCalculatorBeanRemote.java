/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.service;

import com.savoirfairelinux.walter.dao.walter.Aerosolcalculator;
import com.savoirfairelinux.walter.model.Tradename;
import java.util.List;
import javax.ejb.Remote;

/**
 *
 * @author jsgill
 */
@Remote
public interface AerosolCalculatorBeanRemote {
  public List<Tradename> getTradenames(String languageAbbreviation, String country, String franchiseGuid, String unitName) throws Exception;

  public float getProductPrice(String countryCode, String productNumber);

  public void saveReport(Aerosolcalculator ac);

  public List<Aerosolcalculator> getReportByUser(String username);

  public void deleteReport(Aerosolcalculator ac);

  public Aerosolcalculator getAerosolCalculatorById(Long id);
}
