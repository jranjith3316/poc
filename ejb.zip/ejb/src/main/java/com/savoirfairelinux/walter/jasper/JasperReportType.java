/*
 * Copyright 2013 Savoir-faire Linux
 *
 * This file is part of Walter-Portal.
 *
 * Walter-Portal is free software: you can redistribute it and/or modify it under the terms of the
 * GNU General Public License as published by the Free Software Foundation, either version 3
 * of the License, or (at your option) any later version.
 *
 * Walter-Portal is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with Walter-Portal.
 * If not, see http://www.gnu.org/licenses/.
 */
package com.savoirfairelinux.walter.jasper;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author jbonjean
 * @author jderuere
 *
 */
public enum JasperReportType implements Serializable {

  SOLUTION_REPORT("solution-report"),
  GLOBAL_CUSTOMER("global-customer"),
  FACILITY("facility"),
  NEW_IDEA("new-idea"),
  LAB_REPORT_WALTER("lab-report-walter"),
  LAB_REPORT_BIOCIRCLE("lab-report-biocircle"),
  PRODUCTIVITY_REPORT_CUTTING("productivity-report-cutting"),
  PRODUCTIVITY_REPORT_GRINDING("productivity-report-grinding"),
  EXPENSE_REPORT("expense-report"),
  EXPENSE_REPORT_SEARCH("expense-report-search"),
  NAICS_SUSPECTS_SEARCH("naics-suspects-search"),
  AEROSOL_CALCULATOR("aerosol-calculator"),
  MOBILE_PRODUCTIVITY_REPORT_CUTTING("mobile_productivity_report_cutting"),
  MOBILE_PRODUCTIVITY_REPORT_GRINDING("mobile_productivity_report_grinding"),
  MOBILE_PRODUCTIVITY_REPORT_SANDING("mobile_productivity_report_sanding"),
  MOBILE_CROSS_REFERENCE_APP("mobile_cross_reference_app");

  private static final String COMPILED_PATH = "/jasper/compiled/";
  private static final String IMAGES_PATH = "/jasper/images/";
  private final String fileName;

  private JasperReportType(String fileName) {
    this.fileName = fileName;
  }

  public String getImagesPath(String imageFile) {
    return IMAGES_PATH + imageFile;
  }

  public String getCompiledFile() {
    return COMPILED_PATH + fileName + ".jasper";
  }

  public String getTargetFile() {
    return fileName + "-" + new SimpleDateFormat("yyyy-MM-dd-HHmmss").format(new Date()) + ".pdf";
  }
}
