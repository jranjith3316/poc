/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.idb;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author jsgill
 */
@Embeddable
public class WalterTvvideosfilesurlsPK implements Serializable {
  @Basic(optional = false)
  @NotNull
  @Size(min = 1, max = 255)
  @Column(name = "TVVIDEOGUID")
  private String tvvideoguid;
  @Basic(optional = false)
  @NotNull
  @Column(name = "TVVIDEORESOLUTION")
  private long tvvideoresolution;

  public WalterTvvideosfilesurlsPK() {
  }

  public WalterTvvideosfilesurlsPK(String tvvideoguid, long tvvideoresolution) {
    this.tvvideoguid = tvvideoguid;
    this.tvvideoresolution = tvvideoresolution;
  }

  public String getTvvideoguid() {
    return tvvideoguid;
  }

  public void setTvvideoguid(String tvvideoguid) {
    this.tvvideoguid = tvvideoguid;
  }

  public long getTvvideoresolution() {
    return tvvideoresolution;
  }

  public void setTvvideoresolution(long tvvideoresolution) {
    this.tvvideoresolution = tvvideoresolution;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (tvvideoguid != null ? tvvideoguid.hashCode() : 0);
    hash += (int) tvvideoresolution;
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof WalterTvvideosfilesurlsPK)) {
      return false;
    }
    WalterTvvideosfilesurlsPK other = (WalterTvvideosfilesurlsPK) object;
    if ((this.tvvideoguid == null && other.tvvideoguid != null) || (this.tvvideoguid != null && !this.tvvideoguid.equals(other.tvvideoguid))) {
      return false;
    }
    if (this.tvvideoresolution != other.tvvideoresolution) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.idb.WalterTvvideosfilesurlsPK[ tvvideoguid=" + tvvideoguid + ", tvvideoresolution=" + tvvideoresolution + " ]";
  }

}
