package com.savoirfairelinux.walter.dao.waltercb;

import javax.persistence.*;
import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;

/**
 * @author jderuere
 */
@Entity
@Table(name = "U_MATERIAL_TOOL", schema = DatabaseConstants.WALTERCB_SCHEMA)
@NamedQuery(name = "UMaterialTool.findAll", query = "SELECT u FROM UMaterialTool u ORDER BY u.name")
public class UMaterialTool implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(generator = "U_MATERIAL_TOOL_ID_SEQ", strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "U_MATERIAL_TOOL_ID_SEQ", sequenceName = "U_MATERIAL_TOOL_SEQ", schema = DatabaseConstants.WALTERCB_SCHEMA, allocationSize = 1)
    @Column(name = "ID")
    private Long id;
    @Column(name = "MATERIAL_ID")
    private Long materialId;
    @Column(name = "NAME")
    private String name;
    @Column(name = "DESCRIPTION")
    private String description;

    @Transient
    private UMaterial material;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getMaterialId() {
        return materialId;
    }

    private void setMaterialId(Long materialId) {
        this.materialId = materialId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public UMaterial getMaterial() {
        return material;
    }

    public void setMaterial(UMaterial material) {
        if (material != null) this.materialId = material.getUMaterialPK().getMaterialId();
        this.material = material;
    }

    public String getDisplayName() {
        StringBuilder builder = new StringBuilder(name);
        if (description != null) builder.append(" - ").append(description);
        return builder.toString();
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof UMaterialTool)) {
            return false;
        }
        UMaterialTool other = (UMaterialTool) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.UMaterialTool[ id=" + id + " ]";
    }
}