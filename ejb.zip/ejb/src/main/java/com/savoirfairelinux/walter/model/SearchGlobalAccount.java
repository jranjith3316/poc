package com.savoirfairelinux.walter.model;

import com.savoirfairelinux.walter.dao.globalcustomer.UGeographicalCoverage;
import com.savoirfairelinux.walter.dao.waltercb.Country;
import com.savoirfairelinux.walter.dao.waltercb.UIndustry;

import java.io.Serializable;
import java.util.Date;

public class SearchGlobalAccount implements Serializable {

    private Long id;
    private String name;
    private Franchise franchise;
    private Tradename tradename;
    private UIndustry industry;
    private UGeographicalCoverage geographicalCoverage;
    private Country country;
    private Date date;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Franchise getFranchise() {
        return franchise;
    }

    public void setFranchise(Franchise franchise) {
        this.franchise = franchise;
    }

    public Tradename getTradename() {
        return tradename;
    }

    public void setTradename(Tradename tradename) {
        this.tradename = tradename;
    }

    public UIndustry getIndustry() {
        return industry;
    }

    public void setIndustry(UIndustry industry) {
        this.industry = industry;
    }

    public UGeographicalCoverage getGeographicalCoverage() {
        return geographicalCoverage;
    }

    public void setGeographicalCoverage(UGeographicalCoverage geographicalCoverage) {
        this.geographicalCoverage = geographicalCoverage;
    }

    public Country getCountry() {
        return country;
    }

    public void setCountry(Country country) {
        this.country = country;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}
