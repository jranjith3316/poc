/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.service.impl;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.model.User;
import com.liferay.portal.model.UserConstants;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.savoirfairelinux.walter.dao.idb.OoBabelMembers;
import com.savoirfairelinux.walter.dao.idb.OoInstances;
import com.savoirfairelinux.walter.dao.waltercb.PrPicture;
import com.savoirfairelinux.walter.dao.waltercb.PrPictureTxt;
import com.savoirfairelinux.walter.dao.waltercb.PrResult;
import com.savoirfairelinux.walter.dao.waltercb.ProductivityReport;
import com.savoirfairelinux.walter.dao.waltercb.UCompetitor;
import com.savoirfairelinux.walter.dao.waltercb.UCompetitorBrand;
import com.savoirfairelinux.walter.dao.waltercb.UCompetitorProduct;
import com.savoirfairelinux.walter.dao.waltercb.ULang;
import com.savoirfairelinux.walter.dao.waltercb.UMaterial;
import com.savoirfairelinux.walter.dao.walterproductivity.Orders;
import com.savoirfairelinux.walter.dao.walterproductivity.Reports;
import com.savoirfairelinux.walter.jasper.model.JasperMobileProductivityReportBean;
import com.savoirfairelinux.walter.model.PrApplication;
import com.savoirfairelinux.walter.model.PrWalterProduct;
import com.savoirfairelinux.walter.model.ProductivityReportState;
import com.savoirfairelinux.walter.model.SearchProductivityReport;
import com.savoirfairelinux.walter.model.SearchProductivityResult;
import com.savoirfairelinux.walter.model.Tradename;
import com.savoirfairelinux.walter.service.ProductivityReportBeanRemote;
import com.savoirfairelinux.walter.service.productivityreport.CuttingCalculation;
import com.savoirfairelinux.walter.service.productivityreport.GrindingCalculation;
import com.savoirfairelinux.walter.util.criteriabuilder.ProductivityCriteriaBuilder;
import com.savoirfairelinux.walter.util.criteriabuilder.ProductivityResultCriteriaBuilder;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.security.PermitAll;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Schedule;
import javax.ejb.Startup;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import org.hibernate.Hibernate;

/**
 *
 * @author jderuere
 */
@Startup
@Stateless(name = "ProductivityReportBean")
@TransactionManagement(TransactionManagementType.CONTAINER)
@PermitAll
@LocalBean
public class ProductivityReportBean implements ProductivityReportBeanRemote {

  public static final Logger LOG = Logger.getLogger(ProductivityReportBean.class.getCanonicalName());

  @PersistenceContext(unitName = "waltershare")
  EntityManager entityManager;
  @EJB
  SingletonBean singletonBean;
  @EJB
  NotificationBean notificationBean;
  @EJB
  WalterBean walterBean;
  @EJB
  JasperBean jasperBean;
  ResourceBundle messages;

  @Override
  public ProductivityReport save(ProductivityReport report) {
    try {
      return walterBean.save(report);
    } catch (Exception e) {
      LOG.severe(e.getMessage());
    }
    return null;
  }

  @Override
  public void remove(ProductivityReport report) {
    try {
      report = entityManager.find(ProductivityReport.class, report.getId());
      entityManager.remove(report);
    } catch (Exception e) {
      LOG.severe(e.getMessage());
    }
  }

  @Override
  public void remove(PrResult prResult) {
    try {
      prResult = entityManager.find(PrResult.class, prResult.getId());
      entityManager.remove(prResult);
    } catch (Exception e) {
      LOG.severe(e.getMessage());
    }
  }

  @Override
  public PrResult save(PrResult result) {
    try {
      return walterBean.save(result);
    } catch (Exception e) {
      LOG.severe(e.getMessage());
    }
    return null;
  }

  @Override
  public void remove(UCompetitorProduct product) {
    try {
      product = entityManager.merge(product);
      entityManager.remove(product);
      entityManager.flush();
      UCompetitorBrand brand = entityManager.merge(product.getBrand());
      if (brand.getProducts().isEmpty()) {
        entityManager.remove(brand);
      }
    } catch (Exception e) {
      LOG.severe(e.getMessage());
    }
  }

  @Override
  public List<ProductivityReport> search(SearchProductivityReport form, Long langId, String languageAbbreviation, String webSiteCountryName) throws Exception {
    List<ProductivityReport> result = new ArrayList<ProductivityReport>();
    try {
      ProductivityCriteriaBuilder criteriaBuilder = new ProductivityCriteriaBuilder(entityManager, form);
      List<ProductivityReport> reports = criteriaBuilder.buildQuery().getQuery().getResultList();
      ULang uLang = walterBean.getULang(langId);
      if (!reports.isEmpty()) {
        try {
          List<Object[]> rows = entityManager.createQuery(singletonBean.getProductivityReportQuery("productivity.report.loadProductsFromReports"), Object[].class)
                  .setParameter("reports", reports)
                  .setParameter("country", webSiteCountryName)
                  .getResultList();

          Map<String, PrWalterProduct> map = new HashMap<String, PrWalterProduct>();
          for (Object[] row : rows) {
            PrWalterProduct product = new PrWalterProduct();
            product.setProductVersionGUID(String.valueOf(row[0]));
            product.setProductNumber(String.valueOf(row[1]));

            String tradename = getWalterTradenamesTranslation(uLang.getIdbAbbreviation(), String.valueOf(row[2]));
            if ( tradename == null || tradename.equals("") ){
              tradename = String.valueOf(row[3]);
            }

            product.setProductName(new Tradename(String.valueOf(row[2]), null, tradename));
            map.put(product.getProductNumber(), product);
          }

          for (ProductivityReport report : reports) {
            PrWalterProduct product = map.get(report.getWalterProductNumber());
            if (product != null) {
              report.setWalterProduct(product);
              result.add(report);
            }
          }
        } catch (NoResultException e) {
        }

        for (ProductivityReport report : result) {
          report.setApplication(getApplication(report.getApplicationGUID(), languageAbbreviation));
          report.setMaterial(getMaterial(report.getMaterialId(), langId));
        }
      }
    } catch (Exception e) {
      LOG.severe(e.getMessage());
    }
    return result;
  }

  @Override
  public List<PrResult> search(SearchProductivityResult form, String userName, String organization, Long langId, String webSiteCountryName, Boolean readOnly) throws Exception {
    List<PrResult> results;
    try {
      ProductivityResultCriteriaBuilder criteriaBuilder = new ProductivityResultCriteriaBuilder(entityManager, form, readOnly);
      results = criteriaBuilder.buildQuery().getQuery().getResultList();
    } catch (Exception e) {
      results = new ArrayList<PrResult>();
      LOG.severe(e.getMessage());
    }
    ULang uLang = walterBean.getULang(langId);
    if (!results.isEmpty()) {
      try {
        List<Object[]> rows = entityManager.createQuery(singletonBean.getProductivityReportQuery("productivity.report.loadProductsFromResults"), Object[].class)
                .setParameter("results", results)
                .setParameter("country", webSiteCountryName)
                .getResultList();

        Map<String, PrWalterProduct> map = new HashMap<String, PrWalterProduct>();
        for (Object[] row : rows) {
          PrWalterProduct product = new PrWalterProduct();
          product.setProductVersionGUID(String.valueOf(row[0]));
          product.setProductNumber(String.valueOf(row[1]));

          String tradename = getWalterTradenamesTranslation(uLang.getIdbAbbreviation(), String.valueOf(row[2]));
          if ( tradename == null || tradename.equals("") ){
            tradename = String.valueOf(row[3]);
          }
          product.setProductName(new Tradename(String.valueOf(row[2]), null, tradename));
          product.setDiameter(String.valueOf(row[4]));
          map.put(product.getProductNumber(), product);
        }

        for (PrResult result : results) {
          PrWalterProduct product = map.get(result.getWalterProductNumber());
          result.setWalterProduct(product);
        }
      } catch (NoResultException e) {
      }
    }
    return results;
  }

  @Override
  public String submit(ProductivityReport report) {
    String result = null;

    report.setSubmitDate(new Date());

    PrResult competitorResult = getCompetitorResult(report.getCompetitorProduct(), report.getMaterialId(), null);
    report.setCompetitorResult(competitorResult);

    PrResult walterResult = getWalterResult(report.getWalterProductNumber(), report.getMaterialId(), null);
    report.setWalterResult(walterResult);

    if (competitorResult != null && walterResult != null) {
      report = publish(report);
    } else {
      report = save(report);
      notificationBean.sendSubmitProductivityReportNotification(report);

      if (competitorResult == null) {
        result = "sendSampleWarning";
      } else {
        result = "noNeedSampleWarning";
      }
    }

    Calendar calendar = Calendar.getInstance();
    calendar.setTime(report.getSubmitDate());
    StringBuilder walterId = new StringBuilder(String.valueOf(calendar.get(Calendar.YEAR)).substring(2)).append("-").append(report.getId());
    report.setWalterId(walterId.toString());
    save(report);
    return result;
  }

  @Override
  public ProductivityReport publish(ProductivityReport report) {
    report.setPublishDate(new Date());
    computeProductivity(report);
    if (report.getCompetitorResult().getDate() == null) {
      report.getCompetitorResult().setDate(new Date());
    }
    if (report.getWalterResult().getDate() == null) {
      report.getWalterResult().setDate(new Date());
    }
    report = save(report);
    notificationBean.sendPublishedProductivityReportNotification(report);
    return report;
  }

  @Override
  public void publishCompetitor(PrResult result) {
    result.setDate(new Date());
    save(result);
  }

  @Override
  public void publishWalter(PrResult result) {
    result.setDate(new Date());
    save(result);
  }

  @Override
  public ProductivityReport getProductivityReport(Long id, String languageAbbreviation, String webSiteCountryName, Long langId) throws Exception {
    SearchProductivityReport form = new SearchProductivityReport();
    form.setId(id);

    ProductivityCriteriaBuilder criteriaBuilder = new ProductivityCriteriaBuilder(entityManager, form);
    ProductivityReport result = criteriaBuilder.buildQuery().getQuery().getSingleResult();

    if (result == null) {
      throw new Exception("You are not allowed to view this Productivity Report!");
    }

    if (result.getWalterResult() != null) {
      Hibernate.initialize(result.getWalterResult().getPictures());
      List<PrPictureTxt> pictureTexts = entityManager.createQuery(singletonBean.getProductivityReportQuery("productivity.report.getPicturesDescriptions"), PrPictureTxt.class)
              .setParameter("result", result.getWalterResult())
              .setParameter("langId", langId)
              .getResultList();

      for (PrPicture picture : result.getWalterResult().getPictures()) {
        for (PrPictureTxt pictureTxt : pictureTexts) {
          if (picture.equals(pictureTxt.getPicture())) {
            picture.setCurrentPictureText(pictureTxt);
            break;
          }
        }
      }
    }

    if (result.getCompetitorResult() != null) {
      Hibernate.initialize(result.getCompetitorResult().getPictures());
      List<PrPictureTxt> pictureTexts = entityManager.createQuery(singletonBean.getProductivityReportQuery("productivity.report.getPicturesDescriptions"), PrPictureTxt.class)
              .setParameter("result", result.getCompetitorResult())
              .setParameter("langId", langId)
              .getResultList();

      for (PrPicture picture : result.getCompetitorResult().getPictures()) {
        for (PrPictureTxt pictureTxt : pictureTexts) {
          if (picture.equals(pictureTxt.getPicture())) {
            picture.setCurrentPictureText(pictureTxt);
            break;
          }
        }
      }
    }

    result.setApplication(getApplication(result.getApplicationGUID(), languageAbbreviation));
    result.setWalterProduct(getWalterProduct(result.getWalterProductNumber(), webSiteCountryName, languageAbbreviation));
    result.setMaterial(getMaterial(result.getMaterialId(), langId));
    return result;
  }

  @Override
  public List<ProductivityReport> getSubmitReports(Long langId, String languageAbbreviation, String webSiteCountryName) {
    List<ProductivityReport> result;
    SearchProductivityReport searchForm = new SearchProductivityReport();
    searchForm.setState(ProductivityReportState.SUBMIT);
    try {
      result = search(searchForm, langId, languageAbbreviation, webSiteCountryName);
    } catch (Exception e) {
      result = new ArrayList<ProductivityReport>();
      LOG.severe(e.getMessage());
    }
    return result;
  }

  @Override
  public PrResult getCompetitorResult(UCompetitorProduct product, Long materialId, Long langId) {
    PrResult result = null;
    if (product.getId() != null) {
      try {
        result = entityManager.createQuery(singletonBean.getProductivityReportQuery("productivity.report.getCompetitorResult"), PrResult.class)
                .setParameter("competitorProduct", product)
                .setParameter("materialId", materialId)
                .setMaxResults(1).getSingleResult();
        if (langId != null) {
          loadResultPictures(result, langId);
        }
      } catch (NoResultException e) {
      }
    }
    return result;
  }

  @Override
  public PrResult getWalterResult(String productNumber, Long materialId, Long langId) {
    PrResult result;
    try {
      result = entityManager.createQuery(singletonBean.getProductivityReportQuery("productivity.report.getWalterResult"), PrResult.class)
              .setParameter("walterProductNumber", productNumber)
              .setParameter("materialId", materialId)
              .setMaxResults(1)
              .getSingleResult();
      if (langId != null) {
        loadResultPictures(result, langId);
      }
    } catch (NoResultException e) {
      result = null;
    }

    return result;
  }

  @Override
  public boolean existPublishedReport(UCompetitorProduct product) {
    boolean result = false;
    if (product.getId() != null) {
      try {
        Long number = entityManager.createQuery(singletonBean.getProductivityReportQuery("productivity.report.competitorProduct.existPublishedReport"), Long.class)
                .setParameter("competitorProduct", product).getSingleResult();
        if (number > 0) {
          result = true;
        }
      } catch (NoResultException e) {
      }
    }
    return result;
  }

  @Override
  public PrResult getResult(Long id, String languageAbbreviation, String webSiteCountryName, Long langId) throws Exception {
    SearchProductivityResult form = new SearchProductivityResult();
    form.setId(id);

    ProductivityResultCriteriaBuilder criteriaBuilder = new ProductivityResultCriteriaBuilder(entityManager, form, false);
    PrResult result = criteriaBuilder.buildQuery().getQuery().getSingleResult();

    if (result == null) {
      throw new Exception("You are not allowed to view this Productivity Result!");
    }

    loadResultPictures(result, langId);

    result.setWalterProduct(getWalterProduct(result.getWalterProductNumber(), webSiteCountryName, languageAbbreviation));
    result.getMaterialTool().setMaterial(getMaterial(result.getMaterialTool().getMaterialId(), langId));
    return result;
  }

  private void loadResultPictures(PrResult result, Long langId) {
    Hibernate.initialize(result.getPictures());

    List<PrPictureTxt> pictureTexts = entityManager.createQuery(singletonBean.getProductivityReportQuery("productivity.report.getPicturesDescriptions"), PrPictureTxt.class)
            .setParameter("result", result)
            .setParameter("langId", langId)
            .getResultList();

    for (PrPicture picture : result.getPictures()) {
      for (PrPictureTxt pictureTxt : pictureTexts) {
        if (picture.equals(pictureTxt.getPicture())) {
          picture.setCurrentPictureText(pictureTxt);
          break;
        }
      }
    }
  }

  private UMaterial getMaterial(Long materialId, Long langId) {
    UMaterial uMaterial = null;
    try {
      uMaterial = entityManager.createQuery(singletonBean.getProductivityReportQuery("productivity.report.material"), UMaterial.class)
              .setParameter("materialId", materialId)
              .setParameter("langId", langId)
              .getSingleResult();
    } catch (NoResultException e) {
    }
    return uMaterial;
  }

  @Override
  public PrApplication getApplication(String applicationGUID, String languageAbbreviation) {
    PrApplication application;
    try {
      OoBabelMembers row = entityManager.createQuery(singletonBean.getProductivityReportQuery("productivity.report.application"), OoBabelMembers.class)
              .setParameter("languageAbbreviation", languageAbbreviation)
              .setParameter("applicationGUID", applicationGUID)
              .getSingleResult();

      application = new PrApplication(String.valueOf(row.getInstanceguid().getInstanceguid()));
      application.setName(String.valueOf(row.getMembervalue()));
    } catch (NoResultException e) {
      application = null;
    }
    return application;
  }

  @Override
  public List<PrApplication> getApplications(String languageAbbreviation) {
    List<PrApplication> applications;
    try {
      List<OoBabelMembers> rows = entityManager.createQuery(singletonBean.getProductivityReportQuery("productivity.report.applications"), OoBabelMembers.class)
              .setParameter("languageAbbreviation", languageAbbreviation)
              .getResultList();
      applications = new ArrayList<PrApplication>(rows.size());
      for (OoBabelMembers row : rows) {
        PrApplication application = new PrApplication(String.valueOf(row.getInstanceguid().getInstanceguid()));
        application.setName(String.valueOf(row.getMembervalue()));
        applications.add(application);
      }
    } catch (NoResultException e) {
      applications = new ArrayList<PrApplication>();
    }
    return applications;
  }

  @Override
  public PrWalterProduct getWalterProduct(String productNumber, String webSiteCountryName, String languageAbbreviation) {
    PrWalterProduct product = null;
    try {
      List<Object[]> rowList = entityManager.createQuery(singletonBean.getProductivityReportQuery("productivity.report.product"), Object[].class)
              .setParameter("productNumber", productNumber)
              .setParameter("country", webSiteCountryName)
              .getResultList();

      product = new PrWalterProduct();
//      System.out.println("------------------ ");
//      System.out.println("webSiteCountryName: " + webSiteCountryName);
      for ( Object[] row : rowList ){
//        System.out.println("productNumber: " + productNumber);
        product.setProductVersionGUID(String.valueOf(row[0]));
        product.setProductNumber(String.valueOf(row[1]));

        String tradename = getWalterTradenamesTranslation(languageAbbreviation, String.valueOf(row[2]));
        if ( tradename == null || tradename.equals("") ){
          tradename = String.valueOf(row[3]);
        }
        product.setProductName(new Tradename(String.valueOf(row[2]), null, tradename));
        product.setApplication(getApplication(String.valueOf(row[4]), languageAbbreviation));
        product.setProductLineClaassesguid(String.valueOf(row[5]));
        product.setPrice(String.valueOf(row[6]));
        break;
      }
//      System.out.println("------------------ ");

      product = loadWalterProduct(product, languageAbbreviation);

    } catch (NoResultException e) {
    }
    return product;
  }

  @Override
  @Deprecated
  public List<PrWalterProduct> getWalterProducts(String webSiteCountryName) {
    List<PrWalterProduct> products;
    try {
      List<Object[]> rows = entityManager.createQuery(singletonBean.getProductivityReportQuery("productivity.report.products"), Object[].class)
              .setParameter("country", webSiteCountryName)
              .getResultList();
      products = new ArrayList<PrWalterProduct>(rows.size());
      for (Object[] row : rows) {
        PrWalterProduct product = new PrWalterProduct();
        product.setProductVersionGUID(String.valueOf(row[0]));
        product.setProductNumber(String.valueOf(row[1]));
        product.setProductName(new Tradename(String.valueOf(row[2]), null, String.valueOf(row[3])));
        product.setApplication(new PrApplication(String.valueOf(row[4])));
        product.setProductLineClaassesguid(String.valueOf(row[5]));
        products.add(product);
      }
    } catch (NoResultException e) {
      products = new ArrayList<PrWalterProduct>();
    }
    return products;
  }

  @Override
  public List<PrWalterProduct> getWalterProducts(String countryCode, String langCode) {
    List<PrWalterProduct> products;
    try {
      List<Object[]> rows = entityManager.createQuery(singletonBean.getProductivityReportQuery("productivity.report.products"), Object[].class)
              .setParameter("country", countryCode)
              .getResultList();
      products = new ArrayList<PrWalterProduct>(rows.size());
      for (Object[] row : rows) {
        PrWalterProduct product = new PrWalterProduct();
        product.setProductVersionGUID(String.valueOf(row[0]));
        product.setProductNumber(String.valueOf(row[1]));
        String tradename = getWalterTradenamesTranslation(langCode, String.valueOf(row[2]));
        if ( tradename == null || tradename.equals("") ){
          tradename = String.valueOf(row[3]);
        }
        product.setProductName(new Tradename(String.valueOf(row[2]), null, tradename));
        product.setApplication(getApplication(String.valueOf(row[4]), langCode));
        product.setProductLineClaassesguid(String.valueOf(row[5]));
        product.setPrice(String.valueOf(row[6]));

        /** Fix bug with Allsteel franchise to be show in PRO APP and Productivity Report in WalterShare change action to cutting and franchise to abrasive **/
        String tradeGuid = String.valueOf(row[2]);
        if ( tradeGuid.equals("7EF4FFFDD0F27FEBE053E80BA8C0B53B") || tradeGuid.equals("7EF4FFFDD0FB7FEBE053E80BA8C0B53B") || tradeGuid.equals("7EF4FFFDD0F57FEBE053E80BA8C0B53B") ||
             tradeGuid.equals("7F1CBC5584795C70E053E80BA8C0CD50") || tradeGuid.equals("7EF4FFFDD0FB7FEBE053E80BA8C0B53B")) { // guid of ALLSTEEL&trade; Cut-Off Wheels
          product.setApplication(getApplication("FC82683BAB71E656E043C0A8011FE656", langCode)); // cutting guid
          product.setProductLineClaassesguid("7AC5E2256DC09F40E043C0A8011F9F40");
        }

        if ( tradeGuid.equals("7EF4FFFDD0FE7FEBE053E80BA8C0B53B") ) { // guid of ALLSTEEL&trade; Grinding Wheels
          product.setApplication(getApplication("FC2177416194CD2CE043C0A8011FCD2C", langCode)); // Grinding guid
          product.setProductLineClaassesguid("7AC5E2256DC09F40E043C0A8011F9F40");
        }

        if ( tradeGuid.equals("7EF4FFFDD1077FEBE053E80BA8C0B53B")) { // guid of ALLSTEEL&trade; Flap Discs
          product.setApplication(getApplication("FC831CE581A022B6E043C0A8011F22B6", langCode)); // Blending guid
          product.setProductLineClaassesguid("7AC5E2256DC09F40E043C0A8011F9F40");
        }

        products.add(product);
      }
    } catch (NoResultException e) {
      products = new ArrayList<PrWalterProduct>();
    }
    return products;
  }

  @Override
  public List<PrWalterProduct> getAllWalterProducts(String countryCode, String langCode) {
    List<PrWalterProduct> products;
    try {
      List<Object[]> rows = entityManager.createQuery(singletonBean.getProductivityReportQuery("productivity.report.Allproducts"), Object[].class)
              .setParameter("country", countryCode)
              .getResultList();
      products = new ArrayList<PrWalterProduct>(rows.size());
      for (Object[] row : rows) {
        PrWalterProduct product = new PrWalterProduct();
        product.setProductVersionGUID(String.valueOf(row[0]));
        product.setProductNumber(String.valueOf(row[1]));
        String tradename = getWalterTradenamesTranslation(langCode, String.valueOf(row[2]));
        if ( tradename == null || tradename.equals("") ){
          tradename = String.valueOf(row[3]);
        }
        product.setProductName(new Tradename(String.valueOf(row[2]), null, tradename));
        product.setApplication(getApplication(String.valueOf(row[4]), langCode));
        product.setProductLineClaassesguid(String.valueOf(row[5]));
        product.setPrice(String.valueOf(row[6]));
        products.add(product);
      }
    } catch (NoResultException e) {
      products = new ArrayList<PrWalterProduct>();
    }
    return products;
  }

  public String getWalterTradenamesTranslation(String languageAbbreviation, String tradeguid) {
    String result = "";
    try {
        result = entityManager.createQuery(singletonBean.getAerosolCalculatorQuery("walter.tradenames.translation"), String.class)
                              .setParameter("languageAbbreviation", languageAbbreviation)
                              .setParameter("tradeguid", tradeguid)
                              .getSingleResult();

    } catch (Exception e) {
        LOG.severe(e.getMessage());
    }
    return result;
  }

  @Override
  public PrWalterProduct loadWalterProduct(PrWalterProduct product, String languageAbbreviation) {

    /**  Need to change the franchise guid to ALLSTEEL to get technical information. **/
    if ( product.getProductName() != null ) {
      String tradeGuid = product.getProductName().getTradenameId();
      if ( tradeGuid.equals("7F1CBC5584795C70E053E80BA8C0CD50") || tradeGuid.equals("7EF4FFFDD1077FEBE053E80BA8C0B53B") || tradeGuid.equals("7EF4FFFDD0FE7FEBE053E80BA8C0B53B") ||
           tradeGuid.equals("7EF4FFFDD0F27FEBE053E80BA8C0B53B") || tradeGuid.equals("41FFA00FEF28174BE053E80BA8C0E7E1") || tradeGuid.equals("7EF4FFFDD0FB7FEBE053E80BA8C0B53B") ||
           tradeGuid.equals("7EF4FFFDD0F57FEBE053E80BA8C0B53B")) { // guid of ALLSTEEL&trade; Cut-Off Wheels
        product.setProductLineClaassesguid("7E969EC9512D5F19E053E80BA8C001FD");
      }
    }

    TypedQuery<String> query = entityManager.createQuery(singletonBean.getProductivityReportQuery("productivity.report.product.information"), String.class)
            .setParameter("productVersionGUID", product.getProductVersionGUID())
            .setParameter("franchiseClassesGuid", product.getProductLineClaassesguid());

    try {
      String diameter = query.setParameter("information", "Diameter").getSingleResult();
      product.setDiameter(diameter);
    } catch (NoResultException e) {
//      LOG.log(Level.WARNING, "diameter not found: " + e.getMessage());
    }
    try {
      String thickness = query.setParameter("information", "Thickness").getSingleResult();
      product.setThickness(thickness);
    } catch (NoResultException e) {
//      LOG.log(Level.WARNING, e.getMessage());
    }
    try {
      String arbor = query.setParameter("information", "Arbor").getSingleResult();
      product.setArbor(arbor);
    } catch (NoResultException e) {
//      LOG.log(Level.WARNING, e.getMessage());
    }
    query = entityManager.createQuery(singletonBean.getProductivityReportQuery("productivity.report.product.otherInformation"), String.class);
    try {
      String grit = query.setParameter("information", "Grit")
              .setParameter("productVersionGUID", product.getProductVersionGUID())
              .setParameter("franchiseClassesGuid", product.getProductLineClaassesguid())
              .getSingleResult();

      String translation = getTranslation(grit, languageAbbreviation);
      if (translation != null && !translation.equals("")) {
        grit = translation;
      }

      product.setGrit(grit);
    } catch (NoResultException e) {
//      LOG.log(Level.WARNING, e.getMessage());
    }
    try {
      String type = query.setParameter("information", "Shape")
              .setParameter("productVersionGUID", product.getProductVersionGUID())
              .getSingleResult();

      String translation = getTranslation(type, languageAbbreviation);
      if (translation != null && !translation.equals("")) {
        type = translation;
      }

      product.setType(type);
    } catch (NoResultException e) {
//      LOG.log(Level.WARNING, "loadWalterProduct: " + e.getMessage());
    }
    return product;
  }

  @Override
  public List<String> getGrits() {
    List<String> result = entityManager.createQuery(singletonBean.getProductivityReportQuery("productivity.report.otherInformations"), String.class)
            .setParameter("information", "Grit")
            .getResultList();
    return result;
  }

  @Override
  public List<String> getTypes() {
    List<String> result = entityManager.createQuery(singletonBean.getProductivityReportQuery("productivity.report.otherInformations"), String.class)
            .setParameter("information", "Shape")
            .getResultList();
    return result;
  }

  private void computeProductivity(ProductivityReport report) {
    if (report.getApplicationGUID().equals(PrApplication.CUTTING)) {
      report.computeProductivity(new CuttingCalculation());
    } else {
      report.computeProductivity(new GrindingCalculation());
    }
  }

  @Override
  public List<ProductivityReport> getMyUnsubmitReports(String userName, Long langId, String languageAbbreviation, String webSiteCountryName) {
    List<ProductivityReport> result;
    SearchProductivityReport searchForm = new SearchProductivityReport();
    searchForm.setCreatorScreenName(userName);
    searchForm.setState(ProductivityReportState.UNSUBMIT);
    try {
      result = search(searchForm, langId, languageAbbreviation, webSiteCountryName);
    } catch (Exception e) {
      result = new ArrayList<ProductivityReport>();
      LOG.severe(e.getMessage());
    }
    return result;
  }

  @Override
  public List<ProductivityReport> getMySubmittedReports(String userName, Long langId, String languageAbbreviation, String webSiteCountryName) {
    List<ProductivityReport> result;
    SearchProductivityReport searchForm = new SearchProductivityReport();
    searchForm.setCreatorScreenName(userName);
    searchForm.setState(ProductivityReportState.SUBMIT);
    try {
      result = search(searchForm, langId, languageAbbreviation, webSiteCountryName);
    } catch (Exception e) {
      result = new ArrayList<ProductivityReport>();
      LOG.severe(e.getMessage());
    }
    return result;
  }

  @Override
  public List<ProductivityReport> getMyPublishedReports(String userName, Long langId, String languageAbbreviation, String webSiteCountryName) {
    List<ProductivityReport> result;
    SearchProductivityReport searchForm = new SearchProductivityReport();
    searchForm.setCreatorScreenName(userName);
    searchForm.setState(ProductivityReportState.PUBLISH);
    try {
      result = search(searchForm, langId, languageAbbreviation, webSiteCountryName);
    } catch (Exception e) {
      result = new ArrayList<ProductivityReport>();
      LOG.severe(e.getMessage());
    }
    return result;
  }

  @Override
  public UCompetitor loadCompetitor(UCompetitor competitor) {
    UCompetitor mergedCompetitor = entityManager.merge(competitor);
    Hibernate.initialize(mergedCompetitor.getProductBrands());
    return mergedCompetitor;
  }

  @Override
  public List<UMaterial> getMaterialList(Long langId) {
    List<UMaterial> result = new ArrayList<UMaterial>();

    result = entityManager.createQuery(singletonBean.getProductivityReportQuery("productivity.report.materialList"), UMaterial.class)
            .setParameter("langId", langId)
            .getResultList();
    return result;
  }

  public String getTranslation(String instanceguid, String languageAbbreviation) {
    String returnValue = "";
    try {
      returnValue = entityManager.createQuery(singletonBean.getProductivityReportQuery("productivity.report.getTranslation"), String.class)
              .setParameter("languageAbbreviation", languageAbbreviation)
              .setParameter("instanceguid", instanceguid)
              .getSingleResult();

    } catch (NoResultException e) {
      LOG.warning("translation not found: " + e.getMessage());
    }
    return returnValue;
  }

  @Override
  public PrWalterProduct getProductByGuid(String productVersionGuid, String countryCode, String langCode) {
    PrWalterProduct pr = new PrWalterProduct();

    try {
      List<Object[]> objectList = entityManager.createNativeQuery(singletonBean.getProductivityReportQuery("mobileProductivity.getWalterProduct"))
              .setParameter("productVersion", productVersionGuid)
              .setParameter("countryCode", countryCode)
              .getResultList();
      if (objectList.size() > 0) {

        Object[] object = objectList.get(0);

        String productNumber = object[0].toString();
        String franchiseguid = object[1].toString();

        pr.setProductNumber(productNumber);
        pr.setProductLineClaassesguid(franchiseguid);
        pr = getWalterProduct(productNumber, countryCode, langCode);
      }

    } catch (NoResultException e) {
      LOG.warning("getProductByGuid not found: " + e.getMessage());
    }
    return pr;
  }

  @Override
  public UMaterial getMaterial(long materialId, long langId) {
    UMaterial um = new UMaterial();
    try {

      um = entityManager.createQuery(singletonBean.getProductivityReportQuery("material.getMaterial"), UMaterial.class)
              .setParameter("materialId", materialId)
              .setParameter("langId", langId)
              .getSingleResult();

    } catch (NoResultException e) {
      LOG.warning("getMaterial not found: " + e.getMessage());
    }
    return um;
  }

  public JasperMobileProductivityReportBean MobileProductivitySendEmail(Reports report) {
    JasperMobileProductivityReportBean jmprb = new JasperMobileProductivityReportBean();
    try {
      jmprb.setCom((report.getCom() != null) ? report.getCom() : "");
      jmprb.setComBackingNumber((report.getComBackingNumber() != null) ? report.getComBackingNumber() : "");
      jmprb.setComBackingPadPrice((report.getComBackingPadPrice() != null) ? report.getComBackingPadPrice() : 0D);
      jmprb.setComDiameter((report.getComDiameter() != null) ? report.getComDiameter() : 0D);
      jmprb.setComEndUserPrice((report.getComEndUserPrice() != null) ? report.getComEndUserPrice() : 0D);
      jmprb.setComGrit((report.getComGrit() != null) ? report.getComGrit() : "");
      jmprb.setComNumberOfYears((report.getComNumberOfYears() != null) ? report.getComNumberOfYears() : 0L);
      jmprb.setComOtherPowerTools((report.getComOtherPowerTools() != null) ? report.getComOtherPowerTools() : "");
      jmprb.setComPowerTools((report.getComPowerTools() != null) ? report.getComPowerTools() : "");
      jmprb.setComProductName((report.getComProductName() != null) ? report.getComProductName() : "");
      jmprb.setComProductNumber((report.getComProductNumber() != null) ? report.getComProductNumber() : "");
      jmprb.setComQuantityBackingPerYear((report.getComQuantityBackingPerYear() != null) ? report.getComQuantityBackingPerYear() : 0L);
      jmprb.setComQuantityDiscPerYear((report.getComQuantityDiscPerYear() != null) ? report.getComQuantityDiscPerYear() : 0L);
      jmprb.setContactAddress1((report.getContactAddress1() != null) ? report.getContactAddress1() : "");
      jmprb.setContactAddress2((report.getContactAddress2() != null) ? report.getContactAddress2() : "");
      jmprb.setContactCity((report.getContactCity() != null) ? report.getContactCity() : "");
      jmprb.setContactCountry((report.getContactCountry() != null) ? report.getContactCountry() : "");
      jmprb.setContactEmail((report.getContactEmail() != null) ? report.getContactEmail() : "");
      jmprb.setContactEnterprise((report.getContactEnterprise() != null) ? report.getContactEnterprise() : "");
      jmprb.setContactName((report.getContactName() != null) ? report.getContactName() : "");
      jmprb.setContactZip((report.getContactZip() != null) ? report.getContactZip() : "");
      jmprb.setShopRate((report.getShopRate() != null) ? report.getShopRate() : 0D);
      jmprb.setTimePerDiscChangeover((report.getTimePerDiscChangeover() != null) ? report.getTimePerDiscChangeover() : 0L);
      jmprb.setWalEndUserPrice((report.getWalEndUserPrice() != null) ? report.getWalEndUserPrice() : 0D);
      jmprb.setWalOtherPowerTools((report.getWalOtherPowerTools() != null) ? report.getWalOtherPowerTools() : "");
      jmprb.setWalPowerTools((report.getWalPowerTools() != null) ? report.getWalPowerTools() : "");

      String clientAdrress = "";
      clientAdrress = (!jmprb.getContactEnterprise().equals("")) ? jmprb.getContactEnterprise() + "\n" : "";
      clientAdrress += (!jmprb.getContactAddress1().equals("")) ? jmprb.getContactAddress1() + " " : "";
      clientAdrress += (!jmprb.getContactAddress2().equals("")) ? jmprb.getContactAddress2() : "";
      if (!jmprb.getContactAddress1().equals("") || !jmprb.getContactAddress2().equals("")) {
        clientAdrress += "\n";
      }
      clientAdrress += (!jmprb.getContactCity().equals("")) ? jmprb.getContactCity() + " " : "";
      clientAdrress += (!jmprb.getContactZip().equals("")) ? jmprb.getContactZip() + " " : "";
      clientAdrress += (!jmprb.getContactCountry().equals("")) ? jmprb.getContactCountry() : "";
      jmprb.setClientAddress(clientAdrress);

      jmprb.setClientContact(((!jmprb.getContactName().equals("")) ? jmprb.getContactName().toUpperCase() + "\n" : "")
              + ((!jmprb.getContactEmail().equals("")) ? jmprb.getContactEmail() : ""));

      jmprb.setAnnualCuttingRequirements((report.getReportsProductivity().getAnnualCuttingRequirements() != null) ? report.getReportsProductivity().getAnnualCuttingRequirements() : 0L);
      jmprb.setAnnualRemovalRequirements((report.getReportsProductivity().getAnnualRemovalRequirements() != null) ? report.getReportsProductivity().getAnnualRemovalRequirements() : 0D);
      jmprb.setComAnnualBackingPadsCost((report.getReportsProductivity().getComAnnualBackingPadsCost() != null) ? report.getReportsProductivity().getComAnnualBackingPadsCost() : 0L);
      jmprb.setComAnnualDiscsCost((report.getReportsProductivity().getComAnnualDiscsCost() != null) ? report.getReportsProductivity().getComAnnualDiscsCost() : 0L);
      jmprb.setComAnnualLaborCost((report.getReportsProductivity().getComAnnualLaborCost() != null) ? report.getReportsProductivity().getComAnnualLaborCost() : 0L);
      jmprb.setComAnnualOperationCost((report.getReportsProductivity().getComAnnualOperationCost() != null) ? report.getReportsProductivity().getComAnnualOperationCost() : 0L);
      jmprb.setComAnnualOperationTime((report.getReportsProductivity().getComAnnualOperationTime() != null) ? report.getReportsProductivity().getComAnnualOperationTime() : 0L);
      jmprb.setComAnnualTotalProdCost((report.getReportsProductivity().getComAnnualTotalProdCost() != null) ? report.getReportsProductivity().getComAnnualTotalProdCost() : 0L);
      jmprb.setComAnnualTotalTime((report.getReportsProductivity().getComAnnualTotalTime() != null) ? report.getReportsProductivity().getComAnnualTotalTime() : 0L);
      jmprb.setComAvgTimePerCut((report.getReportsProductivity().getComAvgTimePerCut() != null) ? report.getReportsProductivity().getComAvgTimePerCut() : 0D);
      jmprb.setComDurability((report.getReportsProductivity().getComDurability() != null) ? report.getReportsProductivity().getComDurability() : 0L);
      jmprb.setComNumberCutPerDisc((report.getReportsProductivity().getComNumberCutPerDisc() != null) ? report.getReportsProductivity().getComNumberCutPerDisc() : 0L);
      jmprb.setComTimePerWheelChangeOver((report.getReportsProductivity().getComTimePerWheelChangeOver() != null) ? report.getReportsProductivity().getComTimePerWheelChangeOver() : 0L);
      jmprb.setLaborCostSaving((report.getReportsProductivity().getLaborCostSaving() != null) ? report.getReportsProductivity().getLaborCostSaving() : 0L);
      jmprb.setLaborCostSavingPercentage((report.getReportsProductivity().getLaborCostSavingPercentage() != null) ? report.getReportsProductivity().getLaborCostSavingPercentage() : 0L);
      jmprb.setProdCostSaving((report.getReportsProductivity().getProdCostSaving() != null) ? report.getReportsProductivity().getProdCostSaving() : 0L);
      jmprb.setProdCostSavingPercentage((report.getReportsProductivity().getProdCostSavingPercentage() != null) ? report.getReportsProductivity().getProdCostSavingPercentage() : 0L);
      jmprb.setTotalCostSaving((report.getReportsProductivity().getTotalCostSaving() != null) ? report.getReportsProductivity().getTotalCostSaving() : 0L);
      jmprb.setTotalCostSavingPercentage((report.getReportsProductivity().getTotalCostSavingPercentage() != null) ? report.getReportsProductivity().getTotalCostSavingPercentage() : 0L);
      jmprb.setWalAnnualDiscConsumption((report.getReportsProductivity().getWalAnnualDiscConsumption() != null) ? report.getReportsProductivity().getWalAnnualDiscConsumption() : 0L);
      jmprb.setWalAnnualDiscsCost((report.getReportsProductivity().getWalAnnualDiscsCost() != null) ? report.getReportsProductivity().getWalAnnualDiscsCost() : 0L);
      jmprb.setWalAnnualLaborCost((report.getReportsProductivity().getWalAnnualLaborCost() != null) ? report.getReportsProductivity().getWalAnnualLaborCost() : 0L);
      jmprb.setWalAnnualOperationCost((report.getReportsProductivity().getWalAnnualOperationCost() != null) ? report.getReportsProductivity().getWalAnnualOperationCost() : 0L);
      jmprb.setWalAnnualOperationTime((report.getReportsProductivity().getWalAnnualOperationTime() != null) ? report.getReportsProductivity().getWalAnnualOperationTime() : 0L);
      jmprb.setWalAnnualTotalProdCost((report.getReportsProductivity().getWalAnnualTotalProdCost() != null) ? report.getReportsProductivity().getWalAnnualTotalProdCost() : 0L);
      jmprb.setWalAnnualTotalTime((report.getReportsProductivity().getWalAnnualTotalTime() != null) ? report.getReportsProductivity().getWalAnnualTotalTime() : 0L);
      jmprb.setWalAvgTimePerCut((report.getReportsProductivity().getWalAvgTimePerCut() != null) ? report.getReportsProductivity().getWalAvgTimePerCut() : 0D);
      jmprb.setWalBackingPadQuantity((report.getReportsProductivity().getWalBackingPadQuantity() != null) ? report.getReportsProductivity().getWalBackingPadQuantity() : 0L);
      jmprb.setWalDurability((report.getReportsProductivity().getWalDurability() != null) ? report.getReportsProductivity().getWalDurability() : 0L);
      jmprb.setWalNumberCutPerDisc((report.getReportsProductivity().getWalNumberCutPerDisc() != null) ? report.getReportsProductivity().getWalNumberCutPerDisc() : 0L);
      jmprb.setWalTotalMaterialRemoved((report.getReportsProductivity().getWalTotalMaterialRemoved()!= null) ? report.getReportsProductivity().getWalTotalMaterialRemoved() : 0D);
      jmprb.setComTotalMaterialRemoved((report.getReportsProductivity().getComTotalMaterialRemoved()!= null) ? report.getReportsProductivity().getComTotalMaterialRemoved() : 0D);
      jmprb.setWalTimePerWheelChangeOver((report.getReportsProductivity().getWalTimePerWheelChangeOver() != null) ? report.getReportsProductivity().getWalTimePerWheelChangeOver() : 0L);
      jmprb.setWalRemovalRate((report.getReportsProductivity().getWalRemovalRate()!= null) ? report.getReportsProductivity().getWalRemovalRate() : 0L);
      jmprb.setComRemovalRate((report.getReportsProductivity().getComRemovalRate()!= null) ? report.getReportsProductivity().getComRemovalRate() : 0L);
      jmprb.setCreationDate(new SimpleDateFormat("dd/MM/YYYY").format(report.getCreationDate()));

      jmprb.setMethodId( (report.getMethodId() != null) ? report.getMethodId() : "0" );
      jmprb.setNbPiecesDone( (report.getReportsProductivity().getNbPiecesDone() != null) ? report.getReportsProductivity().getNbPiecesDone() : 0L );
      jmprb.setComAvgTimePiece((report.getComAvgTimePiece()!= null) ? report.getComAvgTimePiece() : 0L);
      jmprb.setComDistance((report.getComDistance()!= null) ? report.getComDistance() : 0D);
      jmprb.setComNbPieces((report.getComNbPieces() != null) ? report.getComNbPieces() : 0L);
      jmprb.setComTotalTime((report.getComTotalTime()!= null) ? report.getComTotalTime() : 0D);
      jmprb.setWalAvgTimePiece((report.getWalAvgTimePiece()!= null) ? report.getWalAvgTimePiece() : 0L);
      jmprb.setWalDistance((report.getWalDistance()!= null) ? report.getWalDistance() : 0L);
      jmprb.setWalNbPieces((report.getWalNbPieces()!= null) ? report.getWalNbPieces() : 0L);
      jmprb.setWalTotalTime((report.getWalTotalTime() != null) ? report.getWalTotalTime() : 0D);

//      $F{showReimbursement} == true && $F{totalCostSaving}>0 && $F{totalCostSaving}>$F{comAnnualTotalProdCost}
//
//      $F{showReimbursement} == true && $F{totalCostSaving}>0 && $F{totalCostSaving}<$F{comAnnualTotalProdCost}



      if ( report.getReportsLostsavings() != null && report.getReportsLostsavings().getSaving()!= null ){
        jmprb.setSaving((report.getReportsLostsavings().getSaving() != null) ? report.getReportsLostsavings().getSaving() : 0D);
      } else {
        jmprb.setSaving(0D);
      }
      if ( report.getReportsReimbursement() != null && report.getReportsReimbursement().getActive() != null ){
        jmprb.setReimbursement((report.getReportsReimbursement().getReimbursement() != null) ? report.getReportsReimbursement().getReimbursement() : 0D);
        jmprb.setPricePerDisc((report.getReportsReimbursement().getPricePerDisc() != null) ? report.getReportsReimbursement().getPricePerDisc() : 0D);
        jmprb.setNumberOfPads((report.getReportsReimbursement().getNumberOfPads() != null) ? report.getReportsReimbursement().getNumberOfPads() : 0L);
        jmprb.setNumberOfDiscs((report.getReportsReimbursement().getNumberOfDiscs() != null) ? report.getReportsReimbursement().getNumberOfDiscs() : 0L);
      } else {
        jmprb.setReimbursement(0D);
        jmprb.setPricePerDisc(0D);
        jmprb.setNumberOfPads(0L);
        jmprb.setNumberOfDiscs(0L);
      }

      if ( report.getApplicationId() != null ){
        OoInstances oo = walterBean.getWalterById(OoInstances.class, report.getApplicationId());
        jmprb.setActionNameEn(oo.getInstancename());
      }

      if (report.getReportsReimbursement() != null && report.getReportsReimbursement().getActive() == 1) {
        jmprb.setShowReimbursement(true);
      } else {
        jmprb.setShowReimbursement(false);
      }

      if (report.getReportsLostsavings() != null && report.getReportsLostsavings().getActive() == 1) {
        jmprb.setShowSaving(true);
      } else {
        jmprb.setShowSaving(false);
      }

      User reportCreator = UserLocalServiceUtil.getUserById(report.getUserId().longValue());

      System.out.println("reportCreator.getScreenName: " + reportCreator.getScreenName());
      System.out.println("reportCreator.getLocale: " + reportCreator.getLocale());




      jmprb.setSaleRepEmail(reportCreator.getEmailAddress());
      jmprb.setSaleRepFirstName(reportCreator.getFirstName());
      jmprb.setSaleRepImage(UserConstants.getPortraitURL("http://waltershare.com/image", reportCreator.isMale(), reportCreator.getPortraitId()));
      jmprb.setSaleRepLastName(reportCreator.getLastName());

      String country = walterBean.getWebSiteCountryName(reportCreator.getScreenName().toUpperCase());

      Locale locale = reportCreator.getLocale();

      PrWalterProduct prWalterProduct = getProductByGuid(report.getWalProductId(), country, locale.getLanguage());

      PrApplication prApplication = getApplication(report.getApplicationId(), locale.getLanguage());
      jmprb.setApplicationName(prApplication.getName());
      jmprb.setWalProductTradeName(prWalterProduct.getProductName().getDescription());

      String productnumber = prWalterProduct.getProductNumber().substring(0, 2) + "-" + prWalterProduct.getProductNumber().substring(2, 3) + " " + prWalterProduct.getProductNumber().substring(3);

      jmprb.setWalProductNumber(productnumber);
      jmprb.setWalProductDiameter(( prWalterProduct.getDiameter() != null ) ? prWalterProduct.getDiameter() : "");

      long langId = walterBean.getDbLanguageId(locale.getLanguage());

      UMaterial um = getMaterial(Long.parseLong(report.getMaterialId()), langId);
      jmprb.setMaterial(um.getMaterialDesc());

      if ( jmprb.getActionNameEn().equals("Cutting") ){

        Double performance = 0D;
        Double faster = 0D;
        if ( jmprb.getMethodId().equals("1") ){
          performance =  (jmprb.getWalDistance().doubleValue() - jmprb.getComDistance().doubleValue()) / jmprb.getComDistance().doubleValue() * 100;
          faster = (jmprb.getWalTotalTime()- jmprb.getComTotalTime()) / jmprb.getComTotalTime()* 100 * -1;
        } else {
          performance =  (jmprb.getWalNumberCutPerDisc().doubleValue() - jmprb.getComNumberCutPerDisc().doubleValue()) / jmprb.getComNumberCutPerDisc().doubleValue() * 100;
          faster = (jmprb.getWalAvgTimePerCut() - jmprb.getComAvgTimePerCut()) / jmprb.getComAvgTimePerCut() * 100 * -1;
        }

        jmprb.setPerformanceMoreDurable(performance.longValue());
        jmprb.setPerformanceFaster(faster);

      } else {
        Double performanceMoreRemoval = (jmprb.getWalTotalMaterialRemoved().doubleValue() - jmprb.getComTotalMaterialRemoved().doubleValue()) / jmprb.getComTotalMaterialRemoved().doubleValue() * 100;
        jmprb.setPerformanceMoreRemoval(performanceMoreRemoval.longValue());

        Double performanceMoreDurable= (jmprb.getWalDurability().doubleValue() - jmprb.getComDurability().doubleValue()) / jmprb.getComDurability().doubleValue() * 100;
        jmprb.setPerformanceMoreDurable(performanceMoreDurable.longValue());

        Double faster = (jmprb.getWalRemovalRate().doubleValue()- jmprb.getComRemovalRate().doubleValue()) / jmprb.getComRemovalRate().doubleValue()* 100;
        jmprb.setPerformanceFaster(faster);
      }
      jmprb.setDiscsLess(((jmprb.getComQuantityDiscPerYear() != null) ? jmprb.getComQuantityDiscPerYear() : 0L)
              - ((jmprb.getWalAnnualDiscConsumption() != null) ? jmprb.getWalAnnualDiscConsumption() : 0L));

      jmprb.setLocale(locale);
      jmprb.setLangId(langId);

      jmprb.setDiscCostSaving( jmprb.getComAnnualTotalProdCost()-jmprb.getTotalCostSaving() );
      jmprb.setLessTime( jmprb.getComAnnualTotalTime().doubleValue() - jmprb.getWalAnnualTotalTime().doubleValue());

      messages = ResourceBundle.getBundle("resources/MessagesBundle", locale);

      double walTotalMaterialRemoved = (report.getReportsProductivity().getWalTotalMaterialRemoved() != null) ? report.getReportsProductivity().getWalTotalMaterialRemoved() : 0D;
      long walRemovalRate = (report.getReportsProductivity().getWalRemovalRate() != null) ? report.getReportsProductivity().getWalRemovalRate() : 0L;

      double comTotalMaterialRemoved = (report.getReportsProductivity().getComTotalMaterialRemoved() != null) ? report.getReportsProductivity().getComTotalMaterialRemoved() : 0D;
      long comRemovalRate = (report.getReportsProductivity().getComRemovalRate() != null) ? report.getReportsProductivity().getComRemovalRate() : 0L;

      if ( country.equals("US") ){
        jmprb.setWalTotalMaterialRemovedStr(weightGramToLbs(walTotalMaterialRemoved, locale));
        jmprb.setWalRemovalRateStr(weightGramToLbs(walRemovalRate, locale));
        jmprb.setComTotalMaterialRemovedStr(weightGramToLbs(comTotalMaterialRemoved, locale));
        jmprb.setComRemovalRateStr(weightGramToLbs(comRemovalRate, locale));
        jmprb.setDistanceUnit(getMessage("labelMobileProductivityDistanceImperial"));
        String annualRemovalQuantity = "";
        DecimalFormat formatterFloat = new DecimalFormat("###,###");
        if ( jmprb.getMethodId().equals("1") ){
          annualRemovalQuantity = formatterFloat.format(Math.round((float)(jmprb.getComDistance() * jmprb.getComQuantityDiscPerYear()/12))) + " " + getMessage("labelMobileProductivityDistanceFeetImperial")+getMessage("labelMobileProductivityByYear");

        } else if ( jmprb.getMethodId().equals("2") ) {
          annualRemovalQuantity = weightGramToLbs(comTotalMaterialRemoved * jmprb.getComQuantityDiscPerYear(), locale) + " " + getMessage("labelMobileProductivityByYear");

        } else if ( jmprb.getMethodId().equals("3") ) {
          annualRemovalQuantity = formatterFloat.format(jmprb.getComNbPieces() * jmprb.getComQuantityDiscPerYear()) + " " + getMessage("labelMobileProductivityPiecesYear");

        } else {
          annualRemovalQuantity = formatterFloat.format(jmprb.getComNumberCutPerDisc() * jmprb.getComQuantityDiscPerYear()) + " " + getMessage("labelMobileProductivityCutYear");
        }

        jmprb.setAnnualRemovalQuantity(annualRemovalQuantity);

      } else {
        String labelG = getMessage("labelMobileProductivityGramAbbreviation");
        String labelmin = getMessage("labelMobileProductivityMinuteAbbreviation");
        DecimalFormat formatterFloat = new DecimalFormat("###,###");
        jmprb.setWalTotalMaterialRemovedStr(formatterFloat.format(Math.round((float)walTotalMaterialRemoved)) + " " + labelG);
        jmprb.setWalRemovalRateStr(formatterFloat.format(Math.round((float)walRemovalRate)) + " " + labelG+"/"+labelmin);
        jmprb.setComTotalMaterialRemovedStr(formatterFloat.format(Math.round((float)comTotalMaterialRemoved)) + " " + labelG);
        jmprb.setComRemovalRateStr(formatterFloat.format(Math.round((float)comRemovalRate)) + " " + labelG+"/"+labelmin);
        jmprb.setDistanceUnit(getMessage("labelMobileProductivityDistanceMetric"));

        String annualRemovalQuantity = "";

        if ( jmprb.getMethodId().equals("1") ){
          annualRemovalQuantity = formatterFloat.format(Math.round((float)(jmprb.getComDistance() * jmprb.getComQuantityDiscPerYear()/100))) + " " + getMessage("labelMobileProductivityDistanceMeterMetric")+getMessage("labelMobileProductivityByYear");

        } else if ( jmprb.getMethodId().equals("2") ) {
          annualRemovalQuantity = formatterFloat.format(comTotalMaterialRemoved * jmprb.getComQuantityDiscPerYear()/1000) + " " + getMessage("labelMobileProductivityKiloGramAbbreviation") + getMessage("labelMobileProductivityByYear");

        } else if ( jmprb.getMethodId().equals("3") ) {
          annualRemovalQuantity = formatterFloat.format(jmprb.getComNbPieces() * jmprb.getComQuantityDiscPerYear()) + " " + getMessage("labelMobileProductivityPiecesYear");

        } else {
          annualRemovalQuantity = formatterFloat.format((jmprb.getComNumberCutPerDisc() * jmprb.getComQuantityDiscPerYear())) + " " + getMessage("labelMobileProductivityCutYear");
        }
        jmprb.setAnnualRemovalQuantity(annualRemovalQuantity);

      }

    } catch (PortalException ex) {
      jmprb = new JasperMobileProductivityReportBean();
      Logger.getLogger(ProductivityReportBean.class.getName()).log(Level.SEVERE, "PortalException: " + ex.getMessage(), ex);
    } catch (SystemException ex) {
      jmprb = new JasperMobileProductivityReportBean();
      Logger.getLogger(ProductivityReportBean.class.getName()).log(Level.SEVERE, "SystemException: " + ex.getMessage(), ex);
    } catch (Exception ex) {
      jmprb = new JasperMobileProductivityReportBean();
      Logger.getLogger(ProductivityReportBean.class.getName()).log(Level.SEVERE, "Exception: " + ex.getMessage(), ex);
    }
    if ( jmprb.getWalProductNumber() == null ){
      jmprb = new JasperMobileProductivityReportBean();
    }

    return jmprb;
  }

  private String weightGramToLbs(double weight, Locale locale){

    String labelLb = getMessage("labelMobileProductivityLbs");
    String labelOz = getMessage("labelMobileProductivityOz");
    weight = weight / 453.592;
    double lb = Math.round(Math.floor(weight) * 100 / 100);
    double oz = Math.round(((weight % 1) * 16) * 100 / 100);
    return ( Math.round((float)lb) + labelLb + " " + Math.round((float)oz) +labelOz);
  }


  public String getMessage(String key) {
    try {
      return messages.getString(key);
    } catch (Exception ex) {
      return key;
    }
  }

  public List<Reports> getMobileProductivityReportReadyEmail(){
    List<Reports> reports = new ArrayList<>();
    try {

      reports = entityManager.createQuery(singletonBean.getProductivityReportQuery("mobileProductivity.getReportReadyToSendEmail"))
                             .getResultList();
    } catch (Exception e) {
//      e.printStackTrace();
      System.out.println("getMobileProductivityReportReadyEmail not found: " + e.getMessage());
      LOG.warning("getMobileProductivityReportReadyEmail not found: " + e.getMessage());
    }

    return reports;
  }

  public List<Orders> getMobileProductivityOrderEmail(){
    List<Orders> orders = new ArrayList<>();
    try {

      orders = entityManager.createQuery(singletonBean.getProductivityReportQuery("mobileProductivity.getOrderReadyToSendEmail"))
                             .getResultList();
    } catch (Exception e) {
      LOG.warning("getMobileProductivityOrderEmail not found: " + e.getMessage());
    }

    return orders;
  }

  @Schedule(hour="*", minute="*/10")
  private void MobileProductivityReportSendEmail(){
    System.out.println("send email for MobileProductivityReport " + new Date());
    notificationBean.sendMobileProductivityReportSendEmail();
    notificationBean.sendMobileProductivityOrderNotification();
  }

}
