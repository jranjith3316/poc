package com.savoirfairelinux.walter.util;

import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.List;

/**
 *
 * @author jsgill
 */
public class CSV {

//  private FileWriter file;
  private String fileName;
  private String liferayPath;
  private String columnName;
  private char separators;
  private char quote;
  private StringBuilder sb;

  private ByteArrayOutputStream baos;
  private BufferedWriter writer;

  public CSV(String fileName, String liferayPath, String columnName, char separators, char quote) {
    this.fileName = fileName;
    this.liferayPath = liferayPath;
    this.columnName = columnName;
    this.separators = separators;
    this.quote = quote;
    sb = new StringBuilder();
    baos = new ByteArrayOutputStream();
    writer = new BufferedWriter(new OutputStreamWriter(baos));
  }

  public void saveFile() throws IOException {
//    file = new FileWriter("/tmp/" + fileName);
    writer.write(columnName + "\n");
    writer.write(sb.toString());
  }

  public void closeFile() throws IOException{
    writer.flush();
    writer.close();
  }

  private String replaceQuote(String value) {
    String result = value;

    if (result.contains("\"")) {
      result = result.replace("\"", "\"\"");
    }
    return result;
  }

  public void writeLine(List<String> values) throws IOException{
    writeLine(values, separators, quote);
  }

  public void writeLine(List<String> values, char separators, char quote) throws IOException {

    boolean first = true;

    for (String value : values) {
      if (!first) {
        sb.append(separators);
      }
      if (quote == ' ') {
        sb.append(replaceQuote(value));
      } else {
        sb.append(quote).append(replaceQuote(value)).append(quote);
      }

      first = false;
    }
    sb.append("\n");
  }

  public ByteArrayOutputStream getBaos() {
    return baos;
  }



}
