/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "U_INDUSTRY", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "UIndustry.findAll", query = "SELECT u FROM UIndustry u"),
    @NamedQuery(name = "UIndustry.findByIndustryId", query = "SELECT u FROM UIndustry u WHERE u.uIndustryPK.industryId = :industryId"),
    @NamedQuery(name = "UIndustry.findByLangId", query = "SELECT u FROM UIndustry u WHERE u.uIndustryPK.langId = :langId ORDER BY u.industryDesc"),
    @NamedQuery(name = "UIndustry.findByIndustryDesc", query = "SELECT u FROM UIndustry u WHERE u.industryDesc = :industryDesc")})
public class UIndustry implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected UIndustryPK uIndustryPK;
    @Size(max = 100)
    @Column(name = "INDUSTRY_DESC")
    private String industryDesc;

    public UIndustry() {
    }

    public UIndustry(UIndustryPK uIndustryPK) {
        this.uIndustryPK = uIndustryPK;
    }

    public UIndustry(long industryId, long langId) {
        this.uIndustryPK = new UIndustryPK(industryId, langId);
    }

    public UIndustryPK getUIndustryPK() {
        return uIndustryPK;
    }

    public void setUIndustryPK(UIndustryPK uIndustryPK) {
        this.uIndustryPK = uIndustryPK;
    }

    public String getIndustryDesc() {
        return industryDesc;
    }

    public void setIndustryDesc(String industryDesc) {
        this.industryDesc = industryDesc;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (uIndustryPK != null ? uIndustryPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof UIndustry)) {
            return false;
        }
        UIndustry other = (UIndustry) object;
        if ((this.uIndustryPK == null && other.uIndustryPK != null) || (this.uIndustryPK != null && !this.uIndustryPK.equals(other.uIndustryPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.UIndustry[ uIndustryPK=" + uIndustryPK + " ]";
    }
    
}
