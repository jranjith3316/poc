/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.service.impl;

import com.savoirfairelinux.walter.dao.waltercb.NaicsCustomer;
import com.savoirfairelinux.walter.model.SearchSuspectNaics;
import com.savoirfairelinux.walter.service.NaicsBeanRemote;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;
import javax.annotation.security.PermitAll;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

/**
 *
 * @author jsgill
 */
@Stateless(name = "NaicsBean")
@TransactionManagement(TransactionManagementType.CONTAINER)
@PermitAll
@LocalBean
public class NaicsBean implements NaicsBeanRemote{
  public static final Logger LOG = Logger.getLogger(AnalysisReportBean.class.getCanonicalName());

  @PersistenceContext(unitName = "waltershare")
  EntityManager entityManager;
  @EJB
  SingletonBean singletonBean;
  @EJB
  WalterBean walterBean;
  
  @Override
  public List<NaicsCustomer> getNaicsCustomer(SearchSuspectNaics searchSuspectNaics) throws Exception{
    List<NaicsCustomer> naicsCustomerList = new ArrayList<NaicsCustomer>();

    try{

      StringBuilder queryBuilder = new StringBuilder();
      queryBuilder.append(" select nc ")
                  .append("  from NaicsCustomer nc")
                  .append(" where nc.countryId = :countryId ");

      Map<String, Object> properties = new HashMap<String, Object>();
      properties.put("countryId", searchSuspectNaics.getCountryId() );

      if ( searchSuspectNaics.getNaics() != null && !searchSuspectNaics.getNaics().equals("") ){
        queryBuilder.append("   and nc.primaryNaics like :naics ");
        properties.put("naics", searchSuspectNaics.getNaics()+"%");
      } else if ( searchSuspectNaics.getCbNaics() != null && !searchSuspectNaics.getCbNaics().equals("") ){
        queryBuilder.append("   and nc.primaryNaics like :cbNaics ");
        properties.put("cbNaics", searchSuspectNaics.getCbNaics()+"%");
      }

      if ( searchSuspectNaics.getCity() != null && !searchSuspectNaics.getCity().equals("") ){
        queryBuilder.append("   and lower(nc.city)  like :city ");
        properties.put("city", "%" + searchSuspectNaics.getCity().toLowerCase() + "%");
      }

      if ( searchSuspectNaics.getPostalCode() != null && !searchSuspectNaics.getPostalCode().equals("") ){
        queryBuilder.append("   and replace(lower(nc.postalCode),' ', '') like :postalCode ");
        properties.put("postalCode", "%" + searchSuspectNaics.getPostalCode().toLowerCase().replace(" ", "") + "%");
      }

      if ( searchSuspectNaics.getCountryStateTxt() != null && searchSuspectNaics.getCountryStateTxt().getCountryStateTxtPK() != null && 
           searchSuspectNaics.getCountryStateTxt().getCountryStateTxtPK().getStateCode() != null &&  !searchSuspectNaics.getCountryStateTxt().getCountryStateTxtPK().getStateCode().equals("") ){
        queryBuilder.append("   and nc.province = :state ");
        properties.put("state", searchSuspectNaics.getCountryStateTxt().getCountryStateTxtPK().getStateCode());
      }

      TypedQuery<NaicsCustomer> query = entityManager.createQuery(queryBuilder.toString(), NaicsCustomer.class);
      for (Map.Entry<String, Object> entry : properties.entrySet()) {
          query.setParameter(entry.getKey(), entry.getValue());
      }
      naicsCustomerList = query.getResultList();
    
    
    } catch (Exception e) {
      LOG.severe(e.getMessage());
      throw new Exception(e.getMessage());
    }

    return naicsCustomerList;
  }
  
}
