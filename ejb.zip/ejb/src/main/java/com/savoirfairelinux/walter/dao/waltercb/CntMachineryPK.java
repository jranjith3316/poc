/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

/**
 *
 * @author mgubaidullin
 */
@Embeddable
public class CntMachineryPK implements Serializable {
    @Basic(optional = false)
    @NotNull
    @Column(name = "CNT_ID")
    private long cntId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "MACHINERY_ID")
    private long machineryId;

    public CntMachineryPK() {
    }

    public CntMachineryPK(long cntId, long machineryId) {
        this.cntId = cntId;
        this.machineryId = machineryId;
    }

    public long getCntId() {
        return cntId;
    }

    public void setCntId(long cntId) {
        this.cntId = cntId;
    }

    public long getMachineryId() {
        return machineryId;
    }

    public void setMachineryId(long machineryId) {
        this.machineryId = machineryId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) cntId;
        hash += (int) machineryId;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CntMachineryPK)) {
            return false;
        }
        CntMachineryPK other = (CntMachineryPK) object;
        if (this.cntId != other.cntId) {
            return false;
        }
        if (this.machineryId != other.machineryId) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.CntMachineryPK[ cntId=" + cntId + ", machineryId=" + machineryId + " ]";
    }
    
}
