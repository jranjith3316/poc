/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.service.impl;

import com.savoirfairelinux.walter.dao.walter.UPerson;
import com.savoirfairelinux.walter.dao.waltercb.Country;
import com.savoirfairelinux.walter.dao.waltercb.CountryStateTxt;
import com.savoirfairelinux.walter.dao.waltercb.ULang;
import com.savoirfairelinux.walter.service.WalterBeanRemote;
import java.util.List;
import java.util.logging.Logger;
import javax.annotation.security.PermitAll;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

/**
 *
 * @author mgubaidullin
 */
@Stateless(name = "WalterBean")
@TransactionManagement(TransactionManagementType.CONTAINER)
@PermitAll
@LocalBean
public class WalterBean implements WalterBeanRemote {

    @PersistenceContext(unitName = "waltershare")
    EntityManager entityManager;
    public static final Logger LOG = Logger.getLogger(WalterBean.class.getCanonicalName());

    @Override
    public <T> T save(T coreObject) throws Exception {
        try {
            ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
            Validator validator = factory.getValidator();
            validator.validate(coreObject);
            coreObject = entityManager.merge(coreObject);
            return coreObject;
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    @Override
    public <T> T getWalterById(Class<T> aclClass, String id) throws Exception {
        T result;
        try {
            result = entityManager.find(aclClass, id);
        } catch (Exception e) {
          throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    public <T> List<T> getAllWalter(Class<T> aclClass) throws Exception {
        List<T> result;
        Query query = entityManager.createNamedQuery(aclClass.getSimpleName() + ".findAll");
        try {
            result = query.getResultList();
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    public <T> List<T> getAllWalterByLanguage(Class<T> aclClass, Long langId) throws Exception {
        List<T> result;
        Query query = entityManager.createNamedQuery(aclClass.getSimpleName() + ".findByLangId");
        query.setParameter("langId", langId);
        try {
            result = query.getResultList();

            if (result == null || result.isEmpty()) {
                query.setParameter("langId", Long.valueOf(ULang.ENGLISH_ID));
                result = query.getResultList();
            }
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    public <T> List<T> getAllWalterByCountry(Class<T> aclClass, Integer countryId) throws Exception {
        List<T> result;
        Query query = entityManager.createNamedQuery(aclClass.getSimpleName() + ".findByCountryId");
        query.setParameter("countryId", countryId);
        try {
            result = query.getResultList();
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    public Long getDbLanguageId(String httpLang) {
        ULang result;
        try {
//        	LOG.info("getDbLanguageId lang = " + httpLang);
            result = entityManager.createNamedQuery("ULang.findByHttpAbbreviation", ULang.class).setParameter("httpAbbreviation", httpLang).getSingleResult();
        } catch (Exception e) {
            LOG.warning(e.getMessage());
            result = entityManager.createNamedQuery("ULang.findByHttpAbbreviation", ULang.class).setParameter("httpAbbreviation", "en_US").getSingleResult();
        }
        return result.getLangId();
    }

    @Override
    public String getIdbAbbreviation(String httpLang) throws Exception {
        ULang result;
        try {
            result = entityManager.createNamedQuery("ULang.findByHttpAbbreviation", ULang.class).setParameter("httpAbbreviation", httpLang).getSingleResult();
        } catch (Exception e) {
            LOG.warning(e.getMessage());
            result = entityManager.createNamedQuery("ULang.findByHttpAbbreviation", ULang.class).setParameter("httpAbbreviation", "en_US").getSingleResult();
        }
        return result.getIdbAbbreviation();
    }

    @Override
    public String getWebSiteCountryName(String userName) throws Exception {
        Country result;
        try {
            result = entityManager
                    .createQuery("SELECT country FROM Country country, UPerson person WHERE country.countryId = person.countryId AND person.uPersonPK.userName = :userName", Country.class)
                    .setParameter("userName", userName.toUpperCase())
                    .getResultList().get(0);
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result.getWebsiteCountry();
    }

    @Override
    public Long getWebSiteCountryId(String userName) throws Exception {
        Country result;
        try {
            result = entityManager
                    .createQuery("SELECT country FROM Country country, UPerson person WHERE country.countryId = person.countryId AND person.uPersonPK.userName = :userName", Country.class)
                    .setParameter("userName", userName.toUpperCase())
                    .getResultList().get(0);
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result.getCountryId();
    }

    public ULang getULang(String languageAbbreviation) throws Exception {
        ULang result;
        try {
            result = entityManager.createNamedQuery("ULang.findByIdbAbbreviation", ULang.class).setParameter("idbAbbreviation", languageAbbreviation).getSingleResult();
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    public ULang getULang(Long langId) throws Exception {
        ULang result;
        try {
            result = entityManager.createNamedQuery("ULang.findByLangId", ULang.class).setParameter("langId", langId).getSingleResult();
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    public List<ULang> getAllULangOrderById() throws Exception {
        List<ULang> result;
        Query query = entityManager.createNamedQuery("ULang.findAll.orderBy.langId");
        try {
            result = query.getResultList();
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    public UPerson getUPerson(String userName) throws Exception {
        UPerson result;
        try {
            result = entityManager.createNamedQuery("UPerson.findByUserName", UPerson.class)
                    .setParameter("userName", userName)
                    .getSingleResult();
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    public List<UPerson> getUPersons(String managerName) throws Exception {
        List<UPerson> results;
        try {
            results = entityManager.createNamedQuery("UPerson.findByManagerUserName", UPerson.class)
                    .setParameter("managerUserName", managerName)
                    .getResultList();
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return results;
    }

    @Override
    public List<CountryStateTxt> getCountryStateTxtList(Long countryId, Long langId) throws Exception {
        List<CountryStateTxt> countryStateTxt = null;
        try {

            String query = " select cst\n"
                    + "   from CountryStateTxt cst\n"
                    + "  where cst.countryStateTxtPK.countryId = :countryId\n"
                    + "    and cst.countryStateTxtPK.langId in (select max(cst2.countryStateTxtPK.langId)\n"
                    + "                                           from CountryStateTxt cst2\n"
                    + "                                          where cst2.countryStateTxtPK.countryId = cst.countryStateTxtPK.countryId\n"
                    + "                                            and cst2.countryStateTxtPK.stateCode = cst.countryStateTxtPK.stateCode\n"
                    + "                                            and cst2.countryStateTxtPK.langId in (1, :langId ))\n"
                    + "  order by cst.stateDesc";

            countryStateTxt = entityManager
                    .createQuery(query, CountryStateTxt.class)
                    .setParameter("countryId", countryId)
                    .setParameter("langId", langId)
                    .getResultList();

        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return countryStateTxt;
    }

    @Override
    public String getNewGuid() throws Exception{
      Object result = new Object();
      try {

        result = entityManager.createNativeQuery("select rawtohex(sys_guid()) from dual")
                              .getSingleResult();


      } catch (Exception e) {
        LOG.info(e.getMessage());
      }
      return result.toString();

    }

}
