/* 
 * Copyright 2012 Savoir-faire Linux
 * 
 * This file is part of Walter-Portal.
 * 
 * Walter-Portal is free software: you can redistribute it and/or modify it under the terms of the 
 * GNU General Public License as published by the Free Software Foundation, either version 3 
 * of the License, or (at your option) any later version.
 * 
 * Walter-Portal is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with Walter-Portal. 
 * If not, see http://www.gnu.org/licenses/.
 */
package com.savoirfairelinux.walter.service;

import com.savoirfairelinux.walter.dao.waltercb.*;
import com.savoirfairelinux.walter.model.*;

import javax.ejb.Remote;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 *
 * @author mgubaidullin
 * @author jderuere
 */
@Remote
public interface SolutionReportBeanRemote {

    public List<Cnt> getRecentSolutionReports(String organization, String userName, String languageAbbreviation, String country) throws Exception;

    public List<Cnt> getUnreadSolutionReports(String organization, String userName, String languageAbbreviation, String country) throws Exception;

    public List<Cnt> getBestOpinionSolutionReports(String organization, String userName, String languageAbbreviation, String country) throws Exception;

    public List<Cnt> getValidationSolutionReports(String organization, String userName, String languageAbbreviation, String country) throws Exception;

    public List<Cnt> getMySolutionReports(String organization, String screenName, String idbAbbreviation, String webSiteCountryName, ReportState value) throws Exception;

    public List<Cnt> getManagementSolutionReports(String organization, String screenName, String idbAbbreviation, String webSiteCountryName, ReportState value) throws Exception;

    public List<Cnt> getReporterProfilSolutionReports(String organization, String screenName, String idbAbbreviation, String webSiteCountryName, String reporterScreenName) throws Exception;

    public Cnt getSolutionReport(Long cntId, String organization) throws Exception;

    public Cnt getSolutionReport(Long cntId, String organization, String languageAbbreviation) throws Exception;

    public CntCounter setCntCounter(Long cntId, String userName, String sessionId) throws Exception;

    public List<String> getSolutionReporterScreenNames() throws Exception;

    public List<CntLight> getSolutionReportReferences(String organization) throws Exception;

    public List<Cnt> search(SearchReport model, String userName, String languageAbbreviation) throws Exception;

    public List<UActivity> getSolutionReportActivities(Long cntId, Long langId) throws Exception;

    public List<UMachinery> getSolutionReportMachineries(Long cntId, Long langId) throws Exception;

    public List<UContaminant> getSolutionReportContaminants(Long cntId, Long langId) throws Exception;

    public List<UIndustry> getSolutionReportIndustries(Long cntId, Long langId) throws Exception;

    public List<UMaterial> getSolutionReportMaterials(Long cntId, Long langId) throws Exception;

    public List<Naics> getNaics(NaicsLevel level, Long countryId) throws Exception;

    public List<Naics> getNaicsList(String naics, Long countryId) throws Exception;

    public List<Franchise> getFranchises(String languageAbbreviation, String organization) throws Exception;

    public List<Tradename> getTradenames(String languageAbbreviation, String country, String organization) throws Exception;

    public List<CntTranslate> getMyPendingForTranslation(String userName, String languageAbbreviation, String country) throws Exception;

    public List<CntTranslate> getPendingForTranslation(String organization, String userName, String languageAbbreviation, String country) throws Exception;

    public void cancel(Cnt cnt, String userName) throws Exception;

    public Cnt addOpinion(CntOpinion cntOpinion) throws Exception;

    public CntTxt getCntTxt(Long cntId, Long langId) throws Exception;

    public void validate(Cnt cnt) throws Exception;

    public void invalidate(Cnt cnt) throws Exception;

    public Cnt publish(Cnt cnt) throws Exception;

    public List<NaicsCustomer> getNaicsCustomers(String customerFilter, Long countryId) throws Exception;

    public NaicsCustomer getNaicsCustomer(BigDecimal id) throws Exception;

    public Map<Long, Map<BigDecimal, String>> getNaicsCustomersMap() throws Exception;

    public Cnt save(Cnt cnt, Country country, ULang language, String pmName, String translatorName) throws Exception;

    public Cnt submit(Cnt cnt) throws Exception;

    public void submitTranslation(Cnt cnt, CntTranslate originalTranslate, long langId, String translatorName) throws Exception;

    public Cnt saveTranslation(Cnt cnt, CntTranslate originalTranslate, long langId, String translatorName) throws Exception;

    public void reply(CntFeedbackR feedbackReply) throws Exception;

    public void feedBack(CntFeedback feedback) throws Exception;

    public void load(Set<Cnt> reports, ULang language) throws Exception;

    Map<String, String> getWalterFranchisesTranslation(String languageAbbreviation) throws Exception;

    List<Tradename> getTradenames(String languageAbbreviation, String country) throws Exception;

    Map<String, String> getWalterTradenamesTranslation(String languageAbbreviation) throws Exception;
}
