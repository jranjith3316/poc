/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import javax.persistence.*;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "IDEA_FILE_TXT", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "IdeaFileTxt.findAll", query = "SELECT i FROM IdeaFileTxt i"),
    @NamedQuery(name = "IdeaFileTxt.findByFileId", query = "SELECT i FROM IdeaFileTxt i WHERE i.ideaFileTxtPK.fileId = :fileId"),
    @NamedQuery(name = "IdeaFileTxt.findByLangId", query = "SELECT i FROM IdeaFileTxt i WHERE i.ideaFileTxtPK.langId = :langId"),
    @NamedQuery(name = "IdeaFileTxt.findByFileTxt", query = "SELECT i FROM IdeaFileTxt i WHERE i.fileTxt = :fileTxt")})
public class IdeaFileTxt implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected IdeaFileTxtPK ideaFileTxtPK;
    @Size(max = 1000)
    @Column(name = "FILE_TXT")
    private String fileTxt;
    @JoinColumn(name = "FILE_ID", referencedColumnName = "FILE_ID", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private IdeaFile ideaFile;

    public IdeaFileTxt() {
    }

    public IdeaFileTxt(IdeaFileTxt ideaFileTxt, long langId) {
        this.ideaFileTxtPK = new IdeaFileTxtPK(ideaFileTxt.getIdeaFileTxtPK().getFileId(), langId);
        this.fileTxt = ideaFileTxt.getFileTxt();
        this.ideaFile = ideaFileTxt.getIdeaFile();
    }

    public IdeaFileTxt(IdeaFileTxtPK ideaFileTxtPK) {
        this.ideaFileTxtPK = ideaFileTxtPK;
    }

    public IdeaFileTxt(long fileId, long langId) {
        this.ideaFileTxtPK = new IdeaFileTxtPK(fileId, langId);
    }

    public IdeaFileTxtPK getIdeaFileTxtPK() {
        return ideaFileTxtPK;
    }

    public void setIdeaFileTxtPK(IdeaFileTxtPK ideaFileTxtPK) {
        this.ideaFileTxtPK = ideaFileTxtPK;
    }

    public String getFileTxt() {
        return fileTxt;
    }

    public void setFileTxt(String fileTxt) {
        this.fileTxt = fileTxt;
    }

    public IdeaFile getIdeaFile() {
        return ideaFile;
    }

    public void setIdeaFile(IdeaFile ideaFile) {
        this.ideaFile = ideaFile;
    }

    @PrePersist
    private void prePersist() {
        if (ideaFile != null && ideaFileTxtPK != null) {
            ideaFileTxtPK.setFileId(ideaFile.getFileId());
        }
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (ideaFileTxtPK != null ? ideaFileTxtPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof IdeaFileTxt)) {
            return false;
        }
        IdeaFileTxt other = (IdeaFileTxt) object;
        if (this.ideaFileTxtPK == null && other.ideaFileTxtPK == null) {
            return this == other;
        } else if ((this.ideaFileTxtPK == null && other.ideaFileTxtPK != null) || (this.ideaFileTxtPK != null && !this.ideaFileTxtPK.equals(other.ideaFileTxtPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.IdeaFileTxt[ ideaFileTxtPK=" + ideaFileTxtPK + " ]";
    }
}
