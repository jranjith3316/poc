/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.crossreferenceapp;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "COMPETITOR_MATERIAL", catalog = "", schema = "CROSSREFERENCEAPP")
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "CompetitorMaterial.findAll", query = "SELECT c FROM CompetitorMaterial c"),
  @NamedQuery(name = "CompetitorMaterial.findByBrandId", query = "SELECT c FROM CompetitorMaterial c WHERE c.competitorMaterialPK.brandId = :brandId"),
  @NamedQuery(name = "CompetitorMaterial.findByCompetitorId", query = "SELECT c FROM CompetitorMaterial c WHERE c.competitorMaterialPK.competitorId = :competitorId"),
  @NamedQuery(name = "CompetitorMaterial.findByProductId", query = "SELECT c FROM CompetitorMaterial c WHERE c.competitorMaterialPK.productId = :productId"),
  @NamedQuery(name = "CompetitorMaterial.findByCountryId", query = "SELECT c FROM CompetitorMaterial c WHERE c.competitorMaterialPK.countryId = :countryId"),
  @NamedQuery(name = "CompetitorMaterial.findByMaterialGuid", query = "SELECT c FROM CompetitorMaterial c WHERE c.competitorMaterialPK.materialGuid = :materialGuid"),
  @NamedQuery(name = "CompetitorMaterial.findByCreatedUserName", query = "SELECT c FROM CompetitorMaterial c WHERE c.createdUserName = :createdUserName"),
  @NamedQuery(name = "CompetitorMaterial.findByCreatedDate", query = "SELECT c FROM CompetitorMaterial c WHERE c.createdDate = :createdDate"),
  @NamedQuery(name = "CompetitorMaterial.findByUpdatedUserName", query = "SELECT c FROM CompetitorMaterial c WHERE c.updatedUserName = :updatedUserName"),
  @NamedQuery(name = "CompetitorMaterial.findByUpdatedDate", query = "SELECT c FROM CompetitorMaterial c WHERE c.updatedDate = :updatedDate")})
public class CompetitorMaterial implements Serializable {
  private static final long serialVersionUID = 1L;
  @EmbeddedId
  protected CompetitorMaterialPK competitorMaterialPK;
  @Size(max = 255)
  @Column(name = "CREATED_USER_NAME")
  private String createdUserName;
  @Column(name = "CREATED_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date createdDate;
  @Size(max = 255)
  @Column(name = "UPDATED_USER_NAME")
  private String updatedUserName;
  @Column(name = "UPDATED_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date updatedDate;

  public CompetitorMaterial() {
  }

  public CompetitorMaterial(CompetitorMaterialPK competitorMaterialPK) {
    this.competitorMaterialPK = competitorMaterialPK;
  }

  public CompetitorMaterial(long brandId, long competitorId, long productId, long countryId, String materialGuid) {
    this.competitorMaterialPK = new CompetitorMaterialPK(brandId, competitorId, productId, countryId, materialGuid);
  }

  public CompetitorMaterialPK getCompetitorMaterialPK() {
    return competitorMaterialPK;
  }

  public void setCompetitorMaterialPK(CompetitorMaterialPK competitorMaterialPK) {
    this.competitorMaterialPK = competitorMaterialPK;
  }

  public String getCreatedUserName() {
    return createdUserName;
  }

  public void setCreatedUserName(String createdUserName) {
    this.createdUserName = createdUserName;
  }

  public Date getCreatedDate() {
    return createdDate;
  }

  public void setCreatedDate(Date createdDate) {
    this.createdDate = createdDate;
  }

  public String getUpdatedUserName() {
    return updatedUserName;
  }

  public void setUpdatedUserName(String updatedUserName) {
    this.updatedUserName = updatedUserName;
  }

  public Date getUpdatedDate() {
    return updatedDate;
  }

  public void setUpdatedDate(Date updatedDate) {
    this.updatedDate = updatedDate;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (competitorMaterialPK != null ? competitorMaterialPK.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof CompetitorMaterial)) {
      return false;
    }
    CompetitorMaterial other = (CompetitorMaterial) object;
    if ((this.competitorMaterialPK == null && other.competitorMaterialPK != null) || (this.competitorMaterialPK != null && !this.competitorMaterialPK.equals(other.competitorMaterialPK))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.crossreferenceapp.CompetitorMaterial[ competitorMaterialPK=" + competitorMaterialPK + " ]";
  }

}
