/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "U_MATERIAL", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "UMaterial.findAll", query = "SELECT u FROM UMaterial u"),
    @NamedQuery(name = "UMaterial.findByMaterialId", query = "SELECT u FROM UMaterial u WHERE u.uMaterialPK.materialId = :materialId"),
    @NamedQuery(name = "UMaterial.findByLangId", query = "SELECT u FROM UMaterial u WHERE u.uMaterialPK.langId = :langId ORDER BY u.materialDesc"),
    @NamedQuery(name = "UMaterial.findByMaterialDesc", query = "SELECT u FROM UMaterial u WHERE u.materialDesc = :materialDesc")})
public class UMaterial implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected UMaterialPK uMaterialPK;
    @Size(max = 100)
    @Column(name = "MATERIAL_DESC")
    private String materialDesc;

    public UMaterial() {
    }

    public UMaterial(UMaterialPK uMaterialPK) {
        this.uMaterialPK = uMaterialPK;
    }

    public UMaterial(long materialId, long langId) {
        this.uMaterialPK = new UMaterialPK(materialId, langId);
    }

    public UMaterialPK getUMaterialPK() {
        return uMaterialPK;
    }

    public void setUMaterialPK(UMaterialPK uMaterialPK) {
        this.uMaterialPK = uMaterialPK;
    }

    public String getMaterialDesc() {
        return materialDesc;
    }

    public void setMaterialDesc(String materialDesc) {
        this.materialDesc = materialDesc;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (uMaterialPK != null ? uMaterialPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof UMaterial)) {
            return false;
        }
        UMaterial other = (UMaterial) object;
        if ((this.uMaterialPK == null && other.uMaterialPK != null) || (this.uMaterialPK != null && !this.uMaterialPK.equals(other.uMaterialPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.UMaterial[ uMaterialPK=" + uMaterialPK + " ]";
    }
    
}
