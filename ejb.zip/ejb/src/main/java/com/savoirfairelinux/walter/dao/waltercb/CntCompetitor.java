/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "CNT_COMPETITOR", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CntCompetitor.findAll", query = "SELECT c FROM CntCompetitor c"),
    @NamedQuery(name = "CntCompetitor.findByCntId", query = "SELECT c FROM CntCompetitor c WHERE c.cntCompetitorPK.cntId = :cntId"),
    @NamedQuery(name = "CntCompetitor.findByCompetitorId", query = "SELECT c FROM CntCompetitor c WHERE c.cntCompetitorPK.competitorId = :competitorId"),
    @NamedQuery(name = "CntCompetitor.findByProductDesc", query = "SELECT c FROM CntCompetitor c WHERE c.productDesc = :productDesc")})
public class CntCompetitor implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected CntCompetitorPK cntCompetitorPK;
    @Size(max = 40)
    @Column(name = "PRODUCT_DESC")
    private String productDesc;
    @JoinColumn(name = "CNT_ID", referencedColumnName = "CNT_ID", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Cnt cnt;

    public CntCompetitor() {
    }

    public CntCompetitor(CntCompetitorPK cntCompetitorPK) {
        this.cntCompetitorPK = cntCompetitorPK;
    }

    public CntCompetitor(long cntId, long competitorId) {
        this.cntCompetitorPK = new CntCompetitorPK(cntId, competitorId);
    }

    public CntCompetitorPK getCntCompetitorPK() {
        return cntCompetitorPK;
    }

    public void setCntCompetitorPK(CntCompetitorPK cntCompetitorPK) {
        this.cntCompetitorPK = cntCompetitorPK;
    }

    public String getProductDesc() {
        return productDesc;
    }

    public void setProductDesc(String productDesc) {
        this.productDesc = productDesc;
    }

    public Cnt getCnt() {
        return cnt;
    }

    public void setCnt(Cnt cnt) {
        this.cnt = cnt;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cntCompetitorPK != null ? cntCompetitorPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CntCompetitor)) {
            return false;
        }
        CntCompetitor other = (CntCompetitor) object;
        if ((this.cntCompetitorPK == null && other.cntCompetitorPK != null) || (this.cntCompetitorPK != null && !this.cntCompetitorPK.equals(other.cntCompetitorPK))) {
            return false;
        }
        return true;
    }
    
    @PrePersist
    private void prePersist() {
    	if (cnt != null && cntCompetitorPK != null) {
    		cntCompetitorPK.setCntId(cnt.getCntId());
    	}
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.CntCompetitor[ cntCompetitorPK=" + cntCompetitorPK + " ]";
    }
    
}
