package com.savoirfairelinux.walter.model;

import java.io.Serializable;

public class ProductivityCountry implements Serializable {
	private static final long serialVersionUID = 1L;

	private Long countryId;
	private String description;
	private String countryCode;
	
	public ProductivityCountry() {
	}
	
	public ProductivityCountry(Long countryId, String description, String countryCode) {
		this.countryId = countryId;
		this.description = description;
		this.countryCode = countryCode;
	}
	
	public Long getCountryId() {
		return countryId;
	}
	
	public void setCountryId(Long countryId) {
		this.countryId = countryId;
	}
	
	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	public String getCountryCode() {
		return countryCode;
	}
	
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
}
