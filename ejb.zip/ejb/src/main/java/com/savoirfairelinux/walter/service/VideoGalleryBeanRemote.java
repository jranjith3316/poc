/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.service;

import com.savoirfairelinux.walter.dao.walter.VgTreeItem;
import com.savoirfairelinux.walter.dao.walter.VgTreeItemTxt;
import com.savoirfairelinux.walter.dao.walter.VgTreeProduct;
import com.savoirfairelinux.walter.model.Franchise;
import com.savoirfairelinux.walter.model.Tradename;
import com.savoirfairelinux.walter.model.VideoGalleryItem;
import java.util.HashMap;
import java.util.List;
import javax.ejb.Remote;

/**
 *
 * @author jsgill
 */
@Remote
public interface VideoGalleryBeanRemote {
  public void deleteItem(Integer itemId, String treeCode, String userName) throws Exception;

//  public VgTreeItem getParentId(String treeCode, Integer parentId) throws Exception;
  
  public VgTreeItem getPhoto(Integer itemId, String treeCode) throws Exception ;

  public Integer getNextItemId(String treeCode) throws Exception;

  public Short getNextOrderBy(String treeCode, Integer parentId) throws Exception;

  public List<VgTreeItemTxt> getItemVideosByParentId(Integer itemParentId, Long langId, String treeCode) throws Exception;

  public List<VgTreeItemTxt> getImagesTxt(String languageAbbreviature, String treeCode) throws Exception;

   public List<VgTreeItemTxt> getTxtForItem(VgTreeItem pgTreeItem) throws Exception;
  
  public List<VgTreeItemTxt> getVideoItem(VgTreeItem pgTreeItem) throws Exception;

  public void setOrderUp(String treeCode, Integer itemIdSelected, Integer itemIdGoUp) throws Exception;

  public void setOrderDown(String treeCode, Integer itemIdSelected, Integer itemIdGoUp) throws Exception;
  
  public void setOrderBy(String vgTreeCode, Integer parentId) throws Exception;
  
  public VgTreeItemTxt getTxtByItemIdLangId(VgTreeItem vgTreeItem, Integer langId ) throws Exception;

  public List<VgTreeProduct> getProduct(VgTreeItem vgTreeItem) throws Exception;

  public Integer getNextProductId(String treeCode, int itemId ) throws Exception;

  public List<Tradename> getTradenames(String languageAbbreviation, String country, String organization, String vgTreeCode, int itemId) throws Exception;

  public HashMap<String, String> getWalterTradenamesTranslation(String languageAbbreviation) throws Exception;
  
  public List<Franchise> getFranchises(String languageAbbreviation, String organization) throws Exception;
  
  public HashMap<String, String> getWalterFranchisesTranslation(String languageAbbreviation) throws Exception;

  public Tradename getProductTradeName(String languageAbbreviation, String country, String tradeGuid) throws Exception;
  
  public Franchise getFranchise(String languageAbbreviation, String franchiseGuid) throws Exception;
}
