/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;

/**
 *
 * @author mgubaidullin
 */
@Embeddable
public class ErTrialTxtPK implements Serializable {
    @Basic(optional = false)
    @NotNull
    @Column(name = "TRIAL_ID", nullable = false)
    private long trialId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "LANG_ID", nullable = false)
    private long langId;

    public ErTrialTxtPK() {
    }

    public ErTrialTxtPK(long trialId, long langId) {
        this.trialId = trialId;
        this.langId = langId;
    }

    public long getTrialId() {
        return trialId;
    }

    public void setTrialId(long trialId) {
        this.trialId = trialId;
    }

    public long getLangId() {
        return langId;
    }

    public void setLangId(long langId) {
        this.langId = langId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) trialId;
        hash += (int) langId;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ErTrialTxtPK)) {
            return false;
        }
        ErTrialTxtPK other = (ErTrialTxtPK) object;
        if (this.trialId != other.trialId) {
            return false;
        }
        if (this.langId != other.langId) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.ErTrialTxtPK[ trialId=" + trialId + ", langId=" + langId + " ]";
    }
    
}
