/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "CB_TRADENAME", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CbTradename.findAll", query = "SELECT c FROM CbTradename c"),
    @NamedQuery(name = "CbTradename.findByTradenameId", query = "SELECT c FROM CbTradename c WHERE c.cbTradenamePK.tradenameId = :tradenameId"),
    @NamedQuery(name = "CbTradename.findByFranchiseId", query = "SELECT c FROM CbTradename c WHERE c.cbTradenamePK.franchiseId = :franchiseId"),
    @NamedQuery(name = "CbTradename.findByCreatedBy", query = "SELECT c FROM CbTradename c WHERE c.createdBy = :createdBy"),
    @NamedQuery(name = "CbTradename.findByCreationDate", query = "SELECT c FROM CbTradename c WHERE c.creationDate = :creationDate"),
    @NamedQuery(name = "CbTradename.findByDisplay", query = "SELECT c FROM CbTradename c WHERE c.display = :display")})
public class CbTradename implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected CbTradenamePK cbTradenamePK;
    @Size(max = 256)
    @Column(name = "CREATED_BY")
    private String createdBy;
    @Column(name = "CREATION_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date creationDate;
    @Column(name = "DISPLAY")
    private Character display;
    @JoinColumn(name = "FRANCHISE_ID", referencedColumnName = "FRANCHISE_ID", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private CbFranchise cbFranchise;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "cbTradename")
    private List<CbTradenameTxt> cbTradenameTxtList;

    public CbTradename() {
    }

    public CbTradename(CbTradenamePK cbTradenamePK) {
        this.cbTradenamePK = cbTradenamePK;
    }

    public CbTradename(long tradenameId, short franchiseId) {
        this.cbTradenamePK = new CbTradenamePK(tradenameId, franchiseId);
    }

    public CbTradenamePK getCbTradenamePK() {
        return cbTradenamePK;
    }

    public void setCbTradenamePK(CbTradenamePK cbTradenamePK) {
        this.cbTradenamePK = cbTradenamePK;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public Character getDisplay() {
        return display;
    }

    public void setDisplay(Character display) {
        this.display = display;
    }

    public CbFranchise getCbFranchise() {
        return cbFranchise;
    }

    public void setCbFranchise(CbFranchise cbFranchise) {
        this.cbFranchise = cbFranchise;
    }

    @XmlTransient
    public List<CbTradenameTxt> getCbTradenameTxtList() {
        return cbTradenameTxtList;
    }

    public void setCbTradenameTxtList(List<CbTradenameTxt> cbTradenameTxtList) {
        this.cbTradenameTxtList = cbTradenameTxtList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cbTradenamePK != null ? cbTradenamePK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CbTradename)) {
            return false;
        }
        CbTradename other = (CbTradename) object;
        if ((this.cbTradenamePK == null && other.cbTradenamePK != null) || (this.cbTradenamePK != null && !this.cbTradenamePK.equals(other.cbTradenamePK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.CbTradename[ cbTradenamePK=" + cbTradenamePK + " ]";
    }
    
}
