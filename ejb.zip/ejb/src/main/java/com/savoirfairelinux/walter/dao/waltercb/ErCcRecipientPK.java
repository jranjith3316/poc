/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;

/**
 *
 * @author mgubaidullin
 */
@Embeddable
public class ErCcRecipientPK implements Serializable {
    @Basic(optional = false)
    @NotNull
    @Column(name = "ER_ID", nullable = false)
    private long erId;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 256)
    @Column(name = "USER_NAME", nullable = false, length = 256)
    private String userName;

    public ErCcRecipientPK() {
    }

    public ErCcRecipientPK(long erId, String userName) {
        this.erId = erId;
        this.userName = userName;
    }

    public long getErId() {
        return erId;
    }

    public void setErId(long erId) {
        this.erId = erId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) erId;
        hash += (userName != null ? userName.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ErCcRecipientPK)) {
            return false;
        }
        ErCcRecipientPK other = (ErCcRecipientPK) object;
        if (this.erId != other.erId) {
            return false;
        }
        if ((this.userName == null && other.userName != null) || (this.userName != null && !this.userName.equals(other.userName))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.ErCcRecipientPK[ erId=" + erId + ", userName=" + userName + " ]";
    }
    
}
