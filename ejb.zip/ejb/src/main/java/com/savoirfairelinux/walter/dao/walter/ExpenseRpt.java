/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.walter;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Set;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "EXPENSE_RPT", catalog = "", schema = DatabaseConstants.WALTER_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "ExpenseRpt.findAll", query = "SELECT e FROM ExpenseRpt e"),
    @NamedQuery(name = "ExpenseRpt.findByExpenseRptId", query = "SELECT e FROM ExpenseRpt e WHERE e.expenseRptId = :expenseRptId"),
    @NamedQuery(name = "ExpenseRpt.findByCreatorUserName", query = "SELECT e FROM ExpenseRpt e WHERE e.creatorUserName = :creatorUserName"),
    @NamedQuery(name = "ExpenseRpt.findByCreationDate", query = "SELECT e FROM ExpenseRpt e WHERE e.creationDate = :creationDate"),
    @NamedQuery(name = "ExpenseRpt.findByFromDate", query = "SELECT e FROM ExpenseRpt e WHERE e.fromDate = :fromDate"),
    @NamedQuery(name = "ExpenseRpt.findByToDate", query = "SELECT e FROM ExpenseRpt e WHERE e.toDate = :toDate"),
    @NamedQuery(name = "ExpenseRpt.findByCancelDate", query = "SELECT e FROM ExpenseRpt e WHERE e.cancelDate = :cancelDate"),
    @NamedQuery(name = "ExpenseRpt.findByValidationDate", query = "SELECT e FROM ExpenseRpt e WHERE e.validationDate = :validationDate"),
    @NamedQuery(name = "ExpenseRpt.findBySubmitDate", query = "SELECT e FROM ExpenseRpt e WHERE e.submitDate = :submitDate"),
    @NamedQuery(name = "ExpenseRpt.findByValidatedByUserName", query = "SELECT e FROM ExpenseRpt e WHERE e.validatedByUserName = :validatedByUserName"),
    @NamedQuery(name = "ExpenseRpt.findByCountryId", query = "SELECT e FROM ExpenseRpt e WHERE e.countryId = :countryId"),
    @NamedQuery(name = "ExpenseRpt.findByModified", query = "SELECT e FROM ExpenseRpt e WHERE e.modified = :modified"),
    @NamedQuery(name = "ExpenseRpt.findByMgrUserName", query = "SELECT e FROM ExpenseRpt e WHERE e.mgrUserName = :mgrUserName"),
    @NamedQuery(name = "ExpenseRpt.findByMgrReceptionDate", query = "SELECT e FROM ExpenseRpt e WHERE e.mgrReceptionDate = :mgrReceptionDate"),
    @NamedQuery(name = "ExpenseRpt.findByMgrValidationDate", query = "SELECT e FROM ExpenseRpt e WHERE e.mgrValidationDate = :mgrValidationDate"),
    @NamedQuery(name = "ExpenseRpt.findByApprovedByUserName", query = "SELECT e FROM ExpenseRpt e WHERE e.approvedByUserName = :approvedByUserName"),
    @NamedQuery(name = "ExpenseRpt.findByPerdiemBonus", query = "SELECT e FROM ExpenseRpt e WHERE e.perdiemBonus = :perdiemBonus")})
public class ExpenseRpt implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "EXPENSE_RPT_ID")
    @GeneratedValue(generator = "EXPENSE_RPT_ID_SEQ", strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "EXPENSE_RPT_ID_SEQ", sequenceName = "EXPENSE_RPT_ID_SEQ", schema = DatabaseConstants.WALTER_SCHEMA, allocationSize = 1)
    private Long expenseRptId;
    @Size(max = 256)
    @Column(name = "CREATOR_USER_NAME", length = 256)
    private String creatorUserName;
    @Column(name = "CREATION_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date creationDate;
    @Column(name = "FROM_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date fromDate;
    @Column(name = "TO_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date toDate;
    @Column(name = "CANCEL_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date cancelDate;
    @Column(name = "VALIDATION_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date validationDate;
    @Column(name = "SUBMIT_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date submitDate;
    @Size(max = 256)
    @Column(name = "VALIDATED_BY_USER_NAME", length = 256)
    private String validatedByUserName;
    @Column(name = "COUNTRY_ID")
    private Long countryId;
    private String modified;
    @Size(max = 256)
    @Column(name = "MGR_USER_NAME", length = 256)
    private String mgrUserName;
    @Column(name = "MGR_RECEPTION_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date mgrReceptionDate;
    @Column(name = "MGR_VALIDATION_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date mgrValidationDate;
    @Size(max = 256)
    @Column(name = "APPROVED_BY_USER_NAME", length = 256)
    private String approvedByUserName;
    @Column(name = "PERDIEM_BONUS", precision = 12, scale = 2)
    private BigDecimal perdiemBonus;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "expenseRpt")
    private Set<ExpenseRptD> expenseRptDSet;
    @Column(name = "PERDIEM_REPORT")
    private String perdiemReport;
    public ExpenseRpt() {
    }

    public ExpenseRpt(Long expenseRptId) {
        this.expenseRptId = expenseRptId;
    }

    public Long getExpenseRptId() {
        return expenseRptId;
    }

    public void setExpenseRptId(Long expenseRptId) {
        this.expenseRptId = expenseRptId;
    }

    public String getCreatorUserName() {
        return creatorUserName;
    }

    public void setCreatorUserName(String creatorUserName) {
        this.creatorUserName = creatorUserName;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public Date getFromDate() {
        return fromDate;
    }

    public void setFromDate(Date fromDate) {
        this.fromDate = fromDate;
    }

    public Date getToDate() {
        return toDate;
    }

    public void setToDate(Date toDate) {
        this.toDate = toDate;
    }

    public Date getCancelDate() {
        return cancelDate;
    }

    public void setCancelDate(Date cancelDate) {
        this.cancelDate = cancelDate;
    }

    public Date getValidationDate() {
        return validationDate;
    }

    public void setValidationDate(Date validationDate) {
        this.validationDate = validationDate;
    }

    public Date getSubmitDate() {
        return submitDate;
    }

    public void setSubmitDate(Date submitDate) {
        this.submitDate = submitDate;
    }

    public String getValidatedByUserName() {
        return validatedByUserName;
    }

    public void setValidatedByUserName(String validatedByUserName) {
        this.validatedByUserName = validatedByUserName;
    }

    public Long getCountryId() {
        return countryId;
    }

    public void setCountryId(Long countryId) {
        this.countryId = countryId;
    }

    public String getModified() {
        return modified;
    }

    public void setModified(String modified) {
        this.modified = modified;
    }

    public String getMgrUserName() {
        return mgrUserName;
    }

    public void setMgrUserName(String mgrUserName) {
        this.mgrUserName = mgrUserName;
    }

    public Date getMgrReceptionDate() {
        return mgrReceptionDate;
    }

    public void setMgrReceptionDate(Date mgrReceptionDate) {
        this.mgrReceptionDate = mgrReceptionDate;
    }

    public Date getMgrValidationDate() {
        return mgrValidationDate;
    }

    public void setMgrValidationDate(Date mgrValidationDate) {
        this.mgrValidationDate = mgrValidationDate;
    }

    public String getApprovedByUserName() {
        return approvedByUserName;
    }

    public void setApprovedByUserName(String approvedByUserName) {
        this.approvedByUserName = approvedByUserName;
    }

    public BigDecimal getPerdiemBonus() {
      return perdiemBonus;
    }

    public void setPerdiemBonus(BigDecimal perdiemBonus) {
      this.perdiemBonus = perdiemBonus;
    }

    @XmlTransient
    public Set<ExpenseRptD> getExpenseRptDSet() {
        return expenseRptDSet;
    }

    public void setExpenseRptDSet(Set<ExpenseRptD> expenseRptDSet) {
        this.expenseRptDSet = expenseRptDSet;
    }

    public String getPerdiemReport() {
      return perdiemReport;
    }

    public void setPerdiemReport(String perdiemReport) {
      this.perdiemReport = perdiemReport;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (expenseRptId != null ? expenseRptId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ExpenseRpt)) {
            return false;
        }
        ExpenseRpt other = (ExpenseRpt) object;
        if ((this.expenseRptId == null && other.expenseRptId != null) || (this.expenseRptId != null && !this.expenseRptId.equals(other.expenseRptId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.walter.ExpenseRpt[ expenseRptId=" + expenseRptId + " ]";
    }

  }
