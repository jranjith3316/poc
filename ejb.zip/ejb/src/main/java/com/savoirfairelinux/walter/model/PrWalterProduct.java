package com.savoirfairelinux.walter.model;

import java.io.Serializable;

/**
 * @author jderuere
 */
public class PrWalterProduct implements Serializable {

    private String productVersionGUID;
    private String productNumber;
    private Tradename productName;
    private PrApplication application;
    private String diameter;
    private String thickness;
    private String arbor;
    private String grit;
    private String price;
    private String type;
    private String productLineClaassesguid;

    public String getProductVersionGUID() {
        return productVersionGUID;
    }

    public void setProductVersionGUID(String productVersionGUID) {
        this.productVersionGUID = productVersionGUID;
    }

    public String getProductNumber() {
        return productNumber;
    }

    public void setProductNumber(String productNumber) {
        this.productNumber = productNumber;
    }

    public Tradename getProductName() {
        return productName;
    }

    public void setProductName(Tradename productName) {
        this.productName = productName;
    }

    public String getDiameter() {
        return diameter;
    }

    public void setDiameter(String diameter) {
        this.diameter = diameter;
    }

    public String getThickness() {
        return thickness;
    }

    public void setThickness(String thickness) {
        this.thickness = thickness;
    }

    public String getArbor() {
        return arbor;
    }

    public void setArbor(String arbor) {
        this.arbor = arbor;
    }

    public String getGrit() {
        return grit;
    }

    public void setGrit(String grit) {
        this.grit = grit;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public PrApplication getApplication() {
        return application;
    }

    public void setApplication(PrApplication application) {
        this.application = application;
    }

    public String getProductLineClaassesguid() {
        return productLineClaassesguid;
    }

    public void setProductLineClaassesguid(String productLineClaassesguid) {
        this.productLineClaassesguid = productLineClaassesguid;
    }
    
    public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	@Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof PrWalterProduct)) return false;

        PrWalterProduct that = (PrWalterProduct) o;

        if (!productNumber.equals(that.productNumber)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return productNumber.hashCode();
    }
}