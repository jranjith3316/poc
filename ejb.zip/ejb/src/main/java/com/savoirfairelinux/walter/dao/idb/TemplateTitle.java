/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.idb;

import com.savoirfairelinux.walter.dao.DatabaseConstants;
import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "TEMPLATE_TITLE", catalog = "", schema = DatabaseConstants.IDB_SCHEMA)
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "TemplateTitle.findAll", query = "SELECT t FROM TemplateTitle t"),
  @NamedQuery(name = "TemplateTitle.findByTemplateguid", query = "SELECT t FROM TemplateTitle t WHERE t.templateTitlePK.templateguid = :templateguid"),
  @NamedQuery(name = "TemplateTitle.findByColumnId", query = "SELECT t FROM TemplateTitle t WHERE t.templateTitlePK.columnId = :columnId"),
  @NamedQuery(name = "TemplateTitle.findByRowId", query = "SELECT t FROM TemplateTitle t WHERE t.templateTitlePK.rowId = :rowId"),
  @NamedQuery(name = "TemplateTitle.findByTitleguid", query = "SELECT t FROM TemplateTitle t WHERE t.titleguid = :titleguid"),
  @NamedQuery(name = "TemplateTitle.findByColspan", query = "SELECT t FROM TemplateTitle t WHERE t.colspan = :colspan"),
  @NamedQuery(name = "TemplateTitle.findByAlign", query = "SELECT t FROM TemplateTitle t WHERE t.align = :align"),
  @NamedQuery(name = "TemplateTitle.findByWidth", query = "SELECT t FROM TemplateTitle t WHERE t.width = :width"),
  @NamedQuery(name = "TemplateTitle.findByOrderby", query = "SELECT t FROM TemplateTitle t WHERE t.orderby = :orderby")})
public class TemplateTitle implements Serializable {
  private static final long serialVersionUID = 1L;
  @EmbeddedId
  protected TemplateTitlePK templateTitlePK;
  @Size(max = 50)
  @Column(name = "TITLEGUID")
  private String titleguid;
  @Column(name = "COLSPAN")
  private Short colspan;
  @Size(max = 6)
  @Column(name = "ALIGN")
  private String align;
  @Size(max = 3)
  @Column(name = "WIDTH")
  private String width;
  @Column(name = "ORDERBY")
  private Short orderby;
  @JoinColumn(name = "TEMPLATEGUID", referencedColumnName = "TEMPLATEGUID", insertable = false, updatable = false)
  @ManyToOne(optional = false)
  private Template template;

  public TemplateTitle() {
  }

  public TemplateTitle(TemplateTitlePK templateTitlePK) {
    this.templateTitlePK = templateTitlePK;
  }

  public TemplateTitle(String templateguid, short columnId, short rowId) {
    this.templateTitlePK = new TemplateTitlePK(templateguid, columnId, rowId);
  }

  public TemplateTitlePK getTemplateTitlePK() {
    return templateTitlePK;
  }

  public void setTemplateTitlePK(TemplateTitlePK templateTitlePK) {
    this.templateTitlePK = templateTitlePK;
  }

  public String getTitleguid() {
    return titleguid;
  }

  public void setTitleguid(String titleguid) {
    this.titleguid = titleguid;
  }

  public Short getColspan() {
    return colspan;
  }

  public void setColspan(Short colspan) {
    this.colspan = colspan;
  }

  public String getAlign() {
    return align;
  }

  public void setAlign(String align) {
    this.align = align;
  }

  public String getWidth() {
    return width;
  }

  public void setWidth(String width) {
    this.width = width;
  }

  public Short getOrderby() {
    return orderby;
  }

  public void setOrderby(Short orderby) {
    this.orderby = orderby;
  }

  public Template getTemplate() {
    return template;
  }

  public void setTemplate(Template template) {
    this.template = template;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (templateTitlePK != null ? templateTitlePK.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof TemplateTitle)) {
      return false;
    }
    TemplateTitle other = (TemplateTitle) object;
    if ((this.templateTitlePK == null && other.templateTitlePK != null) || (this.templateTitlePK != null && !this.templateTitlePK.equals(other.templateTitlePK))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.idb.TemplateTitle[ templateTitlePK=" + templateTitlePK + " ]";
  }

}
