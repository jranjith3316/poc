/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.crossreferenceapp.model;

import java.io.Serializable;

/**
 *
 * @author jsgill
 */
public class HazardModel implements Serializable{
  private static final long serialVersionUID = 3511338233023397895L;

  private String label;
  private String value;

  public HazardModel() {
  }

  public HazardModel(String label, String value) {
    this.label = label;
    this.value = value;
  }

  public String getLabel() {
    return label;
  }

  public void setLabel(String label) {
    this.label = label;
  }

  public String getValue() {
    return value;
  }

  public void setValue(String value) {
    this.value = value;
  }

}
