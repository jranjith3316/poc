/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

/**
 *
 * @author mgubaidullin
 */
@Embeddable
public class CntActivityPK implements Serializable {
    @Basic(optional = false)
    @NotNull
    @Column(name = "CNT_ID")
    private long cntId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "ACTIVITY_ID")
    private long activityId;

    public CntActivityPK() {
    }

    public CntActivityPK(long cntId, long activityId) {
        this.cntId = cntId;
        this.activityId = activityId;
    }

    public long getCntId() {
        return cntId;
    }

    public void setCntId(long cntId) {
        this.cntId = cntId;
    }

    public long getActivityId() {
        return activityId;
    }

    public void setActivityId(long activityId) {
        this.activityId = activityId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) cntId;
        hash += (int) activityId;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CntActivityPK)) {
            return false;
        }
        CntActivityPK other = (CntActivityPK) object;
        if (this.cntId != other.cntId) {
            return false;
        }
        if (this.activityId != other.activityId) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.CntActivityPK[ cntId=" + cntId + ", activityId=" + activityId + " ]";
    }
    
}
