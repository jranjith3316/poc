/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.walter;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author jsgill
 */
@Embeddable
public class VgTreeTypePK implements Serializable {
  @Basic(optional = false)
  @NotNull
  @Size(min = 1, max = 10)
  @Column(name = "VG_TREE_CODE")
  private String vgTreeCode;
  @Basic(optional = false)
  @NotNull
  @Column(name = "TYPE_ID")
  private short typeId;

  public VgTreeTypePK() {
  }

  public VgTreeTypePK(String vgTreeCode, short typeId) {
    this.vgTreeCode = vgTreeCode;
    this.typeId = typeId;
  }

  public String getVgTreeCode() {
    return vgTreeCode;
  }

  public void setVgTreeCode(String vgTreeCode) {
    this.vgTreeCode = vgTreeCode;
  }

  public short getTypeId() {
    return typeId;
  }

  public void setTypeId(short typeId) {
    this.typeId = typeId;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (vgTreeCode != null ? vgTreeCode.hashCode() : 0);
    hash += (int) typeId;
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof VgTreeTypePK)) {
      return false;
    }
    VgTreeTypePK other = (VgTreeTypePK) object;
    if ((this.vgTreeCode == null && other.vgTreeCode != null) || (this.vgTreeCode != null && !this.vgTreeCode.equals(other.vgTreeCode))) {
      return false;
    }
    if (this.typeId != other.typeId) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.walter.VgTreeTypePK[ vgTreeCode=" + vgTreeCode + ", typeId=" + typeId + " ]";
  }
  
}
