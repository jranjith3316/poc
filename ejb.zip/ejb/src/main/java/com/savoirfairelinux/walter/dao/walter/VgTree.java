/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.walter;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import java.util.Date;
import java.util.Set;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "VG_TREE", catalog = "", schema = DatabaseConstants.WALTER_SCHEMA)
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "VgTree.findAll", query = "SELECT v FROM VgTree v"),
  @NamedQuery(name = "VgTree.findByVgTreeCode", query = "SELECT v FROM VgTree v WHERE v.vgTreeCode = :vgTreeCode"),
  @NamedQuery(name = "VgTree.findByName", query = "SELECT v FROM VgTree v WHERE v.name = :name"),
  @NamedQuery(name = "VgTree.findByCreatedBy", query = "SELECT v FROM VgTree v WHERE v.createdBy = :createdBy"),
  @NamedQuery(name = "VgTree.findByCreationDate", query = "SELECT v FROM VgTree v WHERE v.creationDate = :creationDate"),
  @NamedQuery(name = "VgTree.findByDeletedBy", query = "SELECT v FROM VgTree v WHERE v.deletedBy = :deletedBy"),
  @NamedQuery(name = "VgTree.findByDeleteDate", query = "SELECT v FROM VgTree v WHERE v.deleteDate = :deleteDate")})
public class VgTree implements Serializable {
  private static final long serialVersionUID = 1L;
  @Id
  @Basic(optional = false)
  @NotNull
  @Size(min = 1, max = 10)
  @Column(name = "VG_TREE_CODE")
  private String vgTreeCode;
  @Size(max = 100)
  @Column(name = "NAME")
  private String name;
  @Size(max = 256)
  @Column(name = "CREATED_BY")
  private String createdBy;
  @Column(name = "CREATION_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date creationDate;
  @Size(max = 256)
  @Column(name = "DELETED_BY")
  private String deletedBy;
  @Column(name = "DELETE_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date deleteDate;
  @OneToMany(cascade = CascadeType.ALL, mappedBy = "vgTree")
  private Set<VgTreeItem> vgTreeItemSet;
  @OneToMany(cascade = CascadeType.ALL, mappedBy = "vgTree")
  private Set<VgTreeType> vgTreeTypeSet;

  public VgTree() {
  }

  public VgTree(String vgTreeCode) {
    this.vgTreeCode = vgTreeCode;
  }

  public String getVgTreeCode() {
    return vgTreeCode;
  }

  public void setVgTreeCode(String vgTreeCode) {
    this.vgTreeCode = vgTreeCode;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getCreatedBy() {
    return createdBy;
  }

  public void setCreatedBy(String createdBy) {
    this.createdBy = createdBy;
  }

  public Date getCreationDate() {
    return creationDate;
  }

  public void setCreationDate(Date creationDate) {
    this.creationDate = creationDate;
  }

  public String getDeletedBy() {
    return deletedBy;
  }

  public void setDeletedBy(String deletedBy) {
    this.deletedBy = deletedBy;
  }

  public Date getDeleteDate() {
    return deleteDate;
  }

  public void setDeleteDate(Date deleteDate) {
    this.deleteDate = deleteDate;
  }

  @XmlTransient
  public Set<VgTreeItem> getVgTreeItemSet() {
    return vgTreeItemSet;
  }

  public void setVgTreeItemSet(Set<VgTreeItem> vgTreeItemSet) {
    this.vgTreeItemSet = vgTreeItemSet;
  }

  @XmlTransient
  public Set<VgTreeType> getVgTreeTypeSet() {
    return vgTreeTypeSet;
  }

  public void setVgTreeTypeSet(Set<VgTreeType> vgTreeTypeSet) {
    this.vgTreeTypeSet = vgTreeTypeSet;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (vgTreeCode != null ? vgTreeCode.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof VgTree)) {
      return false;
    }
    VgTree other = (VgTree) object;
    if ((this.vgTreeCode == null && other.vgTreeCode != null) || (this.vgTreeCode != null && !this.vgTreeCode.equals(other.vgTreeCode))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.walter.VgTree[ vgTreeCode=" + vgTreeCode + " ]";
  }
  
}
