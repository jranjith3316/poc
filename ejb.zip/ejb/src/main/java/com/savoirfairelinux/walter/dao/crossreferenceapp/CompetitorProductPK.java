/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.crossreferenceapp;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

/**
 *
 * @author jsgill
 */
@Embeddable
public class CompetitorProductPK implements Serializable {
  @Basic(optional = false)
  @NotNull
  @Column(name = "COMPETITOR_ID")
  private long competitorId;
  @Basic(optional = false)
  @NotNull
  @Column(name = "BRAND_ID")
  private long brandId;
  @Basic(optional = false)
  @NotNull
  @Column(name = "PRODUCT_ID")
  private long productId;
  @Basic(optional = false)
  @NotNull
  @Column(name = "COUNTRY_ID")
  private long countryId;

  public CompetitorProductPK() {
  }

  public CompetitorProductPK(long competitorId, long brandId, long productId, long countryId) {
    this.competitorId = competitorId;
    this.brandId = brandId;
    this.productId = productId;
    this.countryId = countryId;
  }

  public long getCompetitorId() {
    return competitorId;
  }

  public void setCompetitorId(long competitorId) {
    this.competitorId = competitorId;
  }

  public long getBrandId() {
    return brandId;
  }

  public void setBrandId(long brandId) {
    this.brandId = brandId;
  }

  public long getProductId() {
    return productId;
  }

  public void setProductId(long productId) {
    this.productId = productId;
  }

  public long getCountryId() {
    return countryId;
  }

  public void setCountryId(long countryId) {
    this.countryId = countryId;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (int) competitorId;
    hash += (int) brandId;
    hash += (int) productId;
    hash += (int) countryId;
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof CompetitorProductPK)) {
      return false;
    }
    CompetitorProductPK other = (CompetitorProductPK) object;
    if (this.competitorId != other.competitorId) {
      return false;
    }
    if (this.brandId != other.brandId) {
      return false;
    }
    if (this.productId != other.productId) {
      return false;
    }
    if (this.countryId != other.countryId) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.crossreferenceapp.CompetitorProductPK[ competitorId=" + competitorId + ", brandId=" + brandId + ", productId=" + productId + ", countryId=" + countryId + " ]";
  }

}
