package com.savoirfairelinux.walter.util.criteriabuilder;

import com.savoirfairelinux.walter.dao.waltercb.*;
import com.savoirfairelinux.walter.model.Franchise;
import com.savoirfairelinux.walter.model.ReportState;
import com.savoirfairelinux.walter.model.Tradename;
import com.savoirfairelinux.walter.model.WalterOrganization;

import javax.persistence.EntityManager;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Map;

public class CntCriteriaBuilder extends AbstractCriteriaBuilder<Cnt> {

    private ULang lang;

    public CntCriteriaBuilder(EntityManager entityManager, ULang lang) {
        super(entityManager, Cnt.class);
        this.lang = lang;
    }

    @Override
    protected void initQuery(StringBuilder queryBuilder, Map<String, Object> properties) {
        queryBuilder.append("SELECT cnt FROM Cnt cnt ");
    }

    @Override
    protected void initJoinQuery(StringBuilder queryBuilder, Map<String, Object> properties) {
        queryBuilder.append(" LEFT OUTER JOIN FETCH cnt.cntTxtList as txt ");
    }

    @Override
    protected void buildSpecificQuery(StringBuilder queryBuilder, Map<String, Object> properties) {
        queryBuilder.append(" WHERE cnt.cancelDate IS NULL ");

    }

    @Override
    protected void initOrderByQuery(StringBuilder queryBuilder, Map<String, Object> properties) {    	
        queryBuilder.append(" ORDER BY cnt.publicationDate DESC, cnt.entryDate DESC, cnt.cntId DESC ");
    }

    protected void addOrganization2Criteria(StringBuilder queryBuilder, Map<String, Object> properties, WalterOrganization organization, WalterOrganization organization2) {
        if (organization2 != null) {
            queryBuilder.append(" AND (cnt.organization = :organization ")
                    .append(" OR cnt IN (")
                    .append(" SELECT cnt2 FROM Cnt cnt2, CntProduct product, UTradenameShare tshare ")
                    .append(" WHERE cnt2.organization = :organization2 ")
                    .append(" AND product.cntProductPK.cntId = cnt2.cntId ")
                    .append((organization.equals(WalterOrganization.WALTER) ?
                            " AND TO_CHAR(tshare.cbFranchiseId) = product.cntProductPK.franchiseguid AND TO_CHAR(tshare.cbTradenameId) = product.cntProductPK.tradenameguid "
                            : " AND tshare.wFranchiseGuid = product.cntProductPK.franchiseguid AND tshare.wTradenameGuid = product.cntProductPK.tradenameguid " +
                              " AND cnt2.ratingAvg >= 4"))
                    .append(" ) )");
            properties.put("organization", organization.getName());
            properties.put("organization2", organization2.getName());
        } else if (organization != null) {
            queryBuilder.append(" AND cnt.organization = :organization ");
            properties.put("organization", organization.getName());
        }
    }

    protected void addFromPublicationDateCriteria(StringBuilder queryBuilder, Map<String, Object> properties, Date fromPublicationDate) {
        if (fromPublicationDate != null) {
            queryBuilder.append(" AND cnt.publicationDate >= :fromPublicationDate ");
            properties.put("fromPublicationDate", fromPublicationDate);
        }
    }

    protected void addToPublicationDateCriteria(StringBuilder queryBuilder, Map<String, Object> properties, Date toPublicationDate) {
        if (toPublicationDate != null) {
            queryBuilder.append(" AND cnt.publicationDate <= :toPublicationDate");
            properties.put("toPublicationDate", toPublicationDate);
        }
    }

    protected void addTradenameCriteria(StringBuilder queryBuilder, Map<String, Object> properties, Tradename tradename) {
        if (tradename != null) {
            queryBuilder.append(" AND cnt.cntId IN ( ")
                    .append(" SELECT DISTINCT product.cntProductPK.cntId FROM CntProduct product ")
                    .append(" WHERE product.cntProductPK.franchiseguid = :franchiseId ")
                    .append(" AND product.cntProductPK.tradenameguid = :tradenameId) ");
            properties.put("franchiseId", tradename.getFranchise().getFranchiseId());
            properties.put("tradenameId", tradename.getTradenameId());
        }
    }

    protected void addCntIdCriteria(StringBuilder queryBuilder, Map<String, Object> properties, Long cntId) {
        if (cntId != null) {
            queryBuilder.append(" AND cnt.cntId = :cntId");
            properties.put("cntId", cntId);
        }
    }

    protected void addKeywordCriteria(StringBuilder queryBuilder, Map<String, Object> properties, String keyword) {
        if (keyword != null && !keyword.isEmpty()) {
            queryBuilder.append(" AND txt.cntTxtPK.langId = :langId")
                    .append(" AND ( UPPER(txt.objective) LIKE :keyword ")
                    .append(" OR UPPER(txt.currentProcess) LIKE :keyword ")
                    .append(" OR UPPER(txt.walterSolution) LIKE :keyword ")
                    .append(" OR UPPER(txt.keySaleAdvantage1) LIKE :keyword ")
                    .append(" OR UPPER(txt.keySaleAdvantage2) LIKE :keyword ")
                    .append(" OR UPPER(txt.keySaleAdvantage3) LIKE :keyword ")
                    .append(" OR UPPER(txt.keySaleAdvantage4) LIKE :keyword ")
                    .append(" OR UPPER(txt.keySaleAdvantage5) LIKE :keyword ")
                    .append(" OR UPPER(txt.cntComment) LIKE :keyword ")
                    .append(" OR UPPER(txt.pmComment) LIKE :keyword ")
                    .append(" OR UPPER(txt.otherMaterial) LIKE :keyword ")
                    .append(" OR UPPER(txt.otherIndustry) LIKE :keyword ")
                    .append(" OR UPPER(txt.otherActivity) LIKE :keyword ")
                    .append(" OR UPPER(txt.otherContaminant) LIKE :keyword ")
                    .append(" OR UPPER(txt.otherCompetitor) LIKE :keyword ")
                    .append(" OR UPPER(txt.otherCompProd) LIKE :keyword ")
                    .append(" OR UPPER(txt.otherMachinery) LIKE :keyword ")
                    .append(" ) ");
//                    .append(" OR cnt IN ( ")
//                    .append(" SELECT DISTINCT picTxt.cntPicture.cnt FROM CntPictureTxt picTxt ")
//                    .append(" WHERE picTxt.cntPictureTxtPK.langId = :langId")
//                    .append(" AND picTxt.pictureTxt LIKE :keyword ")
//                    .append(" ) ")
//                    .append(" OR cnt IN ( ")
//                    .append(" SELECT DISTINCT urlTxt.cntUrl.cnt FROM CntUrlTxt urlTxt ")
//                    .append(" WHERE urlTxt.cntUrlTxtPK.langId = :langId")
//                    .append(" AND urlTxt.urlTxt LIKE :keyword ")
//                    .append(" ) ")
//                    .append(" ) ");
            properties.put("langId", lang.getLangId());
            properties.put("keyword", "%" + keyword.toUpperCase() + "%");
        }
    }

    protected void addFranchiseCriteria(StringBuilder queryBuilder, Map<String, Object> properties, Franchise franchise) {
        if (franchise != null) {
            queryBuilder.append(" AND cnt.cntId IN ( ")
                    .append(" SELECT DISTINCT product.cntProductPK.cntId FROM CntProduct product ")
                    .append(" WHERE product.cntProductPK.franchiseguid = :franchiseId) ");
            properties.put("franchiseId", franchise.getFranchiseId());
        }
    }

    protected void addIndustryCriteria(StringBuilder queryBuilder, Map<String, Object> properties, UIndustry industry) {
        if (industry != null) {
            queryBuilder.append(" AND cnt.cntId IN ( ")
                    .append(" SELECT DISTINCT industry.cntIndustryPK.cntId FROM CntIndustry industry ")
                    .append(" WHERE industry.cntIndustryPK.industryId = :industry) ");
            properties.put("industry", industry.getUIndustryPK().getIndustryId());
        }
    }

    protected void addContaminantCriteria(StringBuilder queryBuilder, Map<String, Object> properties, UContaminant contaminant) {
        if (contaminant != null) {
            queryBuilder.append(" AND cnt.cntId IN ( ")
                    .append(" SELECT DISTINCT contaminant.cntContaminantPK.cntId FROM CntContaminant contaminant ")
                    .append(" WHERE contaminant.cntContaminantPK.contaminantId = :contaminant) ");
            properties.put("contaminant", contaminant.getUContaminantPK().getContaminantId());
        }
    }

    protected void addMaterialCriteria(StringBuilder queryBuilder, Map<String, Object> properties, UMaterial material) {
        if (material != null) {
            queryBuilder.append(" AND cnt.cntId IN ( ")
                    .append(" SELECT DISTINCT material.cntMaterialPK.cntId FROM CntMaterial material ")
                    .append(" WHERE material.cntMaterialPK.materialId = :material) ");
            properties.put("material", material.getUMaterialPK().getMaterialId());
        }
    }

    protected void addActivityCriteria(StringBuilder queryBuilder, Map<String, Object> properties, UActivity activity) {
        if (activity != null) {
            queryBuilder.append(" AND cnt.cntId IN ( ")
                    .append(" SELECT DISTINCT activity.cntActivityPK.cntId FROM CntActivity activity ")
                    .append(" WHERE activity.cntActivityPK.activityId = :activity) ");
            properties.put("activity", activity.getUActivityPK().getActivityId());
        }
    }

    protected void addCompetitorCriteria(StringBuilder queryBuilder, Map<String, Object> properties, UCompetitor competitor) {
        if (competitor != null) {
            queryBuilder.append(" AND cnt.cntId IN ( ")
                    .append(" SELECT DISTINCT competitor.cntCompetitorPK.cntId FROM CntCompetitor competitor ")
                    .append(" WHERE competitor.cntCompetitorPK.competitorId = :competitor) ");
            properties.put("competitor", competitor.getCompetitorId());
        }
    }

    protected void addFromRatingAvgCriteria(StringBuilder queryBuilder, Map<String, Object> properties, BigDecimal fromRatingAvg) {
        if (fromRatingAvg != null) {
            queryBuilder.append(" AND cnt.ratingAvg >= :fromRatingAvg ");
            properties.put("fromRatingAvg", fromRatingAvg);
        }
    }

    protected void addToRatingAvgCriteria(StringBuilder queryBuilder, Map<String, Object> properties, BigDecimal toRatingAvg) {
        if (toRatingAvg != null) {
            queryBuilder.append(" AND cnt.ratingAvg <= :toRatingAvg ");
            properties.put("toRatingAvg", toRatingAvg);
        }
    }

    protected void addTranslateCriteria(StringBuilder queryBuilder, Map<String, Object> properties, ULang lang) {
        if (lang != null) {
            queryBuilder.append(" AND cnt.cntId NOT IN ( ")
                    .append(" SELECT DISTINCT txt.cntTxtPK.cntId FROM CntTxt txt ")
                    .append(" WHERE txt.cntTxtPK.langId = :langId) ");
            properties.put("langId", lang.getLangId());
        }
    }

    protected void addStateCriteria(StringBuilder queryBuilder, Map<String, Object> properties, ReportState state) {
        if (state != null) {
            switch (state) {
                case UNSUBMIT:
                    queryBuilder.append(" AND cnt.entryDate IS NULL ");
                    break;
                case SUBMIT:
                    queryBuilder.append(" AND cnt.publicationDate IS NULL ")
                            .append(" AND cnt.entryDate IS NOT NULL ")
                            .append(" AND (cnt.validFlag IS NULL OR cnt.validFlag = 1) ")
                            .append(" AND cnt NOT IN ( ")
                            .append(" SELECT DISTINCT translate.cnt FROM CntTranslate translate ")
                            .append(" WHERE translate.receivedFromTr IS NULL ")
                            .append(" AND translate.sentToTr IS NOT NULL ) ");
                    break;
                case PUBLISH:
                    queryBuilder.append(" AND cnt.publicationDate IS NOT NULL ")
                            .append(" AND cnt.entryDate IS NOT NULL ");
                    break;
                case INVALID:
                    queryBuilder.append(" AND cnt.validFlag = 0 ");
                    break;
                case PENDING_FOR_TRANSLATION:
                    queryBuilder.append(" AND cnt IN ( ")
                            .append(" SELECT DISTINCT translate.cnt FROM CntTranslate translate ")
                            .append(" WHERE translate.receivedFromTr IS NULL ")
                            .append(" AND translate.sentToTr IS NOT NULL ) ");
                    break;
                case PENDING_FOR_VALIDATION:
                    queryBuilder.append(" AND cnt.receivedFromPm IS NULL ")
                            .append(" AND cnt.sentToPm IS NOT NULL ");
                    break;
                default:
                    break;
            }
        }
    }
}
