package com.savoirfairelinux.walter.model;

public enum ReportState {

	UNSUBMIT,
	SUBMIT,
	PUBLISH,
	INVALID,
	PENDING_FOR_TRANSLATION,
	PENDING_FOR_VALIDATION,
	VALIDATE;
}
