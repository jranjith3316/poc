/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.walter;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "EXPENSE_TXT", catalog = "", schema = DatabaseConstants.WALTER_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "ExpenseTxt.findAll", query = "SELECT e FROM ExpenseTxt e"),
    @NamedQuery(name = "ExpenseTxt.findByExpenseId", query = "SELECT e FROM ExpenseTxt e WHERE e.expenseTxtPK.expenseId = :expenseId"),
    @NamedQuery(name = "ExpenseTxt.findByLangId", query = "SELECT e FROM ExpenseTxt e WHERE e.expenseTxtPK.langId = :langId"),
    @NamedQuery(name = "ExpenseTxt.findByExpenseDesc", query = "SELECT e FROM ExpenseTxt e WHERE e.expenseDesc = :expenseDesc")})
public class ExpenseTxt implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected ExpenseTxtPK expenseTxtPK;
    @Size(max = 70)
    @Column(name = "EXPENSE_DESC", length = 70)
    private String expenseDesc;
    @JoinColumn(name = "EXPENSE_ID", referencedColumnName = "EXPENSE_ID", nullable = false, insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Expense expense;

    public ExpenseTxt() {
    }

    public ExpenseTxt(ExpenseTxtPK expenseTxtPK) {
        this.expenseTxtPK = expenseTxtPK;
    }

    public ExpenseTxt(long expenseId, long langId) {
        this.expenseTxtPK = new ExpenseTxtPK(expenseId, langId);
    }

    public ExpenseTxtPK getExpenseTxtPK() {
        return expenseTxtPK;
    }

    public void setExpenseTxtPK(ExpenseTxtPK expenseTxtPK) {
        this.expenseTxtPK = expenseTxtPK;
    }

    public String getExpenseDesc() {
        return expenseDesc;
    }

    public void setExpenseDesc(String expenseDesc) {
        this.expenseDesc = expenseDesc;
    }

    public Expense getExpense() {
        return expense;
    }

    public void setExpense(Expense expense) {
        this.expense = expense;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (expenseTxtPK != null ? expenseTxtPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ExpenseTxt)) {
            return false;
        }
        ExpenseTxt other = (ExpenseTxt) object;
        if ((this.expenseTxtPK == null && other.expenseTxtPK != null) || (this.expenseTxtPK != null && !this.expenseTxtPK.equals(other.expenseTxtPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.walter.ExpenseTxt[ expenseTxtPK=" + expenseTxtPK + " ]";
    }
    
}
