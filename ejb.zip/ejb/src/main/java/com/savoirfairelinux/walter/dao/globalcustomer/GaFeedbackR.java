/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.globalcustomer;

import com.savoirfairelinux.walter.dao.DatabaseConstants;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jderuere
 */
@Entity
@Table(name = "GA_FEEDBACK_R", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "GaFeedbackR.findAll", query = "SELECT c FROM GaFeedbackR c"),
    @NamedQuery(name = "GaFeedbackR.findByFeedbackId", query = "SELECT c FROM GaFeedbackR c WHERE c.feedbackRId = :feedbackRId"),
    @NamedQuery(name = "GaFeedbackR.findByReplyDesc", query = "SELECT c FROM GaFeedbackR c WHERE c.replyDesc = :replyDesc"),
    @NamedQuery(name = "GaFeedbackR.findByDateCreated", query = "SELECT c FROM GaFeedbackR c WHERE c.dateCreated = :dateCreated")})
public class GaFeedbackR implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @GeneratedValue(generator = "GA_FEEDBACKR_ID_SEQ", strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "GA_FEEDBACKR_ID_SEQ", sequenceName = "GA_FEEDBACKR_ID_SEQ", schema = DatabaseConstants.WALTERCB_SCHEMA, allocationSize = 1)
    @Column(name = "FEEDBACKR_ID")
    private Long feedbackRId;
    @Size(max = 500)
    @Column(name = "REPLY_DESC")
    private String replyDesc;
    @Column(name = "DATE_CREATED")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateCreated;
    @Size(max = 256)
    @Column(name = "CONTRIBUTOR", nullable = false)
    private String contributor;
    @ManyToOne(optional = false)
    @JoinColumn(name = "FEEDBACK_ID", referencedColumnName = "FEEDBACK_ID")
    private GaFeedback feedback;

    public GaFeedbackR() {
    }

    public Long getFeedbackRId() {
        return feedbackRId;
    }

    public void setFeedbackRId(Long feedbackRId) {
        this.feedbackRId = feedbackRId;
    }

    public String getReplyDesc() {
        return replyDesc;
    }

    public void setReplyDesc(String replyDesc) {
        this.replyDesc = replyDesc;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public String getContributor() {
        return contributor;
    }

    public void setContributor(String contributor) {
        this.contributor = contributor;
    }

    public GaFeedback getFeedback() {
        return feedback;
    }

    public void setFeedback(GaFeedback feedback) {
        this.feedback = feedback;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (feedbackRId != null ? feedbackRId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof GaFeedbackR)) {
            return false;
        }
        GaFeedbackR other = (GaFeedbackR) object;
        if ((this.feedbackRId == null && other.feedbackRId != null) || (this.feedbackRId != null && !this.feedbackRId.equals(other.feedbackRId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.globalCustomer.GaFeedbackR[ cntFeedbackRId=" + feedbackRId + " ]";
    }
    
}
