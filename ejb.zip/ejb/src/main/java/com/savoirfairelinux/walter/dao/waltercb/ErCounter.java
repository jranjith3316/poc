/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import javax.persistence.*;
import javax.xml.bind.annotation.XmlRootElement;
import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "ER_COUNTER", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "ErCounter.findAll", query = "SELECT e FROM ErCounter e"),
    @NamedQuery(name = "ErCounter.findByErId", query = "SELECT e FROM ErCounter e WHERE e.erCounterPK.erId = :erId"),
    @NamedQuery(name = "ErCounter.findByUserName", query = "SELECT e FROM ErCounter e WHERE e.erCounterPK.userName = :userName"),
    @NamedQuery(name = "ErCounter.findByCounter", query = "SELECT e FROM ErCounter e WHERE e.counter = :counter"),
    @NamedQuery(name = "ErCounter.findByLastRead", query = "SELECT e FROM ErCounter e WHERE e.lastRead = :lastRead"),
    @NamedQuery(name = "ErCounter.findByFirstRead", query = "SELECT e FROM ErCounter e WHERE e.firstRead = :firstRead")})
public class ErCounter implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected ErCounterPK erCounterPK;
    @Column(name = "COUNTER")
    private Long counter;
    @Column(name = "LAST_READ")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastRead;
    @Column(name = "FIRST_READ")
    @Temporal(TemporalType.TIMESTAMP)
    private Date firstRead;
    @JoinColumn(name = "ER_ID", referencedColumnName = "ER_ID", nullable = false, insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Er er;

    public ErCounter() {
    }

    public ErCounter(ErCounterPK erCounterPK) {
        this.erCounterPK = erCounterPK;
    }

    public ErCounter(long erId, String userName) {
        this.erCounterPK = new ErCounterPK(erId, userName);
    }

    public ErCounterPK getErCounterPK() {
        return erCounterPK;
    }

    public void setErCounterPK(ErCounterPK erCounterPK) {
        this.erCounterPK = erCounterPK;
    }

    public Long getCounter() {
        return counter;
    }

    public void setCounter(Long counter) {
        this.counter = counter;
    }

    public Date getLastRead() {
        return lastRead;
    }

    public void setLastRead(Date lastRead) {
        this.lastRead = lastRead;
    }

    public Date getFirstRead() {
        return firstRead;
    }

    public void setFirstRead(Date firstRead) {
        this.firstRead = firstRead;
    }

    public Er getEr() {
        return er;
    }

    public void setEr(Er er) {
        this.er = er;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (erCounterPK != null ? erCounterPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ErCounter)) {
            return false;
        }
        ErCounter other = (ErCounter) object;
        if ((this.erCounterPK == null && other.erCounterPK != null) || (this.erCounterPK != null && !this.erCounterPK.equals(other.erCounterPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.ErCounter[ erCounterPK=" + erCounterPK + " ]";
    }
    
}
