/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.service.impl;

import com.savoirfairelinux.walter.dao.waltercb.Country;
import com.savoirfairelinux.walter.model.AnalysisReportByMonth;
import com.savoirfairelinux.walter.model.AnalysisSearchSolRptCreated;
import com.savoirfairelinux.walter.model.AnalysisSolRptCreated;
import com.savoirfairelinux.walter.model.MobileProductivityReportModel;
import com.savoirfairelinux.walter.model.ProductivityReportModel;
import com.savoirfairelinux.walter.service.AnalysisReportRemote;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;
import javax.annotation.security.PermitAll;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

/**
 *
 * @author jsgill
 */
@Stateless(name = "AnalysisReportBean")
@TransactionManagement(TransactionManagementType.CONTAINER)
@PermitAll
@LocalBean
public class AnalysisReportBean implements AnalysisReportRemote {

  public static final Logger LOG = Logger.getLogger(AnalysisReportBean.class.getCanonicalName());

  @PersistenceContext(unitName = "waltershare")
  EntityManager entityManager;
  @EJB
  SingletonBean singletonBean;
  @EJB
  WalterBean walterBean;

  @Override
  public List<AnalysisSolRptCreated> getSolRptCreatedList(AnalysisSearchSolRptCreated form) throws Exception {
    List<Object[]> result = null;
    List<AnalysisSolRptCreated> analysisSolRptCreatedList = new ArrayList<AnalysisSolRptCreated>();
    try {

      StringBuilder queryBuilder = new StringBuilder();
      queryBuilder.append(" select c.creatorUserName, count(c.cntId) ")
              .append("  from Cnt c,  UPerson u")
              .append(" where c.published = 'Y' ")
              .append("   and c.cancelDate is null")
              .append("   and u.uPersonPK.userName = c.creatorUserName");

      Map<String, Object> properties = new HashMap<String, Object>();

      if (form.getOrganization() != null && !form.getOrganization().equals("All")) {
        queryBuilder.append(" and c.organization = lower('" + form.getOrganization() + "') ");
      }

      if (form.getFromDate() != null) {
        queryBuilder.append(" and c.publicationDate >= :fromDate ");
        properties.put("fromDate", form.getFromDate());
      }

      if (form.getToDate() != null) {
        queryBuilder.append(" and c.publicationDate <= :toDate ");
        properties.put("toDate", form.getToDate());
      }

      if (form.getCountry() != null) {
        queryBuilder.append(" and u.countryId = :countryId ");
        properties.put("countryId", Integer.parseInt(form.getCountry().getCountryId().toString()));
      }

      if (form.getUserName() != null) {
        queryBuilder.append(" and c.creatorUserName = :userName ");
        properties.put("userName", form.getUserName().toUpperCase());
      }

      queryBuilder.append(" group by c.creatorUserName ");

      TypedQuery<Object[]> query = entityManager.createQuery(queryBuilder.toString(), Object[].class);
      for (Map.Entry<String, Object> entry : properties.entrySet()) {
        query.setParameter(entry.getKey(), entry.getValue());
      }

      result = query.getResultList();
      for (Object[] obj : result) {
        analysisSolRptCreatedList.add(new AnalysisSolRptCreated(obj[0].toString(), Integer.parseInt(obj[1].toString())));
      }

    } catch (Exception e) {
      LOG.severe(e.getMessage());
      throw new Exception(e.getMessage());
    }
    return analysisSolRptCreatedList;
  }

  @Override
  public AnalysisReportByMonth getAnalysisReportByMonth(AnalysisSearchSolRptCreated form, String userName) throws Exception {
    AnalysisReportByMonth arbm = new AnalysisReportByMonth();
    arbm.setUserName(userName);
    arbm.setMonth1(getAnalysisReportByMonth(form, userName, 1));
    arbm.setMonth2(getAnalysisReportByMonth(form, userName, 2));
    arbm.setMonth3(getAnalysisReportByMonth(form, userName, 3));
    arbm.setMonth4(getAnalysisReportByMonth(form, userName, 4));
    arbm.setMonth5(getAnalysisReportByMonth(form, userName, 5));
    arbm.setMonth6(getAnalysisReportByMonth(form, userName, 6));
    arbm.setMonth7(getAnalysisReportByMonth(form, userName, 7));
    arbm.setMonth8(getAnalysisReportByMonth(form, userName, 8));
    arbm.setMonth9(getAnalysisReportByMonth(form, userName, 9));
    arbm.setMonth10(getAnalysisReportByMonth(form, userName, 10));
    arbm.setMonth11(getAnalysisReportByMonth(form, userName, 11));
    arbm.setMonth12(getAnalysisReportByMonth(form, userName, 12));
    int total = arbm.getMonth1() + arbm.getMonth2()
            + arbm.getMonth3() + arbm.getMonth4()
            + arbm.getMonth5() + arbm.getMonth6()
            + arbm.getMonth7() + arbm.getMonth8()
            + arbm.getMonth9() + arbm.getMonth10()
            + arbm.getMonth11() + arbm.getMonth12();
    arbm.setTotal(total);

    return arbm;
  }

  private int getAnalysisReportByMonth(AnalysisSearchSolRptCreated form, String userName, int month) throws Exception {
    int returnValue = 0;

    StringBuilder queryBuilder = new StringBuilder();
    queryBuilder.append(" select count(c.cntId) ")
            .append("  from Cnt c,  UPerson u")
            .append(" where c.published = 'Y' ")
            .append("   and c.cancelDate is null")
            .append("   and u.uPersonPK.userName = c.creatorUserName")
            .append("   and c.creatorUserName = :userName ")
            .append("   and to_char(c.publicationDate,'mm-yyyy') = :month");

    Map<String, Object> properties = new HashMap<String, Object>();
    properties.put("userName", userName.toUpperCase());
    properties.put("month", String.format("%02d", month) + "-" + form.getYear());

    if (form.getOrganization() != null && !form.getOrganization().equals("All")) {
      queryBuilder.append(" and c.organization = lower('" + form.getOrganization() + "') ");
    }

    if (form.getCountry() != null) {
      queryBuilder.append(" and u.countryId = :countryId ");
      properties.put("countryId", Integer.parseInt(form.getCountry().getCountryId().toString()));
    }

    TypedQuery<Object[]> query = entityManager.createQuery(queryBuilder.toString(), Object[].class);
    for (Map.Entry<String, Object> entry : properties.entrySet()) {
      query.setParameter(entry.getKey(), entry.getValue());
    }

    Object result = query.getSingleResult();

    returnValue = Integer.parseInt(result.toString());

    return returnValue;
  }

  @Override
  public List<AnalysisSolRptCreated> getFeedbackCreated(AnalysisSearchSolRptCreated form) throws Exception {
    List<Object[]> result = null;
    List<AnalysisSolRptCreated> analysisSolRptCreatedList = new ArrayList<AnalysisSolRptCreated>();
    try {

      StringBuilder queryBuilder = new StringBuilder();

      queryBuilder.append("select cf.userName, count(cf.feedbackId)")
              .append("  from Cnt c, CntFeedback cf, UPerson up")
              .append(" where c.published = 'Y'")
              .append("   and c.cancelDate is null")
              .append("   and c.cntId = cf.cnt.cntId")
              .append("   and cf.userName = up.uPersonPK.userName");

      Map<String, Object> properties = new HashMap<String, Object>();

//      if (form.getOrganization() != null && !form.getOrganization().equals("All")){
//        queryBuilder.append(" and c.organization = lower('"+form.getOrganization()+"') ");
//      }
      if (form.getFromDate() != null) {
        queryBuilder.append(" and cf.dateCreated >= :fromDate ");
        properties.put("fromDate", form.getFromDate());
      }

      if (form.getToDate() != null) {
        queryBuilder.append(" and cf.dateCreated <= :toDate ");
        properties.put("toDate", form.getToDate());
      }

      if (form.getCountry() != null) {
        queryBuilder.append(" and up.countryId = :countryId ");
        properties.put("countryId", Integer.parseInt(form.getCountry().getCountryId().toString()));
      }

      if (form.getUserName() != null) {
        queryBuilder.append(" and cf.userName = :userName ");
        properties.put("userName", form.getUserName().toUpperCase());
      }

      queryBuilder.append(" group by cf.userName ");

      TypedQuery<Object[]> query = entityManager.createQuery(queryBuilder.toString(), Object[].class);
      for (Map.Entry<String, Object> entry : properties.entrySet()) {
        query.setParameter(entry.getKey(), entry.getValue());
      }

      result = query.getResultList();
      for (Object[] obj : result) {
        analysisSolRptCreatedList.add(new AnalysisSolRptCreated(obj[0].toString(), Integer.parseInt(obj[1].toString())));
      }

    } catch (Exception e) {
      LOG.severe(e.getMessage());
      throw new Exception(e.getMessage());
    }
    return analysisSolRptCreatedList;
  }

  public List<AnalysisSolRptCreated> getSolutionReportRead(AnalysisSearchSolRptCreated form) throws Exception {
    List<Object[]> result = null;
    List<AnalysisSolRptCreated> analysisSolRptCreatedList = new ArrayList<AnalysisSolRptCreated>();
    try {

      StringBuilder queryBuilder = new StringBuilder();

      queryBuilder.append("select cc.cntCounterPK.userName, count(cc.counter)")
              .append("  from Cnt c, CntCounter cc, UPerson up")
              .append(" where c.published = 'Y'")
              .append("   and c.cancelDate is null")
              .append("   and c.cntId = cc.cntCounterPK.cntId")
              .append("   and cc.cntCounterPK.userName = up.uPersonPK.userName");

      Map<String, Object> properties = new HashMap<String, Object>();

//      if (form.getOrganization() != null && !form.getOrganization().equals("All")){
//        queryBuilder.append(" and c.organization = lower('"+form.getOrganization()+"') ");
//      }
      if (form.getFromDate() != null) {
        queryBuilder.append(" and cc.firstRead >= :fromDate ");
        properties.put("fromDate", form.getFromDate());
      }

      if (form.getToDate() != null) {
        queryBuilder.append(" and cc.firstRead <= :toDate ");
        properties.put("toDate", form.getToDate());
      }

      if (form.getCountry() != null) {
        queryBuilder.append(" and up.countryId = :countryId ");
        properties.put("countryId", Integer.parseInt(form.getCountry().getCountryId().toString()));
      }

      if (form.getUserName() != null) {
        queryBuilder.append(" and cc.cntCounterPK.userName = :userName ");
        properties.put("userName", form.getUserName().toUpperCase());
      }

      queryBuilder.append(" group by cc.cntCounterPK.userName ");

      TypedQuery<Object[]> query = entityManager.createQuery(queryBuilder.toString(), Object[].class);
      for (Map.Entry<String, Object> entry : properties.entrySet()) {
        query.setParameter(entry.getKey(), entry.getValue());
      }

      result = query.getResultList();
      for (Object[] obj : result) {
        analysisSolRptCreatedList.add(new AnalysisSolRptCreated(obj[0].toString(), Integer.parseInt(obj[1].toString())));
      }

    } catch (Exception e) {
      LOG.severe(e.getMessage());
      throw new Exception(e.getMessage());
    }
    return analysisSolRptCreatedList;
  }

  @Override
  public List<Country> getCountries() {
    List<Country> countries = new ArrayList<>();

    try {

      countries = entityManager.createQuery(singletonBean.getAnalysisReportQuerys("country.getAll"))
                               .getResultList();

    } catch (Exception e) {
      LOG.warning("getCountryList: " + e.getMessage());
    }

    return countries;
  }

  @Override
  public List<ProductivityReportModel> getProductivityReport(Date fromDate, Date toDate, Country country) {
    List<ProductivityReportModel> productivityReportModels = new ArrayList<>();

    try {

      StringBuilder queryBuilder = new StringBuilder();
      queryBuilder.append(singletonBean.getAnalysisReportQuerys("productivityReport.getReport"));

      Map<String, Object> properties = new HashMap<String, Object>();

      if (fromDate != null) {
        queryBuilder.append(" and pr.publish_date >= :fromDate ");
        properties.put("fromDate", fromDate);
      }

      if (toDate != null) {
        queryBuilder.append(" and pr.publish_date <= :toDate ");
        properties.put("toDate", toDate);
      }

      if (country != null) {
        queryBuilder.append(" and u.country_Id = :countryId ");
        properties.put("countryId", country.getCountryId());
      }

      Query query = entityManager.createNativeQuery(queryBuilder.toString());
      for (Map.Entry<String, Object> entry : properties.entrySet()) {
          query.setParameter(entry.getKey(), entry.getValue());
      }

      List<Object[]> objList = query.getResultList();

      for ( Object[] object : objList ) {

        int id = Integer.parseInt(object[0].toString());
        float compPrice = ( object[1] != null ) ? Float.parseFloat(object[1].toString()) : 0;
        float hourlyLaborRate = ( object[2] != null ) ? Float.parseFloat(object[2].toString()) : 0;
        String material = ( object[3] != null ) ? object[3].toString() : "";
        Date publishDate = ( object[4] != null ) ? (Date) object[4]: null;
        String saleRep = ( object[5] != null ) ? object[5].toString(): null;
        float walterPrice = ( object[6] != null ) ? Float.parseFloat(object[6].toString()) : 0;
        String walterProductNumber = ( object[7] != null ) ? object[7].toString() : "";
        int yearlyUsage = ( object[8] != null ) ? Integer.parseInt(object[8].toString()) : 0;

        String company = ( object[9] != null ) ? object[9].toString() : "";
        String compModelNumber = ( object[10] != null ) ? object[10].toString() : "";
        String compproductName = ( object[11] != null ) ? object[11].toString() : "";
        String competitorName = ( object[12] != null ) ? object[12].toString() : "";
        String applicatonName = ( object[13] != null ) ? object[13].toString() : "";
        float compAnnualRemMaterial = ( object[14] != null ) ? Float.parseFloat(object[14].toString()) : 0;

        int walterWheelsQuantity = ( object[15] != null ) ? Integer.parseInt(object[15].toString()) : 0;
        int compAnnualCutsNumber = ( object[16] != null ) ? Integer.parseInt(object[16].toString()) : 0;
        float compLabourCost = ( object[17] != null ) ? Float.parseFloat(object[17].toString()) : 0;
        float compProductCost = ( object[18] != null ) ? Float.parseFloat(object[18].toString()) : 0;
        float walterLabourCost = ( object[19] != null ) ? Float.parseFloat(object[19].toString()) : 0;
        float walterProductCost = ( object[20] != null ) ? Float.parseFloat(object[20].toString()) : 0;
        String comments = ( object[21] != null ) ? object[21].toString() : "";
        int compManHoursRequired = ( object[22] != null ) ? Integer.parseInt(object[22].toString()) : 0;
        int walterManHoursRequired = ( object[23] != null ) ? Integer.parseInt(object[23].toString()) : 0;

        ProductivityReportModel prm = new ProductivityReportModel();
        prm.setApplicatonName(applicatonName);
        prm.setComments(comments);
        prm.setCompAnnualCutsNumber(compAnnualCutsNumber);
        prm.setCompAnnualRemMaterial(compAnnualRemMaterial);
        prm.setCompLabourCost(compLabourCost);
        prm.setCompManHoursRequired(compManHoursRequired);
        prm.setCompModelNumber(compModelNumber);
        prm.setCompPrice(compPrice);
        prm.setCompProductCost(compProductCost);
        prm.setCompany(company);
        prm.setCompetitorName(competitorName);
        prm.setCompProductName(compproductName);
        prm.setHourlyLaborRate(hourlyLaborRate);
        prm.setId(id);
        prm.setMaterial(material);
        prm.setPublishDate(publishDate);
        prm.setSaleRep(saleRep);
        prm.setWalterLabourCost(walterLabourCost);
        prm.setWalterManHoursRequired(walterManHoursRequired);
        prm.setWalterPrice(walterPrice);
        prm.setWalterProductCost(walterProductCost);
        prm.setWalterProductNumber(walterProductNumber);
        prm.setWalterWheelsQuantity(walterWheelsQuantity);
        prm.setYearlyUsage(yearlyUsage);

        productivityReportModels.add(prm);

      }

    } catch (Exception e) {
      LOG.warning("getProductivityReport: " + e.getMessage());
      e.printStackTrace();
    }

    return productivityReportModels;
  }

 @Override
  public List<MobileProductivityReportModel> getMobileProductivityReport(Date fromDate, Date toDate, Country country) {
    List<MobileProductivityReportModel> mobileProductivityReportModels = new ArrayList<>();

    try {

      StringBuilder queryBuilder = new StringBuilder();
      queryBuilder.append(singletonBean.getAnalysisReportQuerys("mobileProductivityReport.getReport"));

      Map<String, Object> properties = new HashMap<String, Object>();

      if (fromDate != null) {
        queryBuilder.append(" and r.update_date >= :fromDate ");
        properties.put("fromDate", fromDate);
      }

      if (toDate != null) {
        queryBuilder.append(" and r.update_date <= :toDate ");
        properties.put("toDate", toDate);
      }

      if (country != null) {
        queryBuilder.append(" and c.country_Id = :countryId ");
        properties.put("countryId", country.getCountryId());
      }

      Query query = entityManager.createNativeQuery(queryBuilder.toString());
      for (Map.Entry<String, Object> entry : properties.entrySet()) {
          query.setParameter(entry.getKey(), entry.getValue());
      }

      List<Object[]> objList = query.getResultList();

      for ( Object[] object : objList ) {
        int nbr = 0;
        String id = ( object[nbr] != null ) ? object[nbr].toString() : ""; nbr++;
        String countryName = ( object[nbr] != null ) ? object[nbr].toString() : ""; nbr++;
        String screenname = ( object[nbr] != null ) ? object[nbr].toString() : ""; nbr++;
        Date updateDate = ( object[nbr] != null ) ? (Date) object[nbr] : null; nbr++;
        String status = ( object[nbr] != null ) ? object[nbr].toString() : ""; nbr++;
        String actionName = ( object[nbr] != null ) ? object[nbr].toString() : ""; nbr++;
        String com = ( object[nbr] != null ) ? object[nbr].toString() : ""; nbr++;
        String comBackingNumber = ( object[nbr] != null ) ? object[nbr].toString() : ""; nbr++;
        Double comBackingPadPrice = ( object[nbr] != null ) ? Double.parseDouble(object[nbr].toString()) : 0; nbr++;
        Double comDiameter = ( object[nbr] != null ) ? Double.parseDouble(object[nbr].toString()) : 0; nbr++;
        Double comEndUserPrice = ( object[nbr] != null ) ? Double.parseDouble(object[nbr].toString()) : 0; nbr++;
        String comGrit = ( object[nbr] != null ) ? object[nbr].toString() : ""; nbr++;
        String comOtherPowerTools = ( object[nbr] != null ) ? object[nbr].toString() : ""; nbr++;
        String comPowerTools = ( object[nbr] != null ) ? object[nbr].toString() : ""; nbr++;
        String comProductName = ( object[nbr] != null ) ? object[nbr].toString() : ""; nbr++;
        String comProductNumber = ( object[nbr] != null ) ? object[nbr].toString() : ""; nbr++;
        Long comQuantityBackingPerYear = ( object[nbr] != null ) ? Long.parseLong(object[nbr].toString()) : 0; nbr++;
        Long comQuantityDiscPerYear = ( object[nbr] != null ) ? Long.parseLong(object[nbr].toString()) : 0; nbr++;
        String contactEnterprise = ( object[nbr] != null ) ? object[nbr].toString() : ""; nbr++;
        String materialDesc = ( object[nbr] != null ) ? object[nbr].toString() : ""; nbr++;
        String reportName = ( object[nbr] != null ) ? object[nbr].toString() : ""; nbr++;
        String resellerCompagny = ( object[nbr] != null ) ? object[nbr].toString() : ""; nbr++;
        Short saleGenerated = ( object[nbr] != null ) ? Short.parseShort(object[nbr].toString()) : 0; nbr++;
        Double shopRate = ( object[nbr] != null ) ? Double.parseDouble(object[nbr].toString()) : 0; nbr++;
        Long timePerDiscChangeover = ( object[nbr] != null ) ? Long.parseLong(object[nbr].toString()) : 0; nbr++;
        Double walEndUserPrice = ( object[nbr] != null ) ? Double.parseDouble(object[nbr].toString()) : 0; nbr++;
        String walOtherPowerTools = ( object[nbr] != null ) ? object[nbr].toString() : ""; nbr++;
        String walPowerTools = ( object[nbr] != null ) ? object[nbr].toString() : ""; nbr++;
        String walterProductNumber = ( object[nbr] != null ) ? object[nbr].toString() : ""; nbr++;
        Double saving = ( object[nbr] != null ) ? Double.parseDouble(object[nbr].toString()) : 0; nbr++;
        Long numberOfDiscs = ( object[nbr] != null ) ? Long.parseLong(object[nbr].toString()) : 0; nbr++;
        Long numberOfPads = ( object[nbr] != null ) ? Long.parseLong(object[nbr].toString()) : 0; nbr++;
        Double pricePerDisc = ( object[nbr] != null ) ? Double.parseDouble(object[nbr].toString()) : 0; nbr++;
        Double reimbursement = ( object[nbr] != null ) ? Double.parseDouble(object[nbr].toString()) : 0; nbr++;

        MobileProductivityReportModel mprm = new MobileProductivityReportModel();
        mprm.setActionName(actionName);
        mprm.setCom(com);
        mprm.setComBackingNumber(comBackingNumber);
        mprm.setComBackingPadPrice(comBackingPadPrice);
        mprm.setComDiameter(comDiameter);
        mprm.setComEndUserPrice(comEndUserPrice);
        mprm.setComGrit(comGrit);
        mprm.setComOtherPowerTools(comOtherPowerTools);
        mprm.setComPowerTools(comPowerTools);
        mprm.setComProductName(comProductName);
        mprm.setComProductNumber(comProductNumber);
        mprm.setComQuantityBackingPerYear(comQuantityBackingPerYear);
        mprm.setComQuantityDiscPerYear(comQuantityDiscPerYear);
        mprm.setContactEnterprise(contactEnterprise);
        mprm.setCountryName(countryName);
        mprm.setId(id);
        mprm.setMaterialDesc(materialDesc);
        mprm.setNumberOfDiscs(numberOfDiscs);
        mprm.setNumberOfPads(numberOfPads);
        mprm.setPricePerDisc(pricePerDisc);
        mprm.setReimbursement(reimbursement);
        mprm.setReportName(reportName);
        mprm.setResellerCompagny(resellerCompagny);
        mprm.setSaleGenerated(saleGenerated);
        mprm.setSaving(saving);
        mprm.setScreenname(screenname);
        mprm.setShopRate(shopRate);
        mprm.setStatus(status);
        mprm.setTimePerDiscChangeover(timePerDiscChangeover);
        mprm.setUpdateDate(updateDate);
        mprm.setWalEndUserPrice(walEndUserPrice);
        mprm.setWalOtherPowerTools(walOtherPowerTools);
        mprm.setWalPowerTools(walPowerTools);
        mprm.setWalterProductNumber(walterProductNumber);
        mobileProductivityReportModels.add(mprm);
      }

    } catch (Exception e) {
      LOG.warning("getMobileProductivityReport: " + e.getMessage());
      e.printStackTrace();
    }

    return mobileProductivityReportModels;
  }

//
//r.id, c.description as countryName, u.screenname, u.firstname, u.lastname, r.update_date, r.status, app.instancename as actionName,
//           r.com, r.com_backing_number, r.com_backing_pad_price, r.com_diameter, r.com_end_user_price, r.com_grit, r.com_other_power_tools,
//           r.com_power_tools, r.com_product_name, r.com_product_number, r.com_quantity_backing_per_year, r.com_quantity_disc_per_year, r.contact_enterprise,
//           um.material_desc, r.name as reportName, r.reseller_compagny, r.sale_generated, r.shop_rate, r.status,
//           r.time_per_disc_changeover, r.wal_end_user_price, r.wal_other_power_tools, r.wal_power_tools, prod.instancealternatekey, rl.saving,
//           rr.number_of_discs, rr.number_of_pads, rr.price_per_disc, rr.reimbursement

}
