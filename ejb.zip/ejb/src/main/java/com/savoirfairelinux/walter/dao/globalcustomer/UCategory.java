package com.savoirfairelinux.walter.dao.globalcustomer;

import com.savoirfairelinux.walter.dao.DatabaseConstants;
import javax.persistence.*;
import javax.validation.constraints.Size;
import java.io.Serializable;

/**
 * @author jderuere
 */
@Entity
@Table(name = "U_CATEGORY", schema = DatabaseConstants.WALTERCB_SCHEMA)
@NamedQueries({
        @NamedQuery(name = "UCategory.findAll", query = "SELECT u FROM UCategory u"),
        @NamedQuery(name = "UCategory.findByLangId", query = "SELECT u FROM UCategory u WHERE u.uCategoryPK.langId = :langId"),
        @NamedQuery(name = "UCategory.findByDescription", query = "SELECT u FROM UCategory u WHERE u.categoryDesc = :categoryDesc")})
public class UCategory implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected UCategoryPK uCategoryPK;
    @Size(max = 100)
    @Column(name = "CATEGORY_DESC")
    private String categoryDesc;

    public UCategoryPK getUCategoryPK() {
        return uCategoryPK;
    }

    public void setUCategoryPK(UCategoryPK uCategoryPK) {
        this.uCategoryPK = uCategoryPK;
    }

    public String getCategoryDesc() {
        return categoryDesc;
    }

    public void setCategoryDesc(String categoryDesc) {
        this.categoryDesc = categoryDesc;
    }
}
