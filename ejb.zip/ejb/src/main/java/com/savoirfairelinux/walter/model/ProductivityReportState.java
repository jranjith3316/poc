package com.savoirfairelinux.walter.model;

public enum ProductivityReportState {

	UNSUBMIT,
	SUBMIT,
	PUBLISH;
}
