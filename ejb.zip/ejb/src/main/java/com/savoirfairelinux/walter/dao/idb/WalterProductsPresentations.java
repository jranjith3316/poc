/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.idb;

import com.savoirfairelinux.walter.dao.DatabaseConstants;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "WALTER_PRODUCTS_PRESENTATIONS", catalog = "", schema = DatabaseConstants.IDB_SCHEMA)
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "WalterProductsPresentations.findAll", query = "SELECT w FROM WalterProductsPresentations w"),
  @NamedQuery(name = "WalterProductsPresentations.findByProductupccode", query = "SELECT w FROM WalterProductsPresentations w WHERE w.productupccode = :productupccode"),
  @NamedQuery(name = "WalterProductsPresentations.findByProductpresentationguid", query = "SELECT w FROM WalterProductsPresentations w WHERE w.productpresentationguid = :productpresentationguid"),
  @NamedQuery(name = "WalterProductsPresentations.findByAdddatetime", query = "SELECT w FROM WalterProductsPresentations w WHERE w.adddatetime = :adddatetime"),
  @NamedQuery(name = "WalterProductsPresentations.findByDeletedatetime", query = "SELECT w FROM WalterProductsPresentations w WHERE w.deletedatetime = :deletedatetime"),
  @NamedQuery(name = "WalterProductsPresentations.findByUpdatedatetime", query = "SELECT w FROM WalterProductsPresentations w WHERE w.updatedatetime = :updatedatetime")})
public class WalterProductsPresentations implements Serializable {
  private static final long serialVersionUID = 1L;
  @Size(max = 255)
  @Column(name = "PRODUCTUPCCODE")
  private String productupccode;
  @Lob
  @Column(name = "PRODUCTPRESENTATIONDESCRIPTION")
  private String productpresentationdescription;
  @Id
  @Basic(optional = false)
  @NotNull
  @Size(min = 1, max = 255)
  @Column(name = "PRODUCTPRESENTATIONGUID")
  private String productpresentationguid;
  @Column(name = "ADDDATETIME")
  @Temporal(TemporalType.TIMESTAMP)
  private Date adddatetime;
  @Column(name = "DELETEDATETIME")
  @Temporal(TemporalType.TIMESTAMP)
  private Date deletedatetime;
  @Column(name = "UPDATEDATETIME")
  @Temporal(TemporalType.TIMESTAMP)
  private Date updatedatetime;
//  @OneToMany(mappedBy = "productpresentationguid")
//  private Set<WalterProductsDocuments> walterProductsDocumentsSet;
  @JoinColumn(name = "PRODUCTGUID", referencedColumnName = "PRODUCTGUID")
  @ManyToOne(optional = false)
  private WalterProducts productguid;
  @JoinColumn(name = "PRESENTATIONGUID", referencedColumnName = "INSTANCEGUID")
  @ManyToOne(optional = false)
  private OoInstances presentationguid;
//  @OneToMany(cascade = CascadeType.ALL, mappedBy = "productpresentationguid")
//  private Set<WalterProductsCountries> walterProductsCountriesSet;

  public WalterProductsPresentations() {
  }

  public WalterProductsPresentations(String productpresentationguid) {
    this.productpresentationguid = productpresentationguid;
  }

  public String getProductupccode() {
    return productupccode;
  }

  public void setProductupccode(String productupccode) {
    this.productupccode = productupccode;
  }

  public String getProductpresentationdescription() {
    return productpresentationdescription;
  }

  public void setProductpresentationdescription(String productpresentationdescription) {
    this.productpresentationdescription = productpresentationdescription;
  }

  public String getProductpresentationguid() {
    return productpresentationguid;
  }

  public void setProductpresentationguid(String productpresentationguid) {
    this.productpresentationguid = productpresentationguid;
  }

  public Date getAdddatetime() {
    return adddatetime;
  }

  public void setAdddatetime(Date adddatetime) {
    this.adddatetime = adddatetime;
  }

  public Date getDeletedatetime() {
    return deletedatetime;
  }

  public void setDeletedatetime(Date deletedatetime) {
    this.deletedatetime = deletedatetime;
  }

  public Date getUpdatedatetime() {
    return updatedatetime;
  }

  public void setUpdatedatetime(Date updatedatetime) {
    this.updatedatetime = updatedatetime;
  }

//  @XmlTransient
//  public Set<WalterProductsDocuments> getWalterProductsDocumentsSet() {
//    return walterProductsDocumentsSet;
//  }
//
//  public void setWalterProductsDocumentsSet(Set<WalterProductsDocuments> walterProductsDocumentsSet) {
//    this.walterProductsDocumentsSet = walterProductsDocumentsSet;
//  }

  public WalterProducts getProductguid() {
    return productguid;
  }

  public void setProductguid(WalterProducts productguid) {
    this.productguid = productguid;
  }

  public OoInstances getPresentationguid() {
    return presentationguid;
  }

  public void setPresentationguid(OoInstances presentationguid) {
    this.presentationguid = presentationguid;
  }

//  @XmlTransient
//  public Set<WalterProductsCountries> getWalterProductsCountriesSet() {
//    return walterProductsCountriesSet;
//  }
//
//  public void setWalterProductsCountriesSet(Set<WalterProductsCountries> walterProductsCountriesSet) {
//    this.walterProductsCountriesSet = walterProductsCountriesSet;
//  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (productpresentationguid != null ? productpresentationguid.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof WalterProductsPresentations)) {
      return false;
    }
    WalterProductsPresentations other = (WalterProductsPresentations) object;
    if ((this.productpresentationguid == null && other.productpresentationguid != null) || (this.productpresentationguid != null && !this.productpresentationguid.equals(other.productpresentationguid))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.idb.WalterProductsPresentations[ productpresentationguid=" + productpresentationguid + " ]";
  }

}
