/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.idb;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author jsgill
 */
@Embeddable
public class TemplateTitlePK implements Serializable {
  @Basic(optional = false)
  @NotNull
  @Size(min = 1, max = 255)
  @Column(name = "TEMPLATEGUID")
  private String templateguid;
  @Basic(optional = false)
  @NotNull
  @Column(name = "COLUMN_ID")
  private short columnId;
  @Basic(optional = false)
  @NotNull
  @Column(name = "ROW_ID")
  private short rowId;

  public TemplateTitlePK() {
  }

  public TemplateTitlePK(String templateguid, short columnId, short rowId) {
    this.templateguid = templateguid;
    this.columnId = columnId;
    this.rowId = rowId;
  }

  public String getTemplateguid() {
    return templateguid;
  }

  public void setTemplateguid(String templateguid) {
    this.templateguid = templateguid;
  }

  public short getColumnId() {
    return columnId;
  }

  public void setColumnId(short columnId) {
    this.columnId = columnId;
  }

  public short getRowId() {
    return rowId;
  }

  public void setRowId(short rowId) {
    this.rowId = rowId;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (templateguid != null ? templateguid.hashCode() : 0);
    hash += (int) columnId;
    hash += (int) rowId;
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof TemplateTitlePK)) {
      return false;
    }
    TemplateTitlePK other = (TemplateTitlePK) object;
    if ((this.templateguid == null && other.templateguid != null) || (this.templateguid != null && !this.templateguid.equals(other.templateguid))) {
      return false;
    }
    if (this.columnId != other.columnId) {
      return false;
    }
    if (this.rowId != other.rowId) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.idb.TemplateTitlePK[ templateguid=" + templateguid + ", columnId=" + columnId + ", rowId=" + rowId + " ]";
  }

}
