/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "U_TRANSLATOR", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "UTranslator.findAll", query = "SELECT u FROM UTranslator u"),
    @NamedQuery(name = "UTranslator.findBySubscriberId", query = "SELECT u FROM UTranslator u WHERE u.uTranslatorPK.subscriberId = :subscriberId"),
    @NamedQuery(name = "UTranslator.findByUserName", query = "SELECT u FROM UTranslator u WHERE u.uTranslatorPK.userName = :userName"),
    @NamedQuery(name = "UTranslator.findByLangId", query = "SELECT u FROM UTranslator u WHERE u.uTranslatorPK.langId = :langId"),
    @NamedQuery(name = "UTranslator.findByRandomNum", query = "SELECT u FROM UTranslator u WHERE u.randomNum = :randomNum")})
public class UTranslator implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected UTranslatorPK uTranslatorPK;
    @Column(name = "RANDOM_NUM")
    private Long randomNum;

    public UTranslator() {
    }

    public UTranslator(UTranslatorPK uTranslatorPK) {
        this.uTranslatorPK = uTranslatorPK;
    }

    public UTranslator(long subscriberId, String userName, short langId) {
        this.uTranslatorPK = new UTranslatorPK(subscriberId, userName, langId);
    }

    public UTranslatorPK getUTranslatorPK() {
        return uTranslatorPK;
    }

    public void setUTranslatorPK(UTranslatorPK uTranslatorPK) {
        this.uTranslatorPK = uTranslatorPK;
    }

    public Long getRandomNum() {
        return randomNum;
    }

    public void setRandomNum(Long randomNum) {
        this.randomNum = randomNum;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (uTranslatorPK != null ? uTranslatorPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof UTranslator)) {
            return false;
        }
        UTranslator other = (UTranslator) object;
        if ((this.uTranslatorPK == null && other.uTranslatorPK != null) || (this.uTranslatorPK != null && !this.uTranslatorPK.equals(other.uTranslatorPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.UTranslator[ uTranslatorPK=" + uTranslatorPK + " ]";
    }
    
}
