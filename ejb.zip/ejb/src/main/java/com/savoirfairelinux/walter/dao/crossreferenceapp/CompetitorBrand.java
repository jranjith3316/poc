/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.crossreferenceapp;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "COMPETITOR_BRAND", catalog = "", schema = "CROSSREFERENCEAPP")
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "CompetitorBrand.findAll", query = "SELECT c FROM CompetitorBrand c"),
  @NamedQuery(name = "CompetitorBrand.findByCompetitorId", query = "SELECT c FROM CompetitorBrand c WHERE c.competitorBrandPK.competitorId = :competitorId"),
  @NamedQuery(name = "CompetitorBrand.findByBrandId", query = "SELECT c FROM CompetitorBrand c WHERE c.competitorBrandPK.brandId = :brandId"),
  @NamedQuery(name = "CompetitorBrand.findByName", query = "SELECT c FROM CompetitorBrand c WHERE c.name = :name"),
  @NamedQuery(name = "CompetitorBrand.findByCreatedUserName", query = "SELECT c FROM CompetitorBrand c WHERE c.createdUserName = :createdUserName"),
  @NamedQuery(name = "CompetitorBrand.findByCreatedDate", query = "SELECT c FROM CompetitorBrand c WHERE c.createdDate = :createdDate"),
  @NamedQuery(name = "CompetitorBrand.findByUpdatedUserName", query = "SELECT c FROM CompetitorBrand c WHERE c.updatedUserName = :updatedUserName"),
  @NamedQuery(name = "CompetitorBrand.findByUpdatedDate", query = "SELECT c FROM CompetitorBrand c WHERE c.updatedDate = :updatedDate"),
  @NamedQuery(name = "CompetitorBrand.findByDeleteUserName", query = "SELECT c FROM CompetitorBrand c WHERE c.deleteUserName = :deleteUserName"),
  @NamedQuery(name = "CompetitorBrand.findByDeletedDate", query = "SELECT c FROM CompetitorBrand c WHERE c.deletedDate = :deletedDate")})
public class CompetitorBrand implements Serializable {
  private static final long serialVersionUID = 1L;
  @EmbeddedId
  protected CompetitorBrandPK competitorBrandPK;
  @Size(max = 100)
  @Column(name = "NAME")
  private String name;
  @Size(max = 255)
  @Column(name = "CREATED_USER_NAME")
  private String createdUserName;
  @Column(name = "CREATED_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date createdDate;
  @Size(max = 255)
  @Column(name = "UPDATED_USER_NAME")
  private String updatedUserName;
  @Column(name = "UPDATED_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date updatedDate;
  @Size(max = 255)
  @Column(name = "DELETE_USER_NAME")
  private String deleteUserName;
  @Column(name = "DELETED_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date deletedDate;

  public CompetitorBrand() {
  }

  public CompetitorBrand(CompetitorBrandPK competitorBrandPK) {
    this.competitorBrandPK = competitorBrandPK;
  }

  public CompetitorBrand(long competitorId, long brandId) {
    this.competitorBrandPK = new CompetitorBrandPK(competitorId, brandId);
  }

  public CompetitorBrandPK getCompetitorBrandPK() {
    return competitorBrandPK;
  }

  public void setCompetitorBrandPK(CompetitorBrandPK competitorBrandPK) {
    this.competitorBrandPK = competitorBrandPK;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getCreatedUserName() {
    return createdUserName;
  }

  public void setCreatedUserName(String createdUserName) {
    this.createdUserName = createdUserName;
  }

  public Date getCreatedDate() {
    return createdDate;
  }

  public void setCreatedDate(Date createdDate) {
    this.createdDate = createdDate;
  }

  public String getUpdatedUserName() {
    return updatedUserName;
  }

  public void setUpdatedUserName(String updatedUserName) {
    this.updatedUserName = updatedUserName;
  }

  public Date getUpdatedDate() {
    return updatedDate;
  }

  public void setUpdatedDate(Date updatedDate) {
    this.updatedDate = updatedDate;
  }

  public String getDeleteUserName() {
    return deleteUserName;
  }

  public void setDeleteUserName(String deleteUserName) {
    this.deleteUserName = deleteUserName;
  }

  public Date getDeletedDate() {
    return deletedDate;
  }

  public void setDeletedDate(Date deletedDate) {
    this.deletedDate = deletedDate;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (competitorBrandPK != null ? competitorBrandPK.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof CompetitorBrand)) {
      return false;
    }
    CompetitorBrand other = (CompetitorBrand) object;
    if ((this.competitorBrandPK == null && other.competitorBrandPK != null) || (this.competitorBrandPK != null && !this.competitorBrandPK.equals(other.competitorBrandPK))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.crossreferenceapp.CompetitorBrand[ competitorBrandPK=" + competitorBrandPK + " ]";
  }

}
