/* 
 * Copyright 2012 Savoir-faire Linux
 * 
 * This file is part of Walter-Portal.
 * 
 * Walter-Portal is free software: you can redistribute it and/or modify it under the terms of the 
 * GNU General Public License as published by the Free Software Foundation, either version 3 
 * of the License, or (at your option) any later version.
 * 
 * Walter-Portal is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with Walter-Portal. 
 * If not, see http://www.gnu.org/licenses/.
 */
package com.savoirfairelinux.walter.service.notification;

import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.HtmlUtil;
import com.liferay.portal.kernel.util.HttpUtil;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.Address;
import com.liferay.portal.model.Organization;
import com.liferay.portal.model.User;
import com.liferay.portal.model.VirtualHost;
import com.liferay.portal.service.VirtualHostLocalServiceUtil;
import com.liferay.portlet.documentlibrary.model.DLFileEntry;
import com.liferay.portlet.documentlibrary.model.DLFileVersion;
import com.liferay.portlet.documentlibrary.model.DLFolder;
import com.liferay.portlet.documentlibrary.model.DLFolderConstants;
import com.liferay.portlet.documentlibrary.service.DLFileEntryLocalServiceUtil;
import com.liferay.portlet.documentlibrary.service.DLFolderLocalServiceUtil;
import com.savoirfairelinux.walter.service.impl.NotificationBean;

import javax.mail.internet.InternetAddress;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.ResourceBundle.Control;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author jbonjean
 *
 */
public class NotificationUtil {

    public static final Logger LOG = Logger.getLogger(NotificationUtil.class.getCanonicalName());

    /**
     * Find template on file system, depending on the locale, read it and load
     * it in a String
     */
    public static String readTemplate(String templateName, Locale locale) throws IOException {

        // Find the correct template, we use bits of ResourceBundle logic
        Control control = ResourceBundle.Control.getControl(Control.FORMAT_DEFAULT);
        URL templateURL = null;
        for (Locale l : control.getCandidateLocales("", locale)) {
            String bundleName = control.toBundleName(templateName, l);
            String resourceName = control.toResourceName(bundleName, NotificationTemplate.EXTENSION);
            String resourcePath = NotificationTemplate.PATH + resourceName;
            templateURL = NotificationUtil.class.getClassLoader().getResource(resourcePath);
            if (templateURL != null) {
                break;
            }
        }

        // Template not found, I'm not happy
        if (templateURL == null) {
            throw new IOException("Template not found: " + templateName);
        }

        // Load the template into a String
        StringBuffer templateContent = new StringBuffer();
        BufferedReader in = new BufferedReader(new InputStreamReader(templateURL.openStream(), "UTF-8"));
        String inputLine;
        while ((inputLine = in.readLine()) != null) {
            templateContent.append(inputLine);
        }
        in.close();

        return templateContent.toString();
    }

    /**
     * Safely return the user country name
     */
    public static String getCountry(User user) {
        String country = null;

        try {
            List<Address> addresses = user.getAddresses();
            if (addresses.size() > 0) // take the country of the first user address
            {
                country = addresses.get(0).getCountry().getName();
            }
        } catch (SystemException e) {
            NotificationBean.LOGGER.severe(e.getMessage());
        }

        if (country == null) {
            // trying to get a country from user locale
            country = user.getLocale().getCountry();

            // if still nothing, we cannot do better, return a dummy string
            if (country == null || country.isEmpty()) {
                country = "[NOT FOUND]";
            }
        }
        return country;
    }

    /**
     * Generate url to the organization logo
     */
    public static String getLogoURL(Organization organization) {
        StringBuffer url = new StringBuffer();
        try {
            OrganizationProperties organizationProperties = NotificationUtil.getOrganizationProperties(organization);
            DLFolder folder = DLFolderLocalServiceUtil.getFolder(organization.getGroupId(), DLFolderConstants.DEFAULT_PARENT_FOLDER_ID, "Logo");
            DLFileEntry fileEntry = DLFileEntryLocalServiceUtil.getFileEntry(organization.getGroupId(), folder.getFolderId(), organizationProperties.getLogoFileName());
            DLFileVersion version = fileEntry.getLatestFileVersion(true);
            VirtualHost host = VirtualHostLocalServiceUtil.getVirtualHost(organization.getCompanyId(), organization.getGroup().getPublicLayoutSet().getLayoutSetId());
            url.append("http://"+host.getHostname()).append("/documents/")
                    .append(fileEntry.getRepositoryId()).append(StringPool.SLASH).append(fileEntry.getFolderId())
                    .append(StringPool.SLASH).append(HttpUtil.encodeURL(HtmlUtil.unescape(fileEntry.getTitle())))
                    .append(StringPool.SLASH).append(fileEntry.getUuid())
                    .append("?version=").append(version.getVersion())
                    .append("&t=").append(version.getModifiedDate().getTime());
            
        } catch (Exception e) {
            LOG.log(Level.WARNING, "Can't find the logo : " + url.toString(), e);
        }

        return url.toString();
    }

    /**
     * Return the management email address, depending of the organization
     */
    public static InternetAddress getManagementEmail(Organization organization) throws Exception {
        OrganizationProperties organizationProperties = NotificationUtil.getOrganizationProperties(organization);
        String name = organizationProperties.getManagementName();
        String email = organizationProperties.getManagementEmail();
        return new InternetAddress(email, name);
    }

    /**
     * Return organization properties associated with Liferay organization
     */
    public static OrganizationProperties getOrganizationProperties(Organization organization) throws Exception {
        return NotificationUtil.isWalter(organization) ? OrganizationProperties.WALTER
                : OrganizationProperties.BIO_CIRCLE;
    }

    /**
     * Return true if it is Walter's organization
     */
    public static boolean isWalter(Organization organization) throws Exception {
        if (organization.getName().equals(OrganizationProperties.WALTER.getName())) {
            return true;
        }
        if (organization.getName().equals(OrganizationProperties.BIO_CIRCLE.getName())) {
            return false;
        }

        throw new Exception("Unknown organization " + organization.getName());
    }

    /**
     * Return user's organization
     */
    public static Organization getOrganization(String organizationName, User user) throws Exception {
        Organization result = user.getOrganizations().get(0);

        if (result == null) {
            throw new Exception("User does not have any organization (with dbname attribute)");
        }
        return result;
    }
}
