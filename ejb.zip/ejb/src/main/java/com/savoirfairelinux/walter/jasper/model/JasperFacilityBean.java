/* 
 * Copyright 2013 Savoir-faire Linux
 * 
 * This file is part of Walter-Portal.
 * 
 * Walter-Portal is free software: you can redistribute it and/or modify it under the terms of the 
 * GNU General Public License as published by the Free Software Foundation, either version 3 
 * of the License, or (at your option) any later version.
 * 
 * Walter-Portal is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with Walter-Portal. 
 * If not, see http://www.gnu.org/licenses/.
 */
package com.savoirfairelinux.walter.jasper.model;

import java.io.InputStream;
import java.io.Serializable;
import java.util.List;

/**
 * 
 * @author jbonjean
 * 
 */
public class JasperFacilityBean implements Serializable {
    private String accountName;
    private InputStream logo;
    private String keyContact;
    private String facilityName;
    private String address;
    private String city;
    private String postalCode;
    private String provinceState;
    private String country;
    private String category;
    private String mainContact;
    private String department;
    private String emailAddress;
    private String phoneNumber;
    private String saleRepresentative;
    private String saleRepresentativeEmailAddress;
    private String organization;
    private List<JasperProductBean> products;
    private List<JasperFeedbackBean> feedbacks;

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public String getKeyContact() {
        return keyContact;
    }

    public void setKeyContact(String keyContact) {
        this.keyContact = keyContact;
    }

    public String getFacilityName() {
        return facilityName;
    }

    public void setFacilityName(String facilityName) {
        this.facilityName = facilityName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getProvinceState() {
        return provinceState;
    }

    public void setProvinceState(String provinceState) {
        this.provinceState = provinceState;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getMainContact() {
        return mainContact;
    }

    public void setMainContact(String mainContact) {
        this.mainContact = mainContact;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getSaleRepresentative() {
        return saleRepresentative;
    }

    public void setSaleRepresentative(String saleRepresentative) {
        this.saleRepresentative = saleRepresentative;
    }

    public String getSaleRepresentativeEmailAddress() {
        return saleRepresentativeEmailAddress;
    }

    public void setSaleRepresentativeEmailAddress(String saleRepresentativeEmailAddress) {
        this.saleRepresentativeEmailAddress = saleRepresentativeEmailAddress;
    }

    public String getOrganization() {
        return organization;
    }

    public void setOrganization(String organization) {
        this.organization = organization;
    }

    public List<JasperProductBean> getProducts() {
        return products;
    }

    public void setProducts(List<JasperProductBean> products) {
        this.products = products;
    }

    public InputStream getLogo() {
        return logo;
    }

    public void setLogo(InputStream logo) {
        this.logo = logo;
    }

    public List<JasperFeedbackBean> getFeedbacks() {
        return feedbacks;
    }

    public void setFeedbacks(List<JasperFeedbackBean> feedbacks) {
        this.feedbacks = feedbacks;
    }
}
