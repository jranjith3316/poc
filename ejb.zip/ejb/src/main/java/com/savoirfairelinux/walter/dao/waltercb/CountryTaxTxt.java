/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "COUNTRY_TAX_TXT", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CountryTaxTxt.findAll", query = "SELECT c FROM CountryTaxTxt c"),
    @NamedQuery(name = "CountryTaxTxt.findByCountryId", query = "SELECT c FROM CountryTaxTxt c WHERE c.countryTaxTxtPK.countryId = :countryId"),
    @NamedQuery(name = "CountryTaxTxt.findByTaxCode", query = "SELECT c FROM CountryTaxTxt c WHERE c.countryTaxTxtPK.taxCode = :taxCode"),
    @NamedQuery(name = "CountryTaxTxt.findByLangId", query = "SELECT c FROM CountryTaxTxt c WHERE c.countryTaxTxtPK.langId = :langId"),
    @NamedQuery(name = "CountryTaxTxt.findByTaxDesc", query = "SELECT c FROM CountryTaxTxt c WHERE c.taxDesc = :taxDesc"),
    @NamedQuery(name = "CountryTaxTxt.findByTaxAbbreviation", query = "SELECT c FROM CountryTaxTxt c WHERE c.taxAbbreviation = :taxAbbreviation")})
public class CountryTaxTxt implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected CountryTaxTxtPK countryTaxTxtPK;
    @Size(max = 40)
    @Column(name = "TAX_DESC")
    private String taxDesc;
    @Size(max = 3)
    @Column(name = "TAX_ABBREVIATION")
    private String taxAbbreviation;

    public CountryTaxTxt() {
    }

    public CountryTaxTxt(CountryTaxTxtPK countryTaxTxtPK) {
        this.countryTaxTxtPK = countryTaxTxtPK;
    }

    public CountryTaxTxt(long countryId, String taxCode, long langId) {
        this.countryTaxTxtPK = new CountryTaxTxtPK(countryId, taxCode, langId);
    }

    public CountryTaxTxtPK getCountryTaxTxtPK() {
        return countryTaxTxtPK;
    }

    public void setCountryTaxTxtPK(CountryTaxTxtPK countryTaxTxtPK) {
        this.countryTaxTxtPK = countryTaxTxtPK;
    }

    public String getTaxDesc() {
        return taxDesc;
    }

    public void setTaxDesc(String taxDesc) {
        this.taxDesc = taxDesc;
    }

    public String getTaxAbbreviation() {
        return taxAbbreviation;
    }

    public void setTaxAbbreviation(String taxAbbreviation) {
        this.taxAbbreviation = taxAbbreviation;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (countryTaxTxtPK != null ? countryTaxTxtPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CountryTaxTxt)) {
            return false;
        }
        CountryTaxTxt other = (CountryTaxTxt) object;
        if ((this.countryTaxTxtPK == null && other.countryTaxTxtPK != null) || (this.countryTaxTxtPK != null && !this.countryTaxTxtPK.equals(other.countryTaxTxtPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.CountryTaxTxt[ countryTaxTxtPK=" + countryTaxTxtPK + " ]";
    }
    
}
