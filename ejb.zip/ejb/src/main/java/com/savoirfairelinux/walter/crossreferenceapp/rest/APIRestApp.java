/*
 * To create the JSON file for the cross reference app
 */
package com.savoirfairelinux.walter.crossreferenceapp.rest;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.model.Company;
import com.liferay.portal.model.CompanyConstants;
import com.liferay.portal.model.User;
import com.liferay.portal.model.UserConstants;
import com.liferay.portal.service.CompanyLocalServiceUtil;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.savoirfairelinux.walter.crossreferenceapp.model.CompetitorModel;
import com.savoirfairelinux.walter.crossreferenceapp.model.CompetitorRequestApi;
import com.savoirfairelinux.walter.crossreferenceapp.model.CounterRequestAPI;
import com.savoirfairelinux.walter.crossreferenceapp.model.CrossReferenceAppModel;
import com.savoirfairelinux.walter.crossreferenceapp.model.LoginModel;
import com.savoirfairelinux.walter.crossreferenceapp.model.LoginRequestAPI;
import com.savoirfairelinux.walter.crossreferenceapp.model.WalterProductAppModel;
import com.savoirfairelinux.walter.crossreferenceapp.model.WalterProductDeletedModel;
import com.savoirfairelinux.walter.crossreferenceapp.model.WalterProductModel;
import com.savoirfairelinux.walter.crossreferenceapp.model.WalterProductRequestApi;
import com.savoirfairelinux.walter.crossreferenceapp.model.counterResponse;
import com.savoirfairelinux.walter.jasper.JasperReportType;
import com.savoirfairelinux.walter.jasper.exceptions.JasperException;
import com.savoirfairelinux.walter.jasper.model.JasperCrossReferenceAppBean;
import com.savoirfairelinux.walter.service.impl.CrossReferenceAppBean;
import com.savoirfairelinux.walter.service.impl.JasperBean;
import com.savoirfairelinux.walter.service.impl.WalterBean;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
/**
 *
 * @author jsgill
 */
@Stateless
@Path("/API/crossReferenceApp")
public class APIRestApp {

  private static final Logger LOG = Logger.getLogger(APIRestApp.class.getCanonicalName());

  @EJB
  CrossReferenceAppBean crossReferenceAppBean;

  @EJB
  WalterBean walterBean;

  @EJB
  JasperBean jasperBean;

  @Context  //injected response proxy supporting multiple threads
  private HttpServletResponse response;

  /**
   * Export all competitor available for the country in XML format
   *
   * @param request
   * @return ProductModel in XML format
   */
  @Path("/XML/getWalterProduct")
  @POST
  @Consumes(MediaType.APPLICATION_XML)
  @Produces(MediaType.APPLICATION_XML)
  @TransactionAttribute(TransactionAttributeType.NEVER)
  public WalterProductAppModel getXMLWalterProductList(WalterProductRequestApi request) {
    System.out.println("getXMLWalterProductList");
    System.out.println("request.getCountryCode(): " + request.getCountryCode());
    System.out.println("request.getLangCode(): " + request.getLangCode());
    System.out.println("request.getLastUpdate(): " + request.getLastUpdate());
    WalterProductAppModel wpam = getWalterProductModel(request);

    return wpam;
  }

  /**
   * Export all competitor available for the country in XML format
   *
   * @param request
   * @return ProductModel in XML format
   */
  @Path("/JSON/getWalterProduct")
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @TransactionAttribute(TransactionAttributeType.NEVER)
  public WalterProductAppModel getJSONWalterProductList(WalterProductRequestApi request) {
    System.out.println("getJSONWalterProductList");
    System.out.println("request.getCountryCode(): " + request.getCountryCode());
    System.out.println("request.getLangCode(): " + request.getLangCode());
    System.out.println("request.getLastUpdate(): " + request.getLastUpdate());


    WalterProductAppModel wpam = getWalterProductModel(request);

    return wpam;
  }

   /**
   * Export all competitor available for the country in XML format
   *
   * @param request
   * @return ProductModel in XML format
   */
  @Path("/XML/getDeletedWalterProduct")
  @POST
  @Consumes(MediaType.APPLICATION_XML)
  @Produces(MediaType.APPLICATION_XML)
  @TransactionAttribute(TransactionAttributeType.NEVER)
  public WalterProductDeletedModel getXMLWalterProductDeleted(WalterProductRequestApi request) {
    System.out.println("getXMLWalterProductDeleted");
    System.out.println("request.getCountryCode(): " + request.getCountryCode());
    System.out.println("request.getLangCode(): " + request.getLangCode());
    System.out.println("request.getLastUpdate(): " + request.getLastUpdate());
    WalterProductDeletedModel wpm = getWalterProductDeletedModel(request);

    return wpm;
  }

  /**
   * Export all competitor available for the country in XML format
   *
   * @param request
   * @return ProductModel in XML format
   */
  @Path("/JSON/getDeletedWalterProduct")
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @TransactionAttribute(TransactionAttributeType.NEVER)
  public WalterProductDeletedModel getJSONWalterProductDeleted(WalterProductRequestApi request) {
    System.out.println("getJSONWalterProductDeleted");
    System.out.println("request.getCountryCode(): " + request.getCountryCode());
    System.out.println("request.getLangCode(): " + request.getLangCode());
    System.out.println("request.getLastUpdate(): " + request.getLastUpdate());
    WalterProductDeletedModel wpm = getWalterProductDeletedModel(request);

    return wpm;
  }

  /**
   * Export all competitor available for the country in XML format
   *
   * @param request
   * @return ProductModel in XML format
   */
  @Path("/XML/getCompetitor")
  @POST
  @Consumes(MediaType.APPLICATION_XML)
  @Produces(MediaType.APPLICATION_XML)
  @TransactionAttribute(TransactionAttributeType.NEVER)
  public CrossReferenceAppModel getXMLCompetitorList(CompetitorRequestApi request) {
    System.out.println("getXMLCompetitorList");
    System.out.println("request.getCountryCode(): " + request.getCountryCode());
    System.out.println("request.getLangCode(): " + request.getLangCode());
    System.out.println("request.getLastUpdate(): " + request.getLastUpdate());
    CrossReferenceAppModel cram = getCrossReferenceAppModel(request);

    return cram;
  }

  /**
   * Export all competitor available for the country in XML format
   *
   * @param request
   * @return ProductModel in XML format
   */
  @Path("/JSON/getCompetitor")
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @TransactionAttribute(TransactionAttributeType.NEVER)
  public CrossReferenceAppModel getJSONCompetitorList(CompetitorRequestApi request) {
    System.out.println("getJSONCompetitorList");
    System.out.println("request.getCountryCode(): " + request.getCountryCode());
    System.out.println("request.getLangCode(): " + request.getLangCode());
    System.out.println("request.getLastUpdate(): " + request.getLastUpdate());
    CrossReferenceAppModel cram = getCrossReferenceAppModel(request);

    return cram;
  }

    /**
   * Add counter for competitor product don't have walter equivalent
   *
   * @param request
   * @return true when call work
   */
  @Path("/JSON/addCounter")
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @TransactionAttribute(TransactionAttributeType.NEVER)
  public counterResponse addJsonCounter(CounterRequestAPI request) {
    System.out.println("addJsonCounter");
    System.out.println("request.getCountryCode(): " + request.getCountryCode());
    System.out.println("request.getBrandId(): " + request.getBrandId());
    System.out.println("request.getCompetitorId(): " + request.getCompetitorId());
    System.out.println("request.getCountryCode(): " + request.getCountryCode());
    System.out.println("request.getProductId(): " + request.getProductId());
    System.out.println("request.getUserName(): " + request.getUserName());
    counterResponse cr = new counterResponse();

    long competitorId =  Long.parseLong(request.getCompetitorId());
    long brandId = Long.parseLong(request.getBrandId());
    long productId = Long.parseLong(request.getProductId());

    boolean valid = crossReferenceAppBean.insertCounter(competitorId, brandId, productId, request.getCountryCode(), request.getUserName());

    cr.setValid(valid);

    return cr;
  }

    /**
   * Add counter for competitor product don't have walter equivalent
   *
   * @param request
   * @return true when call work
   */
  @Path("/XML/addCounter")
  @POST
  @Consumes(MediaType.APPLICATION_XML)
  @Produces(MediaType.APPLICATION_XML)
  @TransactionAttribute(TransactionAttributeType.NEVER)
  public counterResponse addXMLCounter(CounterRequestAPI request) {
    System.out.println("addXMLCounter");
    System.out.println("request.getCountryCode(): " + request.getCountryCode());
    System.out.println("request.getBrandId(): " + request.getBrandId());
    System.out.println("request.getCompetitorId(): " + request.getCompetitorId());
    System.out.println("request.getCountryCode(): " + request.getCountryCode());
    System.out.println("request.getProductId(): " + request.getProductId());
    System.out.println("request.getUserName(): " + request.getUserName());
    counterResponse cr = new counterResponse();

    long competitorId =  Long.parseLong(request.getCompetitorId());
    long brandId = Long.parseLong(request.getBrandId());
    long productId = Long.parseLong(request.getProductId());

    boolean valid = crossReferenceAppBean.insertCounter(competitorId, brandId, productId, request.getCountryCode(), request.getUserName());

    cr.setValid(valid);

    return cr;
  }

   /**
   * Check if user can login
   *
   * @param request
   * @return error found or user country code
   */
  @Path("/JSON/validUser")
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @TransactionAttribute(TransactionAttributeType.NEVER)
  public LoginModel getJSONLogin(LoginRequestAPI request) {
    System.out.println("getJSONLogin");
    System.out.println("request.getCountryCode(): " + request.getEmail());

    LoginModel lm = getLogin(request);

    return lm;
  }

  /**
   * Check if user can login
   *
   * @param request
   * @return error found or user country code
   */
  @Path("/XML/validUser")
  @POST
  @Consumes(MediaType.APPLICATION_XML)
  @Produces(MediaType.APPLICATION_XML)
  @TransactionAttribute(TransactionAttributeType.NEVER)
  public LoginModel getXMLLogin(LoginRequestAPI request) {
    System.out.println("getXMLLogin");
    System.out.println("request.getCountryCode(): " + request.getEmail());
    LoginModel lm = getLogin(request);

    return lm;
  }

  private LoginModel getLogin(LoginRequestAPI request) {
    LoginModel lm = new LoginModel();// = getCrossReferenceAppModel(request);
    try {

      Company company = CompanyLocalServiceUtil.getCompanyByWebId("liferay.com");

      User user = UserLocalServiceUtil.fetchUserByEmailAddress(company.getCompanyId(), request.getEmail());

      long userId = UserLocalServiceUtil.authenticateForBasic(company.getCompanyId(), CompanyConstants.AUTH_TYPE_EA, request.getEmail(), request.getPassword());

      if ( user != null && user.getUserId() == userId ) {

        String countryCode = walterBean.getWebSiteCountryName(user.getScreenName().toUpperCase());
        lm.setUserId(user.getUserId());
        lm.setPrintPdfLink("http://www.waltershare.com/ProductCompare/printPdf");

        lm.setCountryCode(countryCode);
      } else if ( user != null && user.getStatus() == 0){
        lm.setError("PasswordException");
      } else if (  user != null && user.getStatus() != 0 ) {
        lm.setError("UserDeletedException");
      } else {
        lm.setError("UserNameNotFoundException");
      }

    } catch (PortalException ex) {
      Logger.getLogger(APIRestApp.class.getName()).log(Level.SEVERE, null, ex);
      lm.setError(ex.getMessage());
    } catch (SystemException ex) {
      Logger.getLogger(APIRestApp.class.getName()).log(Level.SEVERE, null, ex);
      lm.setError(ex.getMessage());
    } catch (Exception ex) {
      Logger.getLogger(APIRestApp.class.getName()).log(Level.SEVERE, null, ex);
      lm.setError(ex.getMessage());
    }

     return lm;
  }


  private CrossReferenceAppModel getCrossReferenceAppModel(CompetitorRequestApi request) {
    CrossReferenceAppModel cram = new CrossReferenceAppModel();

    Date date = null;
    if (  request.getLastUpdate() != null) {
      Calendar cal = Calendar.getInstance();
      cal.setTimeInMillis(request.getLastUpdate());
      cal.add(Calendar.HOUR, -5);
      date = cal.getTime();
      System.out.println("date: " + date);
      System.out.println("cal.getTimeInMillis(): " + cal.getTimeInMillis());
    }

    cram.setCountryCode(request.getCountryCode());
    cram.setLangCode(request.getLangCode());

    String langCode = request.getLangCode();
    String countryCode= request.getCountryCode();

    cram.setCompetitors(crossReferenceAppBean.getCompetitorInformation(countryCode, langCode, date));

//    System.out.println("check data");
//    System.out.println(" competitor.size(): " + cram.getCompetitors().size());
//
//    int brand = 0;
//    int productNumber = 0;
//
//    for ( CompetitorModel cm : cram.getCompetitors() ){
//      brand = cm.getCompetitorBrands().size() + brand;
//      for (  CompetitorBrandModel cbm2 : cm.getCompetitorBrands() ) {
//        productNumber = cbm2.getCompetitorProducts().size() + productNumber;
//      }
//
//
//    }
//    System.out.println(" brand.size(): " + brand);
//    System.out.println(" productNumber.size(): " + productNumber);

    return cram;
  }

  private WalterProductAppModel getWalterProductModel(WalterProductRequestApi request){
    WalterProductAppModel wpam = new WalterProductAppModel();

    wpam.setCountryCode(request.getCountryCode());
    wpam.setLangCode(request.getLangCode());

    Date date = null;

    if (  request.getLastUpdate() != null) {
      Calendar cal = Calendar.getInstance();
      cal.setTimeInMillis(request.getLastUpdate());
      cal.add(Calendar.HOUR, -5);
      date = cal.getTime();
    }
    wpam.setWalterProducts(crossReferenceAppBean.getWalterProductList(request.getCountryCode(), request.getLangCode(), date));

    return wpam;
  }

  private WalterProductDeletedModel getWalterProductDeletedModel(WalterProductRequestApi request){
    WalterProductDeletedModel wpam = new WalterProductDeletedModel();

    wpam.setCountryCode(request.getCountryCode());
    wpam.setLangCode(request.getLangCode());

    Date date = null;

    if (  request.getLastUpdate() != null) {
      Calendar cal = Calendar.getInstance();
      cal.setTimeInMillis(request.getLastUpdate());
      cal.add(Calendar.HOUR, -5);
      date = cal.getTime();
    }
    wpam.setProductNumbers(crossReferenceAppBean.getWalterProductDeletedList(request.getCountryCode(), request.getLangCode(), date));

    return wpam;
  }

  @Path("/pdf/printPdf")
  @GET
//  @Produces("application/pdf")
  @TransactionAttribute(TransactionAttributeType.NEVER)
  public Response printPDf(@DefaultValue("0") @QueryParam("competitorProductId") String productString,
                           @DefaultValue("0") @QueryParam("userId") String userString,
                           @DefaultValue("") @QueryParam("walterProduct") String walterProductNumber,
                           @DefaultValue("") @QueryParam("langCode") String langCode)  {

    ResponseBuilder responseBuilder = Response.ok();
    try {

      Long userId = 0L;
      Long productId = 0L;

      try{
        userId = Long.parseLong(userString);
        productId = Long.parseLong(productString);


      } catch( NumberFormatException cfe ) {
        responseBuilder.status(Response.Status.fromStatusCode(404)).entity("Error found: PDF are not generated");
        responseBuilder.header("Content-Type", "text/html; charset=utf-8");
        LOG.warning(cfe.getMessage());
      }


      if ( userId == 0 ) {
        responseBuilder.status(Response.Status.fromStatusCode(404)).entity("Error found: PDF are not generated");
        responseBuilder.header("Content-Type", "text/html; charset=utf-8");
        LOG.warning("User are not found");
      } else {
        responseBuilder.header("Content-Type", "application/pdf");
        JasperCrossReferenceAppBean jasperCrossReferenceAppBean = new JasperCrossReferenceAppBean();
        CompetitorModel competitorModel = new CompetitorModel();
        WalterProductModel walterProductModel = new WalterProductModel();

        User user = UserLocalServiceUtil.fetchUserById(userId);
        String countryCode = walterBean.getWebSiteCountryName(user.getScreenName().toUpperCase());

        Locale locale = user.getLocale();
        if ( langCode != null && !langCode.equals(""))
          locale = new Locale(langCode, countryCode);

        long langId = walterBean.getDbLanguageId(locale.getLanguage());

        competitorModel = crossReferenceAppBean.getCompetitor(productId, locale.getLanguage(), countryCode, user.getScreenName().toUpperCase());
        walterProductModel =crossReferenceAppBean.getWalterProduct(countryCode, locale.getLanguage(), walterProductNumber);

        jasperCrossReferenceAppBean.setCountryCode(countryCode);
        jasperCrossReferenceAppBean.setCreatorEmail(user.getEmailAddress());
        jasperCrossReferenceAppBean.setCreatorImage(UserConstants.getPortraitURL("http://waltershare.com/image", user.isMale(), user.getPortraitId()));
        jasperCrossReferenceAppBean.setCreatorName(user.getFirstName() + " " + user.getLastName());

        jasperCrossReferenceAppBean.setWalterAction(walterProductModel.getAction());
        jasperCrossReferenceAppBean.setWalterDiluation(walterProductModel.getDiluation());

        jasperCrossReferenceAppBean.setWalterFormat(walterProductModel.getFormat());
        jasperCrossReferenceAppBean.setWalterImageUrl(walterProductModel.getImageUrl());
        jasperCrossReferenceAppBean.setWalterImperialSize(walterProductModel.getImperialSize());
        jasperCrossReferenceAppBean.setWalterImperialTemperature(walterProductModel.getImperialTemperature());
        jasperCrossReferenceAppBean.setWalterMetricSize(walterProductModel.getMetricSize());
        jasperCrossReferenceAppBean.setWalterMetricTemperature(walterProductModel.getMetricTemperature());
        jasperCrossReferenceAppBean.setWalterPH(walterProductModel.getPh());
        jasperCrossReferenceAppBean.setWalterProductNumber(walterProductModel.getProductNumber());
        jasperCrossReferenceAppBean.setWalterProp65(walterProductModel.getProp65());
        jasperCrossReferenceAppBean.setWalterTradename(walterProductModel.getTradename());
        jasperCrossReferenceAppBean.setWalterUpc(walterProductModel.getUpc());
        jasperCrossReferenceAppBean.setWalterVoc(walterProductModel.getVoc());

        jasperCrossReferenceAppBean.setWalterSdsDocumentName((walterProductModel.getMsdsDocument() != null) ? walterProductModel.getMsdsDocument().getDocumentName(): null);
        jasperCrossReferenceAppBean.setWalterSdsDocumentUrl((walterProductModel.getMsdsDocument() != null) ? walterProductModel.getMsdsDocument().getUrl() : null);
        jasperCrossReferenceAppBean.setWalterTdsDocumentName((walterProductModel.getTdsDocument() != null) ? walterProductModel.getTdsDocument().getDocumentName() : null);
        jasperCrossReferenceAppBean.setWalterTdsDocumentUrl((walterProductModel.getTdsDocument() != null) ? walterProductModel.getTdsDocument().getUrl() : null);

        jasperCrossReferenceAppBean.setWalterApplications(walterProductModel.getApplications());
        jasperCrossReferenceAppBean.setWalterCertifications(walterProductModel.getCertifications());
        jasperCrossReferenceAppBean.setWalterPhysicalHazards(walterProductModel.getPhysicalHazards());
        jasperCrossReferenceAppBean.setWalterEnvironmentalHazards(walterProductModel.getEnvironmentalHazards());
        jasperCrossReferenceAppBean.setWalterHealthHazards(walterProductModel.getHealthHazards());
        jasperCrossReferenceAppBean.setWalterMaterials(walterProductModel.getMaterials());

        List<String> walterElementList = new ArrayList<>();

        if ( walterProductModel.isElementFlame()  ) {
          walterElementList.add(JasperReportType.MOBILE_CROSS_REFERENCE_APP.getImagesPath("flame.png"));
        }

        if ( walterProductModel.isElementFlameCircle()  ) {
          walterElementList.add(JasperReportType.MOBILE_CROSS_REFERENCE_APP.getImagesPath("flame-over-circle.png"));
        }

        if ( walterProductModel.isElementExplodingBomb()  ) {
          walterElementList.add(JasperReportType.MOBILE_CROSS_REFERENCE_APP.getImagesPath("explosive.png"));
        }

        if ( walterProductModel.isElementGasCylinder()  ) {
          walterElementList.add(JasperReportType.MOBILE_CROSS_REFERENCE_APP.getImagesPath("gas-cylinder.png"));
        }

        if ( walterProductModel.isElementSkull()  ) {
          walterElementList.add(JasperReportType.MOBILE_CROSS_REFERENCE_APP.getImagesPath("skull.png"));
        }

        if ( walterProductModel.isElementHealth()  ) {
          walterElementList.add(JasperReportType.MOBILE_CROSS_REFERENCE_APP.getImagesPath("health.png"));
        }

        if ( walterProductModel.isElementCorrosion()  ) {
          walterElementList.add(JasperReportType.MOBILE_CROSS_REFERENCE_APP.getImagesPath("corrosion.png"));
        }

        if ( walterProductModel.isElementExclamation()  ) {
          walterElementList.add(JasperReportType.MOBILE_CROSS_REFERENCE_APP.getImagesPath("exclamation.png"));
        }

        if ( walterProductModel.isElementEnvironment()  ) {
          walterElementList.add(JasperReportType.MOBILE_CROSS_REFERENCE_APP.getImagesPath("environment.png"));
        }

        jasperCrossReferenceAppBean.setWalterElements(walterElementList);

        if ( competitorModel != null &&  competitorModel.getCompetitorBrand() != null ) {
          jasperCrossReferenceAppBean.setDateVerified(competitorModel.getCompetitorBrand().getCompetitorProduct().getDateVerified());
          jasperCrossReferenceAppBean.setCompetitorName(competitorModel.getCompetitorName());
          jasperCrossReferenceAppBean.setCompetitorProductName(competitorModel.getCompetitorBrand().getBrandName());
          jasperCrossReferenceAppBean.setCompetitorApplications(competitorModel.getCompetitorBrand().getCompetitorProduct().getApplications());
          jasperCrossReferenceAppBean.setCompetitorCertifications(competitorModel.getCompetitorBrand().getCompetitorProduct().getCertifications());
          jasperCrossReferenceAppBean.setCompetitorDiluation(competitorModel.getCompetitorBrand().getCompetitorProduct().getDiluation());
          jasperCrossReferenceAppBean.setCompetitorEnvironmentalHazards(competitorModel.getCompetitorBrand().getCompetitorProduct().getEnvironmentalHazards());
          jasperCrossReferenceAppBean.setCompetitorFormat(competitorModel.getCompetitorBrand().getCompetitorProduct().getFormat());
          jasperCrossReferenceAppBean.setCompetitorHealthHazards(competitorModel.getCompetitorBrand().getCompetitorProduct().getHealthHazards());
          jasperCrossReferenceAppBean.setCompetitorImperialSize(competitorModel.getCompetitorBrand().getCompetitorProduct().getImperialSize());
          jasperCrossReferenceAppBean.setCompetitorImperialTemperature(competitorModel.getCompetitorBrand().getCompetitorProduct().getImperialTemperature());
          jasperCrossReferenceAppBean.setCompetitorMaterials(competitorModel.getCompetitorBrand().getCompetitorProduct().getMaterials());
          jasperCrossReferenceAppBean.setCompetitorMetricSize(competitorModel.getCompetitorBrand().getCompetitorProduct().getMetricSize());
          jasperCrossReferenceAppBean.setCompetitorMetricTemperature(competitorModel.getCompetitorBrand().getCompetitorProduct().getMetricTemperature());
          jasperCrossReferenceAppBean.setCompetitorPh(competitorModel.getCompetitorBrand().getCompetitorProduct().getPh());
          jasperCrossReferenceAppBean.setCompetitorPhysicalHazards(competitorModel.getCompetitorBrand().getCompetitorProduct().getPhysicalHazards());
          jasperCrossReferenceAppBean.setCompetitorProductImage(competitorModel.getCompetitorBrand().getCompetitorProduct().getProductImage());
          jasperCrossReferenceAppBean.setCompetitorProductNumber(competitorModel.getCompetitorBrand().getCompetitorProduct().getProductNumber());
          jasperCrossReferenceAppBean.setCompetitorProp65(competitorModel.getCompetitorBrand().getCompetitorProduct().getProp65());
          if ( competitorModel.getCompetitorBrand().getCompetitorProduct().getSdsDocument() != null ){
            jasperCrossReferenceAppBean.setCompetitorSdsDocumentName(competitorModel.getCompetitorBrand().getCompetitorProduct().getSdsDocument().getDocumentName());
            jasperCrossReferenceAppBean.setCompetitorSdsDocumentUrl(competitorModel.getCompetitorBrand().getCompetitorProduct().getSdsDocument().getUrl());
          }
          if ( competitorModel.getCompetitorBrand().getCompetitorProduct().getTdsDocument() != null ) {
            jasperCrossReferenceAppBean.setCompetitorTdsDocumentName(competitorModel.getCompetitorBrand().getCompetitorProduct().getTdsDocument().getDocumentName());
            jasperCrossReferenceAppBean.setCompetitorTdsDocumentUrl(competitorModel.getCompetitorBrand().getCompetitorProduct().getTdsDocument().getUrl());
          }
          jasperCrossReferenceAppBean.setCompetitorUpc(competitorModel.getCompetitorBrand().getCompetitorProduct().getUpc());
          jasperCrossReferenceAppBean.setCompetitorVoc(competitorModel.getCompetitorBrand().getCompetitorProduct().getVoc());

          List<String> competitorElementList = new ArrayList<>();

          if ( competitorModel.getCompetitorBrand().getCompetitorProduct().isElementFlame()  ) {

            competitorElementList.add(JasperReportType.MOBILE_CROSS_REFERENCE_APP.getImagesPath("flame.png"));
          }

          if ( competitorModel.getCompetitorBrand().getCompetitorProduct().isElementFlameCircle()  ) {
            competitorElementList.add(JasperReportType.MOBILE_CROSS_REFERENCE_APP.getImagesPath("flame-over-circle.png"));
          }

          if ( competitorModel.getCompetitorBrand().getCompetitorProduct().isElementExplodingBomb()  ) {
            competitorElementList.add(JasperReportType.MOBILE_CROSS_REFERENCE_APP.getImagesPath("explosive.png"));
          }

          if ( competitorModel.getCompetitorBrand().getCompetitorProduct().isElementGasCylinder()  ) {
            competitorElementList.add(JasperReportType.MOBILE_CROSS_REFERENCE_APP.getImagesPath("gas-cylinder.png"));
          }

          if ( competitorModel.getCompetitorBrand().getCompetitorProduct().isElementSkull()  ) {
            competitorElementList.add(JasperReportType.MOBILE_CROSS_REFERENCE_APP.getImagesPath("skull.png"));
          }

          if ( competitorModel.getCompetitorBrand().getCompetitorProduct().isElementHealth()  ) {
            competitorElementList.add(JasperReportType.MOBILE_CROSS_REFERENCE_APP.getImagesPath("health.png"));
          }

          if ( competitorModel.getCompetitorBrand().getCompetitorProduct().isElementCorrosion()  ) {
            competitorElementList.add(JasperReportType.MOBILE_CROSS_REFERENCE_APP.getImagesPath("corrosion.png"));
          }

          if ( competitorModel.getCompetitorBrand().getCompetitorProduct().isElementExclamation()  ) {
            competitorElementList.add(JasperReportType.MOBILE_CROSS_REFERENCE_APP.getImagesPath("exclamation.png"));
          }

          if ( competitorModel.getCompetitorBrand().getCompetitorProduct().isElementEnvironment()  ) {
            competitorElementList.add(JasperReportType.MOBILE_CROSS_REFERENCE_APP.getImagesPath("environment.png"));
          }

          jasperCrossReferenceAppBean.setCompetitorElements(competitorElementList);
        }
        else {
          jasperCrossReferenceAppBean.setCompetitorName("Product not found");
        }
        byte[] bytes = jasperBean.printMobileCrossReferenceAppReport(jasperCrossReferenceAppBean, locale);
        responseBuilder = Response.ok(bytes, "application/pdf");
      }
    } catch ( JasperException je ) {
//      je.printStackTrace();
      LOG.warning(je.getMessage());
      responseBuilder.status(Response.Status.fromStatusCode(404)).entity("Error found: PDF are not generated");
      responseBuilder.header("Content-Type", "text/html; charset=utf-8");

    } catch (SystemException ex) {
//      ex.printStackTrace();
      LOG.warning(ex.getMessage());
      responseBuilder.status(Response.Status.fromStatusCode(404)).entity("Error found: PDF are not generated");
      responseBuilder.header("Content-Type", "text/html; charset=utf-8");

    } catch (Exception ex) {
      LOG.warning(ex.getMessage());
//      ex.printStackTrace();
      responseBuilder.status(Response.Status.fromStatusCode(404)).entity("Error found: PDF are not generated");
      responseBuilder.header("Content-Type", "text/html; charset=utf-8");
    }
    return responseBuilder.build();
  }

}
