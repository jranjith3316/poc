/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.idb;

import com.savoirfairelinux.walter.dao.DatabaseConstants;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "WALTER_PRODUCTS_COUNTRIES", catalog = "", schema = DatabaseConstants.IDB_SCHEMA)
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "WalterProductsCountries.findAll", query = "SELECT w FROM WalterProductsCountries w"),
  @NamedQuery(name = "WalterProductsCountries.findByListprice", query = "SELECT w FROM WalterProductsCountries w WHERE w.listprice = :listprice"),
  @NamedQuery(name = "WalterProductsCountries.findByStock", query = "SELECT w FROM WalterProductsCountries w WHERE w.stock = :stock"),
  @NamedQuery(name = "WalterProductsCountries.findByDescription", query = "SELECT w FROM WalterProductsCountries w WHERE w.description = :description"),
  @NamedQuery(name = "WalterProductsCountries.findByLongdescription", query = "SELECT w FROM WalterProductsCountries w WHERE w.longdescription = :longdescription"),
  @NamedQuery(name = "WalterProductsCountries.findByStandardpackage", query = "SELECT w FROM WalterProductsCountries w WHERE w.standardpackage = :standardpackage"),
  @NamedQuery(name = "WalterProductsCountries.findByStandardcarton", query = "SELECT w FROM WalterProductsCountries w WHERE w.standardcarton = :standardcarton"),
  @NamedQuery(name = "WalterProductsCountries.findByProductcountryguid", query = "SELECT w FROM WalterProductsCountries w WHERE w.productcountryguid = :productcountryguid"),
  @NamedQuery(name = "WalterProductsCountries.findByTopublish", query = "SELECT w FROM WalterProductsCountries w WHERE w.topublish = :topublish"),
  @NamedQuery(name = "WalterProductsCountries.findByTemplate", query = "SELECT w FROM WalterProductsCountries w WHERE w.template = :template"),
  @NamedQuery(name = "WalterProductsCountries.findByTradename", query = "SELECT w FROM WalterProductsCountries w WHERE w.tradename = :tradename"),
  @NamedQuery(name = "WalterProductsCountries.findByTradeaction", query = "SELECT w FROM WalterProductsCountries w WHERE w.tradeaction = :tradeaction"),
  @NamedQuery(name = "WalterProductsCountries.findByWalterecom", query = "SELECT w FROM WalterProductsCountries w WHERE w.walterecom = :walterecom"),
  @NamedQuery(name = "WalterProductsCountries.findByShippingair", query = "SELECT w FROM WalterProductsCountries w WHERE w.shippingair = :shippingair"),
  @NamedQuery(name = "WalterProductsCountries.findByShippingland", query = "SELECT w FROM WalterProductsCountries w WHERE w.shippingland = :shippingland"),
  @NamedQuery(name = "WalterProductsCountries.findByAdddatetime", query = "SELECT w FROM WalterProductsCountries w WHERE w.adddatetime = :adddatetime"),
  @NamedQuery(name = "WalterProductsCountries.findByDeletedatetime", query = "SELECT w FROM WalterProductsCountries w WHERE w.deletedatetime = :deletedatetime"),
  @NamedQuery(name = "WalterProductsCountries.findByUpdatedatetime", query = "SELECT w FROM WalterProductsCountries w WHERE w.updatedatetime = :updatedatetime"),
  @NamedQuery(name = "WalterProductsCountries.findBySearchenginevisible", query = "SELECT w FROM WalterProductsCountries w WHERE w.searchenginevisible = :searchenginevisible")})
public class WalterProductsCountries implements Serializable {
  private static final long serialVersionUID = 1L;
  // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
  @Column(name = "LISTPRICE")
  private BigDecimal listprice;
  @Column(name = "STOCK")
  private Long stock;
  @Size(max = 255)
  @Column(name = "DESCRIPTION")
  private String description;
  @Size(max = 1000)
  @Column(name = "LONGDESCRIPTION")
  private String longdescription;
  @Column(name = "STANDARDPACKAGE")
  private Long standardpackage;
  @Size(max = 255)
  @Column(name = "STANDARDCARTON")
  private String standardcarton;
  @Id
  @Basic(optional = false)
  @NotNull
  @Size(min = 1, max = 255)
  @Column(name = "PRODUCTCOUNTRYGUID")
  private String productcountryguid;
  @Size(max = 255)
  @Column(name = "TOPUBLISH")
  private String topublish;
  @Size(max = 255)
  @Column(name = "TEMPLATE")
  private String template;
  @Size(max = 255)
  @Column(name = "TRADENAME")
  private String tradename;
  @Size(max = 255)
  @Column(name = "TRADEACTION")
  private String tradeaction;
  @Column(name = "WALTERECOM")
  private Character walterecom;
  @Column(name = "SHIPPINGAIR")
  private Character shippingair;
  @Column(name = "SHIPPINGLAND")
  private Character shippingland;
  @Column(name = "ADDDATETIME")
  @Temporal(TemporalType.TIMESTAMP)
  private Date adddatetime;
  @Column(name = "DELETEDATETIME")
  @Temporal(TemporalType.TIMESTAMP)
  private Date deletedatetime;
  @Column(name = "UPDATEDATETIME")
  @Temporal(TemporalType.TIMESTAMP)
  private Date updatedatetime;
  @Column(name = "SEARCHENGINEVISIBLE")
  private Character searchenginevisible;
//  @OneToMany(cascade = CascadeType.ALL, mappedBy = "productcountryguid")
//  private Set<WalterProductsDocuments> walterProductsDocumentsSet;
//  @OneToMany(cascade = CascadeType.ALL, mappedBy = "productcountryguid")
//  private Set<WalterProductsImages> walterProductsImagesSet;
//  @OneToMany(cascade = CascadeType.ALL, mappedBy = "productcountryguid")
//  private Set<WalterTvvideos> walterTvvideosSet;
  @JoinColumn(name = "TRADENAMEGUID", referencedColumnName = "TRADENAMEGUID")
  @ManyToOne
  private WalterTradenames tradenameguid;
  @JoinColumn(name = "PRODUCTVERSIONGUID", referencedColumnName = "PRODUCTVERSIONGUID")
  @ManyToOne(optional = false)
  private WalterProductsVersions productversionguid;
  @JoinColumn(name = "PRODUCTPRESENTATIONGUID", referencedColumnName = "PRODUCTPRESENTATIONGUID")
  @ManyToOne(optional = false)
  private WalterProductsPresentations productpresentationguid;
  @JoinColumn(name = "PRODUCTGUID", referencedColumnName = "PRODUCTGUID")
  @ManyToOne(optional = false)
  private WalterProducts productguid;
  @JoinColumn(name = "PRESENTATIONGUID", referencedColumnName = "INSTANCEGUID")
  @ManyToOne
  private OoInstances presentationguid;
  @JoinColumn(name = "COUNTRYGUID", referencedColumnName = "INSTANCEGUID")
  @ManyToOne(optional = false)
  private OoInstances countryguid;
  @JoinColumn(name = "DESCRIPTIONGUID", referencedColumnName = "INSTANCEGUID")
  @ManyToOne
  private OoInstances descriptionguid;
  @JoinColumn(name = "LONGDESCRIPTIONGUID", referencedColumnName = "INSTANCEGUID")
  @ManyToOne
  private OoInstances longdescriptionguid;
  @JoinColumn(name = "DISTRIBUTORDESCRIPTIONGUID", referencedColumnName = "INSTANCEGUID")
  @ManyToOne
  private OoInstances distributordescriptionguid;
  @JoinColumn(name = "DISTRIBUTORLONGDESCRIPTIONGUID", referencedColumnName = "INSTANCEGUID")
  @ManyToOne
  private OoInstances distributorlongdescriptionguid;

  public WalterProductsCountries() {
  }

  public WalterProductsCountries(String productcountryguid) {
    this.productcountryguid = productcountryguid;
  }

  public BigDecimal getListprice() {
    return listprice;
  }

  public void setListprice(BigDecimal listprice) {
    this.listprice = listprice;
  }

  public Long getStock() {
    return stock;
  }

  public void setStock(Long stock) {
    this.stock = stock;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getLongdescription() {
    return longdescription;
  }

  public void setLongdescription(String longdescription) {
    this.longdescription = longdescription;
  }

  public Long getStandardpackage() {
    return standardpackage;
  }

  public void setStandardpackage(Long standardpackage) {
    this.standardpackage = standardpackage;
  }

  public String getStandardcarton() {
    return standardcarton;
  }

  public void setStandardcarton(String standardcarton) {
    this.standardcarton = standardcarton;
  }

  public String getProductcountryguid() {
    return productcountryguid;
  }

  public void setProductcountryguid(String productcountryguid) {
    this.productcountryguid = productcountryguid;
  }

  public String getTopublish() {
    return topublish;
  }

  public void setTopublish(String topublish) {
    this.topublish = topublish;
  }

  public String getTemplate() {
    return template;
  }

  public void setTemplate(String template) {
    this.template = template;
  }

  public String getTradename() {
    return tradename;
  }

  public void setTradename(String tradename) {
    this.tradename = tradename;
  }

  public String getTradeaction() {
    return tradeaction;
  }

  public void setTradeaction(String tradeaction) {
    this.tradeaction = tradeaction;
  }

  public Character getWalterecom() {
    return walterecom;
  }

  public void setWalterecom(Character walterecom) {
    this.walterecom = walterecom;
  }

  public Character getShippingair() {
    return shippingair;
  }

  public void setShippingair(Character shippingair) {
    this.shippingair = shippingair;
  }

  public Character getShippingland() {
    return shippingland;
  }

  public void setShippingland(Character shippingland) {
    this.shippingland = shippingland;
  }

  public Date getAdddatetime() {
    return adddatetime;
  }

  public void setAdddatetime(Date adddatetime) {
    this.adddatetime = adddatetime;
  }

  public Date getDeletedatetime() {
    return deletedatetime;
  }

  public void setDeletedatetime(Date deletedatetime) {
    this.deletedatetime = deletedatetime;
  }

  public Date getUpdatedatetime() {
    return updatedatetime;
  }

  public void setUpdatedatetime(Date updatedatetime) {
    this.updatedatetime = updatedatetime;
  }

  public Character getSearchenginevisible() {
    return searchenginevisible;
  }

  public void setSearchenginevisible(Character searchenginevisible) {
    this.searchenginevisible = searchenginevisible;
  }

//  @XmlTransient
//  public Set<WalterProductsDocuments> getWalterProductsDocumentsSet() {
//    return walterProductsDocumentsSet;
//  }
//
//  public void setWalterProductsDocumentsSet(Set<WalterProductsDocuments> walterProductsDocumentsSet) {
//    this.walterProductsDocumentsSet = walterProductsDocumentsSet;
//  }
//
//  @XmlTransient
//  public Set<WalterProductsImages> getWalterProductsImagesSet() {
//    return walterProductsImagesSet;
//  }
//
//  public void setWalterProductsImagesSet(Set<WalterProductsImages> walterProductsImagesSet) {
//    this.walterProductsImagesSet = walterProductsImagesSet;
//  }
//
//  @XmlTransient
//  public Set<WalterTvvideos> getWalterTvvideosSet() {
//    return walterTvvideosSet;
//  }
//
//  public void setWalterTvvideosSet(Set<WalterTvvideos> walterTvvideosSet) {
//    this.walterTvvideosSet = walterTvvideosSet;
//  }

  public WalterTradenames getTradenameguid() {
    return tradenameguid;
  }

  public void setTradenameguid(WalterTradenames tradenameguid) {
    this.tradenameguid = tradenameguid;
  }

  public WalterProductsVersions getProductversionguid() {
    return productversionguid;
  }

  public void setProductversionguid(WalterProductsVersions productversionguid) {
    this.productversionguid = productversionguid;
  }

  public WalterProductsPresentations getProductpresentationguid() {
    return productpresentationguid;
  }

  public void setProductpresentationguid(WalterProductsPresentations productpresentationguid) {
    this.productpresentationguid = productpresentationguid;
  }

  public WalterProducts getProductguid() {
    return productguid;
  }

  public void setProductguid(WalterProducts productguid) {
    this.productguid = productguid;
  }

  public OoInstances getPresentationguid() {
    return presentationguid;
  }

  public void setPresentationguid(OoInstances presentationguid) {
    this.presentationguid = presentationguid;
  }

  public OoInstances getCountryguid() {
    return countryguid;
  }

  public void setCountryguid(OoInstances countryguid) {
    this.countryguid = countryguid;
  }

  public OoInstances getDescriptionguid() {
    return descriptionguid;
  }

  public void setDescriptionguid(OoInstances descriptionguid) {
    this.descriptionguid = descriptionguid;
  }

  public OoInstances getLongdescriptionguid() {
    return longdescriptionguid;
  }

  public void setLongdescriptionguid(OoInstances longdescriptionguid) {
    this.longdescriptionguid = longdescriptionguid;
  }

  public OoInstances getDistributordescriptionguid() {
    return distributordescriptionguid;
  }

  public void setDistributordescriptionguid(OoInstances distributordescriptionguid) {
    this.distributordescriptionguid = distributordescriptionguid;
  }

  public OoInstances getDistributorlongdescriptionguid() {
    return distributorlongdescriptionguid;
  }

  public void setDistributorlongdescriptionguid(OoInstances distributorlongdescriptionguid) {
    this.distributorlongdescriptionguid = distributorlongdescriptionguid;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (productcountryguid != null ? productcountryguid.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof WalterProductsCountries)) {
      return false;
    }
    WalterProductsCountries other = (WalterProductsCountries) object;
    if ((this.productcountryguid == null && other.productcountryguid != null) || (this.productcountryguid != null && !this.productcountryguid.equals(other.productcountryguid))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.idb.WalterProductsCountries[ productcountryguid=" + productcountryguid + " ]";
  }

}
