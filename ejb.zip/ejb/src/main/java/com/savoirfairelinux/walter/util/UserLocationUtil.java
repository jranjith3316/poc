/* 
 * Copyright 2013 Savoir-faire Linux
 * 
 * This file is part of Walter-Portal.
 * 
 * Walter-Portal is free software: you can redistribute it and/or modify it under the terms of the 
 * GNU General Public License as published by the Free Software Foundation, either version 3 
 * of the License, or (at your option) any later version.
 * 
 * Walter-Portal is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with Walter-Portal. 
 * If not, see http://www.gnu.org/licenses/.
 */
package com.savoirfairelinux.walter.util;

import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.model.Address;
import com.liferay.portal.model.User;

import java.util.logging.Logger;

/**
 * 
 * @author jbonjean
 * 
 */
public class UserLocationUtil {

	private static final Logger LOGGER = Logger.getLogger(UserLocationUtil.class.getCanonicalName());

	public static String getLocation(User user) {
        StringBuilder location = new StringBuilder();
        if (user != null) {
            try {
                if (!user.getAddresses().isEmpty()) {
                    // we use the first one, should we do otherwise?
                    Address address = user.getAddresses().get(0);
                    if (!address.getCity().equals("NO CITY DEFINED")) {
                        location.append(address.getCity());
                        location.append(", ");
                    }
                    location.append(address.getCountry().getName());
                }
            } catch (SystemException e) {
                LOGGER.warning(e.getMessage());
            }
        }
        return location.toString();
	}

	public static String getState(User user) {
        StringBuilder location = new StringBuilder();
        if (user != null) {
            try {
                if (!user.getAddresses().isEmpty()) {
                    // we use the first one, should we do otherwise?
                    Address address = user.getAddresses().get(0);

                    location.append(address.getRegion().getName());
                }
            } catch (SystemException e) {
                LOGGER.warning(e.getMessage());
            }
        }
        return location.toString();
	}

}
