/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.globalcustomer;

import com.savoirfairelinux.walter.dao.DatabaseConstants;
import com.savoirfairelinux.walter.dao.waltercb.Country;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import javax.persistence.*;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 *
 * @author jderuere
 */
@Entity
@Table(name = "GA_FACILITY", schema = DatabaseConstants.WALTERCB_SCHEMA)
@NamedQueries({
        @NamedQuery(name = "GaFacility.findById", query = "SELECT gf FROM GaFacility gf WHERE gf.facilityId = :facilityId")})
public class GaFacility implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(generator = "GA_FACILITY_ID_SEQ", strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "GA_FACILITY_ID_SEQ", sequenceName = "GA_FACILITY_ID_SEQ", schema = DatabaseConstants.WALTERCB_SCHEMA, allocationSize = 1)
    @Column(name = "FACILITY_ID")
    private Long facilityId;
    @Column(name = "KEY_CONTACT", nullable = false)
    private String keyContact;
    @Column(name = "NAME", nullable = false)
    private String name;
    @OneToOne(cascade = CascadeType.ALL, orphanRemoval = true, mappedBy = "facility")
    private GaCategory category;
    @Column(name = "ADDRESS", nullable = false)
    private String address;
    @Size(max = 40)
    @Column(name = "CITY", nullable = false)
    private String city;
    @Size(max = 10)
    @Column(name = "POSTAL_CODE")
    private String postalCode;
    @Column(name = "STATE")
    private String state;
    @ManyToOne
    @JoinColumn(name = "COUNTRY_ID", nullable = false)
    private Country country;
    @Column(name = "PHONE_NUMBER")
    private String phoneNumber;
    @Column(name = "MAIN_CONTACT")
    private String mainContact;
    @Column(name = "DEPARTMENT")
    private String department;
    @Column(name = "EMAIL")
    private String email;
    @Column(name = "SALE_REPRESENTATIVE")
    private String saleRepresentative;
    @Column(name = "CREATE_DATE", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date createDate;
    @ManyToOne(optional = false)
    @JoinColumn(name = "GLOBAL_ACCOUNT_ID", referencedColumnName = "GLOBAL_ACCOUNT_ID", nullable = false)
    private GlobalAccount globalAccount;
    @Fetch(FetchMode.SUBSELECT)
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "facility", orphanRemoval = true, fetch = FetchType.EAGER)
    private List<GaProduct> products;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "facility", orphanRemoval = true)
    private List<GaFeedback> feedbacks;

    public GaFacility() {
    }

    public Long getFacilityId() {
        return facilityId;
    }

    public void setFacilityId(Long facilityId) {
        this.facilityId = facilityId;
    }

    public String getKeyContact() {
        return keyContact;
    }

    public void setKeyContact(String keyContact) {
        this.keyContact = keyContact;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public GaCategory getCategory() {
        return category;
    }

    public void setCategory(GaCategory category) {
        this.category = category;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public Country getCountry() {
        return country;
    }

    public void setCountry(Country country) {
        this.country = country;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getMainContact() {
        return mainContact;
    }

    public void setMainContact(String mainContact) {
        this.mainContact = mainContact;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSaleRepresentative() {
        return saleRepresentative;
    }

    public void setSaleRepresentative(String saleRepresentative) {
        this.saleRepresentative = saleRepresentative;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public GlobalAccount getGlobalAccount() {
        return globalAccount;
    }

    public void setGlobalAccount(GlobalAccount globalAccount) {
        this.globalAccount = globalAccount;
    }

    public List<GaProduct> getProducts() {
        return products;
    }

    public void setProducts(List<GaProduct> products) {
        this.products = products;
    }

    public List<GaFeedback> getFeedbacks() {
        return feedbacks;
    }

    public void setFeedbacks(List<GaFeedback> feedbacks) {
        this.feedbacks = feedbacks;
    }

    @Override
    public int hashCode() {
        int hash = (getFacilityId() != null ? getFacilityId().hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof GaFacility)) {
            return false;
        }
        GaFacility other = (GaFacility) object;
        if ((this.getFacilityId() == null && other.getFacilityId() != null) || (this.getFacilityId() != null && !this.getFacilityId().equals(other.getFacilityId()))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.globalcustomer.GaFacility[ facilityId=" + getFacilityId() + " ]";
    }
}
