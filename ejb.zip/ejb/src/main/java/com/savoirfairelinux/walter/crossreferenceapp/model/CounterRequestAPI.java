/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.crossreferenceapp.model;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@XmlRootElement(name = "counterRequest")
public class CounterRequestAPI implements Serializable{
  private static final long serialVersionUID = 3511338233023397895L;
  private String competitorId;
  private String brandId;
  private String productId;
  private String countryCode;
  private String userName;

  public String getCompetitorId() {
    return competitorId;
  }

  @XmlElement(name = "competitorId")
  public void setCompetitorId(String competitorId) {
    this.competitorId = competitorId;
  }

  public String getBrandId() {
    return brandId;
  }

  @XmlElement(name = "brandId")
  public void setBrandId(String brandId) {
    this.brandId = brandId;
  }

  public String getProductId() {
    return productId;
  }

  @XmlElement(name = "productId")
  public void setProductId(String productId) {
    this.productId = productId;
  }

  public String getCountryCode() {
    return countryCode;
  }

  @XmlElement(name = "countryCode")
  public void setCountryCode(String countryCode) {
    this.countryCode = countryCode;
  }

  public String getUserName() {
    return userName;
  }

  @XmlElement(name = "userName")
  public void setUserName(String userName) {
    this.userName = userName;
  }

}
