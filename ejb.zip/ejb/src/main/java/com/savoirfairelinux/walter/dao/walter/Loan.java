/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.walter;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Set;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "LOAN", catalog = "", schema = DatabaseConstants.WALTER_SCHEMA)
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "Loan.findAll", query = "SELECT l FROM Loan l"),
  @NamedQuery(name = "Loan.findByLoanId", query = "SELECT l FROM Loan l WHERE l.loanId = :loanId"),
  @NamedQuery(name = "Loan.findByUserName", query = "SELECT l FROM Loan l WHERE l.userName = :userName"),
  @NamedQuery(name = "Loan.findByCreationDate", query = "SELECT l FROM Loan l WHERE l.creationDate = :creationDate"),
  @NamedQuery(name = "Loan.findByCreatedByUserName", query = "SELECT l FROM Loan l WHERE l.createdByUserName = :createdByUserName"),
  @NamedQuery(name = "Loan.findByAmountPaid", query = "SELECT l FROM Loan l WHERE l.amountPaid = :amountPaid"),
  @NamedQuery(name = "Loan.findByAmountOpen", query = "SELECT l FROM Loan l WHERE l.amountOpen = :amountOpen"),
  @NamedQuery(name = "Loan.findByCancelDate", query = "SELECT l FROM Loan l WHERE l.cancelDate = :cancelDate"),
  @NamedQuery(name = "Loan.findByCancelByUserName", query = "SELECT l FROM Loan l WHERE l.cancelByUserName = :cancelByUserName")})
public class Loan implements Serializable {
  private static final long serialVersionUID = 1L;
  @Id
  @Basic(optional = false)
  @NotNull
  @Column(name = "LOAN_ID")
  @GeneratedValue(generator = "LOAN_ID_SEQ", strategy = GenerationType.SEQUENCE)
  @SequenceGenerator(name = "LOAN_ID_SEQ", sequenceName = "LOAN_ID_SEQ", schema = DatabaseConstants.WALTER_SCHEMA, allocationSize = 1)
  private Long loanId;
  @Size(max = 256)
  @Column(name = "USER_NAME")
  private String userName;
  @Column(name = "CREATION_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date creationDate;
  @Size(max = 256)
  @Column(name = "CREATED_BY_USER_NAME")
  private String createdByUserName;
  // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
  @Column(name = "AMOUNT_PAID")
  private BigDecimal amountPaid;
  @Column(name = "AMOUNT_OPEN")
  private BigDecimal amountOpen;
  @Column(name = "CANCEL_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date cancelDate;
  @Size(max = 256)
  @Column(name = "CANCEL_BY_USER_NAME")
  private String cancelByUserName;
  @OneToMany(cascade = CascadeType.ALL, mappedBy = "loan")
  private Set<LoanD> loanDSet;

  public Loan() {
  }

  public Loan(Long loanId) {
    this.loanId = loanId;
  }

  public Long getLoanId() {
    return loanId;
  }

  public void setLoanId(Long loanId) {
    this.loanId = loanId;
  }

  public String getUserName() {
    return userName;
  }

  public void setUserName(String userName) {
    this.userName = userName;
  }

  public Date getCreationDate() {
    return creationDate;
  }

  public void setCreationDate(Date creationDate) {
    this.creationDate = creationDate;
  }

  public String getCreatedByUserName() {
    return createdByUserName;
  }

  public void setCreatedByUserName(String createdByUserName) {
    this.createdByUserName = createdByUserName;
  }

  public BigDecimal getAmountPaid() {
    return amountPaid;
  }

  public void setAmountPaid(BigDecimal amountPaid) {
    this.amountPaid = amountPaid;
  }

  public BigDecimal getAmountOpen() {
    return amountOpen;
  }

  public void setAmountOpen(BigDecimal amountOpen) {
    this.amountOpen = amountOpen;
  }

  public Date getCancelDate() {
    return cancelDate;
  }

  public void setCancelDate(Date cancelDate) {
    this.cancelDate = cancelDate;
  }

  public String getCancelByUserName() {
    return cancelByUserName;
  }

  public void setCancelByUserName(String cancelByUserName) {
    this.cancelByUserName = cancelByUserName;
  }

  @XmlTransient
  public Set<LoanD> getLoanDSet() {
    return loanDSet;
  }

  public void setLoanDSet(Set<LoanD> loanDSet) {
    this.loanDSet = loanDSet;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (loanId != null ? loanId.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof Loan)) {
      return false;
    }
    Loan other = (Loan) object;
    if ((this.loanId == null && other.loanId != null) || (this.loanId != null && !this.loanId.equals(other.loanId))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.walter.Loan[ loanId=" + loanId + " ]";
  }
  
}
