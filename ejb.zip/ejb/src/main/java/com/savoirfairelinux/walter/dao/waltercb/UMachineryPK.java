/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

/**
 *
 * @author mgubaidullin
 */
@Embeddable
public class UMachineryPK implements Serializable {
    @Basic(optional = false)
    @NotNull
    @Column(name = "MACHINERY_ID")
    private long machineryId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "LANG_ID")
    private long langId;

    public UMachineryPK() {
    }

    public UMachineryPK(long machineryId, long langId) {
        this.machineryId = machineryId;
        this.langId = langId;
    }

    public long getMachineryId() {
        return machineryId;
    }

    public void setMachineryId(long machineryId) {
        this.machineryId = machineryId;
    }

    public long getLangId() {
        return langId;
    }

    public void setLangId(long langId) {
        this.langId = langId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) machineryId;
        hash += (int) langId;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof UMachineryPK)) {
            return false;
        }
        UMachineryPK other = (UMachineryPK) object;
        if (this.machineryId != other.machineryId) {
            return false;
        }
        if (this.langId != other.langId) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.UMachineryPK[ machineryId=" + machineryId + ", langId=" + langId + " ]";
    }
    
}
