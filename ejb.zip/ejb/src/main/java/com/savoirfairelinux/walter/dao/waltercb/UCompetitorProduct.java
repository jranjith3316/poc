/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.model.PrApplication;

import javax.persistence.*;
import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import java.util.Date;
import java.util.Set;

/**
 *
 * @author jderuere
 */
@Entity
@Table(name = "U_COMPETITOR_PRODUCT", schema = DatabaseConstants.WALTERCB_SCHEMA)
@NamedQuery(name = "UCompetitorProduct.findAll", query = "SELECT cp FROM UCompetitorProduct cp ORDER BY cp.modelNumber")
public class UCompetitorProduct implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(generator = "COMPETITOR_PRODUCT_ID_SEQ", strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "COMPETITOR_PRODUCT_ID_SEQ", sequenceName = "COMPETITOR_PRODUCT_ID_SEQ", schema = DatabaseConstants.WALTERCB_SCHEMA, allocationSize = 1)
    @Column(name = "ID")
    private Long id;
    @Column(name = "APPLICATION_GUID")
    private String applicationGUID;
    @Column(name = "MODEL_NUMBER")
    private String modelNumber;
    @ManyToOne(optional = false, cascade = { CascadeType.PERSIST, CascadeType.MERGE })
    @JoinColumn(name = "BRAND_ID", referencedColumnName = "ID", nullable = false)
    private UCompetitorBrand brand;
    @ManyToOne
    @JoinColumn(name = "DIAMETER", referencedColumnName = "ID")
    private UDiameter diameter;
    @ManyToOne(optional = true, cascade = { CascadeType.PERSIST, CascadeType.MERGE })
    @JoinColumn(name = "THICKNESS", referencedColumnName = "ID" , nullable = true)
    private UThickness thickness;
    @ManyToOne
    @JoinColumn(name = "ARBOR", referencedColumnName = "ID")
    private UArbor arbor;
    @Column(name = "GRIT")
    private String grit;
    @Column(name = "TYPE")
    private String type;
    @Column(name = "WEIGHT", precision = 1)
    private Double weight;
    @ManyToOne
    @JoinColumn(name = "MADE_IN_ID")
    private Country madeIn;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "PRODUCTION_DATE")
    private Date productionDate;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "competitorProduct", orphanRemoval = true)
    private Set<PrResult> results;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "competitorProduct", orphanRemoval = true)
    private Set<ProductivityReport> reports;

    @Transient
    private PrApplication application;

    @PostLoad
    private void postLoad() {
        this.application = new PrApplication(applicationGUID);
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getApplicationGUID() {
        return applicationGUID;
    }

    private void setApplicationGUID(String applicationGUID) {
        this.applicationGUID = applicationGUID;
    }

    public String getModelNumber() {
        return modelNumber;
    }

    public void setModelNumber(String modelNumber) {
        this.modelNumber = modelNumber;
    }

    public UCompetitorBrand getBrand() {
        return brand;
    }

    public void setBrand(UCompetitorBrand brand) {
        this.brand = brand;
    }

    public UDiameter getDiameter() {
        return diameter;
    }

    public void setDiameter(UDiameter diameter) {
        this.diameter = diameter;
    }

    public UThickness getThickness() {
        return thickness;
    }

    public void setThickness(UThickness thickness) {
        this.thickness = thickness;
    }

    public UArbor getArbor() {
        return arbor;
    }

    public void setArbor(UArbor arbor) {
        this.arbor = arbor;
    }

    public String getGrit() {
        return grit;
    }

    public void setGrit(String grit) {
        this.grit = grit;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Double getWeight() {
        return weight;
    }

    public void setWeight(Double weight) {
        this.weight = weight;
    }

    public Date getProductionDate() {
        return productionDate;
    }

    public void setProductionDate(Date productionDate) {
        this.productionDate = productionDate;
    }

    public Country getMadeIn() {
        return madeIn;
    }

    public void setMadeIn(Country madeIn) {
        this.madeIn = madeIn;
    }

    public PrApplication getApplication() {
        return application;
    }

    public void setApplication(PrApplication application) {
        if (application != null) this.applicationGUID = application.getGuid();
        this.application = application;
    }

    public Set<ProductivityReport> getReports() {
        return reports;
    }

    public void setReports(Set<ProductivityReport> reports) {
        this.reports = reports;
    }

    public Set<PrResult> getResults() {
        return results;
    }

    public void setResults(Set<PrResult> results) {
        this.results = results;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof UCompetitorProduct)) {
            return false;
        }
        UCompetitorProduct other = (UCompetitorProduct) object;
        if (this.getId() == null && other.getId() == null) {
            return this == other;
        }
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.UCompetitorProduct[ id=" + id + " ]";
    }
}
