/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.crossreferenceapp;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "COMPETITOR_APPLICATION", catalog = "", schema = "CROSSREFERENCEAPP")
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "CompetitorApplication.findAll", query = "SELECT c FROM CompetitorApplication c"),
  @NamedQuery(name = "CompetitorApplication.findByBrandId", query = "SELECT c FROM CompetitorApplication c WHERE c.competitorApplicationPK.brandId = :brandId"),
  @NamedQuery(name = "CompetitorApplication.findByCompetitorId", query = "SELECT c FROM CompetitorApplication c WHERE c.competitorApplicationPK.competitorId = :competitorId"),
  @NamedQuery(name = "CompetitorApplication.findByProductId", query = "SELECT c FROM CompetitorApplication c WHERE c.competitorApplicationPK.productId = :productId"),
  @NamedQuery(name = "CompetitorApplication.findByCountryId", query = "SELECT c FROM CompetitorApplication c WHERE c.competitorApplicationPK.countryId = :countryId"),
  @NamedQuery(name = "CompetitorApplication.findByApplicationGuid", query = "SELECT c FROM CompetitorApplication c WHERE c.competitorApplicationPK.applicationGuid = :applicationGuid"),
  @NamedQuery(name = "CompetitorApplication.findByCreatedUserName", query = "SELECT c FROM CompetitorApplication c WHERE c.createdUserName = :createdUserName"),
  @NamedQuery(name = "CompetitorApplication.findByCreatedDate", query = "SELECT c FROM CompetitorApplication c WHERE c.createdDate = :createdDate"),
  @NamedQuery(name = "CompetitorApplication.findByUpdatedUserName", query = "SELECT c FROM CompetitorApplication c WHERE c.updatedUserName = :updatedUserName"),
  @NamedQuery(name = "CompetitorApplication.findByUpdatedDate", query = "SELECT c FROM CompetitorApplication c WHERE c.updatedDate = :updatedDate")})
public class CompetitorApplication implements Serializable {
  private static final long serialVersionUID = 1L;
  @EmbeddedId
  protected CompetitorApplicationPK competitorApplicationPK;
  @Size(max = 255)
  @Column(name = "CREATED_USER_NAME")
  private String createdUserName;
  @Column(name = "CREATED_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date createdDate;
  @Size(max = 255)
  @Column(name = "UPDATED_USER_NAME")
  private String updatedUserName;
  @Column(name = "UPDATED_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date updatedDate;

  public CompetitorApplication() {
  }

  public CompetitorApplication(CompetitorApplicationPK competitorApplicationPK) {
    this.competitorApplicationPK = competitorApplicationPK;
  }

  public CompetitorApplication(long brandId, long competitorId, long productId, long countryId, String applicationGuid) {
    this.competitorApplicationPK = new CompetitorApplicationPK(brandId, competitorId, productId, countryId, applicationGuid);
  }

  public CompetitorApplicationPK getCompetitorApplicationPK() {
    return competitorApplicationPK;
  }

  public void setCompetitorApplicationPK(CompetitorApplicationPK competitorApplicationPK) {
    this.competitorApplicationPK = competitorApplicationPK;
  }

  public String getCreatedUserName() {
    return createdUserName;
  }

  public void setCreatedUserName(String createdUserName) {
    this.createdUserName = createdUserName;
  }

  public Date getCreatedDate() {
    return createdDate;
  }

  public void setCreatedDate(Date createdDate) {
    this.createdDate = createdDate;
  }

  public String getUpdatedUserName() {
    return updatedUserName;
  }

  public void setUpdatedUserName(String updatedUserName) {
    this.updatedUserName = updatedUserName;
  }

  public Date getUpdatedDate() {
    return updatedDate;
  }

  public void setUpdatedDate(Date updatedDate) {
    this.updatedDate = updatedDate;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (competitorApplicationPK != null ? competitorApplicationPK.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof CompetitorApplication)) {
      return false;
    }
    CompetitorApplication other = (CompetitorApplication) object;
    if ((this.competitorApplicationPK == null && other.competitorApplicationPK != null) || (this.competitorApplicationPK != null && !this.competitorApplicationPK.equals(other.competitorApplicationPK))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.crossreferenceapp.CompetitorApplication[ competitorApplicationPK=" + competitorApplicationPK + " ]";
  }

}
