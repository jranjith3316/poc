/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.model;

import java.io.Serializable;

/**
 *
 * @author jsgill
 */
public class GLCode implements Serializable {
  private String glCode;

  public GLCode(String glCode) {
    this.glCode = glCode;
  }

  public String getGlCode() {
    return glCode;
  }

  public void setGlCode(String glCode) {
    this.glCode = glCode;
  }

	@Override
	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		} else if (this == obj) {
			return true;
		} else if (glCode == ((GLCode) obj).getGlCode()) {
			return true;
		}
		return false;
	}

}
