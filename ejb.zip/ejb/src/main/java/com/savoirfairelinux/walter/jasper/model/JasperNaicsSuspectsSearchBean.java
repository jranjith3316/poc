/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.jasper.model;

import java.io.Serializable;
import java.util.List;

/**
 *
 * @author jsgill
 */
public class JasperNaicsSuspectsSearchBean implements Serializable{
  private String state;
  private String naics;
  private String city;
  private String postalCode;
  private List<JasperNaicsCustomerBean> jasperNaicsCustomerBean;

  public String getState() {
    return state;
  }

  public void setState(String state) {
    this.state = state;
  }

  public String getNaics() {
    return naics;
  }

  public void setNaics(String naics) {
    this.naics = naics;
  }

  public String getCity() {
    return city;
  }

  public void setCity(String city) {
    this.city = city;
  }

  public String getPostalCode() {
    return postalCode;
  }

  public void setPostalCode(String postalCode) {
    this.postalCode = postalCode;
  }

  public List<JasperNaicsCustomerBean> getJasperNaicsCustomerBean() {
    return jasperNaicsCustomerBean;
  }

  public void setJasperNaicsCustomerBean(List<JasperNaicsCustomerBean> jasperNaicsCustomerBean) {
    this.jasperNaicsCustomerBean = jasperNaicsCustomerBean;
  }



}
