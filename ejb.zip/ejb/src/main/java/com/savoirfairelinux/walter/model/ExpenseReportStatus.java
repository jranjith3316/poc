/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.model;

import java.io.Serializable;

/**
 *
 * @author jsgill
 */
public class ExpenseReportStatus implements Serializable {
  private String statusId;
  private String description;

  public ExpenseReportStatus(String statusId, String description) {
    this.statusId = statusId;
    this.description = description;
  }

  public String getStatusId() {
    return statusId;
  }

  public void setStatusId(String statusId) {
    this.statusId = statusId;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  
  
  @Override
  public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		} else if (this == obj) {
			return true;
		} else if (statusId == ((ExpenseReportStatus) obj).getStatusId()) {
			return true;
		}
		return false;
	}

}
