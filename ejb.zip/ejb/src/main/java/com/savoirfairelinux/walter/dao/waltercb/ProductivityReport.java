/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants;
import com.savoirfairelinux.walter.model.PrApplication;
import com.savoirfairelinux.walter.model.PrWalterProduct;
import com.savoirfairelinux.walter.service.productivityreport.ProductivityCalculation;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;

/**
 *
 * @author jderuere
 */
@Entity
@Table(name = "PRODUCTIVITY_REPORT", schema = DatabaseConstants.WALTERCB_SCHEMA)
public class ProductivityReport implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(generator = "PR_ID_SEQ", strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "PR_ID_SEQ", sequenceName = "PR_ID_SEQ", schema = DatabaseConstants.WALTERCB_SCHEMA, allocationSize = 1)
    @Column(name = "ID")
    private Long id;
    @Column(name = "WALTER_ID")
    private String walterId;
    @ManyToOne(optional = false, cascade = { CascadeType.PERSIST, CascadeType.MERGE })
    @JoinColumn(name = "COMPANY_ID")
    private PrCompany company;
    @Column(name = "SALE_REPRESENTATIVE", nullable = false)
    private String saleRepresentative;
    @Column(name = "MATERIAL_ID")
    private Long materialId;
    @Column(name = "HOURLY_LABOR_RATE", precision = 2, nullable = false)
    private double hourlyLaborRate = 65.0;
    @NotNull
    @Column(name = "APPLICATION_GUID")
    private String applicationGUID;
    @Column(name = "WALTER_PRODUCT_NUMBER")
    private String walterProductNumber;
    @ManyToOne(cascade = { CascadeType.PERSIST, CascadeType.MERGE })
    @JoinColumn(name = "COMP_PRODUCT_ID", referencedColumnName = "ID")
    private UCompetitorProduct competitorProduct;
    @ManyToOne(cascade = { CascadeType.PERSIST, CascadeType.MERGE })
    @JoinColumn(name = "WALTER_RESULT", referencedColumnName = "ID")
    private PrResult walterResult;
    @ManyToOne(cascade = { CascadeType.PERSIST, CascadeType.MERGE })
    @JoinColumn(name = "COMP_RESULT", referencedColumnName = "ID")
    private PrResult competitorResult;
    @ManyToOne
    @JoinColumn(name = "DISTRIBUTOR_ID")
    private Distributor distributor;
    @Column(name = "COMP_PRICE", precision = 2)
    private Double competitorPrice;
    @Column(name = "YEARLY_USAGE")
    private Integer yearlyUsage;
    @Column(name = "WALTER_PRICE", precision = 2)
    private Double walterPrice;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATE_DATE", nullable = false)
    private Date createDate;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "SUBMIT_DATE")
    private Date submitDate;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "PUBLISH_DATE")
    private Date publishDate;
    @Column(name = "COMP_ANNUAL_REM_MATERIAL")
    private Double competitorAnnualRemovedMaterial = 0.0;
    @Column(name = "COMP_ANNUAL_CUTS_NUMBER")
    private Integer competitorAnnualCutsNumber = 0;
    @Column(name = "WALTER_WHEELS_QUANTITY")
    private Integer walterWheelsQuantity = 0;
    @Column(name = "COMP_PRODUCT_COST")
    private Double competitorProductCost = 0.0;
    @Column(name = "COMP_MAN_HOURS_REQUIRED")
    private Integer competitorManHoursRequired = 0;
    @Column(name = "COMP_LABOUR_COST")
    private Double competitorLabourCost = 0.0;
    @Column(name = "WALTER_PRODUCT_COST")
    private Double walterProductCost = 0.0;
    @Column(name = "WALTER_MAN_HOURS_REQUIRED")
    private Integer walterManHoursRequired = 0;
    @Column(name = "WALTER_LABOUR_COST")
    private Double walterLabourCost = 0.0;
    @Column(name = "COMMENTS")
    private String comments;

    @Transient
    private PrApplication application;
    @Transient
    private PrWalterProduct walterProduct;
    @Transient
    private UMaterial material;

    public PrWalterProduct getWalterProduct() {
        return walterProduct;
    }

    public void setWalterProduct(PrWalterProduct walterProduct) {
        if (walterProduct != null) this.walterProductNumber = walterProduct.getProductNumber();
        this.walterProduct = walterProduct;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getWalterId() {
        return walterId;
    }

    public void setWalterId(String walterId) {
        this.walterId = walterId;
    }

    public PrCompany getCompany() {
        return company;
    }

    public void setCompany(PrCompany company) {
        this.company = company;
    }

    public String getSaleRepresentative() {
        return saleRepresentative;
    }

    public void setSaleRepresentative(String saleRepresentative) {
        this.saleRepresentative = saleRepresentative;
    }

    public Long getMaterialId() {
        return materialId;
    }

    public void setMaterialId(Long materialId) {
        this.materialId = materialId;
    }

    public double getHourlyLaborRate() {
        return hourlyLaborRate;
    }

    public void setHourlyLaborRate(double hourlyLaborRate) {
        this.hourlyLaborRate = hourlyLaborRate;
    }

    public String getApplicationGUID() {
        return applicationGUID;
    }

    private void setApplicationGUID(String applicationGUID) {
        this.applicationGUID = applicationGUID;
    }

    public String getWalterProductNumber() {
        return walterProductNumber;
    }

    private void setWalterProductNumber(String walterProductNumber) {
        this.walterProductNumber = walterProductNumber;
    }

    public UCompetitorProduct getCompetitorProduct() {
        return competitorProduct;
    }

    public void setCompetitorProduct(UCompetitorProduct competitorProduct) {
        this.competitorProduct = competitorProduct;
    }

    public PrResult getWalterResult() {
        return walterResult;
    }

    public void setWalterResult(PrResult walterResult) {
        this.walterResult = walterResult;
    }

    public PrResult getCompetitorResult() {
        return competitorResult;
    }

    public void setCompetitorResult(PrResult competitorResult) {
        this.competitorResult = competitorResult;
    }

    public Distributor getDistributor() {
        return distributor;
    }

    public void setDistributor(Distributor distributor) {
        this.distributor = distributor;
    }

    public Double getCompetitorPrice() {
        return competitorPrice;
    }

    public void setCompetitorPrice(Double competitorPrice) {
        this.competitorPrice = competitorPrice;
    }

    public Integer getYearlyUsage() {
        return yearlyUsage;
    }

    public void setYearlyUsage(Integer yearlyUsage) {
        this.yearlyUsage = yearlyUsage;
    }

    public Double getWalterPrice() {
        return walterPrice;
    }

    public void setWalterPrice(Double walterPrice) {
        this.walterPrice = walterPrice;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getSubmitDate() {
        return submitDate;
    }

    public void setSubmitDate(Date submitDate) {
        this.submitDate = submitDate;
    }

    public Date getPublishDate() {
        return publishDate;
    }

    public void setPublishDate(Date publishDate) {
        this.publishDate = publishDate;
    }

    public PrApplication getApplication() {
        return application;
    }

    public void setApplication(PrApplication application) {
        if (application != null) this.applicationGUID = application.getGuid();
        this.application = application;
    }

    public Double getCompetitorAnnualRemovedMaterial() {
        return competitorAnnualRemovedMaterial;
    }

    public void setCompetitorAnnualRemovedMaterial(Double competitorAnnualRemovedMaterial) {
        this.competitorAnnualRemovedMaterial = competitorAnnualRemovedMaterial;
    }

    public Integer getCompetitorAnnualCutsNumber() {
        return competitorAnnualCutsNumber;
    }

    public void setCompetitorAnnualCutsNumber(Integer competitorAnnualCutsNumber) {
        this.competitorAnnualCutsNumber = competitorAnnualCutsNumber;
    }

    public Integer getWalterWheelsQuantity() {
        return walterWheelsQuantity;
    }

    public void setWalterWheelsQuantity(Integer walterWheelsQuantity) {
        this.walterWheelsQuantity = walterWheelsQuantity;
    }

    public Integer getWalterManHoursRequired() {
        return walterManHoursRequired;
    }

    public void setWalterManHoursRequired(Integer walterManHoursRequired) {
        this.walterManHoursRequired = walterManHoursRequired;
    }

    public Integer getCompetitorManHoursRequired() {
        return competitorManHoursRequired;
    }

    public void setCompetitorManHoursRequired(Integer competitorManHoursRequired) {
        this.competitorManHoursRequired = competitorManHoursRequired;
    }

    public Double getCompetitorProductCost() {
        return competitorProductCost;
    }

    public void setCompetitorProductCost(Double competitorProductCost) {
        this.competitorProductCost = competitorProductCost;
    }

    public Double getCompetitorLabourCost() {
        return competitorLabourCost;
    }

    public void setCompetitorLabourCost(Double competitorLabourCost) {
        this.competitorLabourCost = competitorLabourCost;
    }

    public Double getWalterProductCost() {
        return walterProductCost;
    }

    public void setWalterProductCost(Double walterProductCost) {
        this.walterProductCost = walterProductCost;
    }

    public Double getWalterLabourCost() {
        return walterLabourCost;
    }

    public void setWalterLabourCost(Double walterLabourCost) {
        this.walterLabourCost = walterLabourCost;
    }

    public void computeProductivity(ProductivityCalculation calculation) {
        calculation.compute(this);
    }

    public UMaterial getMaterial() {
        return material;
    }

    public void setMaterial(UMaterial material) {
        this.material = material;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ProductivityReport)) {
            return false;
        }
        ProductivityReport other = (ProductivityReport) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.ProductivityReport[ id=" + id + " ]";
    }
}
