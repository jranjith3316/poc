/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.crossreferenceapp;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "ACTION", catalog = "", schema = "CROSSREFERENCEAPP")
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "Action.findAll", query = "SELECT a FROM Action a"),
  @NamedQuery(name = "Action.findByActionId", query = "SELECT a FROM Action a WHERE a.actionPK.actionId = :actionId"),
  @NamedQuery(name = "Action.findByLangId", query = "SELECT a FROM Action a WHERE a.actionPK.langId = :langId"),
  @NamedQuery(name = "Action.findByText", query = "SELECT a FROM Action a WHERE a.text = :text"),
  @NamedQuery(name = "Action.findByCreatedUserName", query = "SELECT a FROM Action a WHERE a.createdUserName = :createdUserName"),
  @NamedQuery(name = "Action.findByCreatedDate", query = "SELECT a FROM Action a WHERE a.createdDate = :createdDate"),
  @NamedQuery(name = "Action.findByUpdatedUserName", query = "SELECT a FROM Action a WHERE a.updatedUserName = :updatedUserName"),
  @NamedQuery(name = "Action.findByUpdatedDate", query = "SELECT a FROM Action a WHERE a.updatedDate = :updatedDate")})
public class Action implements Serializable {
  private static final long serialVersionUID = 1L;
  @EmbeddedId
  protected ActionPK actionPK;
  @Size(max = 500)
  @Column(name = "TEXT")
  private String text;
  @Size(max = 255)
  @Column(name = "CREATED_USER_NAME")
  private String createdUserName;
  @Column(name = "CREATED_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date createdDate;
  @Size(max = 255)
  @Column(name = "UPDATED_USER_NAME")
  private String updatedUserName;
  @Column(name = "UPDATED_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date updatedDate;

  public Action() {
  }

  public Action(ActionPK actionPK) {
    this.actionPK = actionPK;
  }

  public Action(long actionId, long langId) {
    this.actionPK = new ActionPK(actionId, langId);
  }

  public ActionPK getActionPK() {
    return actionPK;
  }

  public void setActionPK(ActionPK actionPK) {
    this.actionPK = actionPK;
  }

  public String getText() {
    return text;
  }

  public void setText(String text) {
    this.text = text;
  }

  public String getCreatedUserName() {
    return createdUserName;
  }

  public void setCreatedUserName(String createdUserName) {
    this.createdUserName = createdUserName;
  }

  public Date getCreatedDate() {
    return createdDate;
  }

  public void setCreatedDate(Date createdDate) {
    this.createdDate = createdDate;
  }

  public String getUpdatedUserName() {
    return updatedUserName;
  }

  public void setUpdatedUserName(String updatedUserName) {
    this.updatedUserName = updatedUserName;
  }

  public Date getUpdatedDate() {
    return updatedDate;
  }

  public void setUpdatedDate(Date updatedDate) {
    this.updatedDate = updatedDate;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (actionPK != null ? actionPK.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof Action)) {
      return false;
    }
    Action other = (Action) object;
    if ((this.actionPK == null && other.actionPK != null) || (this.actionPK != null && !this.actionPK.equals(other.actionPK))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.crossreferenceapp.Action[ actionPK=" + actionPK + " ]";
  }

}
