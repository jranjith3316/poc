package com.savoirfairelinux.walter.service.productivityreport;

import com.savoirfairelinux.walter.dao.waltercb.ProductivityReport;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * @author jderuere
 */
public class CuttingCalculation implements ProductivityCalculation {

    @Override
    public void compute(ProductivityReport report) {
        BigDecimal yearlyUsage = BigDecimal.valueOf(report.getYearlyUsage());
        BigDecimal annualCutsNumber = yearlyUsage.multiply(BigDecimal.valueOf(report.getCompetitorResult().getCutsNumber()));
        BigDecimal walterRequiredQuantity = annualCutsNumber.divide(BigDecimal.valueOf(report.getWalterResult().getCutsNumber()), 2, RoundingMode.HALF_UP);

        BigDecimal competitorCost = BigDecimal.valueOf(report.getCompetitorPrice()).multiply(yearlyUsage);
        BigDecimal competitorManHourRequired = annualCutsNumber.multiply(BigDecimal.valueOf(report.getCompetitorResult().getTimePerCut())).divide(BigDecimal.valueOf(3600), 2, RoundingMode.HALF_UP)
                .add((BigDecimal.valueOf(5)).multiply(yearlyUsage).divide(BigDecimal.valueOf(60), 2, RoundingMode.HALF_UP));
        BigDecimal competitorLabourCost = competitorManHourRequired.multiply(BigDecimal.valueOf(report.getHourlyLaborRate()));

        BigDecimal walterCost = BigDecimal.valueOf(report.getWalterPrice()).multiply(walterRequiredQuantity);
        BigDecimal walterManHourRequired = annualCutsNumber.multiply(BigDecimal.valueOf(report.getWalterResult().getTimePerCut())).divide(BigDecimal.valueOf(3600), 2, RoundingMode.HALF_UP)
                .add(BigDecimal.valueOf(5).multiply(walterRequiredQuantity).divide(BigDecimal.valueOf(60), 2, RoundingMode.HALF_UP));
        BigDecimal walterLabourCost = walterManHourRequired.multiply(BigDecimal.valueOf(report.getHourlyLaborRate()));

        report.setCompetitorAnnualCutsNumber(annualCutsNumber.setScale(0, RoundingMode.HALF_UP).intValue());
        report.setWalterWheelsQuantity(walterRequiredQuantity.setScale(0, RoundingMode.UP).intValue());
        report.setCompetitorProductCost(competitorCost.setScale(2, RoundingMode.HALF_UP).doubleValue());
        report.setCompetitorManHoursRequired(competitorManHourRequired.setScale(0, RoundingMode.HALF_UP).intValue());
        report.setCompetitorLabourCost(competitorLabourCost.setScale(2, RoundingMode.HALF_UP).doubleValue());
        report.setWalterProductCost(walterCost.setScale(2, RoundingMode.HALF_UP).doubleValue());
        report.setWalterManHoursRequired(walterManHourRequired.setScale(0, RoundingMode.HALF_UP).intValue());
        report.setWalterLabourCost(walterLabourCost.setScale(2, RoundingMode.HALF_UP).doubleValue());
    }
}
