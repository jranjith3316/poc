/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.service.impl;

import com.savoirfairelinux.walter.dao.walter.VgTreeItem;
import com.savoirfairelinux.walter.dao.walter.VgTreeItemTxt;
import com.savoirfairelinux.walter.dao.walter.VgTreeProduct;
import com.savoirfairelinux.walter.dao.waltercb.ULang;
import com.savoirfairelinux.walter.model.Franchise;
import com.savoirfairelinux.walter.model.Tradename;
import com.savoirfairelinux.walter.service.VideoGalleryBeanRemote;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.security.PermitAll;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

/**
 *
 * @author jsgill
 */
@Stateless(name = "VideoGalleryBean")
@TransactionManagement(TransactionManagementType.CONTAINER)
@PermitAll
@LocalBean
public class VideoGalleryBean implements VideoGalleryBeanRemote {

  @PersistenceContext(unitName = "waltershare")
  EntityManager entityManager;
  public static final Logger LOG = Logger.getLogger(VideoGalleryBean.class.getCanonicalName());
  @EJB
  WalterBean walterBean;
  @EJB
  SingletonBean singletonBean;

  @Override
  public void deleteItem(Integer itemId, String treeCode, String userName) throws Exception {

    Date date = new Date();


    try {
      VgTreeItem vgTreeItem = getPhoto(itemId, treeCode);
      List<VgTreeItemTxt> txts = getTxtForItem(vgTreeItem);
      for (VgTreeItemTxt txt : txts) {
          //entityManager.remove(txt);
        txt.setCancelBy( userName );
        txt.setCancelDate(date);
        deleteChild(txt, date, userName);
        walterBean.save(txt);
      }

      vgTreeItem.setCancelBy(userName);
      vgTreeItem.setCancelDate(date);
              walterBean.save(vgTreeItem);
        //entityManager.remove(vgTreeItem);
    } catch (Exception e) {
      LOG.severe(e.getMessage());
      throw new Exception(e.getMessage());
    }
  }

  private void deleteChild(VgTreeItemTxt vgTreeItemTxt, Date date, String userName){
    try {
      List<VgTreeItemTxt> vgTreeItemTxtList = getParentId(vgTreeItemTxt.getVgTreeItemTxtPK().getVgTreeCode(), vgTreeItemTxt.getVgTreeItemTxtPK().getItemId());
      for (VgTreeItemTxt tmp :  vgTreeItemTxtList ){
        tmp.setCancelBy(userName);
        tmp.setCancelDate(date);

        deleteChild(tmp, date, userName);
        walterBean.save(tmp);
      }
    } catch (Exception ex) {
      Logger.getLogger(VideoGalleryBean.class.getName()).log(Level.SEVERE, null, ex);
    }
  }

  private List<VgTreeItemTxt> getParentId(String treeCode, Integer parentId) throws Exception{
    List <VgTreeItemTxt> result = new ArrayList<VgTreeItemTxt>();

    Query query = entityManager.createQuery(singletonBean.getVideoGalleryQuery("all.parentId"));

    result = query.setParameter("vgTreeCode", treeCode)
                  .setParameter("parentId", parentId).getResultList();

    return result;
  }

  public List<VgTreeItemTxt> getItemVideosByParentId(Integer itemParentId, Long langId, String treeCode) throws Exception {
    List <VgTreeItemTxt> result = new ArrayList<VgTreeItemTxt>();

    Query query = entityManager.createQuery(singletonBean.getVideoGalleryQuery("all.videos.images"));

    result = query.setParameter("treeCode", treeCode)
                  .setParameter("parentId", itemParentId)
                  .setParameter("langId",  langId.intValue()).getResultList();

    return result;
  }

  @Override
  public VgTreeItem getPhoto(Integer itemId, String treeCode) throws Exception {
    VgTreeItem result = null;
    try {
      Query query = entityManager.createNamedQuery("VgTreeItem.findByItemId", VgTreeItem.class);
      result = (VgTreeItem) query.setParameter("itemId", itemId).getResultList().get(0);
    } catch (Exception e) {
      LOG.severe(e.getMessage());
      throw new Exception(e.getMessage());
    }
    return result;
  }

  @Override
  public Integer getNextItemId(String treeCode) throws Exception {
    Integer result = 0;
    try {
      Query query = entityManager.createQuery(singletonBean.getVideoGalleryQuery("videos.max.id"));
      result = (Integer) query.setParameter("treeCode", treeCode).getSingleResult();
    } catch (Exception e) {
      System.out.println("error in getNextItemId()" + e.getMessage());
      LOG.severe(e.getMessage());
      throw new Exception(e.getMessage());
    }
    return result + 1;
  }

  @Override
  public Short getNextOrderBy(String treeCode, Integer parentId) throws Exception {
    Short result = 0;
    try {
      Query query = entityManager.createQuery(singletonBean.getVideoGalleryQuery("videos.next.orderBy"));
      result = (Short) query.setParameter("treeCode", treeCode)
                            .setParameter("parentId", parentId)
                            .getSingleResult();
    } catch (Exception e) {
      System.out.println("error in getNextOrderBy()" + e.getMessage());
      LOG.severe(e.getMessage());
      throw new Exception(e.getMessage());
    }

    result = (short) (result + 1);

    return result;
  }

  @Override
  public List<VgTreeItemTxt> getImagesTxt(String languageAbbreviature, String treeCode) throws Exception {
    ULang language = walterBean.getULang(languageAbbreviature);
    List<VgTreeItemTxt> result = null;
    Query query = entityManager.createQuery(singletonBean.getVideoGalleryQuery("all.videos.txt"));
    try {
      result = query.setParameter("treeCode", treeCode)
                    .setParameter("lang", language.getLangId().intValue()).getResultList();
    } catch (Exception e) {
      LOG.severe(e.getMessage());
      throw new Exception(e.getMessage());
    }
    return result;
  }

  @Override
  public List<VgTreeItemTxt> getTxtForItem(VgTreeItem vgTreeItem) throws Exception {
    List<VgTreeItemTxt> result = null;
    try {
      Query query = entityManager.createQuery(singletonBean.getVideoGalleryQuery("videos.by.itemid"));
      result = query.setParameter("itemId", vgTreeItem.getVgTreeItemPK().getItemId())
                    .setParameter("treeCode", vgTreeItem.getVgTreeItemPK().getVgTreeCode())
                    .getResultList();
    } catch (Exception e) {
      LOG.severe(e.getMessage());
      throw new Exception(e.getMessage());
    }
    return result;
  }

  @Override
  public List<VgTreeItemTxt> getVideoItem(VgTreeItem vgTreeItem) throws Exception {
//    List<VideoGalleryItem> resultList = new ArrayList<VideoGalleryItem>();
    List<VgTreeItemTxt> vgTreeItemTxtList = new ArrayList<VgTreeItemTxt>();
    try {
      Query query = entityManager.createQuery(singletonBean.getVideoGalleryQuery("videos.by.itemid"));
      vgTreeItemTxtList = query.setParameter("itemId", vgTreeItem.getVgTreeItemPK().getItemId())
                    .setParameter("treeCode", vgTreeItem.getVgTreeItemPK().getVgTreeCode())
                    .getResultList();

    } catch (Exception e) {
      LOG.severe(e.getMessage());
      throw new Exception(e.getMessage());
    }
    return vgTreeItemTxtList;
  }

  @Override
  public void setOrderUp(String treeCode, Integer itemIdSelected, Integer itemIdGoUp) throws Exception{

    try{
      VgTreeItem vgSelected = getPhoto(itemIdSelected, treeCode);
      VgTreeItem vgGoUp = getPhoto(itemIdGoUp, treeCode);

      Short selectedOrderBy = (short) (vgSelected.getOrderBy() + 1);
      Short goUpOrderBy = vgGoUp.getOrderBy();

      // need to check if parentId = new parentId

      if ( vgSelected.getParentId() == vgGoUp.getParentId() ){
        entityManager.createQuery(singletonBean.getVideoGalleryQuery("videos.updateUpSelected.orderby"))
                .setParameter("vgTreeCode", treeCode)
                .setParameter("orderBy", goUpOrderBy )
                .setParameter("itemId", vgSelected.getVgTreeItemPK().getItemId() )
                .executeUpdate();

        entityManager.createQuery(singletonBean.getVideoGalleryQuery("videos.updateUpItem.orderby"))
                .setParameter("vgTreeCode", treeCode)
                .setParameter("parentId", vgSelected.getParentId())
                .setParameter("itemId", vgSelected.getVgTreeItemPK().getItemId())
                .setParameter("orderByFrom", goUpOrderBy)
                .setParameter("orderByTo", selectedOrderBy )
                .executeUpdate();
      }else{
        // set the order by in new parentid
        // set order by in old parentId
        Integer oldParentId = vgSelected.getParentId();
        vgSelected.setParentId( vgGoUp.getParentId() );
        entityManager.merge(vgSelected);

        setOrderBy(treeCode, oldParentId);
        setOrderBy(treeCode, vgSelected.getParentId());

      }
    } catch (Exception e) {
      LOG.severe(e.getMessage());
      throw new Exception(e.getMessage());
    }

  }

  @Override
  public void setOrderDown(String treeCode, Integer itemIdSelected, Integer itemIdGoUp) throws Exception{

    try{
      VgTreeItem vgSelected = getPhoto(itemIdSelected, treeCode);
      VgTreeItem vgGoUp = getPhoto(itemIdGoUp, treeCode);

      Short selectedOrderBy = (short) (vgSelected.getOrderBy() - 1);
      Short goUpOrderBy = vgGoUp.getOrderBy();

      if ( vgSelected.getParentId() == vgGoUp.getParentId() ){
        entityManager.createQuery(singletonBean.getVideoGalleryQuery("videos.updateDownSelected.orderby"))
                .setParameter("vgTreeCode", treeCode)
                .setParameter("orderBy", goUpOrderBy )
                .setParameter("itemId", vgSelected.getVgTreeItemPK().getItemId() )
                .executeUpdate();

        entityManager.createQuery(singletonBean.getVideoGalleryQuery("videos.updateDownItem.orderby"))
                .setParameter("vgTreeCode", treeCode)
                .setParameter("parentId", vgSelected.getParentId())
                .setParameter("itemId", vgSelected.getVgTreeItemPK().getItemId())
                .setParameter("orderByFrom", goUpOrderBy)
                .setParameter("orderByTo", selectedOrderBy )
                .executeUpdate();
      }else{
        // set the order by in new parentid
        // set order by in old parentId
        Integer oldParentId = vgSelected.getParentId();
        vgSelected.setParentId( vgGoUp.getParentId() );
        entityManager.merge(vgSelected);

        setOrderBy(treeCode, oldParentId);
        setOrderBy(treeCode, vgSelected.getParentId());
      }
    } catch (Exception e) {
      LOG.severe(e.getMessage());
      throw new Exception(e.getMessage());
    }

  }

  @Override
  public void setOrderBy(String vgTreeCode, Integer parentId) throws Exception{
    try{
      Query query = entityManager.createQuery(singletonBean.getVideoGalleryQuery("videos.by.parentId"));
      List<VgTreeItem> vgTreeItemList = query.setParameter("vgTreeCode", vgTreeCode)
                                             .setParameter("parentId", parentId)
                                             .getResultList();

      Short orderBy = 1;

      for( VgTreeItem vgTreeItem : vgTreeItemList ){
        vgTreeItem.setOrderBy(orderBy);
        orderBy = (short) (orderBy + 1);
        entityManager.merge(vgTreeItem);

      }

    } catch (Exception e) {
      LOG.severe(e.getMessage());
      throw new Exception(e.getMessage());
    }
  }


  @Override
  public VgTreeItemTxt getTxtByItemIdLangId(VgTreeItem vgTreeItem, Integer langId ) throws Exception {
    VgTreeItemTxt result = null;
    try {
      Query query = entityManager.createQuery(singletonBean.getVideoGalleryQuery("videos.by.itemIdlangId"));
      result = (VgTreeItemTxt) query.setParameter("itemId", vgTreeItem.getVgTreeItemPK().getItemId())
                                    .setParameter("treeCode", vgTreeItem.getVgTreeItemPK().getVgTreeCode())
                                    .setParameter("langId", langId)
                                    .getSingleResult();
    } catch (Exception e) {
      LOG.severe(e.getMessage());
      throw new Exception(e.getMessage());
    }
    return result;
  }


  @Override
  public List<VgTreeProduct> getProduct(VgTreeItem vgTreeItem) throws Exception{
    List<VgTreeProduct> vgTreeProductList = new ArrayList<VgTreeProduct>();

    Query query = entityManager.createQuery(singletonBean.getVideoGalleryQuery("product.by.itemId"));

    vgTreeProductList = query.setParameter("treeCode", vgTreeItem.getVgTreeItemPK().getVgTreeCode())
                             .setParameter("itemId", vgTreeItem.getVgTreeItemPK().getItemId()).getResultList();

    return vgTreeProductList;
  }


  @Override
  public Integer getNextProductId(String treeCode, int itemId ) throws Exception {
    Integer result = 0;
    try {
      Query query = entityManager.createQuery(singletonBean.getVideoGalleryQuery("product.max.productId"));
      result = (Integer) query.setParameter("treeCode", treeCode)
                              .setParameter("itemId", itemId).getSingleResult();
    } catch (Exception e) {
      System.out.println("error in getNextProductId()" + e.getMessage());
      LOG.severe(e.getMessage());
      throw new Exception(e.getMessage());
    }
    return result + 1;
  }

  @Override
  public List<Tradename> getTradenames(String languageAbbreviation, String country, String organization, String vgTreeCode, int itemId) throws Exception {
    List<Tradename> result = new ArrayList<Tradename>();
    String queryKey = "videoGallery.walter.tradenames";
    try {
      HashMap<String, String> translations = getWalterTradenamesTranslation(languageAbbreviation);
      TypedQuery<Object[]> query = entityManager.createQuery(singletonBean.getVideoGalleryQuery(queryKey), Object[].class);
      query.setParameter("country", country);
      query.setParameter("vgTreeCode", vgTreeCode);
      query.setParameter("vgItemId", itemId);

      List<Object[]> rows = query.getResultList();
      for (Object[] row : rows) {
        String tradenameId = String.valueOf(row[0]);
        String franchiseId = String.valueOf(row[1]);
        String franchiseDesc = String.valueOf(row[2]);
        String description = String.valueOf(row[3]);
        description = translations.containsKey(description) ? translations.get(description) : description;
        result.add(new Tradename(tradenameId, new Franchise(franchiseId, franchiseDesc), description));
      }
    } catch (Exception e) {
      LOG.severe(e.getMessage());
      throw new Exception(e.getMessage());
    }

    Collections.sort(result, new Comparator<Tradename>() {
      @Override
      public int compare(Tradename t1, Tradename t2) {
        return t1.getDescription().compareTo(t2.getDescription());
      }
    });

    return result;
  }

  @Override
  public Tradename getProductTradeName(String languageAbbreviation, String country, String tradeGuid) throws Exception {
    Tradename result = null;
    String queryKey = "videoGallery.walter.tradename";
    try {
      HashMap<String, String> translations = getWalterTradenamesTranslation(languageAbbreviation);
      TypedQuery<Object[]> query = entityManager.createQuery(singletonBean.getVideoGalleryQuery(queryKey), Object[].class);
      query.setParameter("country", country);
      query.setParameter("tradeGuid", tradeGuid);

      List<Object[]> rows = query.getResultList();
      for (Object[] row : rows) {
        String tradenameId = String.valueOf(row[0]);
        String franchiseId = String.valueOf(row[1]);
        String franchiseDesc = String.valueOf(row[2]);
        String description = String.valueOf(row[3]);
        description = translations.containsKey(description) ? translations.get(description) : description;
        result = new Tradename(tradenameId, new Franchise(franchiseId, franchiseDesc), description);
      }
    } catch (Exception e) {
      LOG.severe(e.getMessage());
      throw new Exception(e.getMessage());
    }

    return result;
  }


  @Override
  public HashMap<String, String> getWalterTradenamesTranslation(String languageAbbreviation) throws Exception {
    HashMap<String, String> result = new HashMap<String, String>();
    try {
      List<Object[]> rows = entityManager.createQuery(singletonBean.getVideoGalleryQuery("videoGallery.walter.tradenames.translation"), Object[].class)
              .setParameter("languageAbbreviation", languageAbbreviation)
              .getResultList();

      for (Object[] row : rows) {
        String name = String.valueOf(row[0]);
        String translate = String.valueOf(row[1]);
        result.put(name, translate);
      }
    } catch (Exception e) {
      LOG.severe(e.getMessage());
      throw new Exception(e.getMessage());
    }
    return result;
  }

  @Override
  public List<Franchise> getFranchises(String languageAbbreviation, String organization) throws Exception {
    List<Franchise> result = new ArrayList<Franchise>();
    String queryKey = "videoGallery.walter.franchises";
    try {
      HashMap<String, String> translations = getWalterFranchisesTranslation(languageAbbreviation);
      TypedQuery<Object[]> query = entityManager.createQuery(singletonBean.getVideoGalleryQuery(queryKey), Object[].class);
      List<Object[]> rows = query.getResultList();
      for (Object[] row : rows) {
        String franchiseId = String.valueOf(row[0]);
        String description = String.valueOf(row[1]);
        description = translations.containsKey(description) ? translations.get(description) : description;
        result.add(new Franchise(franchiseId, description));
      }
    } catch (Exception e) {
      LOG.severe(e.getMessage());
      throw new Exception(e.getMessage());
    }

    Collections.sort(result, new Comparator<Franchise>() {
      @Override
      public int compare(Franchise f1, Franchise f2) {
        return f1.getDescription().compareTo(f2.getDescription());
      }
    });
    return result;
  }

  @Override
  public HashMap<String, String> getWalterFranchisesTranslation(String languageAbbreviation) throws Exception {
    HashMap<String, String> result = new HashMap<String, String>();
    try {
      List<Object[]> rows = entityManager.createQuery(singletonBean.getVideoGalleryQuery("videoGallery.walter.franchises.translation"), Object[].class)
              .setParameter("languageAbbreviation", languageAbbreviation)
              .getResultList();

      for (Object[] row : rows) {
        String name = String.valueOf(row[0]);
        String translate = String.valueOf(row[1]);
        result.put(name, translate);
      }

    } catch (Exception e) {
      LOG.severe(e.getMessage());
      throw new Exception(e.getMessage());
    }
    return result;
  }

  @Override
  public Franchise getFranchise(String languageAbbreviation, String franchiseGuid) throws Exception {
    Franchise result = null;
    String queryKey = "videoGallery.walter.franchise";
    try {
      HashMap<String, String> translations = getWalterFranchisesTranslation(languageAbbreviation);
      TypedQuery<Object[]> query = entityManager.createQuery(singletonBean.getVideoGalleryQuery(queryKey), Object[].class);
      List<Object[]> rows = query.setParameter("franchiseGuid", franchiseGuid).getResultList();
      for (Object[] row : rows) {
        String franchiseId = String.valueOf(row[0]);
        String description = String.valueOf(row[1]);
        description = translations.containsKey(description) ? translations.get(description) : description;
        result = new Franchise(franchiseId, description);
      }
    } catch (Exception e) {
      LOG.severe(e.getMessage());
      throw new Exception(e.getMessage());
    }

    return result;
  }

}
