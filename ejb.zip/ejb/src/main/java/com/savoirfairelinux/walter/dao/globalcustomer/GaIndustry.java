package com.savoirfairelinux.walter.dao.globalcustomer;

import com.savoirfairelinux.walter.dao.DatabaseConstants;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @author jderuere
 */
@Entity
@Table(name = "GA_INDUSTRY", schema = DatabaseConstants.WALTERCB_SCHEMA, uniqueConstraints = @UniqueConstraint(name = "GA_INDUSTRY_UNIQUE", columnNames = { "INDUSTRY_ID", "GLOBAL_ACCOUNT_ID" }))
public class GaIndustry implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(generator = "GA_INDUSTRY_ID_SEQ", strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "GA_INDUSTRY_ID_SEQ", sequenceName = "GA_INDUSTRY_ID_SEQ", schema = DatabaseConstants.WALTERCB_SCHEMA, allocationSize = 1)
    @Column(name = "GA_INDUSTRY_ID")
    private Long gaIndustryId;

    @NotNull
    @Column(name = "INDUSTRY_ID", nullable = false)
    private long industryId;

    @JoinColumn(name = "GLOBAL_ACCOUNT_ID", referencedColumnName = "GLOBAL_ACCOUNT_ID")
    @OneToOne(optional = false)
    private GlobalAccount globalAccount;

    public GaIndustry() {
    }

    public GaIndustry(long industryId) {
        this.industryId = industryId;
    }

    public Long getGaIndustryId() {
        return gaIndustryId;
    }

    public void setGaIndustryId(Long gaIndustryId) {
        this.gaIndustryId = gaIndustryId;
    }

    public long getIndustryId() {
        return industryId;
    }

    public void setIndustryId(long industryId) {
        this.industryId = industryId;
    }

    public GlobalAccount getGlobalAccount() {
        return globalAccount;
    }

    public void setGlobalAccount(GlobalAccount globalAccount) {
        this.globalAccount = globalAccount;
    }
}