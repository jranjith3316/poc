/* 
 * Copyright 2012 Savoir-faire Linux
 * 
 * This file is part of Walter-Portal.
 * 
 * Walter-Portal is free software: you can redistribute it and/or modify it under the terms of the 
 * GNU General Public License as published by the Free Software Foundation, either version 3 
 * of the License, or (at your option) any later version.
 * 
 * Walter-Portal is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with Walter-Portal. 
 * If not, see http://www.gnu.org/licenses/.
 */
package com.savoirfairelinux.walter.service;

import com.savoirfairelinux.walter.dao.walter.PgTreeItem;
import com.savoirfairelinux.walter.dao.walter.PgTreeItemTxt;
import java.util.List;
import javax.ejb.Remote;

/**
 *
 * @author mgubaidullin
 */
@Remote
public interface PhotoGalleryBeanRemote {
    
    public void deleteItem(Integer itemId) throws Exception;
    
    public PgTreeItem getPhoto(Integer itemId) throws Exception ;
    
    public Integer getNextItemId() throws Exception;
    
    public List<PgTreeItem> getImages(Integer itemParentId, String languageAbbreviature, String company) throws Exception;
    
    public List<PgTreeItemTxt> getImagesTxt(String languageAbbreviature, String company) throws Exception;
    
    public List<PgTreeItemTxt> getTxtForItem(PgTreeItem pgTreeItem) throws Exception;
    
}
