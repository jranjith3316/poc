/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.jasper.model;

import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author jsgill
 */
public class JasperExpenseRptDSearchBean extends JasperExpenseRptDBean{

  private String glCode;
  private long expenseRptid;
  private String validationDate;
  private String creatorUserName;
  private BigDecimal totalBD;

  public JasperExpenseRptDSearchBean(String glCode, long expenseRptid, String validationDate, String creatorUserName, String expenseDate, String state, String city, String expenseType, String detail, int numberNight, BigDecimal totalBD) {
    super(expenseDate, state, city, expenseType, detail, numberNight, "");
    this.glCode = glCode;
    this.expenseRptid = expenseRptid;
    this.validationDate = validationDate;
    this.creatorUserName = creatorUserName;
    this.totalBD = totalBD;
  }
  
  public String getGlCode() {
    return glCode;
  }

  public void setGlCode(String glCode) {
    this.glCode = glCode;
  }

  public long getExpenseRptid() {
    return expenseRptid;
  }

  public void setExpenseRptid(long expenseRptid) {
    this.expenseRptid = expenseRptid;
  }

  public String getValidationDate() {
    return validationDate;
  }

  public void setValidationDate(String validationDate) {
    this.validationDate = validationDate;
  }

  public String getCreatorUserName() {
    return creatorUserName;
  }

  public void setCreatorUserName(String creatorUserName) {
    this.creatorUserName = creatorUserName;
  }

  public BigDecimal getTotalBD() {
    return totalBD;
  }

  public void setTotalBD(BigDecimal totalBD) {
    this.totalBD = totalBD;
  }
}
