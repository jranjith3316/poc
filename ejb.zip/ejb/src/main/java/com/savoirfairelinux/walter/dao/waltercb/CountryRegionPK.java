/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author jsgill
 */
@Embeddable
public class CountryRegionPK implements Serializable {
    @Basic(optional = false)
    @NotNull
    @Column(name = "COUNTRY_ID")
    private long countryId;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "REGION_CODE")
    private String regionCode;

    public CountryRegionPK() {
    }

    public CountryRegionPK(long countryId, String regionCode) {
        this.countryId = countryId;
        this.regionCode = regionCode;
    }

    public long getCountryId() {
        return countryId;
    }

    public void setCountryId(long countryId) {
        this.countryId = countryId;
    }

    public String getRegionCode() {
        return regionCode;
    }

    public void setRegionCode(String regionCode) {
        this.regionCode = regionCode;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) countryId;
        hash += (regionCode != null ? regionCode.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CountryRegionPK)) {
            return false;
        }
        CountryRegionPK other = (CountryRegionPK) object;
        if (this.countryId != other.countryId) {
            return false;
        }
        if ((this.regionCode == null && other.regionCode != null) || (this.regionCode != null && !this.regionCode.equals(other.regionCode))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.CountryRegionPK[ countryId=" + countryId + ", regionCode=" + regionCode + " ]";
    }
    
}
