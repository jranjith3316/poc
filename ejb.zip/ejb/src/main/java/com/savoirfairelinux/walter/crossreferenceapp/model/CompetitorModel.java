/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.crossreferenceapp.model;

import java.io.Serializable;
import java.util.List;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;

/**
 *
 * @author jsgill
 */

public class CompetitorModel implements Serializable{
  private static final long serialVersionUID = 3511338233023397895L;
  private Long competitorId;
  private String competitorName;
  private List<CompetitorBrandModel> competitorBrands;
  private CompetitorBrandModel competitorBrand;

  public Long getCompetitorId() {
    return competitorId;
  }

  public void setCompetitorId(Long competitorId) {
    this.competitorId = competitorId;
  }

  public String getCompetitorName() {
    return competitorName;
  }

  public void setCompetitorName(String competitorName) {
    this.competitorName = competitorName+" ";
  }

  @XmlElementWrapper
  @XmlElement(name="competitorBrand")
  public List<CompetitorBrandModel> getCompetitorBrands() {
    return competitorBrands;
  }

  public void setCompetitorBrands(List<CompetitorBrandModel> competitorBrands) {
    this.competitorBrands = competitorBrands;
  }

  public CompetitorBrandModel getCompetitorBrand() {
    return competitorBrand;
  }

  public void setCompetitorBrand(CompetitorBrandModel competitorBrand) {
    this.competitorBrand = competitorBrand;
  }



}
