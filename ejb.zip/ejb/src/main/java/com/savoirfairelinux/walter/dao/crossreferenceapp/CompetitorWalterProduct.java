/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.crossreferenceapp;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "COMPETITOR_WALTER_PRODUCT", catalog = "", schema = "CROSSREFERENCEAPP")
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "CompetitorWalterProduct.findAll", query = "SELECT c FROM CompetitorWalterProduct c"),
  @NamedQuery(name = "CompetitorWalterProduct.findByCompetitorId", query = "SELECT c FROM CompetitorWalterProduct c WHERE c.competitorWalterProductPK.competitorId = :competitorId"),
  @NamedQuery(name = "CompetitorWalterProduct.findByBrandId", query = "SELECT c FROM CompetitorWalterProduct c WHERE c.competitorWalterProductPK.brandId = :brandId"),
  @NamedQuery(name = "CompetitorWalterProduct.findByProductId", query = "SELECT c FROM CompetitorWalterProduct c WHERE c.competitorWalterProductPK.productId = :productId"),
  @NamedQuery(name = "CompetitorWalterProduct.findByCountryId", query = "SELECT c FROM CompetitorWalterProduct c WHERE c.competitorWalterProductPK.countryId = :countryId"),
  @NamedQuery(name = "CompetitorWalterProduct.findByCategoryId", query = "SELECT c FROM CompetitorWalterProduct c WHERE c.competitorWalterProductPK.categoryId = :categoryId"),
  @NamedQuery(name = "CompetitorWalterProduct.findByProductNumber", query = "SELECT c FROM CompetitorWalterProduct c WHERE c.competitorWalterProductPK.productNumber = :productNumber"),
  @NamedQuery(name = "CompetitorWalterProduct.findByCreatedUserName", query = "SELECT c FROM CompetitorWalterProduct c WHERE c.createdUserName = :createdUserName"),
  @NamedQuery(name = "CompetitorWalterProduct.findByCreatedDate", query = "SELECT c FROM CompetitorWalterProduct c WHERE c.createdDate = :createdDate"),
  @NamedQuery(name = "CompetitorWalterProduct.findByUpdatedUserName", query = "SELECT c FROM CompetitorWalterProduct c WHERE c.updatedUserName = :updatedUserName"),
  @NamedQuery(name = "CompetitorWalterProduct.findByUpdatedDate", query = "SELECT c FROM CompetitorWalterProduct c WHERE c.updatedDate = :updatedDate")})
public class CompetitorWalterProduct implements Serializable {
  private static final long serialVersionUID = 1L;
  @EmbeddedId
  protected CompetitorWalterProductPK competitorWalterProductPK;
  @Size(max = 255)
  @Column(name = "CREATED_USER_NAME")
  private String createdUserName;
  @Column(name = "CREATED_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date createdDate;
  @Size(max = 255)
  @Column(name = "UPDATED_USER_NAME")
  private String updatedUserName;
  @Column(name = "UPDATED_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date updatedDate;

  public CompetitorWalterProduct() {
  }

  public CompetitorWalterProduct(CompetitorWalterProductPK competitorWalterProductPK) {
    this.competitorWalterProductPK = competitorWalterProductPK;
  }

  public CompetitorWalterProduct(long competitorId, long brandId, long productId, long countryId, long categoryId, String productNumber) {
    this.competitorWalterProductPK = new CompetitorWalterProductPK(competitorId, brandId, productId, countryId, categoryId, productNumber);
  }

  public CompetitorWalterProductPK getCompetitorWalterProductPK() {
    return competitorWalterProductPK;
  }

  public void setCompetitorWalterProductPK(CompetitorWalterProductPK competitorWalterProductPK) {
    this.competitorWalterProductPK = competitorWalterProductPK;
  }

  public String getCreatedUserName() {
    return createdUserName;
  }

  public void setCreatedUserName(String createdUserName) {
    this.createdUserName = createdUserName;
  }

  public Date getCreatedDate() {
    return createdDate;
  }

  public void setCreatedDate(Date createdDate) {
    this.createdDate = createdDate;
  }

  public String getUpdatedUserName() {
    return updatedUserName;
  }

  public void setUpdatedUserName(String updatedUserName) {
    this.updatedUserName = updatedUserName;
  }

  public Date getUpdatedDate() {
    return updatedDate;
  }

  public void setUpdatedDate(Date updatedDate) {
    this.updatedDate = updatedDate;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (competitorWalterProductPK != null ? competitorWalterProductPK.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof CompetitorWalterProduct)) {
      return false;
    }
    CompetitorWalterProduct other = (CompetitorWalterProduct) object;
    if ((this.competitorWalterProductPK == null && other.competitorWalterProductPK != null) || (this.competitorWalterProductPK != null && !this.competitorWalterProductPK.equals(other.competitorWalterProductPK))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.crossreferenceapp.CompetitorWalterProduct[ competitorWalterProductPK=" + competitorWalterProductPK + " ]";
  }

}
