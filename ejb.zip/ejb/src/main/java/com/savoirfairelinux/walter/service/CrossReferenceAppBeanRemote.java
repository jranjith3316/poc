/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.service;

import com.savoirfairelinux.walter.crossreferenceapp.model.CompetitorModel;
import com.savoirfairelinux.walter.crossreferenceapp.model.HazardModel;
import com.savoirfairelinux.walter.crossreferenceapp.model.WalterProductModel;
import com.savoirfairelinux.walter.dao.crossreferenceapp.Action;
import com.savoirfairelinux.walter.dao.crossreferenceapp.Competitor;
import com.savoirfairelinux.walter.dao.crossreferenceapp.CompetitorBrand;
import com.savoirfairelinux.walter.dao.crossreferenceapp.CompetitorHazard;
import com.savoirfairelinux.walter.dao.crossreferenceapp.CompetitorProduct;
import com.savoirfairelinux.walter.dao.crossreferenceapp.CompetitorWalterProduct;
import com.savoirfairelinux.walter.dao.crossreferenceapp.Diluent;
import com.savoirfairelinux.walter.dao.idb.OoClasses;
import com.savoirfairelinux.walter.dao.idb.OoInstances;
import com.savoirfairelinux.walter.dao.waltercb.Country;
import java.util.Date;
import java.util.List;
import javax.ejb.Remote;

/**
 *
 * @author jsgill
 */
@Remote
public interface CrossReferenceAppBeanRemote {

  public List<CompetitorModel> getCompetitor(String langCode, String countryCode, Date date);

  public List<Competitor> getCompetitorList();

  public List<CompetitorBrand> getCompetitorBrandList(Long competitorId);

  public List<CompetitorProduct> getCompetitorBrandProductList(Long competitorId, Long brandId, String countryCode, Date date, boolean findOtherCountry);

  public CompetitorProduct getCompetitorBrandProduct(Long competitorId, Long brandId, Long productId, Long countryId);

  public List<OoInstances> getMaterialList(Long competitorId, Long brandId, Long productId, Long countryId);

  public List<CompetitorWalterProduct> getCompetitorWalterProduct(Long competitorId, Long brandId, Long productId, Long countryId);

  public List<String> getCertificationIconList(Long competitorId, Long brandId, Long productId, Long countryId);

  public List<OoInstances> getCertificationList(Long competitorId, Long brandId, Long productId, Long countryId);

  public List<OoInstances> getApplicationInstances(Long competitorId, Long brandId, Long productId, Long countryId);

  public List<Country> getCountryList();

  public Competitor saveCompetitor(Competitor c);

  public CompetitorBrand saveCompetitorBrand(CompetitorBrand competitorBrand);

  public CompetitorProduct saveCompetitorProduct(CompetitorProduct competitorProduct);

  public List<OoInstances> getInstanceByClassname(String classname);

  public List<OoInstances> getInstanceByClassname(String classname, String relationType);

  public List<OoInstances> getMesure(String dimension);

  public List<OoClasses> getOoClassesByParentName(String parentName);

  public OoClasses getOoClasses(String className);

  public List<Diluent> getDiluentList(Long langId);

  public Diluent getDiluent(Long langId, Long diluentId);

  public Long getNextProductId();

  public String getInstanceTraduction(String langCode, String instanceGuid, String memberName);

  public String getInstanceTraduction(String countryCode, String langCode, String instanceGuid, String memberName);

  public List<CompetitorHazard> getByHazardType(long competitorId, long brandId, long productId, long countryId, String parentClassName);

  public void deleteMaterial(long competitorId, long brandId, long productId, long countryId);

  public void deleteCertification(long competitorId, long brandId, long productId, long countryId);

  public void deleteCompetitorWalterProduct(long competitorId, long brandId, long productId, long countryId);

  public void deleteApplication(long competitorId, long brandId, long productId, long countryId);

  public List<Action> getActionList(long langId);

  public Action getAction(long actionId, long langId);

  public String getActionText(long actionId, long langId);

  public Action saveAction(Action action);

  public List<String> getWalterProductNumberList(String countryCode);

  public List<WalterProductModel> getWalterProductList(String countryCode, String langCode, Date lastUpdated);

  public WalterProductModel getWalterProduct(String countryCode, String langCode, String productNumber);

  public List<String> getWalterProductDeletedList(String countryCode, String langCode, Date lastUpdated);

  public boolean insertCounter(long competitorId, long brandId, long productId, String countryCode, String userName);


  public String getValue(Object object);

  public List<HazardModel> getHazard(CompetitorProduct cp, String parentHazard, String langCode);

  public String getTemperatureImperial(Object object);

  public String getTradename(String countryCode, String langCode, String productnumber);

//  public List<HazardCategoryTxt> getHazardCategoryList(Long langId);
//
//  public List<HazardTxt> getHazardList(long categoryId, long langId);

  public CompetitorModel getCompetitor(Long productId, String langCode, String countryCode, String userName);

  public List<CompetitorModel> getCompetitorInformation(String countryCode, String langCode, Date date);

  public List<Object[]> getCompetitorList(Long countryId, String keyword);



}
