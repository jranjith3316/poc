/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.globalcustomer;

import com.savoirfairelinux.walter.dao.DatabaseConstants;
import javax.persistence.*;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author jderuere
 */
@Entity
@Table(name = "GA_PRODUCT", schema = DatabaseConstants.WALTERCB_SCHEMA, uniqueConstraints = @UniqueConstraint(name = "GA_PRODUCT_UNIQUE", columnNames = { "FACILITY_ID", "FRANCHISEGUID", "TRADENAMEGUID" }))
public class GaProduct implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(generator = "GA_PRODUCT_ID_SEQ", strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "GA_PRODUCT_ID_SEQ", sequenceName = "GA_PRODUCT_ID_SEQ", schema = DatabaseConstants.WALTERCB_SCHEMA, allocationSize = 1)
    @Column(name = "GA_PRODUCT_ID")
    private Long gaProductId;
    @Column(name = "CREATE_DATE", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date createDate;
    @Column(name = "APPROVAL")
    private String approval;
    @Column(name = "APPLICATION", length = 100)
    private String application;
    @Column(name = "NOTES", length = 250)
    private String notes;
    @JoinColumn(name = "FACILITY_ID", referencedColumnName = "FACILITY_ID")
    @ManyToOne(optional = false)
    private GaFacility facility;
    @Size(min = 1, max = 255)
    @Column(name = "FRANCHISEGUID", nullable = false)
    private String franchiseguid;
    @Size(min = 1, max = 50)
    @Column(name = "TRADENAMEGUID", nullable = false)
    private String tradenameguid;

    @Transient
    private String displayName;

    public GaProduct() {
    }

    public Long getGaProductId() {
        return gaProductId;
    }

    public void setGaProductId(Long gaProductId) {
        this.gaProductId = gaProductId;
    }

    public GaFacility getFacility() {
        return facility;
    }

    public void setFacility(GaFacility facility) {
        this.facility = facility;
    }

    public String getFranchiseguid() {
        return franchiseguid;
    }

    public void setFranchiseguid(String franchiseguid) {
        this.franchiseguid = franchiseguid;
    }

    public String getTradenameguid() {
        return tradenameguid;
    }

    public void setTradenameguid(String tradenameguid) {
        this.tradenameguid = tradenameguid;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getApproval() {
        return approval;
    }

    public void setApproval(String approval) {
        this.approval = approval;
    }

    public String getApplication() {
        return application;
    }

    public void setApplication(String application) {
        this.application = application;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    @Override
    public int hashCode() {
        int hash = (gaProductId != null ? gaProductId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof GaProduct)) {
            return false;
        }
        GaProduct other = (GaProduct) object;
        if (gaProductId == null && other.gaProductId == null) {
            return this == other;
        } else if ((this.gaProductId == null && other.gaProductId != null) || (this.gaProductId != null && !this.gaProductId.equals(other.gaProductId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.globalcustomer.GaProduct[ gaProductId =" + gaProductId + " ]";
    }
}
