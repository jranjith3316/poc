/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.idb;

import com.savoirfairelinux.walter.dao.DatabaseConstants;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "WALTER_PRODUCTS_IMAGES", catalog = "", schema = DatabaseConstants.IDB_SCHEMA)
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "WalterProductsImages.findAll", query = "SELECT w FROM WalterProductsImages w"),
  @NamedQuery(name = "WalterProductsImages.findByProductimageguid", query = "SELECT w FROM WalterProductsImages w WHERE w.productimageguid = :productimageguid"),
  @NamedQuery(name = "WalterProductsImages.findByFilename", query = "SELECT w FROM WalterProductsImages w WHERE w.filename = :filename"),
  @NamedQuery(name = "WalterProductsImages.findByFormat", query = "SELECT w FROM WalterProductsImages w WHERE w.format = :format"),
  @NamedQuery(name = "WalterProductsImages.findByDefaultimage", query = "SELECT w FROM WalterProductsImages w WHERE w.defaultimage = :defaultimage"),
  @NamedQuery(name = "WalterProductsImages.findByLegend", query = "SELECT w FROM WalterProductsImages w WHERE w.legend = :legend"),
  @NamedQuery(name = "WalterProductsImages.findByAdddatetime", query = "SELECT w FROM WalterProductsImages w WHERE w.adddatetime = :adddatetime"),
  @NamedQuery(name = "WalterProductsImages.findByDeletedatetime", query = "SELECT w FROM WalterProductsImages w WHERE w.deletedatetime = :deletedatetime"),
  @NamedQuery(name = "WalterProductsImages.findByUpdatedatetime", query = "SELECT w FROM WalterProductsImages w WHERE w.updatedatetime = :updatedatetime")})
public class WalterProductsImages implements Serializable {
  private static final long serialVersionUID = 1L;
  @Id
  @Basic(optional = false)
  @NotNull
  @Size(min = 1, max = 255)
  @Column(name = "PRODUCTIMAGEGUID")
  private String productimageguid;
  @Size(max = 255)
  @Column(name = "FILENAME")
  private String filename;
  @Size(max = 255)
  @Column(name = "FORMAT")
  private String format;
  @Size(max = 255)
  @Column(name = "DEFAULTIMAGE")
  private String defaultimage;
  @Size(max = 255)
  @Column(name = "LEGEND")
  private String legend;
  @Column(name = "ADDDATETIME")
  @Temporal(TemporalType.TIMESTAMP)
  private Date adddatetime;
  @Column(name = "DELETEDATETIME")
  @Temporal(TemporalType.TIMESTAMP)
  private Date deletedatetime;
  @Column(name = "UPDATEDATETIME")
  @Temporal(TemporalType.TIMESTAMP)
  private Date updatedatetime;
  @JoinColumn(name = "URLGUID", referencedColumnName = "URLGUID")
  @ManyToOne
  private WalterUrl urlguid;
  @JoinColumn(name = "PRODUCTCOUNTRYGUID", referencedColumnName = "PRODUCTCOUNTRYGUID")
  @ManyToOne(optional = false)
  private WalterProductsCountries productcountryguid;
  @JoinColumn(name = "PRODUCTGUID", referencedColumnName = "PRODUCTGUID")
  @ManyToOne(optional = false)
  private WalterProducts productguid;
  @JoinColumn(name = "FILEGUID", referencedColumnName = "FILEGUID")
  @ManyToOne
  private WalterFiles fileguid;
  @JoinColumn(name = "COUNTRYGUID", referencedColumnName = "INSTANCEGUID")
  @ManyToOne(optional = false)
  private OoInstances countryguid;
  @JoinColumn(name = "PRODUCTIMAGEGUID", referencedColumnName = "INSTANCEGUID", insertable = false, updatable = false)
  @OneToOne(optional = false)
  private OoInstances ooInstances;

  public WalterProductsImages() {
  }

  public WalterProductsImages(String productimageguid) {
    this.productimageguid = productimageguid;
  }

  public String getProductimageguid() {
    return productimageguid;
  }

  public void setProductimageguid(String productimageguid) {
    this.productimageguid = productimageguid;
  }

  public String getFilename() {
    return filename;
  }

  public void setFilename(String filename) {
    this.filename = filename;
  }

  public String getFormat() {
    return format;
  }

  public void setFormat(String format) {
    this.format = format;
  }

  public String getDefaultimage() {
    return defaultimage;
  }

  public void setDefaultimage(String defaultimage) {
    this.defaultimage = defaultimage;
  }

  public String getLegend() {
    return legend;
  }

  public void setLegend(String legend) {
    this.legend = legend;
  }

  public Date getAdddatetime() {
    return adddatetime;
  }

  public void setAdddatetime(Date adddatetime) {
    this.adddatetime = adddatetime;
  }

  public Date getDeletedatetime() {
    return deletedatetime;
  }

  public void setDeletedatetime(Date deletedatetime) {
    this.deletedatetime = deletedatetime;
  }

  public Date getUpdatedatetime() {
    return updatedatetime;
  }

  public void setUpdatedatetime(Date updatedatetime) {
    this.updatedatetime = updatedatetime;
  }

  public WalterUrl getUrlguid() {
    return urlguid;
  }

  public void setUrlguid(WalterUrl urlguid) {
    this.urlguid = urlguid;
  }

  public WalterProductsCountries getProductcountryguid() {
    return productcountryguid;
  }

  public void setProductcountryguid(WalterProductsCountries productcountryguid) {
    this.productcountryguid = productcountryguid;
  }

  public WalterProducts getProductguid() {
    return productguid;
  }

  public void setProductguid(WalterProducts productguid) {
    this.productguid = productguid;
  }

  public WalterFiles getFileguid() {
    return fileguid;
  }

  public void setFileguid(WalterFiles fileguid) {
    this.fileguid = fileguid;
  }

  public OoInstances getCountryguid() {
    return countryguid;
  }

  public void setCountryguid(OoInstances countryguid) {
    this.countryguid = countryguid;
  }

  public OoInstances getOoInstances() {
    return ooInstances;
  }

  public void setOoInstances(OoInstances ooInstances) {
    this.ooInstances = ooInstances;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (productimageguid != null ? productimageguid.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof WalterProductsImages)) {
      return false;
    }
    WalterProductsImages other = (WalterProductsImages) object;
    if ((this.productimageguid == null && other.productimageguid != null) || (this.productimageguid != null && !this.productimageguid.equals(other.productimageguid))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.idb.WalterProductsImages[ productimageguid=" + productimageguid + " ]";
  }

}
