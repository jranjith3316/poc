/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "CNT_ACTIVITY", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CntActivity.findAll", query = "SELECT c FROM CntActivity c"),
    @NamedQuery(name = "CntActivity.findByCntId", query = "SELECT c FROM CntActivity c WHERE c.cntActivityPK.cntId = :cntId"),
    @NamedQuery(name = "CntActivity.findByActivityId", query = "SELECT c FROM CntActivity c WHERE c.cntActivityPK.activityId = :activityId")})
public class CntActivity implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected CntActivityPK cntActivityPK;
    @JoinColumn(name = "CNT_ID", referencedColumnName = "CNT_ID", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Cnt cnt;

    public CntActivity() {
    }

    public CntActivity(CntActivityPK cntActivityPK) {
        this.cntActivityPK = cntActivityPK;
    }

    public CntActivity(long cntId, long activityId) {
        this.cntActivityPK = new CntActivityPK(cntId, activityId);
    }

    public CntActivityPK getCntActivityPK() {
        return cntActivityPK;
    }

    public void setCntActivityPK(CntActivityPK cntActivityPK) {
        this.cntActivityPK = cntActivityPK;
    }

    public Cnt getCnt() {
        return cnt;
    }

    public void setCnt(Cnt cnt) {
        this.cnt = cnt;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cntActivityPK != null ? cntActivityPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CntActivity)) {
            return false;
        }
        CntActivity other = (CntActivity) object;
        if ((this.cntActivityPK == null && other.cntActivityPK != null) || (this.cntActivityPK != null && !this.cntActivityPK.equals(other.cntActivityPK))) {
            return false;
        }
        return true;
    }
    
    @PrePersist
    private void prePersist() {
    	if (cnt != null && cntActivityPK != null) {
    		cntActivityPK.setCntId(cnt.getCntId());
    	}
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.CntActivity[ cntActivityPK=" + cntActivityPK + " ]";
    }
}
