/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.service.impl;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.model.Phone;
import com.liferay.portal.model.User;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.savoirfairelinux.walter.dao.globalcustomer.GaFacility;
import com.savoirfairelinux.walter.dao.globalcustomer.GaFeedback;
import com.savoirfairelinux.walter.dao.globalcustomer.GaFeedbackR;
import com.savoirfairelinux.walter.dao.globalcustomer.GaProduct;
import com.savoirfairelinux.walter.dao.globalcustomer.GlobalAccount;
import com.savoirfairelinux.walter.dao.waltercb.Cnt;
import com.savoirfairelinux.walter.dao.waltercb.CntFeedback;
import com.savoirfairelinux.walter.dao.waltercb.CntFeedbackR;
import com.savoirfairelinux.walter.dao.waltercb.CntPicture;
import com.savoirfairelinux.walter.dao.waltercb.CntPictureTxt;
import com.savoirfairelinux.walter.dao.waltercb.CntTxt;
import com.savoirfairelinux.walter.dao.waltercb.Er;
import com.savoirfairelinux.walter.dao.waltercb.ErContaminant;
import com.savoirfairelinux.walter.dao.waltercb.ErPicture;
import com.savoirfairelinux.walter.dao.waltercb.ErPictureTxt;
import com.savoirfairelinux.walter.dao.waltercb.ErTrialTxt;
import com.savoirfairelinux.walter.dao.waltercb.ErTxt;
import com.savoirfairelinux.walter.dao.waltercb.Idea;
import com.savoirfairelinux.walter.dao.waltercb.IdeaFeedback;
import com.savoirfairelinux.walter.dao.waltercb.IdeaFeedbackR;
import com.savoirfairelinux.walter.dao.waltercb.IdeaFile;
import com.savoirfairelinux.walter.dao.waltercb.IdeaTxt;
import com.savoirfairelinux.walter.dao.waltercb.PrPicture;
import com.savoirfairelinux.walter.dao.waltercb.ProductivityReport;
import com.savoirfairelinux.walter.dao.waltercb.UActivity;
import com.savoirfairelinux.walter.dao.waltercb.UContaminant;
import com.savoirfairelinux.walter.dao.waltercb.UIndustry;
import com.savoirfairelinux.walter.dao.waltercb.ULang;
import com.savoirfairelinux.walter.dao.waltercb.UMachinery;
import com.savoirfairelinux.walter.dao.waltercb.UMaterial;
import com.savoirfairelinux.walter.jasper.JasperReportType;
import com.savoirfairelinux.walter.jasper.exceptions.JasperException;
import com.savoirfairelinux.walter.jasper.model.JasperAerosolCalculator;
import com.savoirfairelinux.walter.jasper.model.JasperCrossReferenceAppBean;
import com.savoirfairelinux.walter.jasper.model.JasperExpenseReportBean;
import com.savoirfairelinux.walter.jasper.model.JasperExpenseRptSearchBean;
import com.savoirfairelinux.walter.jasper.model.JasperFacilityBean;
import com.savoirfairelinux.walter.jasper.model.JasperFeedbackBean;
import com.savoirfairelinux.walter.jasper.model.JasperGeographicalCoverageBean;
import com.savoirfairelinux.walter.jasper.model.JasperGlobalCustomerBean;
import com.savoirfairelinux.walter.jasper.model.JasperLabReportBean;
import com.savoirfairelinux.walter.jasper.model.JasperMobileProductivityReportBean;
import com.savoirfairelinux.walter.jasper.model.JasperNaicsSuspectsSearchBean;
import com.savoirfairelinux.walter.jasper.model.JasperNewIdeaReportBean;
import com.savoirfairelinux.walter.jasper.model.JasperPictureBean;
import com.savoirfairelinux.walter.jasper.model.JasperProductBean;
import com.savoirfairelinux.walter.jasper.model.JasperReport;
import com.savoirfairelinux.walter.jasper.model.JasperSolutionsReportBean;
import com.savoirfairelinux.walter.jasper.model.JasperSolutionsReportSimpleBean;
import com.savoirfairelinux.walter.model.DocumentType;
import com.savoirfairelinux.walter.model.PrPictureType;
import com.savoirfairelinux.walter.service.JasperBeanRemote;
import com.savoirfairelinux.walter.util.UserLocationUtil;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.logging.Logger;
import javax.annotation.security.PermitAll;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

/**
 *
 * @author jderuere
 */
@Stateless(name = "JasperBean")
@TransactionManagement(TransactionManagementType.CONTAINER)
@PermitAll
@LocalBean
public class JasperBean implements JasperBeanRemote {

  public static final Logger LOG = Logger.getLogger(JasperBean.class.getCanonicalName());

  private byte[] print(JasperReport report) throws JasperException {
    final byte[] bytes;
    try {
      InputStream inputStream = JasperReport.class.getResourceAsStream(report.getType().getCompiledFile());
      JasperPrint jasperPrint = JasperFillManager.fillReport(inputStream, report.getParameters(), new JRBeanCollectionDataSource(Arrays.asList(report.getJasperBean())));
      bytes = JasperExportManager.exportReportToPdf(jasperPrint);
    } catch (Exception jcre) {
      throw new JasperException(jcre);
    }
    return bytes;
  }

  @Override
  public byte[] printSolutionReport(Cnt cnt, CntTxt cntTxt, List<UActivity> activities, List<UMaterial> materials, List<UIndustry> industries,
          List<UContaminant> contaminants, List<UMachinery> machineries, String organization, byte[] portrait, String reportType,
          long companyId, Locale locale, long langId) throws JasperException {
    JasperSolutionsReportBean entry = new JasperSolutionsReportBean();

    User reporter = null;
    try {
      reporter = UserLocalServiceUtil.getUserByScreenName(companyId, cnt.getCreatorUserName());
      entry.setUserName(reporter.getFullName());
      entry.setJobTitle(reporter.getJobTitle());
      entry.setEmail(reporter.getEmailAddress());
      String location = UserLocationUtil.getLocation(reporter);
      entry.setLocation(location);
    } catch (PortalException e) {
      LOG.warning(e.getMessage());
      entry.setUserName(cnt.getCreatorUserName());
    } catch (SystemException e) {
      LOG.warning(e.getMessage());
      entry.setUserName(cnt.getCreatorUserName());
    }

    entry.setDepartment("Department");
    entry.setOrganization(organization);

    entry.setObjective(cntTxt.getObjective());
    if (cnt.getPublicationDate() != null) {
      entry.setDate(new SimpleDateFormat("dd-MMM-yyyy").format(cnt.getPublicationDate()));
    }
    entry.setCustomer(cnt.getCustomer());
    entry.setNaics(cnt.getPrimaryNaics());
    entry.setRefNumber(cnt.getCntRef());
    entry.setType(reportType);

    StringBuffer sb = new StringBuffer();
    for (UActivity activity : activities) {
      if (sb.length() > 0) {
        sb.append(",");
      }
      sb.append(activity.getActivityDesc());
    }
    entry.setActivity(sb.toString());

    sb = new StringBuffer();
    for (UContaminant contaminant : contaminants) {
      if (sb.length() > 0) {
        sb.append(",");
      }
      sb.append(contaminant.getContaminantDesc());
    }
    entry.setContaminant(sb.toString());

    sb = new StringBuffer();
    for (UMaterial material : materials) {
      if (sb.length() > 0) {
        sb.append(",");
      }
      sb.append(material.getMaterialDesc());
    }
    entry.setMaterial(sb.toString());

    sb = new StringBuffer();
    for (UIndustry industry : industries) {
      if (sb.length() > 0) {
        sb.append(",");
      }
      sb.append(industry.getIndustryDesc());
    }
    entry.setIndustry(sb.toString());

    sb = new StringBuffer();
    for (UMachinery machinery : machineries) {
      if (sb.length() > 0) {
        sb.append(",");
      }
      sb.append(machinery.getMachineryDesc());
    }
    entry.setMachinery(sb.toString());

    entry.setProducts(cnt.getCntProductList());
    entry.setCurrentProcess(sanitize(cntTxt.getCurrentProcess()));
    entry.setWalterSolution(sanitize(cntTxt.getWalterSolution()));
    entry.setComment(sanitize(cntTxt.getCntComment()));

    List<String> keySalesAdvantages = new ArrayList<String>();
    if (cntTxt.getKeySaleAdvantage1() != null) {
      keySalesAdvantages.add(cntTxt.getKeySaleAdvantage1());
    }
    if (cntTxt.getKeySaleAdvantage2() != null) {
      keySalesAdvantages.add(cntTxt.getKeySaleAdvantage2());
    }
    if (cntTxt.getKeySaleAdvantage3() != null) {
      keySalesAdvantages.add(cntTxt.getKeySaleAdvantage3());
    }
    if (cntTxt.getKeySaleAdvantage4() != null) {
      keySalesAdvantages.add(cntTxt.getKeySaleAdvantage4());
    }
    if (cntTxt.getKeySaleAdvantage5() != null) {
      keySalesAdvantages.add(cntTxt.getKeySaleAdvantage5());
    }
    entry.setKeySalesAdvantages(keySalesAdvantages);

    List<JasperFeedbackBean> feedbacks = new ArrayList<JasperFeedbackBean>();
    for (CntFeedback cntFeedback : cnt.getCntFeedbackList()) {
      JasperFeedbackBean feedback = new JasperFeedbackBean();
      feedback.setDate(new SimpleDateFormat("dd-MMM-yyyy").format(cntFeedback.getDateCreated()));
      try {
        User user = UserLocalServiceUtil.getUserByScreenName(companyId, cntFeedback.getUserName());
        feedback.setCreator(user.getFullName());
      } catch (PortalException e) {
        LOG.warning(e.getMessage());
        feedback.setCreator(cntFeedback.getUserName());
      } catch (SystemException e) {
        LOG.warning(e.getMessage());
        feedback.setCreator(cntFeedback.getUserName());
      }

      feedback.setComment(cntFeedback.getFeedbackDesc());
      feedback.setRating(cntFeedback.getRanking());
      feedback.setRatingImage(getRatingImage(cntFeedback.getRanking()));
      feedback.setReply(false);
      feedbacks.add(feedback);

      for (CntFeedbackR cntFeedbackReply : cnt.getCntFeedbackRList()) {
        if (cntFeedbackReply != null && cntFeedbackReply.getCntFeedbackRPK().getFeedbackId() == cntFeedback.getFeedbackId()) {
          JasperFeedbackBean feedbackReply = new JasperFeedbackBean();
          feedbackReply.setDate(new SimpleDateFormat("dd-MMM-yyyy").format(cntFeedbackReply.getDateCreated()));
          feedbackReply.setCreator(reporter.getFullName());
          feedbackReply.setComment(cntFeedbackReply.getReplyDesc());
          feedbackReply.setRatingImage(JasperReportType.SOLUTION_REPORT.getImagesPath("star.png"));
          feedbackReply.setReply(true);
          feedbacks.add(feedbackReply);
        }
      }
    }
    entry.setFeedback(feedbacks);

    List<JasperPictureBean> picturesBean = new ArrayList<JasperPictureBean>();
    for (CntPicture document : cnt.getCntPictureList()) {
      if (document.getType() != null && document.getType().equals(DocumentType.PICTURE.getType())) {
        JasperPictureBean pictureBean = new JasperPictureBean();
        pictureBean.setImage(new ByteArrayInputStream(document.getBlobContent()));
        for (CntPictureTxt pictureTxt : document.getCntPictureTxtSet()) {
          if (pictureTxt.getCntPictureTxtPK().getLangId() == langId) {
            pictureBean.setDescription(pictureTxt.getPictureTxt());
            break;
          } else if (pictureTxt.getCntPictureTxtPK().getLangId() == ULang.ENGLISH_ID) {
            pictureBean.setDescription(pictureTxt.getPictureTxt());
          }
        }
        picturesBean.add(pictureBean);
      }
    }

    entry.setImages(picturesBean);

    entry.setRatingCount(cnt.getRatingCount() != null ? cnt.getRatingCount().toString() : "0");
    entry.setRatingAverage(cnt.getRatingAvg() != null ? cnt.getRatingAvg().toString() : "0");
    if (portrait != null) {
      entry.setPortrait(new ByteArrayInputStream(portrait));
    }

    JasperReport report = new JasperReport(JasperReportType.SOLUTION_REPORT, locale);
    report.setJasperBean(entry);
    return print(report);
  }

  @Override
  public byte[] printCuttingProductivityReport(ProductivityReport report, long companyId, Locale locale, long langId) throws JasperException {
    return printProductivityReport(report, companyId, JasperReportType.PRODUCTIVITY_REPORT_CUTTING, locale, langId);
  }

  @Override
  public byte[] printGrindingProductivityReport(ProductivityReport report, long companyId, Locale locale, long langId) throws JasperException {
    return printProductivityReport(report, companyId, JasperReportType.PRODUCTIVITY_REPORT_GRINDING, locale, langId);
  }

  private byte[] printProductivityReport(ProductivityReport report, long companyId, JasperReportType type, Locale locale, long langId) throws JasperException {
    JasperReport jasperReport = new JasperReport(type, locale);

    String frontImage = "productivity_front.jpg";
    if (langId == 2) {
      frontImage = "productivity_front_fr.jpg";
    }

    jasperReport.addParameter("FRONT_IMAGE", type.getImagesPath(frontImage));
    jasperReport.addParameter("LOGO", type.getImagesPath("walter_logo.gif"));
    jasperReport.addParameter("BANNER", type.getImagesPath("productivity_banner.jpg"));
    jasperReport.addParameter("FOOTER", type.getImagesPath("productivity_footer.jpg"));
    try {
      User user = UserLocalServiceUtil.getUserByScreenName(companyId, report.getSaleRepresentative());
      jasperReport.addParameter("SALE_REPRESENTATIVE", user.getFullName());
      String phoneNumber = "";
      for (Phone phone : user.getPhones()) {
        if (phone.getTypeId() == 11008) {
          phoneNumber = phone.getNumber();
          break;
        }
      }
      jasperReport.addParameter("SALE_REP_PHONE", phoneNumber);
      jasperReport.addParameter("SALE_REP_EMAIL", user.getEmailAddress());
    } catch (PortalException e) {
      LOG.warning(e.getMessage());
      jasperReport.addParameter("SALE_REPRESENTATIVE", report.getSaleRepresentative());
    } catch (SystemException e) {
      LOG.warning(e.getMessage());
      jasperReport.addParameter("SALE_REPRESENTATIVE", report.getSaleRepresentative());
    }

    Set<PrPicture> walterBeforePicture = new HashSet<PrPicture>();
    Set<PrPicture> walterAfterPicture = new HashSet<PrPicture>();
    Set<PrPicture> competitorBeforePicture = new HashSet<PrPicture>();
    Set<PrPicture> competitorAfterPicture = new HashSet<PrPicture>();

    for (PrPicture picture : report.getWalterResult().getPictures()) {
      picture.setBlobContentInputStream(new ByteArrayInputStream(picture.getBlobContent()));
      if (picture.getType().equals(PrPictureType.BEFORE)) {
        walterBeforePicture.add(picture);
      } else {
        walterAfterPicture.add(picture);
      }
    }

    for (PrPicture picture : report.getCompetitorResult().getPictures()) {
      picture.setBlobContentInputStream(new ByteArrayInputStream(picture.getBlobContent()));
      if (picture.getType().equals(PrPictureType.BEFORE)) {
        competitorBeforePicture.add(picture);
      } else {
        competitorAfterPicture.add(picture);
      }
    }

    jasperReport.addParameter("WALTER_BEFORE_PICTURES", walterBeforePicture);
    jasperReport.addParameter("WALTER_AFTER_PICTURES", walterAfterPicture);
    jasperReport.addParameter("COMPETITOR_BEFORE_PICTURES", competitorBeforePicture);
    jasperReport.addParameter("COMPETITOR_AFTER_PICTURES", competitorAfterPicture);

    jasperReport.setJasperBean(report);
    return print(jasperReport);
  }

  @Override
  public byte[] printBioCircleLabReport(Er er, ErTxt erTxt, List<ErTrialTxt> trialTexts, long langId, long companyId, Locale locale) throws JasperException {
    JasperReport report = generateJasperLabReport(er, erTxt, trialTexts, null, langId, companyId, JasperReportType.LAB_REPORT_BIOCIRCLE, locale);
    ((JasperLabReportBean) report.getJasperBean()).setLogoISO(JasperReportType.LAB_REPORT_BIOCIRCLE.getImagesPath("iso14001_logo.jpg"));
    return print(report);
  }

  @Override
  public byte[] printWalterLabReport(Er er, ErTxt erTxt, List<ErTrialTxt> trialTexts, List<UContaminant> contaminants, long langId, long companyId, Locale locale) throws JasperException {
    JasperReport report = generateJasperLabReport(er, erTxt, trialTexts, contaminants, langId, companyId, JasperReportType.LAB_REPORT_WALTER, locale);
    ((JasperLabReportBean) report.getJasperBean()).setLogoFooter(JasperReportType.LAB_REPORT_WALTER.getImagesPath("walter_logo.gif"));
    return print(report);
  }

  private JasperReport generateJasperLabReport(Er er, ErTxt erTxt, List<ErTrialTxt> trialTexts, List<UContaminant> contaminants, long langId, long companyId, JasperReportType type, Locale locale) throws JasperException {
    JasperLabReportBean jasperBean = new JasperLabReportBean();
    jasperBean.setLogoHeader(JasperReportType.LAB_REPORT_WALTER.getImagesPath("biocircle_logo2.jpg"));
    try {
      User reporter = UserLocalServiceUtil.getUserByScreenName(companyId, er.getCreatorUserName());
      jasperBean.setCreatorUserName(reporter.getFullName());
    } catch (PortalException e) {
      LOG.warning(e.getMessage());
      jasperBean.setCreatorUserName(er.getCreatorUserName());
    } catch (SystemException e) {
      LOG.warning(e.getMessage());
      jasperBean.setCreatorUserName(er.getCreatorUserName());
    }
    jasperBean.setReport(er);
    jasperBean.setText(erTxt);
    jasperBean.setTrialTexts(trialTexts);

    StringBuilder builderContaminant = new StringBuilder();

    if (!er.getErContaminantSet().isEmpty() && contaminants != null && contaminants.size() > 0) {

      for (ErContaminant erContaminant : er.getErContaminantSet()) {
        for (UContaminant contaminant : contaminants) {
          if (erContaminant.getErContaminantPK().getContaminantId() == contaminant.getUContaminantPK().getContaminantId()
                  && erContaminant.getErContaminantPK().getContaminantId() != 0) {
            if (builderContaminant.length() > 0) {
              builderContaminant.append(", ");
            }
            builderContaminant.append(contaminant.getContaminantDesc());
            break;
          }
        }
        if (erContaminant.getErContaminantPK().getContaminantId() == 0) {
          if (builderContaminant.length() > 0) {
            builderContaminant.append(", ");
          }
          builderContaminant.append(erTxt.getOtherContaminant());
        }
      }
    }

    jasperBean.setContaminant(builderContaminant.toString());

    List<ErPicture> pictures = er.getErPictureList();
    Collections.sort(pictures, new Comparator<ErPicture>() {
      @Override
      public int compare(ErPicture o1, ErPicture o2) {
        return Long.valueOf(o1.getPictureSeq()).compareTo(o2.getPictureSeq());
      }
    });

    List<JasperPictureBean> picturesBean = new ArrayList<JasperPictureBean>();
    for (ErPicture document : pictures) {
      if (document.getType() != null && document.getType().equals(DocumentType.PICTURE.getType())) {
        JasperPictureBean pictureBean = new JasperPictureBean();
        pictureBean.setImage(new ByteArrayInputStream(document.getBlobContent()));
        for (ErPictureTxt erPictureTxt : document.getErPictureTxtSet()) {
          if (erPictureTxt.getErPictureTxtPK().getLangId() == langId) {
            pictureBean.setDescription(erPictureTxt.getPictureTxt());
            break;
          } else if (erPictureTxt.getErPictureTxtPK().getLangId() == ULang.ENGLISH_ID) {
            pictureBean.setDescription(erPictureTxt.getPictureTxt());
          }
        }
        picturesBean.add(pictureBean);
      }
    }

    jasperBean.setPictures(picturesBean);
    JasperReport report = new JasperReport(type, locale);
    report.setJasperBean(jasperBean);
    return report;
  }

  @Override
  public byte[] printFacilityReport(GaFacility facility, String organization, long companyId, Locale locale) throws JasperException {
    JasperFacilityBean entry = new JasperFacilityBean();
    entry.setAccountName(facility.getGlobalAccount().getName());
    entry.setKeyContact(facility.getKeyContact());
    entry.setFacilityName(facility.getName());
    entry.setAddress(facility.getAddress());
    entry.setCity(facility.getCity());
    entry.setPostalCode(facility.getPostalCode());
    entry.setProvinceState(facility.getState());
    entry.setCountry(facility.getCountry().getDescription());
    entry.setCategory(facility.getCategory().getName());
    entry.setMainContact(facility.getMainContact());
    entry.setDepartment(facility.getDepartment());
    entry.setEmailAddress(facility.getEmail());
    entry.setPhoneNumber(facility.getPhoneNumber());
    entry.setOrganization(organization);

    byte[] logo = facility.getGlobalAccount().getLogo();
    if (logo != null) {
      entry.setLogo(new ByteArrayInputStream(logo));
    }

    if (facility.getSaleRepresentative() != null) {
      try {
        User user = UserLocalServiceUtil.getUserByScreenName(companyId, entry.getSaleRepresentative());
        entry.setSaleRepresentative(user.getFullName());
        entry.setSaleRepresentativeEmailAddress(user.getEmailAddress());
      } catch (PortalException e) {
        LOG.warning(e.getMessage());
        entry.setSaleRepresentative(entry.getSaleRepresentative());
      } catch (SystemException e) {
        LOG.warning(e.getMessage());
        entry.setSaleRepresentative(entry.getSaleRepresentative());
      }
    }

    List<GaProduct> products = facility.getProducts();
    List<JasperProductBean> productEntries = new ArrayList<JasperProductBean>();
    for (GaProduct product : products) {
      JasperProductBean productEntry = new JasperProductBean();
      productEntry.setDate(new SimpleDateFormat("yyyy-dd-MM").format(product.getCreateDate()));
      productEntry.setProductName(product.getDisplayName());
      productEntry.setApprovalNumber(product.getApproval());
      productEntry.setApplication(product.getApplication());
      productEntry.setNotes(product.getNotes());

      productEntries.add(productEntry);
    }
    entry.setProducts(productEntries);

    List<JasperFeedbackBean> feedbackEntries = new ArrayList<JasperFeedbackBean>();
    for (GaFeedback feedback : facility.getFeedbacks()) {
      JasperFeedbackBean feedbackEntry = new JasperFeedbackBean();
      feedbackEntry.setDate(new SimpleDateFormat("dd-MMM-yyyy").format(feedback.getDateCreated()));

      try {
        User user = UserLocalServiceUtil.getUserByScreenName(companyId, feedback.getContributor());
        feedbackEntry.setCreator(user.getFullName());
      } catch (PortalException e) {
        LOG.warning(e.getMessage());
        feedbackEntry.setCreator(feedback.getContributor());
      } catch (SystemException e) {
        LOG.warning(e.getMessage());
        feedbackEntry.setCreator(feedback.getContributor());
      }

      feedbackEntry.setComment(feedback.getFeedbackDesc());
      feedbackEntry.setReply(false);

      feedbackEntries.add(feedbackEntry);

      for (GaFeedbackR feedbackReply : feedback.getFeedbackReplies()) {
        JasperFeedbackBean feedbackReplyEntry = new JasperFeedbackBean();
        feedbackReplyEntry.setDate(new SimpleDateFormat("dd-MMM-yyyy").format(feedbackReply.getDateCreated()));
        try {
          User user = UserLocalServiceUtil.getUserByScreenName(companyId, feedbackReply.getContributor());
          feedbackReplyEntry.setCreator(user.getFullName());
        } catch (PortalException e) {
          LOG.warning(e.getMessage());
          feedbackReplyEntry.setCreator(feedbackReply.getContributor());
        } catch (SystemException e) {
          LOG.warning(e.getMessage());
          feedbackReplyEntry.setCreator(feedbackReply.getContributor());
        }
        feedbackReplyEntry.setComment(feedbackReply.getReplyDesc());
        feedbackReplyEntry.setReply(true);

        feedbackEntries.add(feedbackReplyEntry);
      }
    }
    entry.setFeedbacks(feedbackEntries);

    JasperReport report = new JasperReport(JasperReportType.FACILITY, locale);
    report.setJasperBean(entry);
    return print(report);
  }

  @Override
  public byte[] printGlobalCustomerReport(GlobalAccount globalAccount, String organization, long langId, long companyId, Locale locale) throws JasperException {
    JasperGlobalCustomerBean entry = new JasperGlobalCustomerBean();

    entry.setAccountName(globalAccount.getName());
    entry.setOrganization(organization);

    byte[] logo = globalAccount.getLogo();
    if (logo != null) {
      entry.setLogo(new ByteArrayInputStream(logo));
    }

        // we populate two maps for customer/not-customer data:
    // - First we decide if it a customer or not
    // - Then we convert the GaFacility to JasperFacilityBean
    Map<String, List<JasperFacilityBean>> customersMap = new HashMap<String, List<JasperFacilityBean>>();
    Map<String, List<JasperFacilityBean>> notCustomersMap = new HashMap<String, List<JasperFacilityBean>>();
    for (GaFacility facility : globalAccount.getFacilities()) {
      if (facility.getProducts().isEmpty()) {
        addFacility(notCustomersMap, facility);
      } else {
        addFacility(customersMap, facility);
      }
    }
    entry.setCustomersAreas(toJasperBean(customersMap));
    entry.setNotCustomersAreas(toJasperBean(notCustomersMap));

    // solution reports
    List<JasperSolutionsReportSimpleBean> reportEntries = new ArrayList<JasperSolutionsReportSimpleBean>();
    for (Cnt cnt : globalAccount.getReports()) {
      JasperSolutionsReportSimpleBean reportEntry = new JasperSolutionsReportSimpleBean();
      reportEntry.setDate(new SimpleDateFormat("yyy-MM-dd").format(cnt.getPublicationDate()));
      reportEntry.setRatingAverage(cnt.getRatingAvg() != null ? cnt.getRatingAvg().toString() : "0");
      reportEntry.setProducts(cnt.getProductName());

      // objective
      CntTxt cntTxt = null;
      CntTxt cntEn = null;
      for (CntTxt txt : cnt.getCntTxtList()) {
        if (txt.getCntTxtPK().getLangId() == langId) {
          cntTxt = txt;
        } else if (txt.getCntTxtPK().getLangId() == ULang.ENGLISH_ID) {
          cntEn = txt;
        }
      }
      if (cntTxt == null) {
        cntTxt = cntEn;
      }
      reportEntry.setObjective(cntTxt.getObjective());

      if (cnt.getCreatorUserName() != null) {
        try {
          User user = UserLocalServiceUtil.getUserByScreenName(companyId, cnt.getCreatorUserName());
          reportEntry.setCreator(user.getFullName());
        } catch (PortalException e) {
          LOG.warning(e.getMessage());
          reportEntry.setCreator(cnt.getCreatorUserName());
        } catch (SystemException e) {
          LOG.warning(e.getMessage());
          reportEntry.setCreator(cnt.getCreatorUserName());
        }
      }
      reportEntries.add(reportEntry);
    }
    entry.setReports(reportEntries);

    JasperReport report = new JasperReport(JasperReportType.GLOBAL_CUSTOMER, locale);
    report.setJasperBean(entry);
    return print(report);
  }

  @Override
  public byte[] printNewIdeaReport(Idea idea, IdeaTxt ideaTxt, String organization, String location, byte[] portrait, long companyId, Locale locale) throws JasperException {
    JasperNewIdeaReportBean entry = new JasperNewIdeaReportBean();
    User reporter = null;
    try {
      reporter = UserLocalServiceUtil.getUserByScreenName(companyId, idea.getCreatorUserName());
      entry.setUserName(reporter.getFullName());
      entry.setJobTitle(reporter.getJobTitle());
      entry.setEmail(reporter.getEmailAddress());
    } catch (PortalException e) {
      LOG.warning(e.getMessage());
      entry.setUserName(idea.getCreatorUserName());
    } catch (SystemException e) {
      LOG.warning(e.getMessage());
      entry.setUserName(idea.getCreatorUserName());
    }
    entry.setDepartment("Department");
    entry.setLocation(location);
    entry.setOrganization(organization);

    entry.setTitle(ideaTxt.getTitle());
    if (idea.getPublishedDate() != null) {
      entry.setDate(new SimpleDateFormat("dd-MMM-yyyy").format(idea.getPublishedDate()));
    }
    entry.setRefNumber(idea.getIdeaRef());

    entry.setProductName(idea.getProductName());
    entry.setDescription(ideaTxt.getExplanation());

    List<JasperFeedbackBean> feedbacks = new ArrayList<JasperFeedbackBean>();
    for (IdeaFeedback ideaFeedback : idea.getIdeaFeedbackList()) {
      JasperFeedbackBean feedback = new JasperFeedbackBean();
      feedback.setDate(new SimpleDateFormat("dd-MMM-yyyy").format(ideaFeedback.getCreatedDate()));
      try {
        User user = UserLocalServiceUtil.getUserByScreenName(companyId, ideaFeedback.getFeedbackUserName());
        feedback.setCreator(user.getFullName());
      } catch (PortalException e) {
        LOG.warning(e.getMessage());
        feedback.setCreator(ideaFeedback.getFeedbackUserName());
      } catch (SystemException e) {
        LOG.warning(e.getMessage());
        feedback.setCreator(ideaFeedback.getFeedbackUserName());
      }

      feedback.setComment(ideaFeedback.getFeedbackDescription());
      feedback.setReply(false);
      feedbacks.add(feedback);

      for (IdeaFeedbackR ideaFeedbackReply : ideaFeedback.getIdeaFeedbackRSet()) {
        if (ideaFeedbackReply != null && ideaFeedbackReply.getIdeaFeedback().getFeedbackId().equals(ideaFeedback.getFeedbackId())) {
          JasperFeedbackBean feedbackReply = new JasperFeedbackBean();
          feedbackReply.setDate(new SimpleDateFormat("dd-MMM-yyyy").format(ideaFeedbackReply.getCreatedDate()));
          feedbackReply.setCreator(reporter.getFullName());
          feedbackReply.setComment(ideaFeedbackReply.getReplyDescription());
          feedbackReply.setRatingImage(JasperReportType.NEW_IDEA.getImagesPath("star.png"));
          feedbackReply.setReply(true);
          feedbacks.add(feedbackReply);
        }
      }
    }
    entry.setFeedback(feedbacks);

    List<InputStream> images = new ArrayList<InputStream>();
    for (IdeaFile document : idea.getIdeaFileSet()) {
      if (document.getType() != null && document.getType().equals(DocumentType.PICTURE.getType())) {
        images.add(new ByteArrayInputStream(document.getBlobContent()));
      }
    }
    entry.setImages(images);
    if (portrait != null) {
      entry.setPortrait(new ByteArrayInputStream(portrait));
    }
    JasperReport report = new JasperReport(JasperReportType.NEW_IDEA, locale);
    report.setJasperBean(entry);
    return print(report);
  }

  private void addFacility(Map<String, List<JasperFacilityBean>> customers, GaFacility facility) {
    // get the coverage name (this is a transient field)
    String coverage = facility.getCountry().getGeographicalCoverage().getName();

    // get the corresponding facilities
    List<JasperFacilityBean> facilities = customers.get(coverage);

    // if no facilities yet, we create the list
    if (facilities == null) {
      facilities = new ArrayList<JasperFacilityBean>();
      customers.put(coverage, facilities);
    }

    // convert from GaFacility to JasperFacilityBean
    JasperFacilityBean facilityEntry = new JasperFacilityBean();
    facilityEntry.setFacilityName(facility.getName());
    facilityEntry.setCategory(facility.getCategory().getName());
    facilityEntry.setCountry(facility.getCountry().getDescription());

    facilities.add(facilityEntry);
  }

  /**
   * We populate the Jasper bean with the maps because Jasper seems to not
   * support maps as parameter
   *
   */
  private List<JasperGeographicalCoverageBean> toJasperBean(Map<String, List<JasperFacilityBean>> customersMap) {
    List<JasperGeographicalCoverageBean> customersAreas = new ArrayList<JasperGeographicalCoverageBean>();

    for (String coverage : customersMap.keySet()) {
      List<JasperFacilityBean> facilities = customersMap.get(coverage);

            // if there are facilities in this area, we create a new JasperGeographicalCoverageBean and add it to the
      // list
      if (facilities != null) {
        JasperGeographicalCoverageBean customersArea = new JasperGeographicalCoverageBean();
        customersArea.setName(coverage);
        customersArea.setFacilities(facilities);

        customersAreas.add(customersArea);
      }
    }

    return customersAreas;
  }

  private String sanitize(String string) {
    if (string == null) {
      return "";
    }
    return string.trim().replace("\r\n", " ");
  }

  private String getRatingImage(Short rating) {
    if (rating == null) {
      return JasperReportType.SOLUTION_REPORT.getImagesPath("blank.png");
    }
    if (rating > 2) {
      return JasperReportType.SOLUTION_REPORT.getImagesPath("thumbs_up.png");
    }
    return JasperReportType.SOLUTION_REPORT.getImagesPath("thumbs_down.png");
  }

  @Override
  public byte[] printWalterExpenseReport(JasperExpenseReportBean jasperExpenseReportBean, long langId, long companyId, Locale locale) throws JasperException {
    JasperReport report = new JasperReport(JasperReportType.EXPENSE_REPORT, locale);
    report.setJasperBean(jasperExpenseReportBean);
    return print(report);

  }

  @Override
  public byte[] printWalterExpenseReportSearch(JasperExpenseRptSearchBean jasperExpenseRptSearchBean, long langId, long companyId, Locale locale) throws JasperException {
    JasperReport report = new JasperReport(JasperReportType.EXPENSE_REPORT_SEARCH, locale);
    report.setJasperBean(jasperExpenseRptSearchBean);
    return print(report);

  }

  @Override
  public byte[] printNaicsSuspectsSearch(JasperNaicsSuspectsSearchBean jasperNaicsSuspectsSearchBean, long langId, long companyId, Locale locale) throws JasperException {
    JasperReport report = new JasperReport(JasperReportType.NAICS_SUSPECTS_SEARCH, locale);
    report.setJasperBean(jasperNaicsSuspectsSearchBean);
    return print(report);

  }

  public byte[] printAerosolCalculatorReport(JasperAerosolCalculator jasperAerosolCalculator, long langId, long companyId, Locale locale) throws JasperException {
    JasperReport report = new JasperReport(JasperReportType.AEROSOL_CALCULATOR, locale);
    jasperAerosolCalculator.setLogoHeader(JasperReportType.AEROSOL_CALCULATOR.getImagesPath("walter_logo.gif"));
    jasperAerosolCalculator.setLogoFooter(JasperReportType.AEROSOL_CALCULATOR.getImagesPath("walter_logo.gif"));

    report.setJasperBean(jasperAerosolCalculator);
    return print(report);
  }

  public byte[] printMobileProductivityReportCuttingReport(JasperMobileProductivityReportBean jasperMobileProductivityReportBean, long langId, long companyId, Locale locale) throws JasperException {
    jasperMobileProductivityReportBean.setHeaderImage(JasperReportType.MOBILE_PRODUCTIVITY_REPORT_CUTTING.getImagesPath("mobile_productivity_cutting.jpg"));
    jasperMobileProductivityReportBean.setHeaderImageSecondPage(JasperReportType.MOBILE_PRODUCTIVITY_REPORT_CUTTING.getImagesPath("mobile_productivity_cutting_2.jpg"));
    jasperMobileProductivityReportBean.setLogoHeaderImage(JasperReportType.MOBILE_PRODUCTIVITY_REPORT_GRINDING.getImagesPath("logo_1_en.png"));
    jasperMobileProductivityReportBean.setLogoHeaderImageSecondPage(JasperReportType.MOBILE_PRODUCTIVITY_REPORT_GRINDING.getImagesPath("logo_2_en.png"));
    jasperMobileProductivityReportBean.setIconImageSecondPage(JasperReportType.MOBILE_PRODUCTIVITY_REPORT_CUTTING.getImagesPath("mobile_productivity_cutting_icon.jpg"));
    jasperMobileProductivityReportBean.setWalterLogo(JasperReportType.MOBILE_PRODUCTIVITY_REPORT_CUTTING.getImagesPath("logo_walter.jpg"));
    jasperMobileProductivityReportBean.setVsLogo(JasperReportType.MOBILE_PRODUCTIVITY_REPORT_CUTTING.getImagesPath("vs_logo.jpg"));

    JasperReport jasperReport = new JasperReport(JasperReportType.MOBILE_PRODUCTIVITY_REPORT_CUTTING, locale);
    jasperReport.setJasperBean(jasperMobileProductivityReportBean);
    return print(jasperReport);
  }

  public byte[] printMobileProductivityReportGrindingReport(JasperMobileProductivityReportBean jasperMobileProductivityReportBean, long langId, long companyId, Locale locale) throws JasperException {
    jasperMobileProductivityReportBean.setHeaderImage(JasperReportType.MOBILE_PRODUCTIVITY_REPORT_GRINDING.getImagesPath("mobile_productivity_grinding.jpg"));
    jasperMobileProductivityReportBean.setHeaderImageSecondPage(JasperReportType.MOBILE_PRODUCTIVITY_REPORT_GRINDING.getImagesPath("mobile_productivity_grinding_2.jpg"));
    jasperMobileProductivityReportBean.setLogoHeaderImage(JasperReportType.MOBILE_PRODUCTIVITY_REPORT_GRINDING.getImagesPath("logo_1_en.png"));
    jasperMobileProductivityReportBean.setLogoHeaderImageSecondPage(JasperReportType.MOBILE_PRODUCTIVITY_REPORT_GRINDING.getImagesPath("logo_2_en.png"));
    jasperMobileProductivityReportBean.setIconImageSecondPage(JasperReportType.MOBILE_PRODUCTIVITY_REPORT_GRINDING.getImagesPath("mobile_productivity_grinding_icon.jpg"));
    jasperMobileProductivityReportBean.setWalterLogo(JasperReportType.MOBILE_PRODUCTIVITY_REPORT_GRINDING.getImagesPath("logo_walter.jpg"));
    jasperMobileProductivityReportBean.setVsLogo(JasperReportType.MOBILE_PRODUCTIVITY_REPORT_GRINDING.getImagesPath("vs_logo.jpg"));

    JasperReport jasperReport = new JasperReport(JasperReportType.MOBILE_PRODUCTIVITY_REPORT_GRINDING, locale);
    jasperReport.setJasperBean(jasperMobileProductivityReportBean);
    return print(jasperReport);
  }

  public byte[] printMobileProductivityReportSandingReport(JasperMobileProductivityReportBean jasperMobileProductivityReportBean, long langId, long companyId, Locale locale) throws JasperException {
    jasperMobileProductivityReportBean.setHeaderImage(JasperReportType.MOBILE_PRODUCTIVITY_REPORT_SANDING.getImagesPath("mobile_productivity_sanding.jpg"));
    jasperMobileProductivityReportBean.setHeaderImageSecondPage(JasperReportType.MOBILE_PRODUCTIVITY_REPORT_SANDING.getImagesPath("mobile_productivity_sanding_2.jpg"));
    jasperMobileProductivityReportBean.setLogoHeaderImage(JasperReportType.MOBILE_PRODUCTIVITY_REPORT_GRINDING.getImagesPath("logo_1_en.png"));
    jasperMobileProductivityReportBean.setLogoHeaderImageSecondPage(JasperReportType.MOBILE_PRODUCTIVITY_REPORT_GRINDING.getImagesPath("logo_2_en.png"));
    jasperMobileProductivityReportBean.setIconImageSecondPage(JasperReportType.MOBILE_PRODUCTIVITY_REPORT_SANDING.getImagesPath("mobile_productivity_sanding_icon.jpg"));
    jasperMobileProductivityReportBean.setWalterLogo(JasperReportType.MOBILE_PRODUCTIVITY_REPORT_SANDING.getImagesPath("logo_walter.jpg"));
    jasperMobileProductivityReportBean.setVsLogo(JasperReportType.MOBILE_PRODUCTIVITY_REPORT_SANDING.getImagesPath("vs_logo.jpg"));


    JasperReport jasperReport = new JasperReport(JasperReportType.MOBILE_PRODUCTIVITY_REPORT_SANDING, locale);
    jasperReport.setJasperBean(jasperMobileProductivityReportBean);
    return print(jasperReport);
  }

  @Override
  public byte[] printMobileCrossReferenceAppReport(JasperCrossReferenceAppBean jasperCrossReferenceAppBean, Locale locale ) throws JasperException {
    jasperCrossReferenceAppBean.setHeaderImage(JasperReportType.MOBILE_CROSS_REFERENCE_APP.getImagesPath("cross_reference_app.jpg"));
    jasperCrossReferenceAppBean.setHeaderImageLogo(JasperReportType.MOBILE_CROSS_REFERENCE_APP.getImagesPath("logo_1_en.png"));
    JasperReport jasperReport = new JasperReport(JasperReportType.MOBILE_CROSS_REFERENCE_APP, locale);
    jasperReport.setJasperBean(jasperCrossReferenceAppBean);
    return print(jasperReport);
  }
}