/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.walter;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import java.util.Set;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(catalog = "", schema = DatabaseConstants.WALTER_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Expense.findAll", query = "SELECT e FROM Expense e"),
    @NamedQuery(name = "Expense.findByExpenseId", query = "SELECT e FROM Expense e WHERE e.expenseId = :expenseId"),
    @NamedQuery(name = "Expense.findByCountryId", query = "SELECT e FROM Expense e WHERE e.countryId = :countryId"),
    @NamedQuery(name = "Expense.findByGlCode", query = "SELECT e FROM Expense e WHERE e.glCode = :glCode"),
    @NamedQuery(name = "Expense.findByTaxCalcMethod", query = "SELECT e FROM Expense e WHERE e.taxCalcMethod = :taxCalcMethod"),
    @NamedQuery(name = "Expense.findByDetail", query = "SELECT e FROM Expense e WHERE e.detail = :detail"),
    @NamedQuery(name = "Expense.findByTotal", query = "SELECT e FROM Expense e WHERE e.total = :total"),
    @NamedQuery(name = "Expense.findByTip", query = "SELECT e FROM Expense e WHERE e.tip = :tip"),
    @NamedQuery(name = "Expense.findByNbrNights", query = "SELECT e FROM Expense e WHERE e.nbrNights = :nbrNights"),
    @NamedQuery(name = "Expense.findByHotelName", query = "SELECT e FROM Expense e WHERE e.hotelName = :hotelName"),
    @NamedQuery(name = "Expense.findByOtherDesc", query = "SELECT e FROM Expense e WHERE e.otherDesc = :otherDesc"),
    @NamedQuery(name = "Expense.findByInternet", query = "SELECT e FROM Expense e WHERE e.internet = :internet"),
    @NamedQuery(name = "Expense.findByTravelCar", query = "SELECT e FROM Expense e WHERE e.travelCar = :travelCar"),
    @NamedQuery(name = "Expense.findByRolesAccess", query = "SELECT e FROM Expense e WHERE e.rolesAccess = :rolesAccess")})
public class Expense implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "EXPENSE_ID", nullable = false)
    private Long expenseId;
    @Column(name = "COUNTRY_ID")
    private Long countryId;
    @Size(max = 10)
    @Column(name = "GL_CODE", length = 10)
    private String glCode;
    @Size(max = 20)
    @Column(name = "TAX_CALC_METHOD", length = 20)
    private String taxCalcMethod;
    private String detail;
    private String total;
    private String tip;
    @Column(name = "NBR_NIGHTS")
    private String nbrNights;
    @Column(name = "HOTEL_NAME")
    private String hotelName;
    @Column(name = "OTHER_DESC")
    private String otherDesc;
    @Column(name = "INTERNET")
    private String internet;
    @Column(name = "TRAVEL_CAR")
    private String travelCar;
    @Column(name = "ROLES_ACCESS")
    private String rolesAccess;
    @Column(name = "OUT_OF_ZONE")
    private String outOfZone;
    @Column(name = "MACHINE_SOLD")
    private String machineSold;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "expense")
    private Set<ExpenseTxt> expenseTxtSet;

    public Expense() {
    }

    public Expense(Long expenseId) {
        this.expenseId = expenseId;
    }

    public Long getExpenseId() {
        return expenseId;
    }

    public void setExpenseId(Long expenseId) {
        this.expenseId = expenseId;
    }

    public Long getCountryId() {
        return countryId;
    }

    public void setCountryId(Long countryId) {
        this.countryId = countryId;
    }

    public String getGlCode() {
        return glCode;
    }

    public void setGlCode(String glCode) {
        this.glCode = glCode;
    }

    public String getTaxCalcMethod() {
        return taxCalcMethod;
    }

    public void setTaxCalcMethod(String taxCalcMethod) {
        this.taxCalcMethod = taxCalcMethod;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public String getTip() {
        return tip;
    }

    public void setTip(String tip) {
        this.tip = tip;
    }

    public String getNbrNights() {
        return nbrNights;
    }

    public void setNbrNights(String nbrNights) {
        this.nbrNights = nbrNights;
    }

    public String getHotelName() {
        return hotelName;
    }

    public void setHotelName(String hotelName) {
        this.hotelName = hotelName;
    }

    public String getOtherDesc() {
        return otherDesc;
    }

    public void setOtherDesc(String otherDesc) {
        this.otherDesc = otherDesc;
    }

    public String getInternet() {
		return internet;
	}

	public void setInternet(String internet) {
		this.internet = internet;
	}

	public String getTravelCar() {
		return travelCar;
	}

	public void setTravelCar(String travelCar) {
		this.travelCar = travelCar;
	}

	public String getRolesAccess() {
		return rolesAccess;
	}

	public void setRolesAccess(String rolesAccess) {
		this.rolesAccess = rolesAccess;
	}

  public String getOutOfZone() {
    return outOfZone;
  }

  public void setOutOfZone(String outOfZone) {
    this.outOfZone = outOfZone;
  }

  public String getMachineSold() {
    return machineSold;
  }

  public void setMachineSold(String machineSold) {
    this.machineSold = machineSold;
  }  
  
	@XmlTransient
    public Set<ExpenseTxt> getExpenseTxtSet() {
        return expenseTxtSet;
    }

    public void setExpenseTxtSet(Set<ExpenseTxt> expenseTxtSet) {
        this.expenseTxtSet = expenseTxtSet;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (expenseId != null ? expenseId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Expense)) {
            return false;
        }
        Expense other = (Expense) object;
        if ((this.expenseId == null && other.expenseId != null) || (this.expenseId != null && !this.expenseId.equals(other.expenseId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.walter.Expense[ expenseId=" + expenseId + " ]";
    }

  }
