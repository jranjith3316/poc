/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.model;

/**
 *
 * @author jsgill
 */
public class UserRole {
  long roleId;
  String roleName;
  long siteId;

  public UserRole(long roleId, String roleName, long siteId) {
    this.roleId = roleId;
    this.roleName = roleName;
    this.siteId = siteId;
  }

  public UserRole(long roleId, String roleName) {
    this.roleId = roleId;
    this.roleName = roleName;
  }

  public long getRoleId() {
    return roleId;
  }

  public void setRoleId(long roleId) {
    this.roleId = roleId;
  }

  public String getRoleName() {
    return roleName;
  }

  public void setRoleName(String roleName) {
    this.roleName = roleName;
  }

  public long getSiteId() {
    return siteId;
  }

  public void setSiteId(long siteId) {
    this.siteId = siteId;
  }

  @Override
  public boolean equals(Object obj) {
    if (obj == null) {
      return false;
    } else if (this == obj) {
			return true;
		} else if (roleId == ((UserRole) obj).getRoleId()) {
      return true;
    }
    return false;
  }

}
