/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.crossreferenceapp.model;

import java.io.Serializable;

/**
 *
 * @author jsgill
 */
public class CompetitorWalterProductModel implements Serializable {
  private static final long serialVersionUID = 3511338233023397895L;
  private String actionName;
  private String productNumber;
  private String productName;

  public CompetitorWalterProductModel() {
  }

  public CompetitorWalterProductModel(String actionName, String productNumber, String productName) {
    this.actionName = actionName;
    this.productNumber = productNumber;
    this.productName = productName;
  }

  public String getActionName() {
    return actionName;
  }

  public void setActionName(String actionName) {
    this.actionName = actionName;
  }

  public String getProductNumber() {
    return productNumber;
  }

  public void setProductNumber(String productNumber) {
    this.productNumber = productNumber;
  }

  public String getProductName() {
    return productName;
  }

  public void setProductName(String productName) {
    this.productName = productName;
  }

}
