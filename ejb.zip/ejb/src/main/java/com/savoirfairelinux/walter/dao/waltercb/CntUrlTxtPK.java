/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

/**
 *
 * @author mgubaidullin
 */
@Embeddable
public class CntUrlTxtPK implements Serializable {
    @Basic(optional = false)
    @NotNull
    @Column(name = "URL_ID")
    private long urlId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "LANG_ID")
    private long langId;

    public CntUrlTxtPK() {
    }

    public CntUrlTxtPK(long urlId, long langId) {
        this.urlId = urlId;
        this.langId = langId;
    }

    public long getUrlId() {
        return urlId;
    }

    public void setUrlId(long urlId) {
        this.urlId = urlId;
    }

    public long getLangId() {
        return langId;
    }

    public void setLangId(long langId) {
        this.langId = langId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) urlId;
        hash += (int) langId;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CntUrlTxtPK)) {
            return false;
        }
        CntUrlTxtPK other = (CntUrlTxtPK) object;
        if (this.urlId != other.urlId) {
            return false;
        }
        if (this.langId != other.langId) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.CntUrlTxtPK[ urlId=" + urlId + ", langId=" + langId + " ]";
    }
    
}
