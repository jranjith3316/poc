/*
 * Copyright 2012 Savoir-faire Linux
 *
 * This file is part of Walter-Portal.
 *
 * Walter-Portal is free software: you can redistribute it and/or modify it under the terms of the
 * GNU General Public License as published by the Free Software Foundation, either version 3
 * of the License, or (at your option) any later version.
 *
 * Walter-Portal is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with Walter-Portal.
 * If not, see http://www.gnu.org/licenses/.
 */
package com.savoirfairelinux.walter.service;

import com.savoirfairelinux.walter.dao.globalcustomer.GaFacility;
import com.savoirfairelinux.walter.dao.globalcustomer.GlobalAccount;
import com.savoirfairelinux.walter.dao.waltercb.Cnt;
import com.savoirfairelinux.walter.dao.waltercb.CntTxt;
import com.savoirfairelinux.walter.dao.waltercb.Er;
import com.savoirfairelinux.walter.dao.waltercb.ErTrialTxt;
import com.savoirfairelinux.walter.dao.waltercb.ErTxt;
import com.savoirfairelinux.walter.dao.waltercb.Idea;
import com.savoirfairelinux.walter.dao.waltercb.IdeaTxt;
import com.savoirfairelinux.walter.dao.waltercb.ProductivityReport;
import com.savoirfairelinux.walter.dao.waltercb.UActivity;
import com.savoirfairelinux.walter.dao.waltercb.UContaminant;
import com.savoirfairelinux.walter.dao.waltercb.UIndustry;
import com.savoirfairelinux.walter.dao.waltercb.UMachinery;
import com.savoirfairelinux.walter.dao.waltercb.UMaterial;
import com.savoirfairelinux.walter.jasper.exceptions.JasperException;
import com.savoirfairelinux.walter.jasper.model.JasperAerosolCalculator;
import com.savoirfairelinux.walter.jasper.model.JasperCrossReferenceAppBean;
import com.savoirfairelinux.walter.jasper.model.JasperExpenseReportBean;
import com.savoirfairelinux.walter.jasper.model.JasperExpenseRptSearchBean;
import com.savoirfairelinux.walter.jasper.model.JasperMobileProductivityReportBean;
import com.savoirfairelinux.walter.jasper.model.JasperNaicsSuspectsSearchBean;
import java.util.List;
import java.util.Locale;
import javax.ejb.Remote;

/**
 *
 * @author jderuere
 */
@Remote
public interface JasperBeanRemote {

    byte[] printSolutionReport(Cnt cnt, CntTxt cntTxt, List<UActivity> activities, List<UMaterial> materials, List<UIndustry> industries,
                               List<UContaminant> contaminants, List<UMachinery> machineries, String organization, byte[] portrait, String reportType,
                               long companyId, Locale locale, long langId) throws JasperException;

    byte[] printWalterLabReport(Er er, ErTxt erTxt, List<ErTrialTxt> trialTexts, List<UContaminant> contaminants, long langId, long companyId, Locale locale) throws JasperException;

    byte[] printBioCircleLabReport(Er er, ErTxt erTxt, List<ErTrialTxt> trialTexts, long langId, long companyId, Locale locale) throws JasperException;

    byte[] printFacilityReport(GaFacility facility, String organization, long companyId, Locale locale) throws JasperException;

    byte[] printGlobalCustomerReport (GlobalAccount globalAccount, String organization, long langId, long companyId, Locale locale) throws JasperException;

    byte[] printNewIdeaReport(Idea idea, IdeaTxt ideaTxt, String organization, String location, byte[] portrait, long companyId, Locale locale) throws JasperException;

    byte[] printGrindingProductivityReport(ProductivityReport report, long companyId, Locale locale, long langId) throws JasperException;

    byte[] printCuttingProductivityReport(ProductivityReport report, long companyId, Locale locale, long langId) throws JasperException;

    byte[] printWalterExpenseReport(JasperExpenseReportBean jasperExpenseReportBean, long langId, long companyId, Locale locale) throws JasperException;

    public byte[] printWalterExpenseReportSearch(JasperExpenseRptSearchBean jasperExpenseRptSearchBean, long langId, long companyId, Locale locale) throws JasperException;

    public byte[] printNaicsSuspectsSearch(JasperNaicsSuspectsSearchBean jasperNaicsSuspectsSearchBean, long langId, long companyId, Locale locale) throws JasperException;

    public byte[] printAerosolCalculatorReport(JasperAerosolCalculator jasperAerosolCalculator, long langId, long companyId, Locale locale) throws JasperException;

    public byte[] printMobileProductivityReportCuttingReport(JasperMobileProductivityReportBean jasperMobileProductivityReportBean, long langId, long companyId, Locale locale) throws JasperException;

    public byte[] printMobileProductivityReportGrindingReport(JasperMobileProductivityReportBean jasperMobileProductivityReportBean, long langId, long companyId, Locale locale) throws JasperException;

    public byte[] printMobileProductivityReportSandingReport(JasperMobileProductivityReportBean jasperMobileProductivityReportBean, long langId, long companyId, Locale locale) throws JasperException;

    public byte[] printMobileCrossReferenceAppReport( JasperCrossReferenceAppBean jasperCrossReferenceAppBean, Locale locale ) throws JasperException;
}
