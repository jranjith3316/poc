/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.service.impl;

import com.savoirfairelinux.walter.dao.walter.UPerson;
import com.savoirfairelinux.walter.service.DailySaleBeanRemote;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import javax.annotation.security.PermitAll;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author jsgill
 */
@Stateless(name = "DailySaleBean")
@TransactionManagement(TransactionManagementType.CONTAINER)
@PermitAll
@LocalBean
public class DailySaleBean implements DailySaleBeanRemote {
  public static final Logger LOG = Logger.getLogger(DailySaleBean.class.getCanonicalName());

  @PersistenceContext(unitName = "waltershare")
  EntityManager entityManager;
  @EJB
  SingletonBean singletonBean;
  @EJB
  WalterBean walterBean;
  @Override
  public List<UPerson> getMecanicalUserList(long companyId, Integer countryId, String userConnected) throws Exception{
    List<UPerson> uPersonList = new ArrayList<UPerson>();
    try {

      uPersonList = entityManager
              .createQuery(singletonBean.getDailySaleQuerys("mecanicalCanadaUserList"), UPerson.class)
              .setParameter("countryId", countryId)
              .getResultList();
    } catch (Exception e) {

//      System.out.println(e.getMessage());

        LOG.severe(e.getMessage());
        throw new Exception(e.getMessage());
    }
    return uPersonList;
  }

  public List<UPerson> getChemicalUserList(long companyId, Integer countryId, String userConnected) throws Exception{
    List<UPerson> uPersonList = new ArrayList<UPerson>();
    try {

      uPersonList = entityManager
              .createQuery(singletonBean.getDailySaleQuerys("chemicalCanadaUserList"), UPerson.class)
              .setParameter("countryId", countryId)
              .getResultList();
    } catch (Exception e) {

//      System.out.println(e.getMessage());

        LOG.severe(e.getMessage());
        throw new Exception(e.getMessage());
    }
    return uPersonList;
  }

  @Override
  public boolean isUserReportTo(String userName, String bossName, boolean immediateBoss) throws Exception{
    boolean reportTo = false;

    try{
    UPerson uPerson =  walterBean.getUPerson(userName.toUpperCase());
//    System.out.println("get uPerson: " + uPerson.getUPersonPK().getUserName());
//    System.out.println("bossName: " + bossName);

    if ( uPerson.getManagerUserName() != null && uPerson.getManagerUserName().equals(uPerson.getUPersonPK().getUserName()) ){
      return reportTo;
    }

    if ( uPerson.getManagerUserName() == null ){
      return reportTo;
    }

    if ( (uPerson.getManagerUserName() != null) && uPerson.getManagerUserName().toUpperCase().equals( bossName) ){
      reportTo = true;
//      System.out.println("get user");
    } else if ( (uPerson.getManagerUserName() != null) && immediateBoss != true ){
//      System.out.println("before recal function");
      reportTo = isUserReportTo(uPerson.getManagerUserName().toUpperCase(), bossName, immediateBoss);
    }
//    System.out.println("just before return");
    }
    catch(Exception ex){
      System.out.println(ex.getMessage());
    }
    return reportTo;

  }
}
