package com.savoirfairelinux.walter.model;

public enum WalterOrganization {

	WALTER("walter"),
	BIO_CIRCLE("cb");
	
	private String name;
	
	private WalterOrganization(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}
}
