/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import javax.persistence.*;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "ER_TXT", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "ErTxt.findAll", query = "SELECT e FROM ErTxt e"),
    @NamedQuery(name = "ErTxt.findById", query = "SELECT e FROM ErTxt e WHERE e.erTxtPK.erId = :erId AND e.erTxtPK.langId = :langId"),
    @NamedQuery(name = "ErTxt.findByErId", query = "SELECT e FROM ErTxt e WHERE e.erTxtPK.erId = :erId"),
    @NamedQuery(name = "ErTxt.findByLangId", query = "SELECT e FROM ErTxt e WHERE e.erTxtPK.langId = :langId"),
    @NamedQuery(name = "ErTxt.findByPartCleanDesc", query = "SELECT e FROM ErTxt e WHERE e.partCleanDesc = :partCleanDesc"),
    @NamedQuery(name = "ErTxt.findByCustomerName", query = "SELECT e FROM ErTxt e WHERE e.customerName = :customerName"),
    @NamedQuery(name = "ErTxt.findByContactName", query = "SELECT e FROM ErTxt e WHERE e.contactName = :contactName"),
    @NamedQuery(name = "ErTxt.findByContactTitle", query = "SELECT e FROM ErTxt e WHERE e.contactTitle = :contactTitle"),
    @NamedQuery(name = "ErTxt.findByRequestedByUserName", query = "SELECT e FROM ErTxt e WHERE e.requestedByUserName = :requestedByUserName"),
    @NamedQuery(name = "ErTxt.findByContaminantDesc", query = "SELECT e FROM ErTxt e WHERE e.contaminantDesc = :contaminantDesc"),
    @NamedQuery(name = "ErTxt.findBySpecialApplication", query = "SELECT e FROM ErTxt e WHERE e.specialApplication = :specialApplication"),
    @NamedQuery(name = "ErTxt.findByCleaningMethod", query = "SELECT e FROM ErTxt e WHERE e.cleaningMethod = :cleaningMethod"),
    @NamedQuery(name = "ErTxt.findByObservation", query = "SELECT e FROM ErTxt e WHERE e.observation = :observation"),
    @NamedQuery(name = "ErTxt.findByOtherContaminant", query = "SELECT e FROM ErTxt e WHERE e.otherContaminant = :otherContaminant"),
    @NamedQuery(name = "ErTxt.findByTranslatable", query = "SELECT e FROM ErTxt e WHERE e.translatable = :translatable"),
    @NamedQuery(name = "ErTxt.findByPublishedDate", query = "SELECT e FROM ErTxt e WHERE e.publishedDate = :publishedDate"),
    @NamedQuery(name = "ErTxt.findBySale", query = "SELECT e FROM ErTxt e WHERE e.sale = :sale"),
    @NamedQuery(name = "ErTxt.findByProdReplaced", query = "SELECT e FROM ErTxt e WHERE e.prodReplaced = :prodReplaced"),
    @NamedQuery(name = "ErTxt.findByFeedback", query = "SELECT e FROM ErTxt e WHERE e.feedback = :feedback"),
    @NamedQuery(name = "ErTxt.findByFeedbackR", query = "SELECT e FROM ErTxt e WHERE e.feedbackR = :feedbackR"),
    @NamedQuery(name = "ErTxt.findByFeedbackDate", query = "SELECT e FROM ErTxt e WHERE e.feedbackDate = :feedbackDate")})
public class ErTxt implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected ErTxtPK erTxtPK;
    @Size(max = 100)
    @Column(name = "PART_CLEAN_DESC", length = 100)
    private String partCleanDesc;
    @Size(max = 100)
    @Column(name = "CUSTOMER_NAME", length = 100)
    private String customerName;
    @Size(max = 100)
    @Column(name = "CONTACT_NAME", length = 100)
    private String contactName;
    @Size(max = 100)
    @Column(name = "CONTACT_TITLE", length = 100)
    private String contactTitle;
    @Size(max = 256)
    @Column(name = "REQUESTED_BY_USER_NAME", length = 256)
    private String requestedByUserName;
    @Size(max = 1000)
    @Column(name = "CONTAMINANT_DESC", length = 1000)
    private String contaminantDesc;
    @Size(max = 1000)
    @Column(name = "SPECIAL_APPLICATION", length = 1000)
    private String specialApplication;
    @Size(max = 1000)
    @Column(name = "CLEANING_METHOD", length = 1000)
    private String cleaningMethod;
    @Size(max = 2000)
    @Column(name = "OBSERVATION", length = 2000)
    private String observation;
    @Size(max = 40)
    @Column(name = "OTHER_CONTAMINANT", length = 40)
    private String otherContaminant;
    @Column(name = "TRANSLATABLE")
    private String translatable;
    @Column(name = "PUBLISHED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date publishedDate;
    @Column(name = "SALE")
    private String sale;
    @Size(max = 100)
    @Column(name = "PROD_REPLACED", length = 100)
    private String prodReplaced;
    @Size(max = 300)
    @Column(name = "FEEDBACK", length = 300)
    private String feedback;
    @Size(max = 300)
    @Column(name = "FEEDBACK_R", length = 300)
    private String feedbackR;
    @Column(name = "FEEDBACK_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date feedbackDate;
    @JoinColumn(name = "ER_ID", referencedColumnName = "ER_ID", nullable = false, insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Er er;

    public ErTxt() {
    }

    public ErTxt(ErTxtPK erTxtPK) {
        this.erTxtPK = erTxtPK;
    }

    public ErTxt(long erId, long langId) {
        this.erTxtPK = new ErTxtPK(erId, langId);
    }

    public ErTxt(ErTxt englishText, Long langId) {
        this(englishText.getErTxtPK().getErId(), langId);
        this.er = englishText.getEr();
        this.partCleanDesc = englishText.getPartCleanDesc();
        this.customerName = englishText.getCustomerName();
        this.contactName = englishText.getContactName();
        this.contactTitle = englishText.getContactTitle();
        this.requestedByUserName = englishText.getRequestedByUserName();
        this.contaminantDesc = englishText.getContaminantDesc();
        this.specialApplication = englishText.getSpecialApplication();
        this.cleaningMethod = englishText.getCleaningMethod();
        this.observation = englishText.getObservation();
        this.otherContaminant = englishText.getOtherContaminant();
        this.translatable = englishText.getTranslatable();
    }

    public ErTxtPK getErTxtPK() {
        return erTxtPK;
    }

    public void setErTxtPK(ErTxtPK erTxtPK) {
        this.erTxtPK = erTxtPK;
    }

    public String getPartCleanDesc() {
        return partCleanDesc;
    }

    public void setPartCleanDesc(String partCleanDesc) {
        this.partCleanDesc = partCleanDesc;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public String getContactTitle() {
        return contactTitle;
    }

    public void setContactTitle(String contactTitle) {
        this.contactTitle = contactTitle;
    }

    public String getRequestedByUserName() {
        return requestedByUserName;
    }

    public void setRequestedByUserName(String requestedByUserName) {
        this.requestedByUserName = requestedByUserName;
    }

    public String getContaminantDesc() {
        return contaminantDesc;
    }

    public void setContaminantDesc(String contaminantDesc) {
        this.contaminantDesc = contaminantDesc;
    }

    public String getSpecialApplication() {
        return specialApplication;
    }

    public void setSpecialApplication(String specialApplication) {
        this.specialApplication = specialApplication;
    }

    public String getCleaningMethod() {
        return cleaningMethod;
    }

    public void setCleaningMethod(String cleaningMethod) {
        this.cleaningMethod = cleaningMethod;
    }

    public String getObservation() {
        return observation;
    }

    public void setObservation(String observation) {
        this.observation = observation;
    }

    public String getOtherContaminant() {
        return otherContaminant;
    }

    public void setOtherContaminant(String otherContaminant) {
        this.otherContaminant = otherContaminant;
    }

    public String getTranslatable() {
        return translatable;
    }

    public void setTranslatable(String translatable) {
        this.translatable = translatable;
    }

    public Date getPublishedDate() {
        return publishedDate;
    }

    public void setPublishedDate(Date publishedDate) {
        this.publishedDate = publishedDate;
    }

    public String getSale() {
        return sale;
    }

    public void setSale(String sale) {
        this.sale = sale;
    }

    public String getProdReplaced() {
        return prodReplaced;
    }

    public void setProdReplaced(String prodReplaced) {
        this.prodReplaced = prodReplaced;
    }

    public String getFeedback() {
        return feedback;
    }

    public void setFeedback(String feedback) {
        this.feedback = feedback;
    }

    public String getFeedbackR() {
        return feedbackR;
    }

    public void setFeedbackR(String feedbackR) {
        this.feedbackR = feedbackR;
    }

    public Date getFeedbackDate() {
        return feedbackDate;
    }

    public void setFeedbackDate(Date feedbackDate) {
        this.feedbackDate = feedbackDate;
    }

    public Er getEr() {
        return er;
    }

    public void setEr(Er er) {
        this.er = er;
    }

    @PrePersist
    private void prePersist() {
        if (er != null && erTxtPK != null) {
            erTxtPK.setErId(er.getErId());
        }
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (erTxtPK != null ? erTxtPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ErTxt)) {
            return false;
        }
        ErTxt other = (ErTxt) object;
        if ((this.erTxtPK == null && other.erTxtPK != null) || (this.erTxtPK != null && !this.erTxtPK.equals(other.erTxtPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.ErTxt[ erTxtPK=" + erTxtPK + " ]";
    }
    
}
