/* 
 * Copyright 2012 Savoir-faire Linux
 * 
 * This file is part of Walter-Portal.
 * 
 * Walter-Portal is free software: you can redistribute it and/or modify it under the terms of the 
 * GNU General Public License as published by the Free Software Foundation, either version 3 
 * of the License, or (at your option) any later version.
 * 
 * Walter-Portal is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with Walter-Portal. 
 * If not, see http://www.gnu.org/licenses/.
 */
package com.savoirfairelinux.walter.service;

import com.savoirfairelinux.walter.dao.waltercb.*;
import com.savoirfairelinux.walter.model.IdeaState;
import com.savoirfairelinux.walter.model.SearchNewIdea;

import javax.ejb.Remote;
import java.util.List;

/**
 *
 * @author mgubaidullin
 * @author jderuere
 */
@Remote
public interface NewIdeaBeanRemote {
    
    
    public List<Idea> getRecentIdeas(Long categoryId, boolean all, IdeaState state, String organization, String userName, String languageAbbreviation) throws Exception;
    
    public List<Idea> getUnreadIdeas(Long categoryId, String organization, String userName, String languageAbbreviation) throws Exception;

    public List<Idea> getUnsubmitIdeas(String organization, String userName, String languageAbbreviation) throws Exception;

    public List<Idea> getInProcessIdeas(String organization, String userName, String languageAbbreviation) throws Exception;

    public List<Idea> getSubmittedIdeas(String organization, String userName, String languageAbbreviation) throws Exception;

    public List<Idea> getPublishedIdeas(String organization, String userName, String languageAbbreviation) throws Exception;

    public Idea save(Idea idea, Country country, ULang language, String productManagerName, String translatorName) throws Exception;

    public void submit(Idea idea) throws Exception;

    public void publish(Idea idea) throws Exception;

    public List<Idea> search(SearchNewIdea form, String userName, String organization, String languageAbbreviation);

    public Idea getIdea(long ideaId);
    
    public Idea getIdea(long ideaId, String languageAbbreviation, String country, String organization);

    public void submitTranslation(Idea idea, IdeaTranslate originalTranslate, long langId, String screenName) throws Exception;

    public Idea saveTranslation(Idea idea, IdeaTranslate originalTranslate, long langId, String screenName) throws Exception;

    public List<IdeaTranslate> getMyPendingForTranslation(String screenName, String languageAbbreviation, String country) throws Exception;

    public List<IdeaTranslate> getPendingForTranslation(String organization, String userName, String languageAbbreviation, String country) throws Exception;

    public IdeaCounter setIdeaCounter(Long ideaId, String userName) throws Exception;

    public void cancel(Idea idea, String screenName) throws Exception;

    void reply(IdeaFeedbackR feedbackReply) throws Exception;

    void feedBack(IdeaFeedback feedback) throws Exception;
}




