/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "PROMO_ITEM_COUNTRY", catalog = "", schema = "WALTERcb")
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "PromoItemCountry.findAll", query = "SELECT p FROM PromoItemCountry p"),
  @NamedQuery(name = "PromoItemCountry.findByItemId", query = "SELECT p FROM PromoItemCountry p WHERE p.promoItemCountryPK.itemId = :itemId"),
  @NamedQuery(name = "PromoItemCountry.findByCountryId", query = "SELECT p FROM PromoItemCountry p WHERE p.promoItemCountryPK.countryId = :countryId"),
  @NamedQuery(name = "PromoItemCountry.findByListPrice", query = "SELECT p FROM PromoItemCountry p WHERE p.listPrice = :listPrice"),
  @NamedQuery(name = "PromoItemCountry.findByWebDisplay", query = "SELECT p FROM PromoItemCountry p WHERE p.webDisplay = :webDisplay"),
  @NamedQuery(name = "PromoItemCountry.findByLogoExtra", query = "SELECT p FROM PromoItemCountry p WHERE p.logoExtra = :logoExtra"),
  @NamedQuery(name = "PromoItemCountry.findByLogoExtraPrice", query = "SELECT p FROM PromoItemCountry p WHERE p.logoExtraPrice = :logoExtraPrice"),
  @NamedQuery(name = "PromoItemCountry.findByCreatedBy", query = "SELECT p FROM PromoItemCountry p WHERE p.createdBy = :createdBy"),
  @NamedQuery(name = "PromoItemCountry.findByCreatedDate", query = "SELECT p FROM PromoItemCountry p WHERE p.createdDate = :createdDate"),
  @NamedQuery(name = "PromoItemCountry.findByUpdatedBy", query = "SELECT p FROM PromoItemCountry p WHERE p.updatedBy = :updatedBy"),
  @NamedQuery(name = "PromoItemCountry.findByUpdatedDate", query = "SELECT p FROM PromoItemCountry p WHERE p.updatedDate = :updatedDate"),
  @NamedQuery(name = "PromoItemCountry.findByCountryId1", query = "SELECT p FROM PromoItemCountry p WHERE p.countryId1 = :countryId1")})
public class PromoItemCountry implements Serializable {
  private static final long serialVersionUID = 1L;
  @EmbeddedId
  protected PromoItemCountryPK promoItemCountryPK;
  // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
  @Column(name = "LIST_PRICE")
  private BigDecimal listPrice;
  @Size(max = 5)
  @Column(name = "WEB_DISPLAY")
  private String webDisplay;
  @Size(max = 5)
  @Column(name = "LOGO_EXTRA")
  private String logoExtra;
  @Column(name = "LOGO_EXTRA_PRICE")
  private BigDecimal logoExtraPrice;
  @Size(max = 255)
  @Column(name = "CREATED_BY")
  private String createdBy;
  @Column(name = "CREATED_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date createdDate;
  @Size(max = 255)
  @Column(name = "UPDATED_BY")
  private String updatedBy;
  @Column(name = "UPDATED_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date updatedDate;
  @Basic(optional = false)
  @NotNull
  @Column(name = "COUNTRY_ID", insertable = false, updatable = false)
  private long countryId1;
  @JoinColumn(name = "ITEM_ID", referencedColumnName = "ITEM_ID", insertable = false, updatable = false)
  @ManyToOne(optional = false)
  private PromoItem promoItem;

  public PromoItemCountry() {
  }

  public PromoItemCountry(PromoItemCountryPK promoItemCountryPK) {
    this.promoItemCountryPK = promoItemCountryPK;
  }

  public PromoItemCountry(PromoItemCountryPK promoItemCountryPK, long countryId1) {
    this.promoItemCountryPK = promoItemCountryPK;
    this.countryId1 = countryId1;
  }

  public PromoItemCountry(long itemId, long countryId) {
    this.promoItemCountryPK = new PromoItemCountryPK(itemId, countryId);
  }

  public PromoItemCountryPK getPromoItemCountryPK() {
    return promoItemCountryPK;
  }

  public void setPromoItemCountryPK(PromoItemCountryPK promoItemCountryPK) {
    this.promoItemCountryPK = promoItemCountryPK;
  }

  public BigDecimal getListPrice() {
    return listPrice;
  }

  public void setListPrice(BigDecimal listPrice) {
    this.listPrice = listPrice;
  }

  public String getWebDisplay() {
    return webDisplay;
  }

  public void setWebDisplay(String webDisplay) {
    this.webDisplay = webDisplay;
  }

  public String getLogoExtra() {
    return logoExtra;
  }

  public void setLogoExtra(String logoExtra) {
    this.logoExtra = logoExtra;
  }

  public BigDecimal getLogoExtraPrice() {
    return logoExtraPrice;
  }

  public void setLogoExtraPrice(BigDecimal logoExtraPrice) {
    this.logoExtraPrice = logoExtraPrice;
  }

  public String getCreatedBy() {
    return createdBy;
  }

  public void setCreatedBy(String createdBy) {
    this.createdBy = createdBy;
  }

  public Date getCreatedDate() {
    return createdDate;
  }

  public void setCreatedDate(Date createdDate) {
    this.createdDate = createdDate;
  }

  public String getUpdatedBy() {
    return updatedBy;
  }

  public void setUpdatedBy(String updatedBy) {
    this.updatedBy = updatedBy;
  }

  public Date getUpdatedDate() {
    return updatedDate;
  }

  public void setUpdatedDate(Date updatedDate) {
    this.updatedDate = updatedDate;
  }

  public long getCountryId1() {
    return countryId1;
  }

  public void setCountryId1(long countryId1) {
    this.countryId1 = countryId1;
  }

  public PromoItem getPromoItem() {
    return promoItem;
  }

  public void setPromoItem(PromoItem promoItem) {
    this.promoItem = promoItem;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (promoItemCountryPK != null ? promoItemCountryPK.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof PromoItemCountry)) {
      return false;
    }
    PromoItemCountry other = (PromoItemCountry) object;
    if ((this.promoItemCountryPK == null && other.promoItemCountryPK != null) || (this.promoItemCountryPK != null && !this.promoItemCountryPK.equals(other.promoItemCountryPK))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.waltercb.PromoItemCountry[ promoItemCountryPK=" + promoItemCountryPK + " ]";
  }

}
