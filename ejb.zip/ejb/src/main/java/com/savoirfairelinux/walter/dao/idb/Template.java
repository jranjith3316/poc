/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.idb;

import com.savoirfairelinux.walter.dao.DatabaseConstants;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "TEMPLATE", catalog = "", schema = DatabaseConstants.IDB_SCHEMA)
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "Template.findAll", query = "SELECT t FROM Template t"),
  @NamedQuery(name = "Template.findByTemplateguid", query = "SELECT t FROM Template t WHERE t.templateguid = :templateguid"),
  @NamedQuery(name = "Template.findByCreatedby", query = "SELECT t FROM Template t WHERE t.createdby = :createdby"),
  @NamedQuery(name = "Template.findByCreationdate", query = "SELECT t FROM Template t WHERE t.creationdate = :creationdate"),
  @NamedQuery(name = "Template.findByDeleteby", query = "SELECT t FROM Template t WHERE t.deleteby = :deleteby"),
  @NamedQuery(name = "Template.findByDeletedate", query = "SELECT t FROM Template t WHERE t.deletedate = :deletedate"),
  @NamedQuery(name = "Template.findByTemplatename", query = "SELECT t FROM Template t WHERE t.templatename = :templatename"),
  @NamedQuery(name = "Template.findByColor", query = "SELECT t FROM Template t WHERE t.color = :color")})
public class Template implements Serializable {
  private static final long serialVersionUID = 1L;
  @Id
  @Basic(optional = false)
  @NotNull
  @Size(min = 1, max = 255)
  @Column(name = "TEMPLATEGUID")
  private String templateguid;
  @Size(max = 256)
  @Column(name = "CREATEDBY")
  private String createdby;
  @Column(name = "CREATIONDATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date creationdate;
  @Size(max = 256)
  @Column(name = "DELETEBY")
  private String deleteby;
  @Column(name = "DELETEDATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date deletedate;
  @Size(max = 8)
  @Column(name = "TEMPLATENAME")
  private String templatename;
  @Size(max = 7)
  @Column(name = "COLOR")
  private String color;
//  @OneToMany(cascade = CascadeType.ALL, mappedBy = "template")
//  private Set<TemplateTitle> templateTitleSet;
//  @OneToMany(cascade = CascadeType.ALL, mappedBy = "template")
//  private Set<TemplateItem> templateItemSet;

  public Template() {
  }

  public Template(String templateguid) {
    this.templateguid = templateguid;
  }

  public String getTemplateguid() {
    return templateguid;
  }

  public void setTemplateguid(String templateguid) {
    this.templateguid = templateguid;
  }

  public String getCreatedby() {
    return createdby;
  }

  public void setCreatedby(String createdby) {
    this.createdby = createdby;
  }

  public Date getCreationdate() {
    return creationdate;
  }

  public void setCreationdate(Date creationdate) {
    this.creationdate = creationdate;
  }

  public String getDeleteby() {
    return deleteby;
  }

  public void setDeleteby(String deleteby) {
    this.deleteby = deleteby;
  }

  public Date getDeletedate() {
    return deletedate;
  }

  public void setDeletedate(Date deletedate) {
    this.deletedate = deletedate;
  }

  public String getTemplatename() {
    return templatename;
  }

  public void setTemplatename(String templatename) {
    this.templatename = templatename;
  }

  public String getColor() {
    return color;
  }

  public void setColor(String color) {
    this.color = color;
  }

//  @XmlTransient
//  public Set<TemplateTitle> getTemplateTitleSet() {
//    return templateTitleSet;
//  }
//
//  public void setTemplateTitleSet(Set<TemplateTitle> templateTitleSet) {
//    this.templateTitleSet = templateTitleSet;
//  }
//
//  @XmlTransient
//  public Set<TemplateItem> getTemplateItemSet() {
//    return templateItemSet;
//  }
//
//  public void setTemplateItemSet(Set<TemplateItem> templateItemSet) {
//    this.templateItemSet = templateItemSet;
//  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (templateguid != null ? templateguid.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof Template)) {
      return false;
    }
    Template other = (Template) object;
    if ((this.templateguid == null && other.templateguid != null) || (this.templateguid != null && !this.templateguid.equals(other.templateguid))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.idb.Template[ templateguid=" + templateguid + " ]";
  }

}
