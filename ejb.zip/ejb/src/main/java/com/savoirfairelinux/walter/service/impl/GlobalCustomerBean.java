/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.service.impl;

import com.savoirfairelinux.walter.dao.globalcustomer.*;
import com.savoirfairelinux.walter.dao.waltercb.UIndustry;
import com.savoirfairelinux.walter.dao.waltercb.ULang;
import com.savoirfairelinux.walter.model.SearchGlobalAccount;
import com.savoirfairelinux.walter.service.GlobalCustomerBeanRemote;
import com.savoirfairelinux.walter.util.criteriabuilder.GlobalAccountCriteriaBuilder;
import com.savoirfairelinux.walter.util.predicate.ProductNamePredicate;
import org.apache.commons.collections.CollectionUtils;
import org.hibernate.Hibernate;
import org.hibernate.transform.DistinctRootEntityResultTransformer;

import javax.annotation.security.PermitAll;
import javax.ejb.*;
import javax.persistence.*;
import java.util.*;
import java.util.logging.Logger;

/**
 *
 * @author jderuere
 */
@Stateless(name = "GlobalCustomerBean")
@TransactionManagement(TransactionManagementType.CONTAINER)
@PermitAll
@LocalBean
public class GlobalCustomerBean implements GlobalCustomerBeanRemote {

    public static final Logger LOG = Logger.getLogger(GlobalCustomerBean.class.getCanonicalName());

    @PersistenceContext(unitName = "waltershare")
    EntityManager entityManager;
    @EJB
    WalterBean walterBean;
    @EJB
    SolutionReportBean solutionReportBean;
    @EJB
    NotificationBean notificationBean;
    @EJB
    SingletonBean singletonBean;

    @Override
    public GlobalAccount save(GlobalAccount globalAccount) {
        String http = "http://";
        if (!globalAccount.getWebsite().startsWith(http)) {
            globalAccount.setWebsite(http + globalAccount.getWebsite());
        }
        globalAccount.setCreateDate(new Date());
        return entityManager.merge(globalAccount);
    }

    @Override
    public GaFacility save(GaFacility facility) {
        facility.setCreateDate(new Date());
        return entityManager.merge(facility);
    }

    @Override
    public GlobalAccount getGlobalAccount(String name) {
        Query query = entityManager.createNamedQuery(GlobalAccount.class.getSimpleName() + ".findByName")
                .setParameter("name", name);
        try {
            return (GlobalAccount) query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @Override
    public List<String> getGlobalAccountNames(String name) {
        String[] splitName = name.split(" ");
        StringBuilder builder = new StringBuilder("SELECT ga.name FROM GlobalAccount ga WHERE ");
        for (int i = 0; i < splitName.length; i++) {
           builder.append(" upper(ga.name) LIKE upper('%" + splitName[i] + "%')");
            if (i < splitName.length - 1 && splitName.length > 1) builder.append(" OR ");
        }
        List<String> names = entityManager.createQuery(builder.toString(), String.class).getResultList();
        return names;
    }

    @Override
    public List<GlobalAccount> search(SearchGlobalAccount form, String languageAbbreviation) {
        List<GlobalAccount> result = null;
        try {
            GlobalAccountCriteriaBuilder criteriaBuilder = new GlobalAccountCriteriaBuilder(entityManager, form);
            List<GlobalAccount> rows = criteriaBuilder.buildQuery().getQuery().getResultList();
            rows = DistinctRootEntityResultTransformer.INSTANCE.transformList(rows);
            List<UGeographicalCoverage> coverageLabels;
            if (form.getGeographicalCoverage() != null) {
                coverageLabels = new ArrayList<UGeographicalCoverage>(Arrays.asList(form.getGeographicalCoverage()));
            } else {
                coverageLabels = walterBean.getAllWalter(UGeographicalCoverage.class);
            }

            List<UIndustry> industryLabels;
            if (form.getIndustry() != null) {
                industryLabels = new ArrayList<UIndustry>(Arrays.asList(form.getIndustry()));
            } else {
                industryLabels = walterBean.getAllWalter(UIndustry.class);
            }

            result = new ArrayList<GlobalAccount>(rows.size());
            for (GlobalAccount account : rows) {
                for (GaFacility facility : account.getFacilities()) {
                    loadWalterProductNames(languageAbbreviation, facility.getProducts());
                    loadCbProductNames(facility.getProducts());
                }

                for (UGeographicalCoverage coverageLabel : coverageLabels) {
                    if (coverageLabel.getGeographicalCoverage().equals(account.getCoverage())) {
                        account.setGeographicalCoverageName(coverageLabel.getDescription());
                        break;
                    }
                }

                for (UIndustry industryLabel : industryLabels) {
                    if (industryLabel.getUIndustryPK().getIndustryId() == account.getIndustry().getIndustryId()) {
                        account.setIndustryType(industryLabel.getIndustryDesc());
                        break;
                    }
                }

                result.add(account);
            }
        } catch (Exception e) {
            LOG.severe(e.getMessage());
        }
        return result;
    }

    private void loadWalterProductNames(String languageAbbreviation, List<GaProduct> products) throws Exception {
        if (!products.isEmpty()) {
            try {
                TypedQuery<Object[]> query = entityManager.createQuery(singletonBean.getGlobalCustomerQuery("global.customer.walter.productnames"), Object[].class)
                        .setParameter("products", products);

                HashMap<String, String> translations = solutionReportBean.getWalterTradenamesTranslation(languageAbbreviation);

                List<Object[]> rows = query.getResultList();
                ProductNamePredicate predicate = new ProductNamePredicate();
                for (Object[] row : rows) {
                    Long productId = (Long) row[0];
                    String name = String.valueOf(row[1]);
                    name = translations.containsKey(name) ? translations.get(name) : name;

                    predicate.setProductId(productId);
                    GaProduct product = (GaProduct) CollectionUtils.find(products, predicate);
                    product.setDisplayName(name + " Walter");
                }
            } catch (Exception e) {
                LOG.severe(e.getMessage());
                throw new Exception(e.getMessage());
            }
        }
    }

    private void loadCbProductNames(List<GaProduct> products) throws Exception {
        if (!products.isEmpty()) {
            try {
                TypedQuery<Object[]> query = entityManager.createQuery(singletonBean.getGlobalCustomerQuery("global.customer.biocircle.productnames"), Object[].class)
                        .setParameter("products", products);

                ProductNamePredicate predicate = new ProductNamePredicate();
                List<Object[]> rows = query.getResultList();
                for (Object[] row : rows) {
                    Long productId = (Long) row[0];
                    String name = String.valueOf(row[1]);

                    predicate.setProductId(productId);
                    GaProduct product = (GaProduct) CollectionUtils.find(products, predicate);
                    product.setDisplayName(name + " CB");
                }
            } catch (Exception e) {
                LOG.severe(e.getMessage());
                throw new Exception(e.getMessage());
            }
        }
    }

    @Override
    public List<GlobalAccount> getRecent(String languageAbbreviation) {
        SearchGlobalAccount model = new SearchGlobalAccount();
        List<GlobalAccount> result = search(model, languageAbbreviation);
        return result;
    }

    @Override
    public GlobalAccount getGlobalAccount(Long gaId, String languageAbbreviation) throws Exception {
        GlobalAccount result;
        try {
            ULang language = walterBean.getULang(languageAbbreviation);
            result = getGlobalAccount(gaId);
            solutionReportBean.load(result.getReports(), language);
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    public void reply(GaFeedbackR feedbackReply) throws Exception {
        feedbackReply.setDateCreated(new Date());
        entityManager.merge(feedbackReply);
        notificationBean.sendNewFeedbackReplyNotification(feedbackReply);
    }

    @Override
    public void feedBack(GaFeedback feedback) throws Exception {
        feedback.setDateCreated(new Date());
        entityManager.merge(feedback);
        notificationBean.sendNewFeedbackNotification(feedback);
    }

    @Override
    public GaFacility getFacility(Long facilityId) throws Exception {
        Query query = entityManager.createNamedQuery("GaFacility.findById")
                .setParameter("facilityId", facilityId);
        GaFacility result = (GaFacility) query.getSingleResult();
        Hibernate.initialize(result.getGlobalAccount().getIndustry());
        Hibernate.initialize(result.getFeedbacks());
        return result;
    }

    private GlobalAccount getGlobalAccount(Long gaId) throws Exception {
        GlobalAccount result;
        try {
            SearchGlobalAccount form = new SearchGlobalAccount();
            form.setId(gaId);

            GlobalAccountCriteriaBuilder criteriaBuilder = new GlobalAccountCriteriaBuilder(entityManager, form);
            result = criteriaBuilder.buildQuery().getQuery().getSingleResult();

            if (result != null) {
                Hibernate.initialize(result.getCoverage());
                Hibernate.initialize(result.getIndustry());
                Hibernate.initialize(result.getReports());
            } else {
                throw new Exception("You are not allowed to view this Global Account!");
            }
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
        return result;
    }
}