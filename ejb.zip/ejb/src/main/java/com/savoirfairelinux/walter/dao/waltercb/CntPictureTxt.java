/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "CNT_PICTURE_TXT", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CntPictureTxt.findAll", query = "SELECT c FROM CntPictureTxt c"),
    @NamedQuery(name = "CntPictureTxt.findByPictureId", query = "SELECT c FROM CntPictureTxt c WHERE c.cntPictureTxtPK.pictureId = :pictureId"),
    @NamedQuery(name = "CntPictureTxt.findByLangId", query = "SELECT c FROM CntPictureTxt c WHERE c.cntPictureTxtPK.langId = :langId"),
    @NamedQuery(name = "CntPictureTxt.findByPictureTxt", query = "SELECT c FROM CntPictureTxt c WHERE c.pictureTxt = :pictureTxt")})
public class CntPictureTxt implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected CntPictureTxtPK cntPictureTxtPK;
    @Size(max = 100)
    @Column(name = "PICTURE_TXT")
    private String pictureTxt;
    @JoinColumn(name = "PICTURE_ID", referencedColumnName = "PICTURE_ID", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private CntPicture cntPicture;

    public CntPictureTxt() {
    }
    
    public CntPictureTxt(CntPictureTxt cntPictureTxt, long langId) {
    	this.cntPictureTxtPK = new CntPictureTxtPK(cntPictureTxt.getCntPictureTxtPK().getPictureId(), langId);
    	this.pictureTxt = cntPictureTxt.getPictureTxt();
    	this.cntPicture = cntPictureTxt.getCntPicture();
    }

    public CntPictureTxt(CntPictureTxtPK cntPictureTxtPK) {
        this.cntPictureTxtPK = cntPictureTxtPK;
    }

    public CntPictureTxt(long pictureId, long langId) {
        this.cntPictureTxtPK = new CntPictureTxtPK(pictureId, langId);
    }

    public CntPictureTxtPK getCntPictureTxtPK() {
        return cntPictureTxtPK;
    }

    public void setCntPictureTxtPK(CntPictureTxtPK cntPictureTxtPK) {
        this.cntPictureTxtPK = cntPictureTxtPK;
    }

    public String getPictureTxt() {
        return pictureTxt;
    }

    public void setPictureTxt(String pictureTxt) {
        this.pictureTxt = pictureTxt;
    }

    public CntPicture getCntPicture() {
        return cntPicture;
    }

    public void setCntPicture(CntPicture cntPicture) {
        this.cntPicture = cntPicture;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cntPictureTxtPK != null ? cntPictureTxtPK.hashCode() : 0);
        return hash;
    }
    
    @PrePersist
    private void prePersist() {
    	if (cntPicture != null && cntPictureTxtPK != null) {
    		cntPictureTxtPK.setPictureId(cntPicture.getPictureId());
    	}
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CntPictureTxt)) {
            return false;
        }
        CntPictureTxt other = (CntPictureTxt) object;
        if ((this.cntPictureTxtPK == null && other.cntPictureTxtPK != null) || (this.cntPictureTxtPK != null && !this.cntPictureTxtPK.equals(other.cntPictureTxtPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.CntPictureTxt[ cntPictureTxtPK=" + cntPictureTxtPK + " ]";
    }
}
