/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
/**
 *
 * @author jsgill
 */
public class DocumentFTPUtil {

  public static final String SERVER = "70.38.110.140";
  public static final int PORT = 21;
  public static final String USER = "ftp_webform";
  public static final String PASS = "Wlt59772015";
//  public static final String SERVER_PATH_IMAGES = "/webform/walteridb/images/";
//  public static final String SERVER_PATH_DOCUMENTS = "/webform/walteridb/documents/";
//  public static final String SERVER_PATH_BACKUP = "/webform/walteridb/images/deletedImages/";
  public static final String SERVER_PATH_CROSS_REFERENCE_APP = "/webform/walteridb/images/crossreferenceapp";

  private FTPClient ftpClient;

  public FTPClient getFTPClient(){
    ftpClient = new FTPClient();
    try {
      ftpClient.connect(SERVER, PORT);
      ftpClient.enterLocalPassiveMode();
      ftpClient.login(USER, PASS);

    } catch (IOException ex) {
      System.out.println("error: " + ex.getMessage());
      Logger.getLogger(DocumentFTPUtil.class.getName()).log(Level.SEVERE, null, ex);
    } catch (Exception ex) {
      Logger.getLogger(DocumentFTPUtil.class.getName()).log(Level.SEVERE, null, ex);
    }
    return ftpClient;
  }

  public boolean addFile(ByteArrayOutputStream byteArrayOutputStream, String newfileName){
    boolean done = false;
    getFTPClient();
    try {
      ftpClient.setFileType(FTP.BINARY_FILE_TYPE);

      ftpClient.changeWorkingDirectory(SERVER_PATH_CROSS_REFERENCE_APP);
      InputStream inputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());

      done = ftpClient.storeFile(newfileName, inputStream);
      inputStream.close();

    } catch (IOException ex) {
      Logger.getLogger(DocumentFTPUtil.class.getName()).log(Level.SEVERE, null, ex);
    }
    closeConnection();
    return done;
  }

  public void closeConnection(){
    try {
      if (ftpClient.isConnected()) {
        ftpClient.logout();
        ftpClient.disconnect();
      }
    } catch (IOException ex) {
      System.out.println("error: " + ex.getMessage());
    }
  }
}