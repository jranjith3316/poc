/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.service;

import com.savoirfairelinux.walter.dao.walter.DistributorLocator;
import com.savoirfairelinux.walter.dao.walter.DistributorLocatorConfig;
import com.savoirfairelinux.walter.dao.walter.DistributorPromoConfig;
import java.util.List;
import javax.ejb.Remote;

/**
 *
 * @author jsgill
 */
@Remote
public interface DistributorLocatorBeanRemote {

  public List<DistributorLocator> getAll();

  public List<DistributorLocator> getDistributorList(String keyword, String country, boolean missingGeo);

  public List<DistributorLocator> getDistributorPromo(String promoCode, String country, String saGroup);

  public List<DistributorLocatorConfig> getDistributorConfig();

  public void saveDistributorConfig(DistributorLocatorConfig distributorLocatorConfig);

  public void createDistributorLocator();

  public List<DistributorPromoConfig> getDistributorPromoConfig();

  public List<String> getPromoCodeList(String country);

  /**
  * Create the CSV for all promo code.
  */
  public void createPromoCSVFile();

  /**
   * delete the row in database
   * @param DistributorLocator
   */
  public void deleteDistributorLocator(DistributorLocator dl);

}
