/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.crossreferenceapp;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "COMPETITOR_PRODUCT", catalog = "", schema = "CROSSREFERENCEAPP")
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "CompetitorProduct.findAll", query = "SELECT c FROM CompetitorProduct c"),
  @NamedQuery(name = "CompetitorProduct.findByCompetitorId", query = "SELECT c FROM CompetitorProduct c WHERE c.competitorProductPK.competitorId = :competitorId"),
  @NamedQuery(name = "CompetitorProduct.findByBrandId", query = "SELECT c FROM CompetitorProduct c WHERE c.competitorProductPK.brandId = :brandId"),
  @NamedQuery(name = "CompetitorProduct.findByProductId", query = "SELECT c FROM CompetitorProduct c WHERE c.competitorProductPK.productId = :productId"),
  @NamedQuery(name = "CompetitorProduct.findByCountryId", query = "SELECT c FROM CompetitorProduct c WHERE c.competitorProductPK.countryId = :countryId"),
  @NamedQuery(name = "CompetitorProduct.findByDescriptionId", query = "SELECT c FROM CompetitorProduct c WHERE c.descriptionId = :descriptionId"),
  @NamedQuery(name = "CompetitorProduct.findByProductNumber", query = "SELECT c FROM CompetitorProduct c WHERE c.productNumber = :productNumber"),
  @NamedQuery(name = "CompetitorProduct.findByUpc", query = "SELECT c FROM CompetitorProduct c WHERE c.upc = :upc"),
  @NamedQuery(name = "CompetitorProduct.findByFormat", query = "SELECT c FROM CompetitorProduct c WHERE c.format = :format"),
  @NamedQuery(name = "CompetitorProduct.findByMetricSize", query = "SELECT c FROM CompetitorProduct c WHERE c.metricSize = :metricSize"),
  @NamedQuery(name = "CompetitorProduct.findByMetricUnitGuid", query = "SELECT c FROM CompetitorProduct c WHERE c.metricUnitGuid = :metricUnitGuid"),
  @NamedQuery(name = "CompetitorProduct.findByImperialSize", query = "SELECT c FROM CompetitorProduct c WHERE c.imperialSize = :imperialSize"),
  @NamedQuery(name = "CompetitorProduct.findByImperialUnitGuid", query = "SELECT c FROM CompetitorProduct c WHERE c.imperialUnitGuid = :imperialUnitGuid"),
  @NamedQuery(name = "CompetitorProduct.findByDateVerified", query = "SELECT c FROM CompetitorProduct c WHERE c.dateVerified = :dateVerified"),
  @NamedQuery(name = "CompetitorProduct.findByTemperatureMin", query = "SELECT c FROM CompetitorProduct c WHERE c.temperatureMin = :temperatureMin"),
  @NamedQuery(name = "CompetitorProduct.findByTemperatureMax", query = "SELECT c FROM CompetitorProduct c WHERE c.temperatureMax = :temperatureMax"),
  @NamedQuery(name = "CompetitorProduct.findByVoc", query = "SELECT c FROM CompetitorProduct c WHERE c.voc = :voc"),
  @NamedQuery(name = "CompetitorProduct.findByVocUnitGuid", query = "SELECT c FROM CompetitorProduct c WHERE c.vocUnitGuid = :vocUnitGuid"),
  @NamedQuery(name = "CompetitorProduct.findByPhLower", query = "SELECT c FROM CompetitorProduct c WHERE c.phLower = :phLower"),
  @NamedQuery(name = "CompetitorProduct.findByPhHight", query = "SELECT c FROM CompetitorProduct c WHERE c.phHight = :phHight"),
  @NamedQuery(name = "CompetitorProduct.findBySdsUrl", query = "SELECT c FROM CompetitorProduct c WHERE c.sdsUrl = :sdsUrl"),
  @NamedQuery(name = "CompetitorProduct.findBySdsDate", query = "SELECT c FROM CompetitorProduct c WHERE c.sdsDate = :sdsDate"),
  @NamedQuery(name = "CompetitorProduct.findByTdsUrl", query = "SELECT c FROM CompetitorProduct c WHERE c.tdsUrl = :tdsUrl"),
  @NamedQuery(name = "CompetitorProduct.findByTdsDate", query = "SELECT c FROM CompetitorProduct c WHERE c.tdsDate = :tdsDate"),
  @NamedQuery(name = "CompetitorProduct.findByElementFlame", query = "SELECT c FROM CompetitorProduct c WHERE c.elementFlame = :elementFlame"),
  @NamedQuery(name = "CompetitorProduct.findByElementGasCylinder", query = "SELECT c FROM CompetitorProduct c WHERE c.elementGasCylinder = :elementGasCylinder"),
  @NamedQuery(name = "CompetitorProduct.findByElementCorrosion", query = "SELECT c FROM CompetitorProduct c WHERE c.elementCorrosion = :elementCorrosion"),
  @NamedQuery(name = "CompetitorProduct.findByElementExclamation", query = "SELECT c FROM CompetitorProduct c WHERE c.elementExclamation = :elementExclamation"),
  @NamedQuery(name = "CompetitorProduct.findByElementHealth", query = "SELECT c FROM CompetitorProduct c WHERE c.elementHealth = :elementHealth"),
  @NamedQuery(name = "CompetitorProduct.findByElementEnvironment", query = "SELECT c FROM CompetitorProduct c WHERE c.elementEnvironment = :elementEnvironment"),
  @NamedQuery(name = "CompetitorProduct.findByElementExplodingBomb", query = "SELECT c FROM CompetitorProduct c WHERE c.elementExplodingBomb = :elementExplodingBomb"),
  @NamedQuery(name = "CompetitorProduct.findByElementSkull", query = "SELECT c FROM CompetitorProduct c WHERE c.elementSkull = :elementSkull"),
  @NamedQuery(name = "CompetitorProduct.findByElementFlameCircle", query = "SELECT c FROM CompetitorProduct c WHERE c.elementFlameCircle = :elementFlameCircle"),
  @NamedQuery(name = "CompetitorProduct.findByProp65", query = "SELECT c FROM CompetitorProduct c WHERE c.prop65 = :prop65"),
  @NamedQuery(name = "CompetitorProduct.findByDiluationRatio", query = "SELECT c FROM CompetitorProduct c WHERE c.diluationRatio = :diluationRatio"),
  @NamedQuery(name = "CompetitorProduct.findByDiluentId", query = "SELECT c FROM CompetitorProduct c WHERE c.diluentId = :diluentId"),
  @NamedQuery(name = "CompetitorProduct.findByCreatedUserName", query = "SELECT c FROM CompetitorProduct c WHERE c.createdUserName = :createdUserName"),
  @NamedQuery(name = "CompetitorProduct.findByCreatedDate", query = "SELECT c FROM CompetitorProduct c WHERE c.createdDate = :createdDate"),
  @NamedQuery(name = "CompetitorProduct.findByUpdatedUserName", query = "SELECT c FROM CompetitorProduct c WHERE c.updatedUserName = :updatedUserName"),
  @NamedQuery(name = "CompetitorProduct.findByUpdatedDate", query = "SELECT c FROM CompetitorProduct c WHERE c.updatedDate = :updatedDate"),
  @NamedQuery(name = "CompetitorProduct.findByDeleteUserName", query = "SELECT c FROM CompetitorProduct c WHERE c.deleteUserName = :deleteUserName"),
  @NamedQuery(name = "CompetitorProduct.findByDeletedDate", query = "SELECT c FROM CompetitorProduct c WHERE c.deletedDate = :deletedDate")})
public class CompetitorProduct implements Serializable {
  private static final long serialVersionUID = 1L;
  @EmbeddedId
  protected CompetitorProductPK competitorProductPK;
  @Column(name = "DESCRIPTION_ID")
  private Integer descriptionId;
  @Basic(optional = false)
  @Column(name = "PRODUCT_NUMBER")
  private String productNumber;
  @Basic(optional = false)
  @Column(name = "UPC")
  private String upc;
  @Size(max = 255)
  @Column(name = "FORMAT")
  private String format;
  @Size(max = 30)
  @Column(name = "METRIC_SIZE")
  private String metricSize;
  @Size(max = 255)
  @Column(name = "METRIC_UNIT_GUID")
  private String metricUnitGuid;
  @Size(max = 30)
  @Column(name = "IMPERIAL_SIZE")
  private String imperialSize;
  @Size(max = 255)
  @Column(name = "IMPERIAL_UNIT_GUID")
  private String imperialUnitGuid;
  @Column(name = "DATE_VERIFIED")
  private Date dateVerified;
  @Size(max = 30)
  @Column(name = "TEMPERATURE_MIN")
  private String temperatureMin;
  @Size(max = 30)
  @Column(name = "TEMPERATURE_MAX")
  private String temperatureMax;
  @Size(max = 30)
  @Column(name = "VOC")
  private String voc;
  @Size(max = 255)
  @Column(name = "VOC_UNIT_GUID")
  private String vocUnitGuid;
  @Size(max = 30)
  @Column(name = "PH_LOWER")
  private String phLower;
  @Size(max = 30)
  @Column(name = "PH_HIGHT")
  private String phHight;
  @Size(max = 500)
  @Column(name = "SDS_URL")
  private String sdsUrl;

  @Column(name = "SDS_DATE")
  private Date sdsDate;
  @Size(max = 500)
  @Column(name = "TDS_URL")
  private String tdsUrl;

  @Column(name = "TDS_DATE")
  private Date tdsDate;
  @Column(name = "ELEMENT_FLAME")
  private Character elementFlame;
  @Column(name = "ELEMENT_GAS_CYLINDER")
  private Character elementGasCylinder;
  @Column(name = "ELEMENT_CORROSION")
  private Character elementCorrosion;
  @Column(name = "ELEMENT_EXCLAMATION")
  private Character elementExclamation;
  @Column(name = "ELEMENT_HEALTH")
  private Character elementHealth;
  @Column(name = "ELEMENT_ENVIRONMENT")
  private Character elementEnvironment;
  @Column(name = "ELEMENT_EXPLODING_BOMB")
  private Character elementExplodingBomb;
  @Column(name = "ELEMENT_SKULL")
  private Character elementSkull;
  @Column(name = "ELEMENT_FLAME_CIRCLE")
  private Character elementFlameCircle;
  @Column(name = "PROP65")
  private String prop65;
  @Size(max = 20)
  @Column(name = "DILUATION_RATIO")
  private String diluationRatio;
  @Column(name = "DILUENT_ID")
  private Long diluentId;
  @Size(max = 255)
  @Column(name = "CREATED_USER_NAME")
  private String createdUserName;
  @Column(name = "CREATED_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date createdDate;
  @Size(max = 255)
  @Column(name = "UPDATED_USER_NAME")
  private String updatedUserName;
  @Column(name = "UPDATED_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date updatedDate;
  @Size(max = 255)
  @Column(name = "DELETE_USER_NAME")
  private String deleteUserName;
  @Column(name = "DELETED_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date deletedDate;
  @Size(max = 350)
  @Column(name = "REAL_FILENAME")
  private String realFilename;
  public CompetitorProduct() {
  }

  public CompetitorProduct(CompetitorProductPK competitorProductPK) {
    this.competitorProductPK = competitorProductPK;
  }

  public CompetitorProduct(CompetitorProductPK competitorProductPK, String productNumber, String upc) {
    this.competitorProductPK = competitorProductPK;
    this.productNumber = productNumber;
    this.upc = upc;
  }

  public CompetitorProduct(long competitorId, long brandId, long productId, long countryId) {
    this.competitorProductPK = new CompetitorProductPK(competitorId, brandId, productId, countryId);
  }

  public CompetitorProductPK getCompetitorProductPK() {
    return competitorProductPK;
  }

  public void setCompetitorProductPK(CompetitorProductPK competitorProductPK) {
    this.competitorProductPK = competitorProductPK;
  }

  public Integer getDescriptionId() {
    return descriptionId;
  }

  public void setDescriptionId(Integer descriptionId) {
    this.descriptionId = descriptionId;
  }

  public String getProductNumber() {
    return productNumber;
  }

  public void setProductNumber(String productNumber) {
    this.productNumber = productNumber;
  }

  public String getUpc() {
    return upc;
  }

  public void setUpc(String upc) {
    this.upc = upc;
  }

  public String getFormat() {
    return format;
  }

  public void setFormat(String format) {
    this.format = format;
  }

  public String getMetricSize() {
    return metricSize;
  }

  public void setMetricSize(String metricSize) {
    this.metricSize = metricSize;
  }

  public String getMetricUnitGuid() {
    return metricUnitGuid;
  }

  public void setMetricUnitGuid(String metricUnitGuid) {
    this.metricUnitGuid = metricUnitGuid;
  }

  public String getImperialSize() {
    return imperialSize;
  }

  public void setImperialSize(String imperialSize) {
    this.imperialSize = imperialSize;
  }

  public String getImperialUnitGuid() {
    return imperialUnitGuid;
  }

  public void setImperialUnitGuid(String imperialUnitGuid) {
    this.imperialUnitGuid = imperialUnitGuid;
  }

  public Date getDateVerified() {
    return dateVerified;
  }

  public void setDateVerified(Date dateVerified) {
    this.dateVerified = dateVerified;
  }

  public String getTemperatureMin() {
    return temperatureMin;
  }

  public void setTemperatureMin(String temperatureMin) {
    this.temperatureMin = temperatureMin;
  }

  public String getTemperatureMax() {
    return temperatureMax;
  }

  public void setTemperatureMax(String temperatureMax) {
    this.temperatureMax = temperatureMax;
  }

  public String getVoc() {
    return voc;
  }

  public void setVoc(String voc) {
    this.voc = voc;
  }

  public String getVocUnitGuid() {
    return vocUnitGuid;
  }

  public void setVocUnitGuid(String vocUnitGuid) {
    this.vocUnitGuid = vocUnitGuid;
  }

  public String getPhLower() {
    return phLower;
  }

  public void setPhLower(String phLower) {
    this.phLower = phLower;
  }

  public String getPhHight() {
    return phHight;
  }

  public void setPhHight(String phHight) {
    this.phHight = phHight;
  }

  public String getSdsUrl() {
    return sdsUrl;
  }

  public void setSdsUrl(String sdsUrl) {
    this.sdsUrl = sdsUrl;
  }

  public Date getSdsDate() {
    return sdsDate;
  }

  public void setSdsDate(Date sdsDate) {
    this.sdsDate = sdsDate;
  }

  public String getTdsUrl() {
    return tdsUrl;
  }

  public void setTdsUrl(String tdsUrl) {
    this.tdsUrl = tdsUrl;
  }

  public Date getTdsDate() {
    return tdsDate;
  }

  public void setTdsDate(Date tdsDate) {
    this.tdsDate = tdsDate;
  }

  public Character getElementFlame() {
    return elementFlame;
  }

  public void setElementFlame(Character elementFlame) {
    this.elementFlame = elementFlame;
  }

  public Character getElementGasCylinder() {
    return elementGasCylinder;
  }

  public void setElementGasCylinder(Character elementGasCylinder) {
    this.elementGasCylinder = elementGasCylinder;
  }

  public Character getElementCorrosion() {
    return elementCorrosion;
  }

  public void setElementCorrosion(Character elementCorrosion) {
    this.elementCorrosion = elementCorrosion;
  }

  public Character getElementExclamation() {
    return elementExclamation;
  }

  public void setElementExclamation(Character elementExclamation) {
    this.elementExclamation = elementExclamation;
  }

  public Character getElementHealth() {
    return elementHealth;
  }

  public void setElementHealth(Character elementHealth) {
    this.elementHealth = elementHealth;
  }

  public Character getElementEnvironment() {
    return elementEnvironment;
  }

  public void setElementEnvironment(Character elementEnvironment) {
    this.elementEnvironment = elementEnvironment;
  }

  public Character getElementExplodingBomb() {
    return elementExplodingBomb;
  }

  public void setElementExplodingBomb(Character elementExplodingBomb) {
    this.elementExplodingBomb = elementExplodingBomb;
  }

  public Character getElementSkull() {
    return elementSkull;
  }

  public void setElementSkull(Character elementSkull) {
    this.elementSkull = elementSkull;
  }

  public Character getElementFlameCircle() {
    return elementFlameCircle;
  }

  public void setElementFlameCircle(Character elementFlameCircle) {
    this.elementFlameCircle = elementFlameCircle;
  }

  public String getProp65() {
    return prop65;
  }

  public void setProp65(String prop65) {
    this.prop65 = prop65;
  }

  public String getDiluationRatio() {
    return diluationRatio;
  }

  public void setDiluationRatio(String diluationRatio) {
    this.diluationRatio = diluationRatio;
  }

  public Long getDiluentId() {
    return diluentId;
  }

  public void setDiluentId(Long diluentId) {
    this.diluentId = diluentId;
  }

  public String getCreatedUserName() {
    return createdUserName;
  }

  public void setCreatedUserName(String createdUserName) {
    this.createdUserName = createdUserName;
  }

  public Date getCreatedDate() {
    return createdDate;
  }

  public void setCreatedDate(Date createdDate) {
    this.createdDate = createdDate;
  }

  public String getUpdatedUserName() {
    return updatedUserName;
  }

  public void setUpdatedUserName(String updatedUserName) {
    this.updatedUserName = updatedUserName;
  }

  public Date getUpdatedDate() {
    return updatedDate;
  }

  public void setUpdatedDate(Date updatedDate) {
    this.updatedDate = updatedDate;
  }

  public String getDeleteUserName() {
    return deleteUserName;
  }

  public void setDeleteUserName(String deleteUserName) {
    this.deleteUserName = deleteUserName;
  }

  public Date getDeletedDate() {
    return deletedDate;
  }

  public void setDeletedDate(Date deletedDate) {
    this.deletedDate = deletedDate;
  }

  public String getRealFilename() {
    return realFilename;
  }

  public void setRealFilename(String realFilename) {
    this.realFilename = realFilename;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (competitorProductPK != null ? competitorProductPK.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof CompetitorProduct)) {
      return false;
    }
    CompetitorProduct other = (CompetitorProduct) object;
    if ((this.competitorProductPK == null && other.competitorProductPK != null) || (this.competitorProductPK != null && !this.competitorProductPK.equals(other.competitorProductPK))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.crossreferenceapp.CompetitorProduct[ competitorProductPK=" + competitorProductPK + " ]";
  }

}
