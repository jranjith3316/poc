package com.savoirfairelinux.walter.model;

import java.io.Serializable;

/**
 * @author julien
 */
public class CntLight implements Serializable {

    private Long cntId;
    private String cntRef;

    public CntLight(Long cntId, String cntRef) {
        this.cntId = cntId;
        this.cntRef = cntRef;
    }

    public Long getCntId() {
        return cntId;
    }

    public void setCntId(Long cntId) {
        this.cntId = cntId;
    }

    public String getCntRef() {
        return cntRef;
    }

    public void setCntRef(String cntRef) {
        this.cntRef = cntRef;
    }
}
