/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.service.impl;

import com.savoirfairelinux.walter.dao.walter.UPerson;
import com.savoirfairelinux.walter.dao.waltercb.PromoItem;
import com.savoirfairelinux.walter.dao.waltercb.PromoItemCountry;
import com.savoirfairelinux.walter.dao.waltercb.PromoItemCountryPK;
import com.savoirfairelinux.walter.dao.waltercb.PromoItemTxt;
import com.savoirfairelinux.walter.dao.waltercb.PromoItemTxtPK;
import com.savoirfairelinux.walter.dao.waltercb.PromoOrder;
import com.savoirfairelinux.walter.dao.waltercb.PromoOrderItem;
import com.savoirfairelinux.walter.model.PromoItemModel;
import com.savoirfairelinux.walter.model.PromoOrderModel;
import com.savoirfairelinux.walter.service.GiveAwaysBeanRemote;
import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;
import javax.annotation.security.PermitAll;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.mail.internet.InternetAddress;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;

/**
 *
 * @author jsgill
 */
@Stateless(name = "GiveAwaysBean")
@TransactionManagement(TransactionManagementType.CONTAINER)
@PermitAll
@LocalBean
public class GiveAwaysBean implements GiveAwaysBeanRemote {

  public static final Logger LOG = Logger.getLogger(GiveAwaysBean.class.getCanonicalName());
  @PersistenceContext(unitName = "waltershare")
  EntityManager entityManager;
  @EJB
  SingletonBean singletonBean;
  @EJB
  WalterBean walterBean;
  @EJB
  NotificationBean notificationBean;

  @Override
  public PromoItem getPromoItem(Long itemId) {
    PromoItem promoItems = new PromoItem();

    try {
      promoItems = entityManager.createQuery(singletonBean.getGiveAwaysQuery("promoItem.getByItemId"), PromoItem.class)
                                .setParameter("itemId", itemId)
                                .getSingleResult();

    } catch (PersistenceException e) {
      LOG.warning("getPromoItem: " + e.getMessage());
    }
    return promoItems;
  }

  @Override
  public PromoItemCountry getPromoItemCountry(Long itemId, Long countryId) {
    PromoItemCountry promoItemsCountry = new PromoItemCountry();

    try {
      promoItemsCountry = entityManager.createQuery(singletonBean.getGiveAwaysQuery("promoItemCountry.getByItemIdCountryId"), PromoItemCountry.class)
                                       .setParameter("itemId", itemId)
                                       .setParameter("countryId", countryId)
                                       .getSingleResult();

    } catch (PersistenceException e) {
      LOG.warning("getPromoItemCountry: " + e.getMessage());
    }
    return promoItemsCountry;
  }

  @Override
  public PromoItemTxt getPromoItemTxt(Long itemId, Long langId) {
    PromoItemTxt promoItemTxt = new PromoItemTxt();

    try {
      promoItemTxt = entityManager.createQuery(singletonBean.getGiveAwaysQuery("promoItemTxt.getByItemIdLangId"), PromoItemTxt.class)
                                  .setParameter("itemId", itemId)
                                  .setParameter("langId", langId)
                                  .getSingleResult();

    } catch (PersistenceException e) {
      LOG.warning("getPromoItemTxt: " + e.getMessage());
    }
    return promoItemTxt;
  }


  @Override
  public void savePromo(PromoItem pi, PromoItemCountry picCA, PromoItemCountry picUSA, PromoItemTxt pitEN, PromoItemTxt pitFR) {
    try {
      if (pi.getItemId() == null) {
        pi.setItemId(getNextItemId());
        picCA.setPromoItemCountryPK(new PromoItemCountryPK(pi.getItemId(), 2L));
        picUSA.setPromoItemCountryPK(new PromoItemCountryPK(pi.getItemId(), 3L));
        pitEN.setPromoItemTxtPK(new PromoItemTxtPK(pi.getItemId(), 1));
        pitFR.setPromoItemTxtPK(new PromoItemTxtPK(pi.getItemId(), 2));
      }

      entityManager.merge(pi);
      entityManager.merge(picCA);
      entityManager.merge(picUSA);
      entityManager.merge(pitEN);
      entityManager.merge(pitFR);
    } catch (PersistenceException e) {
      LOG.warning("savePromo: " + e.getMessage());
    }

  }

  private Long getNextItemId() {

    Long itemId = 0L;
    try {
      Object object = entityManager.createNativeQuery(singletonBean.getGiveAwaysQuery("promoItemCountry.getNextItemId"))
                                   .getSingleResult();

      itemId = Long.parseLong(object.toString());
    } catch (PersistenceException e) {
      LOG.warning("getNextItemId" + e.getMessage());
    }

    return itemId;

  }

  @Override
  public List<PromoItemModel> getItemList() {
    List<PromoItemModel> promoItemModels = new ArrayList<>();
    try {
      List<Object[]> objectList = entityManager.createNativeQuery(singletonBean.getGiveAwaysQuery("promoItem.getItemList"))
                                               .getResultList();

      for ( Object[] object : objectList ){
        Long itemId = Long.parseLong(object[0].toString()); ;
        String productNumber = ( object[1] != null ) ? object[1].toString() : "";
        String name = ( object[2] != null ) ? object[2].toString() : "";

        promoItemModels.add(new PromoItemModel(itemId, productNumber, name));

      }
    } catch (PersistenceException e) {
      LOG.warning("getItemList" + e.getMessage());
    }
    return promoItemModels;
  }

  @Override
  public Boolean getProductNumberExist(String productNumber){
    Boolean productFind = false;
    try{

      String product = entityManager.createQuery(singletonBean.getGiveAwaysQuery("promoItem.getByProductnumber"), String.class)
                                    .setParameter("productNumber", productNumber)
                                    .getSingleResult();

      if ( product != null ){
        productFind = true;
      }


    } catch (PersistenceException e) {
      LOG.warning("getProductNumberExist" + e.getMessage());
    }

    return productFind;
  }

  @Override
  public List<PromoItemModel> getAvailableProduct(Long countryId, Long langId){
    List<PromoItemModel> promoItemModels = new ArrayList<>();
    try{

      List<Object[]> objectList = entityManager.createNativeQuery(singletonBean.getGiveAwaysQuery("promo.availableItemByCountryLang"))
                                               .setParameter("countryId", countryId)
                                               .setParameter("langId", langId)
                                               .getResultList();


      for ( Object[] object : objectList ){
        Long item_id = Long.parseLong(object[0].toString());
        String product_number = ( object[1] != null ) ? object[1].toString() : "";
        Blob image = ( object[2] != null ) ? (Blob) object[2] : null;
        String image_name = ( object[3] != null ) ? object[3].toString() : "";
        BigDecimal list_price = ( object[4] != null ) ? new BigDecimal(object[4].toString()) : BigDecimal.ZERO;
        String name = ( object[5] != null ) ? object[5].toString() : "";

        byte[] img = null;

        if ( image != null )
          img = image.getBytes(1, (int) image.length());

        promoItemModels.add(new PromoItemModel(item_id, product_number, name, img, image_name, list_price));

      }

    } catch (PersistenceException e) {
      LOG.warning("getAvailableProduct" + e.getMessage());
    } catch (SQLException ex) {
     LOG.warning("getAvailableProduct" + ex.getMessage());
    }

    return promoItemModels;
  }

  @Override
  public PromoOrder addPromoOrderItem(PromoOrder po, PromoItemModel pim, Long countryId ){

    try{

      if ( po != null && po.getOrderId() != null ){
        PromoItem pi = getPromoItem(pim.getItemid());
        if ( checkItemAlreadyAdded(countryId, po.getOrderId(), pim.getItemid()) == false ){
          PromoOrderItem poi = new PromoOrderItem(po.getOrderId(), getNextPromoLineId(po.getOrderId()), pi.getItemId());
          PromoItemCountry pic = getPromoItemCountry(pim.getItemid(), countryId);
          poi.setPriceEach(pic.getListPrice());
          poi.setExtraPriceEach(pic.getLogoExtraPrice());
          poi.setQuantity(1);

          entityManager.persist(poi);
        }
      } else {
        po.setOrderId(getNextPromoOrderId());
        PromoItem pi = getPromoItem(pim.getItemid());
        PromoOrderItem poi = new PromoOrderItem(po.getOrderId(), getNextPromoLineId(po.getOrderId()), pi.getItemId());

        PromoItemCountry pic = getPromoItemCountry(pim.getItemid(), countryId);

        poi.setPriceEach(pic.getListPrice());
        poi.setExtraPriceEach(pic.getLogoExtraPrice());
        poi.setQuantity(1);

        entityManager.merge(po);
        entityManager.merge(poi);
      }

    } catch (PersistenceException e) {
      LOG.warning("addPromoOrderItem" + e.getMessage());
    }

    return po;
  }

  private Long getNextPromoOrderId() {

    Long itemId = 0L;
    try {
      Object object = entityManager.createNativeQuery(singletonBean.getGiveAwaysQuery("promoOrderItem.getNextOrderId"))
                                   .getSingleResult();

      itemId = Long.parseLong(object.toString());
    } catch (PersistenceException e) {
      LOG.warning("getNextPromoOrderId: " + e.getMessage());
    }

    return itemId;

  }

  private Long getNextPromoLineId(Long orderId) {

    Long lineId = 0L;
    try {
      Object object = entityManager.createNativeQuery(singletonBean.getGiveAwaysQuery("promoOrderItem.getNextLineId"))
                                   .setParameter("orderId", orderId)
                                   .getSingleResult();

      lineId = Long.parseLong(object.toString());
    } catch (PersistenceException e) {
      LOG.warning("getNextPromoLineId: " + e.getMessage());
    }

    return lineId;

  }

  @Override
  public List<PromoOrderModel> getUnsubmittedOrder(String creatorUserName) {
    List<PromoOrderModel> promoOrderModels = new ArrayList<>();
    try {
      List<Object[]> objectList = entityManager.createNativeQuery(singletonBean.getGiveAwaysQuery("promoOrder.getUnSubmittedOrder"))
                                               .setParameter("creatorUserName", creatorUserName)
                                               .getResultList();

      for ( Object[] object : objectList ){
        Long orderId = Long.parseLong(object[0].toString());
        Date CreationDate = (Date) object[1];
        BigDecimal total = ( object[2] != null ) ? new BigDecimal(object[2].toString()) : BigDecimal.ZERO;
        promoOrderModels.add(new PromoOrderModel(orderId, CreationDate, total));
      }

    } catch (PersistenceException e) {
      LOG.warning("getUnsubmittedOrder: " + e.getMessage());
    }

    return promoOrderModels;

  }

  @Override
  public List<PromoOrderModel> getSubmittedOrder(String creatorUserName) {
    List<PromoOrderModel> promoOrderModels = new ArrayList<>();
    try {
      List<Object[]> objectList = entityManager.createNativeQuery(singletonBean.getGiveAwaysQuery("promoOrder.getSubmittedOrder"))
                                               .setParameter("creatorUserName", creatorUserName)
                                               .getResultList();

      for ( Object[] object : objectList ){
        Long orderId = Long.parseLong(object[0].toString());
        Date CreationDate = (Date) object[1];
        BigDecimal total = ( object[2] != null ) ? new BigDecimal(object[2].toString()) : BigDecimal.ZERO;
        promoOrderModels.add(new PromoOrderModel(orderId, CreationDate, total));
      }

    } catch (PersistenceException e) {
      LOG.warning("getUnsubmittedOrder: " + e.getMessage());
    }

    return promoOrderModels;

  }

  @Override
  public PromoOrder getLastPromoOrder(String creatorUserName){
    PromoOrder po = new PromoOrder();

    try{

      po = entityManager.createQuery(singletonBean.getGiveAwaysQuery("PromoOrder.getLastCreated"), PromoOrder.class)
                        .setParameter("creatorUserName", creatorUserName)
                        .getSingleResult();

    } catch(PersistenceException e){
      LOG.warning("getCurrentPromoOrder: " + e.getMessage());
    }

    return po;
  }

  @Override
  public PromoOrder getPromoOrder(Long orderId) {
    PromoOrder po = new PromoOrder();
    try {
      po = entityManager.createQuery(singletonBean.getGiveAwaysQuery("PromoOrder.getById"), PromoOrder.class)
                        .setParameter("orderId", orderId)
                        .getSingleResult();


    } catch (PersistenceException e) {
      LOG.warning("getPromoOrder: " + e.getMessage());
    }

    return po;

  }

  @Override
  public Long getNumberItemShoppingCart(Long orderId) {
    long numberItem = 0L;
    try {
      if ( orderId != null ){
        Object object = entityManager.createNativeQuery(singletonBean.getGiveAwaysQuery("PromoOrderItem.getNumberItemShoppingCart"))
                                     .setParameter("orderId", orderId.longValue())
                                     .getSingleResult();
        if ( object != null ){
          numberItem = Long.parseLong(object.toString());
        }
      }
    } catch (PersistenceException e) {
      LOG.warning("getNumberItemShoppingCart: " + e.getMessage());
    }

    return numberItem;

  }

  @Override
  public Boolean checkItemAlreadyAdded(Long countryId, Long orderId, Long itemId) {
    Boolean productAdded = false;
    try {

      Object object = entityManager.createNativeQuery(singletonBean.getGiveAwaysQuery("PromoOrderItem.checkItemAlreadyAdded"))
                                   .setParameter("orderId", orderId.longValue())
                                   .setParameter("countryId", countryId)
                                   .setParameter("itemId", itemId.longValue())
                                   .getSingleResult();

      if ( object != null ){
        Long itemCount = Long.parseLong(object.toString());
        if ( itemCount > 0 ){
          productAdded = true;
        }
      }

    } catch (PersistenceException e) {
      LOG.warning("checkItemAlreadyAdded: " + e.getMessage());
    }

    return productAdded;

  }

  @Override
  public List<PromoOrderItem> getPromoOrderItem(Long orderId) {
    List<PromoOrderItem> promoOrderItems = new ArrayList<>();
    try {

      promoOrderItems = entityManager.createQuery(singletonBean.getGiveAwaysQuery("PromoOrderItme.getList"), PromoOrderItem.class)
                                     .setParameter("orderId", orderId)
                                     .getResultList();


    } catch (PersistenceException e) {
      LOG.warning("getPromoOrderItem: " + e.getMessage());
    }

    return promoOrderItems;
  }

  public void deletePromoOrderItem(PromoOrderItem poi){
    try{
      int returnValue = entityManager.createNativeQuery(singletonBean.getGiveAwaysQuery("PromoOrderItme.deleteRow"))
                                     .setParameter("orderId", poi.getPromoOrderItemPK().getOrderId())
                                     .setParameter("lineId", poi.getPromoOrderItemPK().getLineId())
                                     .setParameter("itemId", poi.getPromoOrderItemPK().getItemId())
                                     .executeUpdate();
    } catch (PersistenceException e) {
      LOG.warning("deletePromoOrderItem: " + e.getMessage());
    }
  }

  @Override
  public void submitOrder(PromoOrder po, List<InternetAddress> CSRUsers, String productList){
    try{
      po.setSubmitDate(new Date());

      entityManager.merge(po);


      Object object = entityManager.createNativeQuery(singletonBean.getGiveAwaysQuery("PromoOrderItem.getSum"))
                                   .setParameter("orderId", po.getOrderId())
                                   .getSingleResult();

      if ( object != null ){
        BigDecimal bg = new BigDecimal(object.toString());

        UPerson up = walterBean.getUPerson(po.getCreatorUserName().toUpperCase());
        up.setGiveawaysCredit(up.getGiveawaysCredit().subtract(bg));
        entityManager.merge(up);

      }

      notificationBean.sendGiveAwaysCSRNotification(po, CSRUsers, productList);

    } catch (PersistenceException e) {
      LOG.warning("submitOrder: " + e.getMessage());
    } catch (Exception e) {
      LOG.warning("submitOrder: " + e.getMessage());
    }
  }


}
