package com.savoirfairelinux.walter.service;

import java.math.BigDecimal;
import java.util.List;

import javax.ejb.Remote;

import com.savoirfairelinux.walter.dao.waltercb.CbFranchise;
import com.savoirfairelinux.walter.dao.waltercb.CbFranchiseTxt;
import com.savoirfairelinux.walter.dao.waltercb.CbTradename;
import com.savoirfairelinux.walter.dao.waltercb.CbTradenameTxt;
import com.savoirfairelinux.walter.dao.waltercb.UTradenameShare;
import com.savoirfairelinux.walter.model.Franchise;
import com.savoirfairelinux.walter.model.Tradename;

@Remote
public interface RosettaStoneBeanRemote {

	public List<CbFranchiseTxt> getCBFranchiseList() throws Exception;

	public  String getCBFranchiseToBeTranslated(Short franchiseId) throws Exception;

	public List<Object[]> getCbTradenameTxt(Short franchsieId, String language) throws Exception;

	public String getCBTradeNameToBeTranslated(Short franchiseId, Long tradenameId) throws Exception;

	public List<Object[]> getCBFranchiseEdit(Short franchiseId) throws Exception;

	public CbFranchise setCBFranchise(Short franchiseId, String createdBy) throws Exception;

	public CbFranchiseTxt setCBFranchiseTxt(Short franchiseId, Long langId, String description) throws Exception;

	public Short getCBFranchiseSeq() throws Exception;

	public CbTradenameTxt getCBTradeNameTxt(Short franchiseId, long tradenameId ) throws Exception;

	public List<Object[]> getCBTradeNameEdit(Short franchiseId, long tradenameId ) throws Exception;

	public Long getCBTradeNameIdSeq() throws Exception;

	public CbTradename setCBTradename(Short franchiseId, Long tradenameId, String createdBy) throws Exception;

	public CbTradenameTxt setCBTradenameTxt(Short franchiseId, Long tradenameId, Long langId, String description) throws Exception;	

	public CbTradename deleteCBTradename(Short franchiseId, Long tradenameId) throws Exception;

	public List<Object[]> getListTradeShare() throws Exception;
	
	public List<Tradename> getTradenames(String organization) throws Exception;
	
	public List<Franchise> getFranchises(String organization) throws Exception;
	
	public UTradenameShare setUTradenameShare(UTradenameShare utradename) throws Exception;
	
	public BigDecimal getUTradenameShareSeq() throws Exception;
	
	public void removeUTradenameShare(UTradenameShare utradenameShare) throws Exception;
}
