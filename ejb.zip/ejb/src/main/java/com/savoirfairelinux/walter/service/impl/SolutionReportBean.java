/*
 l * Copyright 2012 Savoir-faire Linux
 *
 * This file is part of Walter-Portal.
 *
 * Walter-Portal is free software: you can redistribute it and/or modify it under the terms of the
 * GNU General Public License as published by the Free Software Foundation, either version 3
 * of the License, or (at your option) any later version.
 *
 * Walter-Portal is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with Walter-Portal.
 * If not, see http://www.gnu.org/licenses/.
 */
package com.savoirfairelinux.walter.service.impl;

import com.savoirfairelinux.walter.dao.waltercb.Cnt;
import com.savoirfairelinux.walter.dao.waltercb.CntCounter;
import com.savoirfairelinux.walter.dao.waltercb.CntCounterPK;
import com.savoirfairelinux.walter.dao.waltercb.CntFeedback;
import com.savoirfairelinux.walter.dao.waltercb.CntFeedbackR;
import com.savoirfairelinux.walter.dao.waltercb.CntOpinion;
import com.savoirfairelinux.walter.dao.waltercb.CntPicture;
import com.savoirfairelinux.walter.dao.waltercb.CntPictureTxt;
import com.savoirfairelinux.walter.dao.waltercb.CntProduct;
import com.savoirfairelinux.walter.dao.waltercb.CntProductPK;
import com.savoirfairelinux.walter.dao.waltercb.CntTranslate;
import com.savoirfairelinux.walter.dao.waltercb.CntTranslatePK;
import com.savoirfairelinux.walter.dao.waltercb.CntTxt;
import com.savoirfairelinux.walter.dao.waltercb.CntUrl;
import com.savoirfairelinux.walter.dao.waltercb.Country;
import com.savoirfairelinux.walter.dao.waltercb.Naics;
import com.savoirfairelinux.walter.dao.waltercb.NaicsCustomer;
import com.savoirfairelinux.walter.dao.waltercb.UActivity;
import com.savoirfairelinux.walter.dao.waltercb.UContaminant;
import com.savoirfairelinux.walter.dao.waltercb.UIndustry;
import com.savoirfairelinux.walter.dao.waltercb.ULang;
import com.savoirfairelinux.walter.dao.waltercb.UMachinery;
import com.savoirfairelinux.walter.dao.waltercb.UMaterial;
import com.savoirfairelinux.walter.model.CntLight;
import com.savoirfairelinux.walter.model.Franchise;
import com.savoirfairelinux.walter.model.NaicsLevel;
import com.savoirfairelinux.walter.model.ReportState;
import com.savoirfairelinux.walter.model.SearchReport;
import com.savoirfairelinux.walter.model.Tradename;
import com.savoirfairelinux.walter.model.WalterOrganization;
import com.savoirfairelinux.walter.service.SolutionReportBeanRemote;
import com.savoirfairelinux.walter.util.criteriabuilder.CntTranslateCriteriaBuilder;
import com.savoirfairelinux.walter.util.criteriabuilder.QueryWrapper;
import com.savoirfairelinux.walter.util.criteriabuilder.ReportCriteriaBuilder;
import com.savoirfairelinux.walter.util.criteriabuilder.ReportSubQueryCriteriaBuilder;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.security.PermitAll;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import org.hibernate.Hibernate;
import org.hibernate.transform.DistinctRootEntityResultTransformer;

/**
 *
 * @author mgubaidullin
 * @author jderuere
 */
@Stateless(name = "SolutionReportBean")
@TransactionManagement(TransactionManagementType.CONTAINER)
@PermitAll
@LocalBean
public class SolutionReportBean implements SolutionReportBeanRemote {

    public static final Logger LOG = Logger.getLogger(SolutionReportBean.class.getCanonicalName());
    @PersistenceContext(unitName = "waltershare")
    EntityManager entityManager;
    @EJB
    SingletonBean singletonBean;
    @EJB
    WalterBean walterBean;
    @EJB
    NotificationBean notificationBean;

    @Override
    @Interceptors(DebugInterceptor.class)
    public List<Cnt> search(SearchReport report, String userName, String languageAbbreviation) throws Exception {
        List<Cnt> result;
        try {
            ULang language = walterBean.getULang(languageAbbreviation);
            ReportCriteriaBuilder criteriaBuilder = new ReportCriteriaBuilder(entityManager, report, language);
            List<Cnt> rows = criteriaBuilder.buildQuery().getQuery().getResultList();

            rows = DistinctRootEntityResultTransformer.INSTANCE.transformList(rows);
            QueryWrapper<Cnt> subQueryWrapper = new ReportSubQueryCriteriaBuilder(entityManager, report, language).buildQuery();
            HashMap<Long, String> walterProductNames = getReportWalterProductNames(languageAbbreviation, subQueryWrapper);
            HashMap<Long, String> cbProductNames = getRecentReportCbProductNames(subQueryWrapper, language.getLangId());
            HashMap<Long, Long> reportCounters = getRecentReportCounters(userName, subQueryWrapper);
            Collection<Cnt> temp = new LinkedHashSet<Cnt>(rows);
            result = new ArrayList<Cnt>(temp.size());
            for (Cnt cnt : temp) {
                String walterProductName = walterProductNames.get(cnt.getCntId());
                String cbProductName = cbProductNames.get(cnt.getCntId());
                cnt.setProductName((walterProductName != null ? walterProductName : "") + ((walterProductName != null && cbProductName != null ? ", " : "")) + (cbProductName != null ? cbProductName : ""));
                cnt.setCounter(reportCounters.containsKey(cnt.getCntId()) ? reportCounters.get(cnt.getCntId()) : 0L);
                String englishLangObjective = null;
                String userLangObjective = null;
                for (CntTxt txt : cnt.getCntTxtList()) {
                    if (txt.getCntTxtPK().getLangId() == language.getLangId()) {
                        userLangObjective = txt.getObjective();
                    } else if (txt.getCntTxtPK().getLangId() == ULang.ENGLISH_ID) {
                        englishLangObjective = txt.getObjective();
                    }
                }
                cnt.setObjective(userLangObjective != null ? userLangObjective : englishLangObjective);
                result.add(cnt);
            }
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    @Interceptors(DebugInterceptor.class)
    public void load(Set<Cnt> reports, ULang language) throws Exception {
        if (!reports.isEmpty()) {
            try {
                HashMap<Long, String> walterProductNames = getReportWalterProductNames(language.getIdbAbbreviation(), reports);
                HashMap<Long, String> cbProductNames = getRecentReportCbProductNames(reports, language.getLangId());
                for (Cnt cnt : reports) {
                    String walterProductName = walterProductNames.get(cnt.getCntId());
                    String cbProductName = cbProductNames.get(cnt.getCntId());
                    cnt.setProductName((walterProductName != null ? walterProductName : "") + ((walterProductName != null && cbProductName != null ? ", " : "")) + (cbProductName != null ? cbProductName : ""));
                    String englishLangObjective = null;
                    String userLangObjective = null;
                    for (CntTxt txt : cnt.getCntTxtList()) {
                        if (txt.getCntTxtPK().getLangId() == language.getLangId()) {
                            userLangObjective = txt.getObjective();
                        } else if (txt.getCntTxtPK().getLangId() == 1) {
                            englishLangObjective = txt.getObjective();
                        }
                    }
                    cnt.setObjective(userLangObjective != null ? userLangObjective : englishLangObjective);
                }
            } catch (Exception e) {
                LOG.severe(e.getMessage());
                throw new Exception(e.getMessage());
            }
        }
    }

    @Override
    @Interceptors(DebugInterceptor.class)
    public List<CntTranslate> getMyPendingForTranslation(String userName, String languageAbbreviation, String country) throws Exception {
        List<CntTranslate> result;
        try {
            result = getPendingForTranslation(null, userName, languageAbbreviation, country);
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    @Interceptors(DebugInterceptor.class)
    public List<CntTranslate> getPendingForTranslation(String organization, String userName, String languageAbbreviation, String country) throws Exception {
        List<CntTranslate> result;
        try {
            CntTranslateCriteriaBuilder criteriaBuilder = new CntTranslateCriteriaBuilder(entityManager, userName, organization);
            List<CntTranslate> rows = criteriaBuilder.buildQuery().getQuery().getResultList();

            ULang language = walterBean.getULang(languageAbbreviation);
            Collection<CntTranslate> temp = new LinkedHashSet<CntTranslate>(rows);
            result = new ArrayList<CntTranslate>(temp.size());
            for (CntTranslate translate : temp) {
                Cnt cnt = translate.getCnt();
                String englishLangObjective = null;
                String userLangObjective = null;
                for (CntTxt txt : cnt.getCntTxtList()) {
                    if (txt.getCntTxtPK().getLangId() == language.getLangId()) {
                        userLangObjective = txt.getObjective();
                    } else if (txt.getCntTxtPK().getLangId() == ULang.ENGLISH_ID) {
                        englishLangObjective = txt.getObjective();
                    }
                }
                cnt.setObjective(userLangObjective != null ? userLangObjective : englishLangObjective);
                result.add(translate);
            }
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    @Interceptors(DebugInterceptor.class)
    public List<Cnt> getRecentSolutionReports(String organization, String userName, String languageAbbreviation, String country) throws Exception {
        List<Cnt> result;
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        calendar.add(Calendar.DAY_OF_MONTH, -90);

        SearchReport report = new SearchReport();
        report.setFromPublicationDate(calendar.getTime());
        report.setToPublicationDate(new Date());
        report.setOrganization(organization.equalsIgnoreCase(WalterOrganization.WALTER.getName()) ? WalterOrganization.WALTER : WalterOrganization.BIO_CIRCLE);
        report.setOrganization2(organization.equalsIgnoreCase(WalterOrganization.WALTER.getName()) ? WalterOrganization.BIO_CIRCLE : WalterOrganization.WALTER);
        try {
            result = search(report, userName, languageAbbreviation);
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    private HashMap<Long, String> getReportWalterProductNames(String languageAbbreviation, Set<Cnt> reports) throws Exception {
        HashMap<Long, String> result = new HashMap<Long, String>();
        try {
            StringBuilder sql = new StringBuilder(singletonBean.getSolutionReportQuery("solution.report.walter.productnames"))
                    .append("AND cnt in (:reports)");

            TypedQuery<Object[]> query = entityManager.createQuery(sql.toString(), Object[].class)
                    .setParameter("reports", reports);

            HashMap<String, String> translations = getWalterTradenamesTranslation(languageAbbreviation);

            List<Object[]> rows = query.getResultList();
            for (Object[] row : rows) {
                Long cntId = (Long) row[0];
                String name = String.valueOf(row[1]);
                name = translations.containsKey(name) ? translations.get(name) : name;

                if (result.containsKey(cntId)) {
                    result.put(cntId, result.get(cntId) + ", " + name);
                } else {
                    result.put(cntId, name);
                }
            }
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    private HashMap<Long, String> getReportWalterProductNames(String languageAbbreviation, QueryWrapper<Cnt> queryWrapper) throws Exception {
        HashMap<Long, String> result = new HashMap<Long, String>();
        try {
            StringBuilder sql = new StringBuilder(singletonBean.getSolutionReportQuery("solution.report.walter.productnames"))
                    .append("AND cnt in (").append(queryWrapper.getQueryString()).append(")");

            TypedQuery<Object[]> query = entityManager.createQuery(sql.toString(), Object[].class);
            for (Map.Entry<String, Object> entry : queryWrapper.getProperties().entrySet()) {
                query.setParameter(entry.getKey(), entry.getValue());
            }

            HashMap<String, String> translations = getWalterTradenamesTranslation(languageAbbreviation);

            List<Object[]> rows = query.getResultList();
            for (Object[] row : rows) {
                Long cntId = (Long) row[0];
                String name = String.valueOf(row[1]);
                name = translations.containsKey(name) ? translations.get(name) : name;

                if (result.containsKey(cntId)) {
                    result.put(cntId, result.get(cntId) + ", " + name);
                } else {
                    result.put(cntId, name);
                }
            }
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }


    private HashMap<Long, String> getRecentReportCbProductNames(Set<Cnt> reports, Long langId) throws Exception {
        HashMap<Long, String> result = new HashMap<Long, String>();
        try {
            StringBuilder sql = new StringBuilder(singletonBean.getSolutionReportQuery("solution.report.biocircle.productnames"))
                    .append("AND cnt in (:reports)");

            TypedQuery<Object[]> query = entityManager.createQuery(sql.toString(), Object[].class)
                    .setParameter("reports", reports)
                    .setParameter("langId", langId);

            List<Object[]> rows = query.getResultList();
            for (Object[] row : rows) {
                Long cntId = (Long) row[0];
                String name = String.valueOf(row[1]);

                if (result.containsKey(cntId)) {
                    result.put(cntId, result.get(cntId) + ", " + name);
                } else {
                    result.put(cntId, name);
                }
            }
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    private HashMap<Long, String> getRecentReportCbProductNames(QueryWrapper<Cnt> queryWrapper, Long langId) throws Exception {
        HashMap<Long, String> result = new HashMap<Long, String>();
        try {
            StringBuilder sql = new StringBuilder(singletonBean.getSolutionReportQuery("solution.report.biocircle.productnames"))
                    .append("AND cnt in (").append(queryWrapper.getQueryString()).append(")");

            TypedQuery<Object[]> query = entityManager.createQuery(sql.toString(), Object[].class);
            for (Map.Entry<String, Object> entry : queryWrapper.getProperties().entrySet()) {
                query.setParameter(entry.getKey(), entry.getValue());
            }

            query.setParameter("langId", langId);

            List<Object[]> rows = query.getResultList();
            for (Object[] row : rows) {
                Long cntId = (Long) row[0];
                String name = String.valueOf(row[1]);

                if (result.containsKey(cntId)) {
                    result.put(cntId, result.get(cntId) + ", " + name);
                } else {
                    result.put(cntId, name);
                }
            }
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    private HashMap<Long, Long> getRecentReportCounters(String userName, QueryWrapper<Cnt> queryWrapper) throws Exception {
        HashMap<Long, Long> result = new HashMap<Long, Long>();
        try {
            StringBuilder sql = new StringBuilder(singletonBean.getSolutionReportQuery("solution.report.read.counter"))
                    .append("AND cnt in (").append(queryWrapper.getQueryString()).append(")");

            TypedQuery<Object[]> query = entityManager.createQuery(sql.toString(), Object[].class);
            for (Map.Entry<String, Object> entry : queryWrapper.getProperties().entrySet()) {
                query.setParameter(entry.getKey(), entry.getValue());
            }

            List<Object[]> rows = query.setParameter("userName", userName.toUpperCase()).getResultList();
            for (Object[] row : rows) {
                Long cntId = ((Long) row[0]);
                Long counter = ((Long) row[1]);
                result.put(cntId, counter);
            }
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    @Interceptors(DebugInterceptor.class)
    public List<Cnt> getUnreadSolutionReports(String organization, String userName, String languageAbbreviation, String country) throws Exception {
        List<Cnt> result = new ArrayList<Cnt>();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        calendar.add(Calendar.DAY_OF_MONTH, -90);

        SearchReport report = new SearchReport();
        report.setFromPublicationDate(calendar.getTime());
        report.setToPublicationDate(new Date());
        report.setOrganization(organization.equalsIgnoreCase(WalterOrganization.WALTER.getName()) ? WalterOrganization.WALTER : WalterOrganization.BIO_CIRCLE);
        report.setOrganization2(organization.equalsIgnoreCase(WalterOrganization.WALTER.getName()) ? WalterOrganization.BIO_CIRCLE : WalterOrganization.WALTER);
        try {
            List<Cnt> temp = search(report, userName, languageAbbreviation);
            for (Cnt cnt : temp) {
                if (cnt.getCounter() == null || cnt.getCounter() == 0) {
                    result.add(cnt);
                }
            }
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    @Interceptors(DebugInterceptor.class)
    public List<Cnt> getBestOpinionSolutionReports(String organization, String userName, String languageAbbreviation, String country) throws Exception {
        List<Cnt> result = new ArrayList<Cnt>();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        calendar.add(Calendar.DAY_OF_MONTH, -700);

        SearchReport report = new SearchReport();
        report.setFromPublicationDate(calendar.getTime());
        report.setToPublicationDate(new Date());
        report.setFromRatingAvg(new BigDecimal("4"));
        report.setToRatingAvg(new BigDecimal("5"));
        report.setOrganization(organization.equalsIgnoreCase(WalterOrganization.WALTER.getName()) ? WalterOrganization.WALTER : WalterOrganization.BIO_CIRCLE);
        report.setOrganization2(organization.equalsIgnoreCase(WalterOrganization.WALTER.getName()) ? WalterOrganization.BIO_CIRCLE : WalterOrganization.WALTER);;
        try {
            result.addAll(search(report, userName, languageAbbreviation));
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    @Interceptors(DebugInterceptor.class)
    public List<Cnt> getValidationSolutionReports(String organization, String userName, String languageAbbreviation, String country) throws Exception {
        List<Cnt> result = new ArrayList<Cnt>();
        SearchReport report = new SearchReport();
        report.setState(ReportState.PENDING_FOR_VALIDATION);
        report.setPmScreenName(userName);
        report.setOrganization(organization.equalsIgnoreCase(WalterOrganization.WALTER.getName()) ? WalterOrganization.WALTER : WalterOrganization.BIO_CIRCLE);
        try {
            result.addAll(search(report, userName, languageAbbreviation));
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    @Interceptors(DebugInterceptor.class)
    public List<Cnt> getMySolutionReports(String organization, String userName, String languageAbbreviation, String country, ReportState state) throws Exception {
        List<Cnt> result = new ArrayList<Cnt>();
        SearchReport report = new SearchReport();
        report.setState(state);
        report.setReporterScreenName(userName);
        report.setOrganization(organization.equalsIgnoreCase(WalterOrganization.WALTER.getName()) ? WalterOrganization.WALTER : WalterOrganization.BIO_CIRCLE);
        report.setOrganization2(organization.equalsIgnoreCase(WalterOrganization.WALTER.getName()) ? WalterOrganization.BIO_CIRCLE : WalterOrganization.WALTER);
        try {
            result.addAll(search(report, userName, languageAbbreviation));
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    @Interceptors(DebugInterceptor.class)
    public List<Cnt> getManagementSolutionReports(String organization, String userName, String languageAbbreviation, String country, ReportState state) throws Exception {
        List<Cnt> result = new ArrayList<Cnt>();
        SearchReport report = new SearchReport();
        report.setState(state);
        report.setOrganization(organization.equalsIgnoreCase(WalterOrganization.WALTER.getName()) ? WalterOrganization.WALTER : WalterOrganization.BIO_CIRCLE);
        try {
            result.addAll(search(report, userName, languageAbbreviation));
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    @Interceptors(DebugInterceptor.class)
    public List<Cnt> getReporterProfilSolutionReports(String organization, String userName, String languageAbbreviation, String webSiteCountryName, String reporterScreenName) throws Exception {
        List<Cnt> result = new ArrayList<Cnt>();
        SearchReport report = new SearchReport();
        report.setState(ReportState.PUBLISH);
        report.setReporterScreenName(reporterScreenName);
        report.setOrganization(organization.equalsIgnoreCase(WalterOrganization.WALTER.getName()) ? WalterOrganization.WALTER : WalterOrganization.BIO_CIRCLE);
        report.setOrganization2(organization.equalsIgnoreCase(WalterOrganization.WALTER.getName()) ? WalterOrganization.BIO_CIRCLE : WalterOrganization.WALTER);
        try {
            result.addAll(search(report, userName, languageAbbreviation));
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    public CntCounter setCntCounter(Long cntId, String userName, String sessionId) throws Exception {
        CntCounter result;
        CntCounterPK cntCounterPK = new CntCounterPK(cntId, userName.toUpperCase());
        try {
            result = entityManager.find(CntCounter.class, cntCounterPK);
            if (result == null) {
                result = new CntCounter(cntCounterPK);
                result.setFirstRead(new Date());
                result.setCounter(0L);
            }
            result.setLastRead(new Date());
            result.setCounter(result.getCounter() + 1);
            result = entityManager.merge(result);
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    @Interceptors(DebugInterceptor.class)
    public List<String> getSolutionReporterScreenNames() throws Exception {
        List<String> result;
        try {
            result = entityManager.createQuery(singletonBean.getSolutionReportQuery("solution.report.walter.creatorUserNames"), String.class).getResultList();
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    @Interceptors(DebugInterceptor.class)
    public List<CntLight> getSolutionReportReferences(String organization) throws Exception {
        List<CntLight> result = new ArrayList<CntLight>();
        try {
            List<Object[]> rows = entityManager.createQuery(singletonBean.getSolutionReportQuery("solution.report.references"), Object[].class)
                    .setParameter("organization", organization)
                    .getResultList();

            for (Object[] row : rows) {
                result.add(new CntLight(((Long) row[0]), ((String) row[1])));
            }
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    @Interceptors(DebugInterceptor.class)
    public List<Naics> getNaics(NaicsLevel level, Long countryId) throws Exception {
        List<Naics> result;
        try {
            result = entityManager.createQuery(singletonBean.getSolutionReportQuery("solution.report.naics"), Naics.class)
                    .setParameter("level", level.getLength())
                    .setParameter("country", Short.valueOf(Long.toString(countryId)))
                    .getResultList();

        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    @Interceptors(DebugInterceptor.class)
    public List<Naics> getNaicsList(String naics, Long countryId) throws Exception {
        List<Naics> result;
        try {
            result = entityManager.createQuery(singletonBean.getSolutionReportQuery("solution.report.naicsList"), Naics.class)
                    .setParameter("naics", naics)
                    .setParameter("countryId", Short.valueOf(Long.toString(countryId)))
                    .getResultList();
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    @Interceptors({DebugInterceptor.class})
    public Cnt getSolutionReport(Long cntId, String organization) throws Exception {
        return getSolutionReport(cntId, organization, "en");
    }

    @Override
    @Interceptors({DebugInterceptor.class})
    public Cnt getSolutionReport(Long cntId, String organization, String languageAbbreviation) throws Exception {
        Cnt result;
        try {
            ULang language = walterBean.getULang(languageAbbreviation);
            result = getSolutionReport(cntId, organization, language);
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Interceptors({DebugInterceptor.class})
    private Cnt getSolutionReport(Long cntId, String organization, ULang language) throws Exception {
        Cnt result;
        try {
            SearchReport report = new SearchReport();
            report.setOrganization(organization.equalsIgnoreCase(WalterOrganization.WALTER.getName()) ? WalterOrganization.WALTER : WalterOrganization.BIO_CIRCLE);
            report.setOrganization2(organization.equalsIgnoreCase(WalterOrganization.WALTER.getName()) ? WalterOrganization.BIO_CIRCLE : WalterOrganization.WALTER);
            report.setCntId(cntId);

            ReportCriteriaBuilder criteriaBuilder = new ReportCriteriaBuilder(entityManager, report, language);
            result = criteriaBuilder.buildQuery().getQuery().getSingleResult();

            if (result != null) {
                Hibernate.initialize(result.getCntTxtList());
                Hibernate.initialize(result.getCntOpinionList());
                Hibernate.initialize(result.getCntFeedbackList());
                Hibernate.initialize(result.getCntFeedbackRList());
                Hibernate.initialize(result.getCntPictureList());
                Hibernate.initialize(result.getCntUrlList());
                Hibernate.initialize(result.getCntProductList());
                Hibernate.initialize(result.getCntIndustryList());
                Hibernate.initialize(result.getCntCompetitorList());
                Hibernate.initialize(result.getCntActivityList());
                Hibernate.initialize(result.getCntContaminantList());
                Hibernate.initialize(result.getCntMaterialList());
                Hibernate.initialize(result.getCntMachineryList());
                Hibernate.initialize(result.getCntTranslateList());

                HashMap<CntProductPK, CntProduct> temp = getProductNames(cntId, language.getIdbAbbreviation());
                for (int i = 0; i < result.getCntProductList().size(); i++) {
                    CntProductPK pk = result.getCntProductList().get(i).getCntProductPK();
                    result.getCntProductList().get(i).setTradeName(temp.containsKey(pk) ? temp.get(pk).getTradeName() : "");
                    Franchise franchise = getFranchise(pk.getFranchiseguid(), language.getIdbAbbreviation(), result.getOrganization());
                    result.getCntProductList().get(i).setFranchiseName(franchise != null ? franchise.getDescription() : "");
                }

                QueryWrapper<Cnt> subQueryWrapper = new ReportSubQueryCriteriaBuilder(entityManager, report, language).buildQuery();
                HashMap<Long, String> walterProductNames = getReportWalterProductNames(language.getIdbAbbreviation(), subQueryWrapper);
                HashMap<Long, String> cbProductNames = getRecentReportCbProductNames(subQueryWrapper, language.getLangId());
                String walterProductName = walterProductNames.get(result.getCntId());
                String cbProductName = cbProductNames.get(result.getCntId());
                result.setProductName((walterProductName != null ? walterProductName : "") + ((walterProductName != null && cbProductName != null ? ", " : "")) + (cbProductName != null ? cbProductName : ""));
                String englishLangObjective = null;
                String userLangObjective = null;
                for (CntTxt txt : result.getCntTxtList()) {
                    if (txt.getCntTxtPK().getLangId() == language.getLangId()) {
                        userLangObjective = txt.getObjective();
                    } else if (txt.getCntTxtPK().getLangId() == ULang.ENGLISH_ID) {
                        englishLangObjective = txt.getObjective();
                    }
                }
                result.setObjective(userLangObjective != null ? userLangObjective : englishLangObjective);
            } else {
                throw new Exception("you are not allowed to view this Solution Report!");
            }
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    private HashMap<CntProductPK, CntProduct> getProductNames(Long cntId, String languageAbbreviation) throws Exception {
        HashMap<CntProductPK, CntProduct> result = new HashMap<CntProductPK, CntProduct>();
        try {
            // walter products
            StringBuilder sql = new StringBuilder(singletonBean.getSolutionReportQuery("solution.report.walter.productnames")).append("AND cnt.cntId = :cntId");
            TypedQuery<Object[]> query = entityManager.createQuery(sql.toString(), Object[].class);
            query.setParameter("cntId", cntId);
            HashMap<String, String> translations = getWalterTradenamesTranslation(languageAbbreviation);
            List<Object[]> rows = query.getResultList();
            // biocircle
            sql = new StringBuilder(singletonBean.getSolutionReportQuery("solution.report.biocircle.productnames")).append("AND cnt.cntId = :cntId");

            query = entityManager.createQuery(sql.toString(), Object[].class);
            ULang language = walterBean.getULang(languageAbbreviation);
            query.setParameter("langId", language.getLangId());
            query.setParameter("cntId", cntId);

            rows.addAll(query.getResultList());

            for (Object[] row : rows) {
                String name = String.valueOf(row[1]);
                String tradenameguid = String.valueOf(row[2]);
                String franchiseguid = String.valueOf(row[3]);
                name = translations.containsKey(name) ? translations.get(name) : name;
                CntProductPK pk = new CntProductPK(cntId, franchiseguid, tradenameguid);
                CntProduct product = new CntProduct(pk);
                product.setTradeName(name);
                result.put(pk, product);
            }
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    @Interceptors({DebugInterceptor.class})
    public List<UActivity> getSolutionReportActivities(Long cntId, Long langId) throws Exception {
        List<UActivity> result;
        try {
            result = entityManager
                    .createQuery(singletonBean.getSolutionReportQuery("solution.report.activities"), UActivity.class)
                    .setParameter("cntId", cntId)
                    .setParameter("langId", langId)
                    .getResultList();
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    @Interceptors({DebugInterceptor.class})
    public List<UMaterial> getSolutionReportMaterials(Long cntId, Long langId) throws Exception {
        List<UMaterial> result;
        try {
            result = entityManager
                    .createQuery(singletonBean.getSolutionReportQuery("solution.report.materials"), UMaterial.class)
                    .setParameter("cntId", cntId)
                    .setParameter("langId", langId)
                    .getResultList();
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    @Interceptors({DebugInterceptor.class})
    public List<UIndustry> getSolutionReportIndustries(Long cntId, Long langId) throws Exception {
        List<UIndustry> result;
        try {
            result = entityManager
                    .createQuery(singletonBean.getSolutionReportQuery("solution.report.industries"), UIndustry.class)
                    .setParameter("cntId", cntId)
                    .setParameter("langId", langId)
                    .getResultList();
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    @Interceptors({DebugInterceptor.class})
    public List<UContaminant> getSolutionReportContaminants(Long cntId, Long langId) throws Exception {
        List<UContaminant> result;
        try {
            result = entityManager
                    .createQuery(singletonBean.getSolutionReportQuery("solution.report.contaminants"), UContaminant.class)
                    .setParameter("cntId", cntId)
                    .setParameter("langId", langId)
                    .getResultList();
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    @Interceptors({DebugInterceptor.class})
    public List<UMachinery> getSolutionReportMachineries(Long cntId, Long langId) throws Exception {
        List<UMachinery> result;
        try {
            result = entityManager
                    .createQuery(singletonBean.getSolutionReportQuery("solution.report.machineries"), UMachinery.class)
                    .setParameter("cntId", cntId)
                    .setParameter("langId", langId)
                    .getResultList();
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    @Interceptors(DebugInterceptor.class)
    public List<Franchise> getFranchises(String languageAbbreviation, String organization) throws Exception {
        List<Franchise> result = new ArrayList<Franchise>();
        String queryKey = organization.equals(WalterOrganization.WALTER.getName()) ? "solution.report.walter.franchises" : "solution.report.biocircle.franchises";
        try {
            HashMap<String, String> translations = getWalterFranchisesTranslation(languageAbbreviation);
            TypedQuery<Object[]> query = entityManager.createQuery(singletonBean.getSolutionReportQuery(queryKey), Object[].class);
            if (organization.equals(WalterOrganization.BIO_CIRCLE.getName())) {
                ULang language = walterBean.getULang(languageAbbreviation);
                query.setParameter("langId", language.getLangId());
            }
            List<Object[]> rows = query.getResultList();
            for (Object[] row : rows) {
                String franchiseId = String.valueOf(row[0]);
                String description = String.valueOf(row[1]);
                description = translations.containsKey(description) ? translations.get(description) : description;
                result.add(new Franchise(franchiseId, description));
            }
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }

        Collections.sort(result, new Comparator<Franchise>() {
            @Override
            public int compare(Franchise f1, Franchise f2) {
                return f1.getDescription().compareTo(f2.getDescription());
            }
        });
        return result;
    }

    @Override
    @Interceptors(DebugInterceptor.class)
    public HashMap<String, String> getWalterFranchisesTranslation(String languageAbbreviation) throws Exception {
        HashMap<String, String> result = new HashMap<String, String>();
        try {
            List<Object[]> rows = entityManager.createQuery(singletonBean.getSolutionReportQuery("solution.report.walter.franchises.translation"), Object[].class)
                    .setParameter("languageAbbreviation", languageAbbreviation)
                    .getResultList();

            for (Object[] row : rows) {
                String name = String.valueOf(row[0]);
                String translate = String.valueOf(row[1]);
                result.put(name, translate);
            }

        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Interceptors(DebugInterceptor.class)
    private Franchise getFranchise(String franchiseId, String languageAbbreviation, String organization) throws Exception {
        Franchise result;
        StringBuilder queryString = new StringBuilder();
        try {
            if (organization.equals(WalterOrganization.WALTER.getName())) {
                queryString.append(singletonBean.getSolutionReportQuery("solution.report.walter.franchises"));
                queryString.append(" AND franchise.classguid = :franchiseId");
            } else {
                queryString.append(singletonBean.getSolutionReportQuery("solution.report.biocircle.franchises"));
                queryString.append(" AND TO_CHAR(cf.franchiseId) = :franchiseId");
            }
            HashMap<String, String> translations = getWalterFranchisesTranslation(languageAbbreviation);
            TypedQuery<Object[]> query = entityManager.createQuery(queryString.toString(), Object[].class);
            query.setParameter("franchiseId", franchiseId);
            if (organization.equals("cb")) {
                ULang language = walterBean.getULang(languageAbbreviation);
                query.setParameter("langId", language.getLangId());
            }
            Object[] row = query.getSingleResult();
            String description = (String) row[1];
            description = translations.containsKey(description) ? translations.get(description) : description;
            result = new Franchise(franchiseId, description);
        } catch (Exception e) {
            LOG.log(Level.SEVERE, e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    @Interceptors({DebugInterceptor.class})
    public List<Tradename> getTradenames(String languageAbbreviation, String country) throws Exception {
        List<Tradename> result = new ArrayList<Tradename>();
        result.addAll(getTradenames(languageAbbreviation, country, WalterOrganization.WALTER.getName()));
        result.addAll(getTradenames(languageAbbreviation, country, WalterOrganization.BIO_CIRCLE.getName()));
        return result;
    }

    @Override
    @Interceptors({DebugInterceptor.class})
    public List<Tradename> getTradenames(String languageAbbreviation, String country, String organization) throws Exception {
        List<Tradename> result = new ArrayList<Tradename>();
        String queryKey = organization.equals(WalterOrganization.WALTER.getName()) ? "solution.report.walter.tradenames" : "solution.report.biocircle.tradenames";
        try {
            HashMap<String, String> translations = getWalterTradenamesTranslation(languageAbbreviation);
            TypedQuery<Object[]> query = entityManager.createQuery(singletonBean.getSolutionReportQuery(queryKey), Object[].class);
            if (organization.equals(WalterOrganization.BIO_CIRCLE.getName())) {
                ULang language = walterBean.getULang(languageAbbreviation);
                query.setParameter("langId", language.getLangId());
            }
//            else {
//                query.setParameter("country", country);
//            }
            List<Object[]> rows = query.getResultList();
            for (Object[] row : rows) {
                String tradenameId = String.valueOf(row[0]);
                String franchiseId = String.valueOf(row[1]);
                String franchiseDesc = String.valueOf(row[2]);
                String description = String.valueOf(row[3]);
                description = translations.containsKey(description) ? translations.get(description) : description;
                result.add(new Tradename(tradenameId, new Franchise(franchiseId, franchiseDesc), description));
            }
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }

        Collections.sort(result, new Comparator<Tradename>() {
            @Override
            public int compare(Tradename t1, Tradename t2) {
                return t1.getDescription().compareTo(t2.getDescription());
            }
        });

        // filtering duplicate objects
        LinkedHashSet<Tradename> resultSet = new LinkedHashSet();
        resultSet.addAll(result);
        result.clear();
        result.addAll(resultSet);

        return result;
    }

    @Override
    @Interceptors(DebugInterceptor.class)
    public HashMap<String, String> getWalterTradenamesTranslation(String languageAbbreviation) throws Exception {
        HashMap<String, String> result = new HashMap<String, String>();
        try {
            List<Object[]> rows = entityManager.createQuery(singletonBean.getSolutionReportQuery("solution.report.walter.tradenames.translation"), Object[].class)
                    .setParameter("languageAbbreviation", languageAbbreviation)
                    .getResultList();

            for (Object[] row : rows) {
                String name = String.valueOf(row[0]);
                String translate = String.valueOf(row[1]);
                // if no translations are available do not display null when viewing in another language
                if (translate.equals("null")) {
                    translate = name;
                }
                result.put(name, translate);
            }
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    @Interceptors(DebugInterceptor.class)
    public void cancel(Cnt cnt, String userName) throws Exception {
        try {
            entityManager.createQuery(singletonBean.getSolutionReportQuery("solution.report.cancel"))
                    .setParameter("cnt", cnt)
                    .setParameter("cancelDate", new Date())
                    .setParameter("cancelBy", userName)
                    .executeUpdate();
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
    }

    @Override
    @Interceptors(DebugInterceptor.class)
    public Cnt addOpinion(CntOpinion cntOpinion) throws Exception {
        try {
            int rating = cntOpinion.getRanking();
            int count = 1;
            Cnt cnt = entityManager.find(Cnt.class, cntOpinion.getCnt().getCntId());
            Hibernate.initialize(cnt.getCntOpinionList());
            for (CntOpinion opinion : cnt.getCntOpinionList()) {
                rating = rating + opinion.getRanking();
                count++;
            }
            cnt.setRatingAvg(BigDecimal.valueOf(rating).divide(BigDecimal.valueOf(count), 2, RoundingMode.DOWN));
            cnt.setRatingCount(count);
            entityManager.merge(cnt);
            entityManager.merge(cntOpinion);
            return cnt;
        } catch (Exception e) {
            LOG.log(Level.SEVERE, e.getMessage());
            throw new Exception(e.getMessage());
        }
    }

    @Override
    @Interceptors(DebugInterceptor.class)
    public CntTxt getCntTxt(Long cntId, Long langId) throws Exception {
        CntTxt result;
        Query query = entityManager.createNamedQuery(CntTxt.class.getSimpleName() + ".findById")
                .setParameter("cntId", cntId)
                .setParameter("langId", langId);
        try {
            result = (CntTxt) query.getSingleResult();
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    @Interceptors(DebugInterceptor.class)
    public List<NaicsCustomer> getNaicsCustomers(String customerFilter, Long countryId) throws Exception {
        List<NaicsCustomer> result;
        try {
            result = entityManager.createQuery(singletonBean.getSolutionReportQuery("solution.report.naicsCustomer"), NaicsCustomer.class)
                    .setParameter("contains", "%" + customerFilter + "%")
                    .setParameter("countryId", countryId)
                    .getResultList();
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    @Interceptors(DebugInterceptor.class)
    public NaicsCustomer getNaicsCustomer(BigDecimal id) throws Exception {
        NaicsCustomer result = null;
        try {
            result = entityManager.find(NaicsCustomer.class, id);
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    @Interceptors(DebugInterceptor.class)
    public Map<Long, Map<BigDecimal, String>> getNaicsCustomersMap() throws Exception {
        return singletonBean.getNaicsCustomersMap();
    }

    @Interceptors(DebugInterceptor.class)
    public Map<Long, Map<BigDecimal, String>> fillNaicsCustomersMap() throws Exception {
        Map<Long, Map<BigDecimal, String>> result = new LinkedHashMap<>();
        try {
            // country 3
            Map<BigDecimal, String> companies3 = new LinkedHashMap<>();
            List<Object[]> rows3 = entityManager.createQuery("SELECT cust.id, cust.businessName FROM NaicsCustomer cust  WHERE cust.countryId = 3 ORDER BY cust.businessName", Object[].class).getResultList();
            for (Object[] row : rows3) {
                BigDecimal id = new BigDecimal(String.valueOf(row[0]));
                String companyName = String.valueOf(row[1]);
                companies3.put(id, companyName);
            }
            result.put(3L, companies3);
            // country 2
            Map<BigDecimal, String> companies2 = new LinkedHashMap<BigDecimal, String>();
            List<Object[]> rows2 = entityManager.createQuery("SELECT cust.id, cust.businessName FROM NaicsCustomer cust  WHERE cust.countryId = 2  ORDER BY cust.businessName", Object[].class).getResultList();
            for (Object[] row : rows2) {
                BigDecimal id = new BigDecimal(String.valueOf(row[0]));
                String companyName = String.valueOf(row[1]);
                companies2.put(id, companyName);
            }
            result.put(2L, companies2);
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    @Interceptors(DebugInterceptor.class)
    public void validate(Cnt cnt) throws Exception {
        cnt.setReceivedFromPm(new Date());
        cnt.setValidFlag(1);
        walterBean.save(cnt);
        notificationBean.sendReportValidatedNotification(cnt);
    }

    @Override
    @Interceptors(DebugInterceptor.class)
    public Cnt publish(Cnt cnt) throws Exception {
        cnt.setPublicationDate(new Date());
        cnt.setPublished("Y");
        Cnt report = walterBean.save(cnt);
        return report;
    }

    @Override
    @Interceptors(DebugInterceptor.class)
    public void invalidate(Cnt cnt) throws Exception {
        cnt.setPublicationDate(null);
        cnt.setValidFlag(0);
        walterBean.save(cnt);
    }

    @Override
    @Interceptors(DebugInterceptor.class)
    public Cnt save(Cnt cnt, Country country, ULang language, String productManagerName, String translatorName) throws Exception {
        if (cnt.getCntRef() == null && cnt.getCntId() != null && country != null) {
            String code = country.getCountryCode();
            String reportId = Long.toString(cnt.getCntId());
            int idDiff = 6 - reportId.length();
            if (idDiff <= 0) {
                reportId.substring(0, 6);
            } else {
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < idDiff; i++) {
                    sb.append("0");
                }
                sb.append(reportId);
                reportId = sb.toString();
            }
            cnt.setCntRef(code + reportId);
        }

        if (language != null) {
            cnt.setOriginalLangId(language.getLangId());
        }

        if (productManagerName != null) {
            cnt.setSentToPm(new Date());
            cnt.setPmUserName(productManagerName.toUpperCase());
        }

        if (translatorName != null) {
            CntTxt copyTxt = generateText(cnt);
            CntTranslate translation = generateTranslation(cnt, translatorName);
            for (CntPicture picture : cnt.getCntPictureList()) {
                CntPictureTxt pictureTxt = generatePictureText(cnt, picture);
                picture.getCntPictureTxtSet().add(pictureTxt);
            }
            cnt.getCntTxtList().add(copyTxt);
            cnt.getCntTranslateList().add(translation);
        }

        String http = "http://";
        for (CntUrl url : cnt.getCntUrlList()) {
            if (!url.getUrlLink().startsWith(http)) {
                url.setUrlLink(http + url.getUrlLink());
            }
            url.getUrlLink();
        }


        if (cnt.getUrl() != null && !cnt.getUrl().isEmpty() && !cnt.getUrl().startsWith(http)) {
            cnt.setUrl(http + cnt.getUrl());
        }

        Cnt report = walterBean.save(cnt);

        // If the report is not in English and the report is new, we send an email to the selected translator
        if (report.getState().equals(ReportState.PENDING_FOR_TRANSLATION) && report.getOriginalLangId() != ULang.ENGLISH_ID) {
            notificationBean.sendPendingForTranslationNotification(report);
        }

        // If the PM has changed, we notify him
        if (report.getState().equals(ReportState.PENDING_FOR_VALIDATION)) {
            notificationBean.sendPendingForValidationNotification(report);
        }
        return report;
    }

    private CntTxt generateText(Cnt cnt) {
        CntTxt newLanguageTxt = null;
        for (CntTxt cntTxt : cnt.getCntTxtList()) {
            if (cntTxt.getCntTxtPK().getLangId() == ULang.ENGLISH_ID) {
                newLanguageTxt = new CntTxt(cntTxt, cnt.getOriginalLangId());
                break;
            }
        }
        return newLanguageTxt;
    }

    private CntPictureTxt generatePictureText(Cnt cnt, CntPicture picture) {
        CntPictureTxt newPictureTxt = null;
        for (CntPictureTxt pictureTxt : picture.getCntPictureTxtSet()) {
            if (pictureTxt.getCntPictureTxtPK().getLangId() == ULang.ENGLISH_ID) {
                newPictureTxt = new CntPictureTxt(pictureTxt, cnt.getOriginalLangId());
                break;
            }
        }
        return newPictureTxt;
    }

    private CntTranslate generateTranslation(Cnt cnt, String translatorName) {
        CntTranslate translation = new CntTranslate(new CntTranslatePK(cnt.getCntId(), ULang.ENGLISH_ID));
        translation.setTranslatorUserName(translatorName.toUpperCase());
        translation.setFromLangId(cnt.getOriginalLangId());
        translation.setSentToTr(new Date());
        return translation;
    }

    @Override
    @Interceptors(DebugInterceptor.class)
    public Cnt submit(Cnt cnt) throws Exception {
        cnt.setEntryDate(new Date());
        Cnt report = walterBean.save(cnt);

        // If new report, we send a notification to the creator and management
        notificationBean.sendNewReportNotification(report);

        return report;
    }

    @Override
    @Interceptors(DebugInterceptor.class)
    public void submitTranslation(Cnt cnt, CntTranslate originalTranslate, long langId, String translatorName) throws Exception {
        Cnt report = cnt;
        if (originalTranslate == null) {
            report = saveTranslation(cnt, originalTranslate, langId, translatorName);
        }
        for (CntTranslate translate : report.getCntTranslateList()) {
            if (translate.getCntTranslatePK().getLangId() == langId) {
                originalTranslate = translate;
                break;
            }
        }
        Date originalDate = originalTranslate.getReceivedFromTr();
        originalTranslate.setReceivedFromTr(new Date());
        walterBean.save(report);

        // If the translation is English and is new, we send a notification to management
        if (originalTranslate.getCntTranslatePK().getLangId() == ULang.ENGLISH_ID && originalDate == null) {
            notificationBean.sendTranslationFinishedNotification(report);
        }
    }

    @Override
    @Interceptors(DebugInterceptor.class)
    public Cnt saveTranslation(Cnt cnt, CntTranslate originalTranslate, long langId, String translatorName) throws Exception {
        if (originalTranslate == null) {
            for (CntTranslate translate : cnt.getCntTranslateList()) {
                if (translate.getCntTranslatePK().getLangId() == langId) {
                    originalTranslate = translate;
                    break;
                }
            }

            if (originalTranslate == null) {
                originalTranslate = new CntTranslate(cnt.getCntId(), langId);
                originalTranslate.setTranslatorUserName(translatorName);
                originalTranslate.setFromLangId(ULang.ENGLISH_ID);
                originalTranslate.setSentToTr(new Date());
                originalTranslate.setCnt(cnt);
                cnt.getCntTranslateList().add(originalTranslate);
            }
        }
        return walterBean.save(cnt);
    }

    @Override
    @Interceptors(DebugInterceptor.class)
    public void reply(CntFeedbackR feedbackReply) throws Exception {
        feedbackReply.setDateCreated(new Date());
        walterBean.save(feedbackReply);
    }

    @Override
    @Interceptors(DebugInterceptor.class)
    public void feedBack(CntFeedback feedback) throws Exception {
        feedback.setDateCreated(new Date());
        walterBean.save(feedback);
        notificationBean.sendNewFeedbackNotification(feedback);
    }
}
