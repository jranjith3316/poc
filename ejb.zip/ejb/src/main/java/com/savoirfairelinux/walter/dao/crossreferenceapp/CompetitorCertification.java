/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.crossreferenceapp;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "COMPETITOR_CERTIFICATION", catalog = "", schema = "CROSSREFERENCEAPP")
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "CompetitorCertification.findAll", query = "SELECT c FROM CompetitorCertification c"),
  @NamedQuery(name = "CompetitorCertification.findByBrandId", query = "SELECT c FROM CompetitorCertification c WHERE c.competitorCertificationPK.brandId = :brandId"),
  @NamedQuery(name = "CompetitorCertification.findByCompetitorId", query = "SELECT c FROM CompetitorCertification c WHERE c.competitorCertificationPK.competitorId = :competitorId"),
  @NamedQuery(name = "CompetitorCertification.findByProductId", query = "SELECT c FROM CompetitorCertification c WHERE c.competitorCertificationPK.productId = :productId"),
  @NamedQuery(name = "CompetitorCertification.findByCountryId", query = "SELECT c FROM CompetitorCertification c WHERE c.competitorCertificationPK.countryId = :countryId"),
  @NamedQuery(name = "CompetitorCertification.findByCertificationGuid", query = "SELECT c FROM CompetitorCertification c WHERE c.competitorCertificationPK.certificationGuid = :certificationGuid"),
  @NamedQuery(name = "CompetitorCertification.findByCreatedUserName", query = "SELECT c FROM CompetitorCertification c WHERE c.createdUserName = :createdUserName"),
  @NamedQuery(name = "CompetitorCertification.findByCreatedDate", query = "SELECT c FROM CompetitorCertification c WHERE c.createdDate = :createdDate"),
  @NamedQuery(name = "CompetitorCertification.findByUpdatedUserName", query = "SELECT c FROM CompetitorCertification c WHERE c.updatedUserName = :updatedUserName"),
  @NamedQuery(name = "CompetitorCertification.findByUpdatedDate", query = "SELECT c FROM CompetitorCertification c WHERE c.updatedDate = :updatedDate")})
public class CompetitorCertification implements Serializable {
  private static final long serialVersionUID = 1L;
  @EmbeddedId
  protected CompetitorCertificationPK competitorCertificationPK;
  @Size(max = 255)
  @Column(name = "CREATED_USER_NAME")
  private String createdUserName;
  @Column(name = "CREATED_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date createdDate;
  @Size(max = 255)
  @Column(name = "UPDATED_USER_NAME")
  private String updatedUserName;
  @Column(name = "UPDATED_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date updatedDate;

  public CompetitorCertification() {
  }

  public CompetitorCertification(CompetitorCertificationPK competitorCertificationPK) {
    this.competitorCertificationPK = competitorCertificationPK;
  }

  public CompetitorCertification(long brandId, long competitorId, long productId, long countryId, String certificationGuid) {
    this.competitorCertificationPK = new CompetitorCertificationPK(brandId, competitorId, productId, countryId, certificationGuid);
  }

  public CompetitorCertificationPK getCompetitorCertificationPK() {
    return competitorCertificationPK;
  }

  public void setCompetitorCertificationPK(CompetitorCertificationPK competitorCertificationPK) {
    this.competitorCertificationPK = competitorCertificationPK;
  }

  public String getCreatedUserName() {
    return createdUserName;
  }

  public void setCreatedUserName(String createdUserName) {
    this.createdUserName = createdUserName;
  }

  public Date getCreatedDate() {
    return createdDate;
  }

  public void setCreatedDate(Date createdDate) {
    this.createdDate = createdDate;
  }

  public String getUpdatedUserName() {
    return updatedUserName;
  }

  public void setUpdatedUserName(String updatedUserName) {
    this.updatedUserName = updatedUserName;
  }

  public Date getUpdatedDate() {
    return updatedDate;
  }

  public void setUpdatedDate(Date updatedDate) {
    this.updatedDate = updatedDate;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (competitorCertificationPK != null ? competitorCertificationPK.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof CompetitorCertification)) {
      return false;
    }
    CompetitorCertification other = (CompetitorCertification) object;
    if ((this.competitorCertificationPK == null && other.competitorCertificationPK != null) || (this.competitorCertificationPK != null && !this.competitorCertificationPK.equals(other.competitorCertificationPK))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.crossreferenceapp.CompetitorCertification[ competitorCertificationPK=" + competitorCertificationPK + " ]";
  }

}
