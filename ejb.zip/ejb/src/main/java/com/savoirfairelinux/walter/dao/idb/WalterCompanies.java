/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.idb;

import com.savoirfairelinux.walter.dao.DatabaseConstants;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "WALTER_COMPANIES", catalog = "", schema = DatabaseConstants.IDB_SCHEMA)
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "WalterCompanies.findAll", query = "SELECT w FROM WalterCompanies w"),
  @NamedQuery(name = "WalterCompanies.findByCompanyguid", query = "SELECT w FROM WalterCompanies w WHERE w.companyguid = :companyguid"),
  @NamedQuery(name = "WalterCompanies.findByCompanyname", query = "SELECT w FROM WalterCompanies w WHERE w.companyname = :companyname"),
  @NamedQuery(name = "WalterCompanies.findByCompanytype", query = "SELECT w FROM WalterCompanies w WHERE w.companytype = :companytype"),
  @NamedQuery(name = "WalterCompanies.findByCompanyemail", query = "SELECT w FROM WalterCompanies w WHERE w.companyemail = :companyemail"),
  @NamedQuery(name = "WalterCompanies.findByCompanywebsiteurl", query = "SELECT w FROM WalterCompanies w WHERE w.companywebsiteurl = :companywebsiteurl"),
  @NamedQuery(name = "WalterCompanies.findByCompanyaddress", query = "SELECT w FROM WalterCompanies w WHERE w.companyaddress = :companyaddress"),
  @NamedQuery(name = "WalterCompanies.findByCompanycity", query = "SELECT w FROM WalterCompanies w WHERE w.companycity = :companycity"),
  @NamedQuery(name = "WalterCompanies.findByCompanypostalcode", query = "SELECT w FROM WalterCompanies w WHERE w.companypostalcode = :companypostalcode"),
  @NamedQuery(name = "WalterCompanies.findByCompanycountry", query = "SELECT w FROM WalterCompanies w WHERE w.companycountry = :companycountry"),
  @NamedQuery(name = "WalterCompanies.findByCompanyphonenumber", query = "SELECT w FROM WalterCompanies w WHERE w.companyphonenumber = :companyphonenumber"),
  @NamedQuery(name = "WalterCompanies.findByCompanystatus", query = "SELECT w FROM WalterCompanies w WHERE w.companystatus = :companystatus"),
  @NamedQuery(name = "WalterCompanies.findByAdddatetime", query = "SELECT w FROM WalterCompanies w WHERE w.adddatetime = :adddatetime"),
  @NamedQuery(name = "WalterCompanies.findByDeletedatetime", query = "SELECT w FROM WalterCompanies w WHERE w.deletedatetime = :deletedatetime"),
  @NamedQuery(name = "WalterCompanies.findByUpdatedatetime", query = "SELECT w FROM WalterCompanies w WHERE w.updatedatetime = :updatedatetime"),
  @NamedQuery(name = "WalterCompanies.findByEventuser", query = "SELECT w FROM WalterCompanies w WHERE w.eventuser = :eventuser")})
public class WalterCompanies implements Serializable {
  private static final long serialVersionUID = 1L;
  @Id
  @Basic(optional = false)
  @NotNull
  @Size(min = 1, max = 255)
  @Column(name = "COMPANYGUID")
  private String companyguid;
  @Size(max = 255)
  @Column(name = "COMPANYNAME")
  private String companyname;
  @Lob
  @Column(name = "COMPANYDESCRIPTION")
  private String companydescription;
  @Column(name = "COMPANYTYPE")
  private Long companytype;
  @Size(max = 255)
  @Column(name = "COMPANYEMAIL")
  private String companyemail;
  @Size(max = 255)
  @Column(name = "COMPANYWEBSITEURL")
  private String companywebsiteurl;
  @Size(max = 255)
  @Column(name = "COMPANYADDRESS")
  private String companyaddress;
  @Size(max = 255)
  @Column(name = "COMPANYCITY")
  private String companycity;
  @Size(max = 255)
  @Column(name = "COMPANYPOSTALCODE")
  private String companypostalcode;
  @Column(name = "COMPANYCOUNTRY")
  private Long companycountry;
  @Size(max = 255)
  @Column(name = "COMPANYPHONENUMBER")
  private String companyphonenumber;
  @Size(max = 255)
  @Column(name = "COMPANYSTATUS")
  private String companystatus;
  @Column(name = "ADDDATETIME")
  @Temporal(TemporalType.TIMESTAMP)
  private Date adddatetime;
  @Column(name = "DELETEDATETIME")
  @Temporal(TemporalType.TIMESTAMP)
  private Date deletedatetime;
  @Column(name = "UPDATEDATETIME")
  @Temporal(TemporalType.TIMESTAMP)
  private Date updatedatetime;
  @Size(max = 255)
  @Column(name = "EVENTUSER")
  private String eventuser;
//  @OneToMany(mappedBy = "companyguid")
//  private Set<WalterProducts> walterProductsSet;
//  @OneToMany(cascade = CascadeType.ALL, mappedBy = "companyguid")
//  private Set<WalterFiles> walterFilesSet;
//  @OneToMany(mappedBy = "companyguid")
//  private Set<WalterTradenames> walterTradenamesSet;
//  @OneToMany(cascade = CascadeType.ALL, mappedBy = "companyguid")
//  private Set<WalterUrl> walterUrlSet;

  public WalterCompanies() {
  }

  public WalterCompanies(String companyguid) {
    this.companyguid = companyguid;
  }

  public String getCompanyguid() {
    return companyguid;
  }

  public void setCompanyguid(String companyguid) {
    this.companyguid = companyguid;
  }

  public String getCompanyname() {
    return companyname;
  }

  public void setCompanyname(String companyname) {
    this.companyname = companyname;
  }

  public String getCompanydescription() {
    return companydescription;
  }

  public void setCompanydescription(String companydescription) {
    this.companydescription = companydescription;
  }

  public Long getCompanytype() {
    return companytype;
  }

  public void setCompanytype(Long companytype) {
    this.companytype = companytype;
  }

  public String getCompanyemail() {
    return companyemail;
  }

  public void setCompanyemail(String companyemail) {
    this.companyemail = companyemail;
  }

  public String getCompanywebsiteurl() {
    return companywebsiteurl;
  }

  public void setCompanywebsiteurl(String companywebsiteurl) {
    this.companywebsiteurl = companywebsiteurl;
  }

  public String getCompanyaddress() {
    return companyaddress;
  }

  public void setCompanyaddress(String companyaddress) {
    this.companyaddress = companyaddress;
  }

  public String getCompanycity() {
    return companycity;
  }

  public void setCompanycity(String companycity) {
    this.companycity = companycity;
  }

  public String getCompanypostalcode() {
    return companypostalcode;
  }

  public void setCompanypostalcode(String companypostalcode) {
    this.companypostalcode = companypostalcode;
  }

  public Long getCompanycountry() {
    return companycountry;
  }

  public void setCompanycountry(Long companycountry) {
    this.companycountry = companycountry;
  }

  public String getCompanyphonenumber() {
    return companyphonenumber;
  }

  public void setCompanyphonenumber(String companyphonenumber) {
    this.companyphonenumber = companyphonenumber;
  }

  public String getCompanystatus() {
    return companystatus;
  }

  public void setCompanystatus(String companystatus) {
    this.companystatus = companystatus;
  }

  public Date getAdddatetime() {
    return adddatetime;
  }

  public void setAdddatetime(Date adddatetime) {
    this.adddatetime = adddatetime;
  }

  public Date getDeletedatetime() {
    return deletedatetime;
  }

  public void setDeletedatetime(Date deletedatetime) {
    this.deletedatetime = deletedatetime;
  }

  public Date getUpdatedatetime() {
    return updatedatetime;
  }

  public void setUpdatedatetime(Date updatedatetime) {
    this.updatedatetime = updatedatetime;
  }

  public String getEventuser() {
    return eventuser;
  }

  public void setEventuser(String eventuser) {
    this.eventuser = eventuser;
  }

//  @XmlTransient
//  public Set<WalterProducts> getWalterProductsSet() {
//    return walterProductsSet;
//  }
//
//  public void setWalterProductsSet(Set<WalterProducts> walterProductsSet) {
//    this.walterProductsSet = walterProductsSet;
//  }
//
//  @XmlTransient
//  public Set<WalterFiles> getWalterFilesSet() {
//    return walterFilesSet;
//  }
//
//  public void setWalterFilesSet(Set<WalterFiles> walterFilesSet) {
//    this.walterFilesSet = walterFilesSet;
//  }
//
//  @XmlTransient
//  public Set<WalterTradenames> getWalterTradenamesSet() {
//    return walterTradenamesSet;
//  }
//
//  public void setWalterTradenamesSet(Set<WalterTradenames> walterTradenamesSet) {
//    this.walterTradenamesSet = walterTradenamesSet;
//  }
//
//  @XmlTransient
//  public Set<WalterUrl> getWalterUrlSet() {
//    return walterUrlSet;
//  }
//
//  public void setWalterUrlSet(Set<WalterUrl> walterUrlSet) {
//    this.walterUrlSet = walterUrlSet;
//  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (companyguid != null ? companyguid.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof WalterCompanies)) {
      return false;
    }
    WalterCompanies other = (WalterCompanies) object;
    if ((this.companyguid == null && other.companyguid != null) || (this.companyguid != null && !this.companyguid.equals(other.companyguid))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.idb.WalterCompanies[ companyguid=" + companyguid + " ]";
  }

}
