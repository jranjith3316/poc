/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.idb;

import com.savoirfairelinux.walter.dao.DatabaseConstants;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "OO_INSTANCES_MEMBERS_VALUES", catalog = "", schema = DatabaseConstants.IDB_SCHEMA)
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "OoInstancesMembersValues.findAll", query = "SELECT o FROM OoInstancesMembersValues o"),
  @NamedQuery(name = "OoInstancesMembersValues.findByInstancemembervalue", query = "SELECT o FROM OoInstancesMembersValues o WHERE o.instancemembervalue = :instancemembervalue"),
  @NamedQuery(name = "OoInstancesMembersValues.findByIntancemembervalueguid", query = "SELECT o FROM OoInstancesMembersValues o WHERE o.intancemembervalueguid = :intancemembervalueguid"),
  @NamedQuery(name = "OoInstancesMembersValues.findByFilterinstanceguid", query = "SELECT o FROM OoInstancesMembersValues o WHERE o.filterinstanceguid = :filterinstanceguid"),
  @NamedQuery(name = "OoInstancesMembersValues.findByAdddatetime", query = "SELECT o FROM OoInstancesMembersValues o WHERE o.adddatetime = :adddatetime"),
  @NamedQuery(name = "OoInstancesMembersValues.findByDeletedatetime", query = "SELECT o FROM OoInstancesMembersValues o WHERE o.deletedatetime = :deletedatetime"),
  @NamedQuery(name = "OoInstancesMembersValues.findByUpdatedatetime", query = "SELECT o FROM OoInstancesMembersValues o WHERE o.updatedatetime = :updatedatetime")})
public class OoInstancesMembersValues implements Serializable {
  private static final long serialVersionUID = 1L;
  @Basic(optional = false)
  @NotNull
  @Size(min = 1, max = 255)
    @Column(name = "INSTANCEMEMBERVALUE", nullable = false, length = 255)
  private String instancemembervalue;
  @Id
  @Basic(optional = false)
  @NotNull
  @Size(min = 1, max = 255)
    @Column(name = "INTANCEMEMBERVALUEGUID", nullable = false, length = 255)
  private String intancemembervalueguid;
  @Size(max = 255)
    @Column(name = "FILTERINSTANCEGUID", length = 255)
  private String filterinstanceguid;
  @Column(name = "ADDDATETIME")
  @Temporal(TemporalType.TIMESTAMP)
  private Date adddatetime;
  @Column(name = "DELETEDATETIME")
  @Temporal(TemporalType.TIMESTAMP)
  private Date deletedatetime;
  @Column(name = "UPDATEDATETIME")
  @Temporal(TemporalType.TIMESTAMP)
  private Date updatedatetime;
    @JoinColumn(name = "INSTANCEGUID", referencedColumnName = "INSTANCEGUID", nullable = false)
  @ManyToOne(optional = false)
  private OoInstances instanceguid;
  @JoinColumn(name = "INSTANCEMEMBERUOMGUID", referencedColumnName = "INSTANCEGUID")
  @ManyToOne
  private OoInstances instancememberuomguid;
    @JoinColumn(name = "INTANCEMEMBERGUID", referencedColumnName = "MEMBERGUID", nullable = false)
  @ManyToOne(optional = false)
  private OoClassesMembers intancememberguid;

  public OoInstancesMembersValues() {
  }

  public OoInstancesMembersValues(String intancemembervalueguid) {
    this.intancemembervalueguid = intancemembervalueguid;
  }

  public OoInstancesMembersValues(String intancemembervalueguid, String instancemembervalue) {
    this.intancemembervalueguid = intancemembervalueguid;
    this.instancemembervalue = instancemembervalue;
  }

  public String getInstancemembervalue() {
    return instancemembervalue;
  }

  public void setInstancemembervalue(String instancemembervalue) {
    this.instancemembervalue = instancemembervalue;
  }

  public String getIntancemembervalueguid() {
    return intancemembervalueguid;
  }

  public void setIntancemembervalueguid(String intancemembervalueguid) {
    this.intancemembervalueguid = intancemembervalueguid;
  }

  public String getFilterinstanceguid() {
    return filterinstanceguid;
  }

  public void setFilterinstanceguid(String filterinstanceguid) {
    this.filterinstanceguid = filterinstanceguid;
  }

  public Date getAdddatetime() {
    return adddatetime;
  }

  public void setAdddatetime(Date adddatetime) {
    this.adddatetime = adddatetime;
  }

  public Date getDeletedatetime() {
    return deletedatetime;
  }

  public void setDeletedatetime(Date deletedatetime) {
    this.deletedatetime = deletedatetime;
  }

  public Date getUpdatedatetime() {
    return updatedatetime;
  }

  public void setUpdatedatetime(Date updatedatetime) {
    this.updatedatetime = updatedatetime;
  }

  public OoInstances getInstanceguid() {
    return instanceguid;
  }

  public void setInstanceguid(OoInstances instanceguid) {
    this.instanceguid = instanceguid;
  }

  public OoInstances getInstancememberuomguid() {
    return instancememberuomguid;
  }

  public void setInstancememberuomguid(OoInstances instancememberuomguid) {
    this.instancememberuomguid = instancememberuomguid;
  }

  public OoClassesMembers getIntancememberguid() {
    return intancememberguid;
  }

  public void setIntancememberguid(OoClassesMembers intancememberguid) {
    this.intancememberguid = intancememberguid;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (intancemembervalueguid != null ? intancemembervalueguid.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof OoInstancesMembersValues)) {
      return false;
    }
    OoInstancesMembersValues other = (OoInstancesMembersValues) object;
    if ((this.intancemembervalueguid == null && other.intancemembervalueguid != null) || (this.intancemembervalueguid != null && !this.intancemembervalueguid.equals(other.intancemembervalueguid))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.idb.OoInstancesMembersValues[ intancemembervalueguid=" + intancemembervalueguid + " ]";
  }

}
