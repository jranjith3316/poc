package com.savoirfairelinux.walter.util.criteriabuilder;

import com.savoirfairelinux.walter.model.SearchEr;

import javax.persistence.EntityManager;
import java.util.Map;

public class ErSubQueryCriteriaBuilder extends ErCriteriaBuilder {

	public ErSubQueryCriteriaBuilder(EntityManager entityManager, SearchEr report) {
		super(entityManager, report);
	}

    @Override
    protected void initJoinQuery(StringBuilder queryBuilder, Map<String, Object> properties) {
        queryBuilder.append(" LEFT OUTER JOIN er.erTxtSet as txt ");
    }

    @Override
	protected void initOrderByQuery(StringBuilder queryBuilder,	Map<String, Object> properties) {
		// Override because no need of the order by in a subquery
	}
}
