/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.jasper.model;

import com.savoirfairelinux.walter.dao.walter.ExpenseRptD;
import java.io.Serializable;
import java.util.List;

/**
 *
 * @author jsgill
 */
public class JasperExpenseReportBean implements Serializable {

  private String userName;
  private String territoryCode;
  private String state;
  private String period;
  private String expenseRptId;
  private String perDiem;
  private String loanUse;
  private String total;
  private String nbrNight;
  private String subtotal;
  private String tip;
  private String tax1;
  private String tax2;
  private boolean managementTable;
  private boolean managementTableDeleted;
  
  private List<JasperExpenseRptDBean> jasperExpenseRptDBean;
  private List<JasperExpenseRptDBean> jasperExpenseRptDBeanDeleted;
  private List<JasperExpenseReportGLCodeBean> jasperExpenseReportGLCodeBean;

  public JasperExpenseReportBean(String userName, String territoryCode, String state, String period, String expenseRptId, String perDiem, String loanUse, String total, List<JasperExpenseRptDBean> jasperExpenseRptDBean) {
    this.userName = userName;
    this.territoryCode = territoryCode;
    this.state = state;
    this.period = period;
    this.expenseRptId = expenseRptId;
    this.perDiem = perDiem;
    this.loanUse = loanUse;
    this.total = total;
    this.jasperExpenseRptDBean = jasperExpenseRptDBean;
    this.managementTable = false;
    this.managementTableDeleted = false;
  }

  public JasperExpenseReportBean() {

  }
  
  public String getUserName() {
    return userName;
  }

  public void setUserName(String userName) {
    this.userName = userName;
  }

  public String getTerritoryCode() {
    return territoryCode;
  }

  public void setTerritoryCode(String territoryCode) {
    this.territoryCode = territoryCode;
  }

  public String getState() {
    return state;
  }

  public void setState(String state) {
    this.state = state;
  }

  public String getPeriod() {
    return period;
  }

  public void setPeriod(String period) {
    this.period = period;
  }

  public String getExpenseRptId() {
    return expenseRptId;
  }

  public void setExpenseRptId(String expenseRptId) {
    this.expenseRptId = expenseRptId;
  }

  public String getPerDiem() {
    return perDiem;
  }

  public void setPerDiem(String perDiem) {
    this.perDiem = perDiem;
  }

  public String getLoanUse() {
    return loanUse;
  }

  public void setLoanUse(String loanUse) {
    this.loanUse = loanUse;
  }

  public String getTotal() {
    return total;
  }

  public void setTotal(String total) {
    this.total = total;
  }

  public List<JasperExpenseRptDBean> getJasperExpenseRptDBean() {
    return jasperExpenseRptDBean;
  }

  public void setJasperExpenseRptDBean(List<JasperExpenseRptDBean> jasperExpenseRptDBean) {
    this.jasperExpenseRptDBean = jasperExpenseRptDBean;
  }

  public boolean isManagementTable() {
    return managementTable;
  }

  public void setManagementTable(boolean managementTable) {
    this.managementTable = managementTable;
  }

  public String getNbrNight() {
    return nbrNight;
  }

  public void setNbrNight(String nbrNight) {
    this.nbrNight = nbrNight;
  }

  public String getSubtotal() {
    return subtotal;
  }

  public void setSubtotal(String subtotal) {
    this.subtotal = subtotal;
  }

  public String getTip() {
    return tip;
  }

  public void setTip(String tip) {
    this.tip = tip;
  }

  public String getTax1() {
    return tax1;
  }

  public void setTax1(String tax1) {
    this.tax1 = tax1;
  }

  public String getTax2() {
    return tax2;
  }

  public void setTax2(String tax2) {
    this.tax2 = tax2;
  }

  public List<JasperExpenseReportGLCodeBean> getJasperExpenseReportGLCodeBean() {
    return jasperExpenseReportGLCodeBean;
  }

  public void setJasperExpenseReportGLCodeBean(List<JasperExpenseReportGLCodeBean> jasperExpenseReportGLCodeBean) {
    this.jasperExpenseReportGLCodeBean = jasperExpenseReportGLCodeBean;
  }

  public List<JasperExpenseRptDBean> getJasperExpenseRptDBeanDeleted() {
    return jasperExpenseRptDBeanDeleted;
  }

  public void setJasperExpenseRptDBeanDeleted(List<JasperExpenseRptDBean> jasperExpenseRptDBeanDeleted) {
    this.jasperExpenseRptDBeanDeleted = jasperExpenseRptDBeanDeleted;
  }

  public boolean isManagementTableDeleted() {
    return managementTableDeleted;
  }

  public void setManagementTableDeleted(boolean managementTableDeleted) {
    this.managementTableDeleted = managementTableDeleted;
  }

}
