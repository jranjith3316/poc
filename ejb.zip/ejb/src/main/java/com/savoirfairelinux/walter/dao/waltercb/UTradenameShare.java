/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "U_TRADENAME_SHARE", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "UTradenameShare.findAll", query = "SELECT u FROM UTradenameShare u"),
    @NamedQuery(name = "UTradenameShare.findByWFranchiseGuid", query = "SELECT u FROM UTradenameShare u WHERE u.wFranchiseGuid = :wFranchiseGuid"),
    @NamedQuery(name = "UTradenameShare.findByWTradenameGuid", query = "SELECT u FROM UTradenameShare u WHERE u.wTradenameGuid = :wTradenameGuid"),
    @NamedQuery(name = "UTradenameShare.findByCbFranchiseId", query = "SELECT u FROM UTradenameShare u WHERE u.cbFranchiseId = :cbFranchiseId"),
    @NamedQuery(name = "UTradenameShare.findByCbTradenameId", query = "SELECT u FROM UTradenameShare u WHERE u.cbTradenameId = :cbTradenameId"),
    @NamedQuery(name = "UTradenameShare.findById", query = "SELECT u FROM UTradenameShare u WHERE u.id = :id")})
public class UTradenameShare implements Serializable {
    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 255)
    @Column(name = "W_FRANCHISE_GUID")
    private String wFranchiseGuid;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "W_TRADENAME_GUID")
    private String wTradenameGuid;
    @Basic(optional = false)
    @NotNull
    @Column(name = "CB_FRANCHISE_ID")
    private short cbFranchiseId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "CB_TRADENAME_ID")
    private long cbTradenameId;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "ID")
    private BigDecimal id;

    public UTradenameShare() {
    }

    public UTradenameShare(BigDecimal id) {
        this.id = id;
    }

    public UTradenameShare(BigDecimal id, String wFranchiseGuid, String wTradenameGuid, short cbFranchiseId, long cbTradenameId) {
        this.id = id;
        this.wFranchiseGuid = wFranchiseGuid;
        this.wTradenameGuid = wTradenameGuid;
        this.cbFranchiseId = cbFranchiseId;
        this.cbTradenameId = cbTradenameId;
    }

    public String getWFranchiseGuid() {
        return wFranchiseGuid;
    }

    public void setWFranchiseGuid(String wFranchiseGuid) {
        this.wFranchiseGuid = wFranchiseGuid;
    }

    public String getWTradenameGuid() {
        return wTradenameGuid;
    }

    public void setWTradenameGuid(String wTradenameGuid) {
        this.wTradenameGuid = wTradenameGuid;
    }

    public short getCbFranchiseId() {
        return cbFranchiseId;
    }

    public void setCbFranchiseId(short cbFranchiseId) {
        this.cbFranchiseId = cbFranchiseId;
    }

    public long getCbTradenameId() {
        return cbTradenameId;
    }

    public void setCbTradenameId(long cbTradenameId) {
        this.cbTradenameId = cbTradenameId;
    }

    public BigDecimal getId() {
        return id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof UTradenameShare)) {
            return false;
        }
        UTradenameShare other = (UTradenameShare) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.UTradenameShare[ id=" + id + " ]";
    }
    
}
