/*
 l * Copyright 2012 Savoir-faire Linux
 *
 * This file is part of Walter-Portal.
 *
 * Walter-Portal is free software: you can redistribute it and/or modify it under the terms of the
 * GNU General Public License as published by the Free Software Foundation, either version 3
 * of the License, or (at your option) any later version.
 *
 * Walter-Portal is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with Walter-Portal.
 * If not, see http://www.gnu.org/licenses/.
 */
package com.savoirfairelinux.walter.service.impl;

import com.savoirfairelinux.walter.dao.waltercb.Country;
import com.savoirfairelinux.walter.dao.waltercb.Idea;
import com.savoirfairelinux.walter.dao.waltercb.IdeaCategory;
import com.savoirfairelinux.walter.dao.waltercb.IdeaCounter;
import com.savoirfairelinux.walter.dao.waltercb.IdeaCounterPK;
import com.savoirfairelinux.walter.dao.waltercb.IdeaFeedback;
import com.savoirfairelinux.walter.dao.waltercb.IdeaFeedbackR;
import com.savoirfairelinux.walter.dao.waltercb.IdeaFile;
import com.savoirfairelinux.walter.dao.waltercb.IdeaFileTxt;
import com.savoirfairelinux.walter.dao.waltercb.IdeaStatusTxt;
import com.savoirfairelinux.walter.dao.waltercb.IdeaTranslate;
import com.savoirfairelinux.walter.dao.waltercb.IdeaTranslatePK;
import com.savoirfairelinux.walter.dao.waltercb.IdeaTxt;
import com.savoirfairelinux.walter.dao.waltercb.ULang;
import com.savoirfairelinux.walter.model.IdeaState;
import com.savoirfairelinux.walter.model.SearchNewIdea;
import com.savoirfairelinux.walter.model.Tradename;
import com.savoirfairelinux.walter.model.WalterOrganization;
import com.savoirfairelinux.walter.service.NewIdeaBeanRemote;
import com.savoirfairelinux.walter.util.criteriabuilder.IdeaSubQueryCriteriaBuilder;
import com.savoirfairelinux.walter.util.criteriabuilder.IdeaTranslateCriteriaBuilder;
import com.savoirfairelinux.walter.util.criteriabuilder.NewIdeaCriteriaBuilder;
import com.savoirfairelinux.walter.util.criteriabuilder.QueryWrapper;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.security.PermitAll;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Startup;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import org.hibernate.Hibernate;
import org.hibernate.transform.DistinctRootEntityResultTransformer;

/**
 *
 * @author mgubaidullin
 * @author jderuere
 */
@Startup
@Stateless(name = "NewIdeaBean")
@TransactionManagement(TransactionManagementType.CONTAINER)
@PermitAll
@LocalBean
public class NewIdeaBean implements NewIdeaBeanRemote {

    public static final Logger LOG = Logger.getLogger(NewIdeaBean.class.getCanonicalName());
    @PersistenceContext(unitName = "waltershare")
    EntityManager entityManager;
    @EJB
    SingletonBean singletonBean;
    @EJB
    WalterBean walterBean;
    @EJB
    NotificationBean notificationBean;
    @EJB
    SolutionReportBean solutionReportBean;

    @Override
    public Idea save(Idea idea, Country country, ULang language, String productManagerName, String translatorName) throws Exception {
        idea.setCreatedDate(new Date());

        idea.setCreatorUserName(idea.getCreatorUserName().toUpperCase());

        if (idea.getIdeaRef() == null && idea.getIdeaId() != null && country != null) {
            String code = country.getCountryCode();
            String reportId = Long.toString(idea.getIdeaId());
            int idDiff = 6 - reportId.length();
            if (idDiff <= 0) {
                reportId = reportId.substring(0, 6);
            } else {
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < idDiff; i++) {
                    sb.append("0");
                }
                sb.append(reportId);
                reportId = sb.toString();
            }
            idea.setIdeaRef(code + reportId);
        }

        if (language != null) {
            idea.setOriginalLangId(language.getLangId());
        }

        if (productManagerName != null) {
            idea.setIdeaStatusId(IdeaState.TO_PUBLISH.getId());
            idea.setPmUserName(productManagerName.toUpperCase());
        }

        if (translatorName != null) {
            idea.setIdeaStatusId(IdeaState.IN_TRANSLATION.getId());
            IdeaTxt copyTxt = generateText(idea);
            IdeaTranslate translation = generateTranslation(idea, translatorName);
            for (IdeaFile file : idea.getIdeaFileSet()) {
                IdeaFileTxt fileTxt = generateFileText(idea, file);
                file.getIdeaFileTxtSet().add(fileTxt);
            }
            idea.getIdeaTxtSet().add(copyTxt);
            idea.getIdeaTranslateSet().add(translation);
        }

        idea = walterBean.save(idea);

        // If the idea is not in English, we send an email to the selected translator
        if (idea.getIdeaStatusId().equals(IdeaState.IN_TRANSLATION.getId()) && idea.getOriginalLangId() != ULang.ENGLISH_ID)
            notificationBean.sendPendingForTranslationNotification(idea);
        return idea;
    }

    private IdeaTxt generateText(Idea idea) {
        IdeaTxt newLanguageTxt = null;
        for (IdeaTxt ideaTxt : idea.getIdeaTxtSet()) {
            if (ideaTxt.getIdeaTxtPK().getLangId() == ULang.ENGLISH_ID) {
                newLanguageTxt = new IdeaTxt(ideaTxt, idea.getOriginalLangId());
                break;
            }
        }
        return newLanguageTxt;
    }

    private IdeaFileTxt generateFileText(Idea idea, IdeaFile file) {
        IdeaFileTxt newFileTxt = null;
        for (IdeaFileTxt fileTxt : file.getIdeaFileTxtSet()) {
            if (fileTxt.getIdeaFileTxtPK().getLangId() == ULang.ENGLISH_ID) {
                newFileTxt = new IdeaFileTxt(fileTxt, idea.getOriginalLangId());
                break;
            }
        }
        return newFileTxt;
    }

    private IdeaTranslate generateTranslation(Idea idea, String translatorName) {
        IdeaTranslate translation = new IdeaTranslate(new IdeaTranslatePK(idea.getIdeaId(), ULang.ENGLISH_ID));
        translation.setTranslatorUserName(translatorName.toUpperCase());
        translation.setFromLangId(idea.getOriginalLangId());
        translation.setSentToTr(new Date());
        return translation;
    }

    @Override
    public void submit(Idea idea) throws Exception {
        idea.setIdeaStatusId(IdeaState.SUBMITTED.getId());
        idea.setSubmitedDate(new Date());
        save(idea, null, null, null, null);
    }

    @Override
    public void publish(Idea idea) throws Exception {
        idea.setIdeaStatusId(IdeaState.OPEN_FOR_DISCUSSION.getId());
        idea.setPublishedDate(new Date());
        idea = save(idea, null, null, null, null);

        notificationBean.sendPublishedNotification(idea);
    }

    @Override
    public List<Idea> search(SearchNewIdea form, String userName, String organization, String languageAbbreviation) {
        List<Idea> result = null;
        try {
            ULang language = walterBean.getULang(languageAbbreviation);
            form.setOrganization(organization.equalsIgnoreCase(WalterOrganization.WALTER.getName()) ? WalterOrganization.WALTER : WalterOrganization.BIO_CIRCLE);
            form.setOrganization2(organization.equalsIgnoreCase(WalterOrganization.WALTER.getName()) ? WalterOrganization.BIO_CIRCLE : WalterOrganization.WALTER);
            NewIdeaCriteriaBuilder criteriaBuilder = new NewIdeaCriteriaBuilder(entityManager, form, language);
            result = criteriaBuilder.buildQuery().getQuery().getResultList();
            result = DistinctRootEntityResultTransformer.INSTANCE.transformList(result);
            QueryWrapper<Idea> subQueryWrapper = new IdeaSubQueryCriteriaBuilder(entityManager, form, language).buildQuery();
            HashMap<Long, String> walterProductNames = getIdeaWalterProductNames(languageAbbreviation, subQueryWrapper);
            HashMap<Long, String> cbProductNames = getIdeaCbProductNames(subQueryWrapper);
            HashMap<Long, Long> ideaCounters = getRecentIdeaCounters(userName, subQueryWrapper);

            List<IdeaCategory> categories = walterBean.getAllWalterByLanguage(IdeaCategory.class, language.getLangId());
            List<IdeaStatusTxt> statusTexts = walterBean.getAllWalterByLanguage(IdeaStatusTxt.class, language.getLangId());

            for (Idea idea : result) {
                String walterProductName = walterProductNames.get(idea.getIdeaId());
                String cbProductName = cbProductNames.get(idea.getIdeaId());
                idea.setProductName((walterProductName != null ? walterProductName : "") + ((walterProductName != null && cbProductName != null ? ", " : "")) + (cbProductName != null ? cbProductName : ""));
                idea.setCounter(ideaCounters.containsKey(idea.getIdeaId()) ? ideaCounters.get(idea.getIdeaId()) : 0L);

                for (IdeaTxt txt : idea.getIdeaTxtSet()) {
                    if (txt.getIdeaTxtPK().getLangId() == language.getLangId()) {
                        idea.setDescription(txt.getExplanation());
                        idea.setTitle(txt.getTitle());
                        idea.setComment(txt.getConsideredComment());
                        break;
                    } else if (txt.getIdeaTxtPK().getLangId() == ULang.ENGLISH_ID) {
                        idea.setDescription(txt.getExplanation());
                        idea.setTitle(txt.getTitle());
                        idea.setComment(txt.getConsideredComment());
                    }
                }

                for (IdeaCategory category : categories) {
                    if (category.getIdeaCategoryPK().getCatId() == idea.getCategoryId()) {
                        idea.setCategory(category.getDescription());
                        break;
                    } else if (category.getIdeaCategoryPK().getLangId() == ULang.ENGLISH_ID) {
                        idea.setCategory(category.getDescription());
                    }
                }

                for (IdeaStatusTxt statusTxt : statusTexts) {
                    if (statusTxt.getIdeaStatusTxtPK().getStatusId() == idea.getIdeaStatusId()) {
                        idea.setStatus(statusTxt.getDescription());
                        break;
                    } else if (statusTxt.getIdeaStatusTxtPK().getLangId() == ULang.ENGLISH_ID) {
                        idea.setStatus(statusTxt.getDescription());
                    }
                }
            }
        } catch (Exception e) {
            LOG.severe(e.getMessage());
        }
        return result;
    }

    @Override
    public Idea getIdea(long ideaId) {
        Idea result = entityManager.find(Idea.class, ideaId);
        if (result != null) {
            Hibernate.initialize(result.getIdeaTxtSet());
            Hibernate.initialize(result.getIdeaTranslateSet());
            Hibernate.initialize(result.getIdeaFileSet());
            Hibernate.initialize(result.getIdeaFeedbackList());
        }
        return result;
    }

    @Override
    public Idea getIdea(long ideaId, String languageAbbreviation, String country, String organization) {
        Idea result = getIdea(ideaId);
        if (result != null) {
            try {
                if (result.getTradename() != null) {
                    List<Tradename> tradenames = solutionReportBean.getTradenames(languageAbbreviation, country, organization);
                    for (Tradename tradename : tradenames) {
                        if (tradename.getTradenameId().equals(result.getTradename())){
                            result.setProductName(tradename.getFranchise().getDescription() + " " + tradename.getDescription());
                            break;
                        }
                    }
                }
                Hibernate.initialize(result.getIdeaTxtSet());
                Hibernate.initialize(result.getIdeaTranslateSet());
                Hibernate.initialize(result.getIdeaFileSet());
            } catch (Exception ex) {
                Logger.getLogger(NewIdeaBean.class.getName()).log(Level.SEVERE, ex.getMessage());
            }
        }
        return result;
    }

    @Override
    public void submitTranslation(Idea idea, IdeaTranslate originalTranslate, long langId, String screenName) throws Exception {
        idea.setIdeaStatusId(IdeaState.SUBMITTED.getId());
        if (originalTranslate == null) {
            idea = saveTranslation(idea, originalTranslate, langId, screenName);
        }
        for (IdeaTranslate translate : idea.getIdeaTranslateSet()) {
            if (translate.getIdeaTranslatePK().getLangId() == langId) {
                originalTranslate = translate;
                break;
            }
        }
        originalTranslate.setReceivedFromTr(new Date());
        walterBean.save(idea);
    }

    @Override
    public Idea saveTranslation(Idea idea, IdeaTranslate originalTranslate, long langId, String screenName) throws Exception {
        if (originalTranslate == null) {
            for (IdeaTranslate translate : idea.getIdeaTranslateSet()) {
                if (translate.getIdeaTranslatePK().getLangId() == langId) {
                    originalTranslate = translate;
                    break;
                }
            }

            if (originalTranslate == null) {
                originalTranslate = new IdeaTranslate(idea.getIdeaId(), langId);
                originalTranslate.setTranslatorUserName(screenName);
                originalTranslate.setFromLangId(ULang.ENGLISH_ID);
                originalTranslate.setSentToTr(new Date());
                originalTranslate.setIdea(idea);
                idea.getIdeaTranslateSet().add(originalTranslate);
            }
        }
        return walterBean.save(idea);
    }

    private HashMap<Long, Long> getRecentIdeaCounters(String userName, QueryWrapper<Idea> queryWrapper) throws Exception {
        HashMap<Long, Long> result = new HashMap<Long, Long>();
        try {
            StringBuilder sql = new StringBuilder(singletonBean.getNewIdeaQuery("new.ideas.read.counter"))
                    .append("AND idea in (").append(queryWrapper.getQueryString()).append(")");

            TypedQuery<Object[]> query = entityManager.createQuery(sql.toString(), Object[].class);
            for (Map.Entry<String, Object> entry : queryWrapper.getProperties().entrySet()) {
                query.setParameter(entry.getKey(), entry.getValue());
            }

            List<Object[]> rows = query.setParameter("userName", userName.toUpperCase()).getResultList();
            for (Object[] row : rows) {
                Long cntId = ((Long) row[0]);
                Long counter = ((Long) row[1]);
                result.put(cntId, counter);
            }
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    public List<IdeaTranslate> getMyPendingForTranslation(String screenName, String idbAbbreviation, String country) throws Exception {
        List<IdeaTranslate> result;
        try {
            result = getPendingForTranslation(null, screenName, idbAbbreviation, country);
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    public List<IdeaTranslate> getPendingForTranslation(String organization, String userName, String languageAbbreviation, String country) throws Exception {
        List<IdeaTranslate> result;
        try {
            IdeaTranslateCriteriaBuilder criteriaBuilder = new IdeaTranslateCriteriaBuilder(entityManager, userName, organization);
            List<IdeaTranslate> rows = criteriaBuilder.buildQuery().getQuery().getResultList();

            ULang language = walterBean.getULang(languageAbbreviation);
            Collection<IdeaTranslate> temp = new LinkedHashSet<IdeaTranslate>(rows);
            result = new ArrayList<IdeaTranslate>(temp.size());
            for (IdeaTranslate translate : temp) {
                Idea idea = translate.getIdea();
                String englishLangObjective = null;
                String userLangObjective = null;
                for (IdeaTxt txt : idea.getIdeaTxtSet()) {
                    if (txt.getIdeaTxtPK().getLangId() == language.getLangId()) {
                        userLangObjective = txt.getTitle();
                    } else if (txt.getIdeaTxtPK().getLangId() == ULang.ENGLISH_ID) {
                        englishLangObjective = txt.getTitle();
                    }
                }
                idea.setTitle(userLangObjective != null ? userLangObjective : englishLangObjective);
                result.add(translate);
            }
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    public List<Idea> getRecentIdeas(Long categoryId, boolean all, IdeaState state, String organization, String userName, String languageAbbreviation) throws Exception {
        List<Idea> result;
        SearchNewIdea searchNewIdea = new SearchNewIdea();
        if (!all) {
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(new Date());
            calendar.add(Calendar.DAY_OF_MONTH, -190);
            searchNewIdea.setCreatedDate(calendar.getTime());
        }
        searchNewIdea.setPublishedDateIsNotNull(Boolean.TRUE);
        searchNewIdea.setStates(state);
        searchNewIdea.setCategoryId(categoryId);
        try {
            result = search(searchNewIdea, userName, organization, languageAbbreviation);
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    public List<Idea> getUnreadIdeas(Long categoryId, String organization, String userName, String languageAbbreviation) throws Exception {
        List<Idea> result = new ArrayList<Idea>();
        SearchNewIdea searchNewIdea = new SearchNewIdea();
        searchNewIdea.setPublishedDateIsNotNull(Boolean.TRUE);
        searchNewIdea.setCategoryId(categoryId);
        try {
            List<Idea> temp = search(searchNewIdea, userName, organization, languageAbbreviation);
            for (Idea idea : temp) {
                if (idea.getCounter() == null || idea.getCounter() == 0) {
                    result.add(idea);
                }
            }
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    public List<Idea> getUnsubmitIdeas(String organization, String userName, String languageAbbreviation) throws Exception {
        List<Idea> result;
        SearchNewIdea searchNewIdea = new SearchNewIdea();
        searchNewIdea.setCreatorScreenName(userName);
        searchNewIdea.setStates(IdeaState.CREATED);
        try {
            result = search(searchNewIdea, userName, organization, languageAbbreviation);
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    public List<Idea> getInProcessIdeas(String organization, String userName, String languageAbbreviation) throws Exception {
        List<Idea> result;
        SearchNewIdea searchNewIdea = new SearchNewIdea();
        searchNewIdea.setCreatorScreenName(userName);
        searchNewIdea.setStates(IdeaState.IN_TRANSLATION, IdeaState.SUBMITTED, IdeaState.CONSIDERED, IdeaState.TO_PUBLISH, IdeaState.NOT_LAUNCHED);
        try {
            result = search(searchNewIdea, userName, organization, languageAbbreviation);
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    public List<Idea> getSubmittedIdeas(String organization, String userName, String languageAbbreviation) throws Exception {
        List<Idea> result;
        SearchNewIdea searchNewIdea = new SearchNewIdea();
        searchNewIdea.setStates(IdeaState.SUBMITTED, IdeaState.TO_PUBLISH);
        try {
            result = search(searchNewIdea, userName, organization, languageAbbreviation);
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    public List<Idea> getPublishedIdeas(String organization, String userName, String languageAbbreviation) throws Exception {
        List<Idea> result;
        SearchNewIdea searchNewIdea = new SearchNewIdea();
        searchNewIdea.setStates(IdeaState.CONSIDERED, IdeaState.NOT_CONSIDERED, IdeaState.OPEN_FOR_DISCUSSION);
        try {
            result = search(searchNewIdea, userName, organization, languageAbbreviation);
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    private HashMap<Long, String> getIdeaWalterProductNames(String languageAbbreviation, QueryWrapper<Idea> queryWrapper) throws Exception {
        HashMap<Long, String> result = new HashMap<Long, String>();
        try {
            String tmp = singletonBean.getNewIdeaQuery("new.ideas.walter.productnames");
            StringBuilder sql = new StringBuilder(tmp)
                    .append("AND idea in (").append(queryWrapper.getQueryString()).append(")");

            TypedQuery<Object[]> query = entityManager.createQuery(sql.toString(), Object[].class);
            for (Map.Entry<String, Object> entry : queryWrapper.getProperties().entrySet()) {
                query.setParameter(entry.getKey(), entry.getValue());
            }

            HashMap<String, String> translations = solutionReportBean.getWalterTradenamesTranslation(languageAbbreviation);

            List<Object[]> rows = query.getResultList();
            for (Object[] row : rows) {
                Long ideaId = (Long) row[0];
                String name = String.valueOf(row[1]);
                name = translations.containsKey(name) ? translations.get(name) : name;

                if (result.containsKey(ideaId)) {
                    result.put(ideaId, result.get(ideaId) + ", " + name);
                } else {
                    result.put(ideaId, name);
                }
            }
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    private HashMap<Long, String> getIdeaCbProductNames(QueryWrapper<Idea> queryWrapper) throws Exception {
        HashMap<Long, String> result = new HashMap<Long, String>();
        try {
            StringBuilder sql = new StringBuilder(singletonBean.getNewIdeaQuery("new.ideas.biocircle.productnames"))
                    .append("AND idea in (").append(queryWrapper.getQueryString()).append(")");

            TypedQuery<Object[]> query = entityManager.createQuery(sql.toString(), Object[].class);
            for (Map.Entry<String, Object> entry : queryWrapper.getProperties().entrySet()) {
                query.setParameter(entry.getKey(), entry.getValue());
            }

            List<Object[]> rows = query.getResultList();
            for (Object[] row : rows) {
                Long ideaId = (Long) row[0];
                String name = String.valueOf(row[1]);

                if (result.containsKey(ideaId)) {
                    result.put(ideaId, result.get(ideaId) + ", " + name);
                } else {
                    result.put(ideaId, name);
                }
            }
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    public IdeaCounter setIdeaCounter(Long ideaId, String userName) throws Exception {
        IdeaCounter result;
        IdeaCounterPK ideaCounterPK = new IdeaCounterPK(ideaId, userName.toUpperCase());
        try {
            result = entityManager.find(IdeaCounter.class, ideaCounterPK);
            if (result == null) {
                result = new IdeaCounter(ideaCounterPK);
                result.setFirstRead(new Date());
                result.setCounter(0L);
            }
            result.setLastRead(new Date());
            result.setCounter(result.getCounter() + 1);
            result = entityManager.merge(result);
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    public void cancel(Idea idea, String userName) throws Exception {
        try {
            entityManager.createQuery(singletonBean.getNewIdeaQuery("new.ideas.cancel"))
                    .setParameter("ideaId", idea.getIdeaId())
                    //.setParameter("cancelDate", new Date())
                    //.setParameter("cancelBy", userName)
                    .executeUpdate();
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
    }

    @Override
    public void reply(IdeaFeedbackR feedbackReply) throws Exception {
        feedbackReply.setCreatedDate(new Date());
        walterBean.save(feedbackReply);
    }

    @Override
    public void feedBack(IdeaFeedback feedback) throws Exception {
        feedback.setCreatedDate(new Date());
        walterBean.save(feedback);
        notificationBean.sendNewFeedbackNotification(feedback);
    }

//    @Schedule(hour="8")
    public void sendAutomaticSoonClosedNotification() throws Exception {
//        List<Idea> ideas = entityManager.createQuery(singletonBean.getNewIdeaQuery("new.ideas.soon.closed")).getResultList();
//
//        for (Idea idea : ideas) {
//            notificationBean.sendSoonClosedNotification(idea);
//        }
    }

//    @Schedule(hour="8")
    public void sendAutomaticClosingNotification() throws Exception {
//        List<Idea> ideas = entityManager.createQuery(singletonBean.getNewIdeaQuery("new.ideas.closing")).getResultList();
//
//        for (Idea idea : ideas) {
//            notificationBean.sendClosingNotification(idea);
//        }
    }
}
