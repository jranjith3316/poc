/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "CNT_INDUSTRY", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CntIndustry.findAll", query = "SELECT c FROM CntIndustry c"),
    @NamedQuery(name = "CntIndustry.findByCntId", query = "SELECT c FROM CntIndustry c WHERE c.cntIndustryPK.cntId = :cntId"),
    @NamedQuery(name = "CntIndustry.findByIndustryId", query = "SELECT c FROM CntIndustry c WHERE c.cntIndustryPK.industryId = :industryId")})
public class CntIndustry implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected CntIndustryPK cntIndustryPK;
    @JoinColumn(name = "CNT_ID", referencedColumnName = "CNT_ID", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Cnt cnt;

    public CntIndustry() {
    }

    public CntIndustry(CntIndustryPK cntIndustryPK) {
        this.cntIndustryPK = cntIndustryPK;
    }

    public CntIndustry(long cntId, long industryId) {
        this.cntIndustryPK = new CntIndustryPK(cntId, industryId);
    }

    public CntIndustryPK getCntIndustryPK() {
        return cntIndustryPK;
    }

    public void setCntIndustryPK(CntIndustryPK cntIndustryPK) {
        this.cntIndustryPK = cntIndustryPK;
    }

    public Cnt getCnt() {
        return cnt;
    }

    public void setCnt(Cnt cnt) {
        this.cnt = cnt;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cntIndustryPK != null ? cntIndustryPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CntIndustry)) {
            return false;
        }
        CntIndustry other = (CntIndustry) object;
        if ((this.cntIndustryPK == null && other.cntIndustryPK != null) || (this.cntIndustryPK != null && !this.cntIndustryPK.equals(other.cntIndustryPK))) {
            return false;
        }
        return true;
    }
    
    @PrePersist
    private void prePersist() {
    	if (cnt != null && cntIndustryPK != null) {
    		cntIndustryPK.setCntId(cnt.getCntId());
    	}
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.CntIndustry[ cntIndustryPK=" + cntIndustryPK + " ]";
    }
}
