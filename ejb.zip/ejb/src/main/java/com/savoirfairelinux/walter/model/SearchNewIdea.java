package com.savoirfairelinux.walter.model;

import java.io.Serializable;
import java.util.Date;

public class SearchNewIdea implements Serializable {

    private Long id;
    private String name;
    private String creatorScreenName;
    private IdeaState[] states;
    private Franchise franchise;
    private Tradename tradename;
    private Date createdDate;
    private Date submittedDate;
    private Date publishedDate;
    private Boolean publishedDateIsNotNull;
    private WalterOrganization organization;
    private WalterOrganization organization2;
    private Long categoryId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCreatorScreenName() {
        return creatorScreenName;
    }

    public void setCreatorScreenName(String creatorScreenName) {
        this.creatorScreenName = creatorScreenName;
    }

    public IdeaState[] getStates() {
        return states;
    }

    public void setStates(IdeaState... states) {
        this.states = states;
    }

    public Franchise getFranchise() {
        return franchise;
    }

    public void setFranchise(Franchise franchise) {
        this.franchise = franchise;
    }

    public Tradename getTradename() {
        return tradename;
    }

    public void setTradename(Tradename tradename) {
        this.tradename = tradename;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date date) {
        this.createdDate = date;
    }

    public Date getSubmittedDate() {
        return submittedDate;
    }

    public void setSubmittedDate(Date submittedDate) {
        this.submittedDate = submittedDate;
    }

    public WalterOrganization getOrganization() {
        return organization;
    }

    public void setOrganization(WalterOrganization organization) {
        this.organization = organization;
    }

    public WalterOrganization getOrganization2() {
        return organization2;
    }

    public void setOrganization2(WalterOrganization organization2) {
        this.organization2 = organization2;
    }

    public Date getPublishedDate() {
        return publishedDate;
    }

    public void setPublishedDate(Date publishedDate) {
        this.publishedDate = publishedDate;
    }

    public Boolean isPublishedDateIsNotNull() {
        return publishedDateIsNotNull;
    }

    public void setPublishedDateIsNotNull(Boolean publishedDateNull) {
        this.publishedDateIsNotNull = publishedDateNull;
    }

    public Long getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Long categoryId) {
        this.categoryId = categoryId;
    }
}
