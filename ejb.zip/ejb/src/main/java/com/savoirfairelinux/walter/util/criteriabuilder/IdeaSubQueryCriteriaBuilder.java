package com.savoirfairelinux.walter.util.criteriabuilder;

import com.savoirfairelinux.walter.dao.waltercb.ULang;
import com.savoirfairelinux.walter.model.SearchNewIdea;

import javax.persistence.EntityManager;
import java.util.Map;

public class IdeaSubQueryCriteriaBuilder extends NewIdeaCriteriaBuilder {

	public IdeaSubQueryCriteriaBuilder(EntityManager entityManager, SearchNewIdea report, ULang lang) {
		super(entityManager, report, lang);
	}

    @Override
    protected void initJoinQuery(StringBuilder queryBuilder, Map<String, Object> properties) {
        queryBuilder.append(" LEFT OUTER JOIN idea.ideaTxtSet txt ");
    }

	@Override
	protected void initOrderByQuery(StringBuilder queryBuilder,	Map<String, Object> properties) {
		// Override because no need of the order by in a subquery
	}
}
