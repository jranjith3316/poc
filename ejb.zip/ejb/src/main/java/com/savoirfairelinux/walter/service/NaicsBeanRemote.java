/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.service;

import com.savoirfairelinux.walter.dao.waltercb.NaicsCustomer;
import com.savoirfairelinux.walter.model.SearchSuspectNaics;
import java.util.List;
import javax.ejb.Remote;

/**
 *
 * @author jsgill
 */
@Remote
public interface NaicsBeanRemote {
  public List<NaicsCustomer> getNaicsCustomer(SearchSuspectNaics searchSuspectNaics) throws Exception;
}
