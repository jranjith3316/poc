/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author jsgill
 */
@Embeddable
public class CountryStateTxtPK implements Serializable {
    @Basic(optional = false)
    @NotNull
    @Column(name = "COUNTRY_ID")
    private long countryId;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 5)
    @Column(name = "STATE_CODE")
    private String stateCode;
    @Basic(optional = false)
    @NotNull
    @Column(name = "LANG_ID")
    private long langId;

    public CountryStateTxtPK() {
    }

    public CountryStateTxtPK(long countryId, String stateCode, long langId) {
        this.countryId = countryId;
        this.stateCode = stateCode;
        this.langId = langId;
    }

    public long getCountryId() {
        return countryId;
    }

    public void setCountryId(long countryId) {
        this.countryId = countryId;
    }

    public String getStateCode() {
        return stateCode;
    }

    public void setStateCode(String stateCode) {
        this.stateCode = stateCode;
    }

    public long getLangId() {
        return langId;
    }

    public void setLangId(long langId) {
        this.langId = langId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) countryId;
        hash += (stateCode != null ? stateCode.hashCode() : 0);
        hash += (int) langId;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CountryStateTxtPK)) {
            return false;
        }
        CountryStateTxtPK other = (CountryStateTxtPK) object;
        if (this.countryId != other.countryId) {
            return false;
        }
        if ((this.stateCode == null && other.stateCode != null) || (this.stateCode != null && !this.stateCode.equals(other.stateCode))) {
            return false;
        }
        if (this.langId != other.langId) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.CountryStateTxtPK[ countryId=" + countryId + ", stateCode=" + stateCode + ", langId=" + langId + " ]";
    }
    
}
