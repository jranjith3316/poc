package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; 
import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "CB_FRANCHISE", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CbFranchise.findAll", query = "SELECT c FROM CbFranchise c"),
    @NamedQuery(name = "CbFranchise.findByFranchiseId", query = "SELECT c FROM CbFranchise c WHERE c.franchiseId = :franchiseId"),
    @NamedQuery(name = "CbFranchise.findByCreatedBy", query = "SELECT c FROM CbFranchise c WHERE c.createdBy = :createdBy"),
    @NamedQuery(name = "CbFranchise.findByCreationDate", query = "SELECT c FROM CbFranchise c WHERE c.creationDate = :creationDate"),
    @NamedQuery(name = "CbFranchise.findByDisplay", query = "SELECT c FROM CbFranchise c WHERE c.display = :display")})
public class CbFranchise implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "FRANCHISE_ID")
    private Short franchiseId;
    @Size(max = 256)
    @Column(name = "CREATED_BY")
    private String createdBy;
    @Column(name = "CREATION_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date creationDate;
    @Column(name = "DISPLAY")
    private Character display;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "cbFranchise")
    private List<CbFranchiseTxt> cbFranchiseTxtList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "cbFranchise")
    private List<CbTradename> cbTradenameList;
    @Transient
    private String missingTranslation;
    
    public CbFranchise() {
    }

    public CbFranchise(Short franchiseId) {
        this.franchiseId = franchiseId;
    }

    public Short getFranchiseId() {
        return franchiseId;
    }

    public void setFranchiseId(Short franchiseId) {
        this.franchiseId = franchiseId;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public Character getDisplay() {
        return display;
    }

    public void setDisplay(Character display) {
        this.display = display;
    }

    @XmlTransient
    public List<CbFranchiseTxt> getCbFranchiseTxtList() {
        return cbFranchiseTxtList;
    }

    public void setCbFranchiseTxtList(List<CbFranchiseTxt> cbFranchiseTxtList) {
        this.cbFranchiseTxtList = cbFranchiseTxtList;
    }

    @XmlTransient
    public List<CbTradename> getCbTradenameList() {
        return cbTradenameList;
    }

    public void setCbTradenameList(List<CbTradename> cbTradenameList) {
        this.cbTradenameList = cbTradenameList;
    }

    public String getMissingTranslation() {
		return missingTranslation;
	}

	public void setMissingTranslation(String missingTranslation) {
		this.missingTranslation = missingTranslation;
	}

	@Override
    public int hashCode() {
        int hash = 0;
        hash += (franchiseId != null ? franchiseId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CbFranchise)) {
            return false;
        }
        CbFranchise other = (CbFranchise) object;
        if ((this.franchiseId == null && other.franchiseId != null) || (this.franchiseId != null && !this.franchiseId.equals(other.franchiseId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.CbFranchise[ franchiseId=" + franchiseId + " ]";
    }
    
}
