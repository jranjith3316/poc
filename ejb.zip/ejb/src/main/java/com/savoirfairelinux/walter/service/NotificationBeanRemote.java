/*
 * Copyright 2012 Savoir-faire Linux
 *
 * This file is part of Walter-Portal.
 *
 * Walter-Portal is free software: you can redistribute it and/or modify it under the terms of the
 * GNU General Public License as published by the Free Software Foundation, either version 3
 * of the License, or (at your option) any later version.
 *
 * Walter-Portal is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with Walter-Portal.
 * If not, see http://www.gnu.org/licenses/.
 */
package com.savoirfairelinux.walter.service;

import com.savoirfairelinux.walter.dao.globalcustomer.GaFeedback;
import com.savoirfairelinux.walter.dao.globalcustomer.GaFeedbackR;
import com.savoirfairelinux.walter.dao.walter.ExpenseRpt;
import com.savoirfairelinux.walter.dao.waltercb.Cnt;
import com.savoirfairelinux.walter.dao.waltercb.CntFeedback;
import com.savoirfairelinux.walter.dao.waltercb.Er;
import com.savoirfairelinux.walter.dao.waltercb.Idea;
import com.savoirfairelinux.walter.dao.waltercb.IdeaFeedback;
import com.savoirfairelinux.walter.dao.waltercb.ProductivityReport;
import java.util.List;
import javax.ejb.Remote;

/**
 *
 * @author jbonjean
 * @author jderuere
 *
 */
@Remote
public interface NotificationBeanRemote {
	public void sendNewReportNotification(Cnt report);
	public void sendNewFeedbackNotification(CntFeedback feedback);
	public void sendPendingForTranslationNotification(Cnt report);
	public void sendTranslationFinishedNotification(Cnt report);
	public void sendPendingForValidationNotification(Cnt report);
	public void sendReportValidatedNotification(Cnt report);

    public void sendNewFeedbackNotification(GaFeedback feedback);
    public void sendNewFeedbackReplyNotification(GaFeedbackR feedbackReply);

    public void sendPendingForTranslationNotification(Idea idea);
    public void sendPublishedNotification(Idea idea);
    public void sendSoonClosedNotification(Idea idea);
    public void sendClosingNotification(Idea idea);
    public void sendNewFeedbackNotification(IdeaFeedback feedback);

    public void sendNewLabReportNotification(Er report);
    public void sendPublishedLabReportNotification(Er report);

    void sendPublishedProductivityReportNotification(ProductivityReport report);
    void sendSubmitProductivityReportNotification(ProductivityReport report);


    public void sendValidationExpenseReportManagerNotification(ExpenseRpt expenseReport);
    public void sendExpenseReportAccountingUserNotification(ExpenseRpt expenseReport);
    public void sendExpenseReportAccountingUserModificationNotification(ExpenseRpt expenseReport);
    public void sendExpenseReportAccountingManagerNotification(ExpenseRpt expenseReport);

    public void sendLoanFoundNotification(String currentUser, String userInactivated, String loan, List<String> hrUserList, List<String> accountingUserList);//, String loan, List<User> hrUserList, List<User> accountingUserList

    public void sendMobileProductivityReportSendEmail();
    public void sendMobileProductivityOrderNotification();
}