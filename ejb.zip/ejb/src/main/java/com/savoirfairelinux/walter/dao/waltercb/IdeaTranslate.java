/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "IDEA_TRANSLATE", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "IdeaTranslate.findAll", query = "SELECT i FROM IdeaTranslate i"),
    @NamedQuery(name = "IdeaTranslate.findByIdeaId", query = "SELECT i FROM IdeaTranslate i WHERE i.ideaTranslatePK.ideaId = :ideaId"),
    @NamedQuery(name = "IdeaTranslate.findByLangId", query = "SELECT i FROM IdeaTranslate i WHERE i.ideaTranslatePK.langId = :langId"),
    @NamedQuery(name = "IdeaTranslate.findByTranslatorUserName", query = "SELECT i FROM IdeaTranslate i WHERE i.translatorUserName = :translatorUserName"),
    @NamedQuery(name = "IdeaTranslate.findBySentToTr", query = "SELECT i FROM IdeaTranslate i WHERE i.sentToTr = :sentToTr"),
    @NamedQuery(name = "IdeaTranslate.findByReceivedFromTr", query = "SELECT i FROM IdeaTranslate i WHERE i.receivedFromTr = :receivedFromTr"),
    @NamedQuery(name = "IdeaTranslate.findByFromLangId", query = "SELECT i FROM IdeaTranslate i WHERE i.fromLangId = :fromLangId")})
public class IdeaTranslate implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected IdeaTranslatePK ideaTranslatePK;
    @Size(max = 256)
    @Column(name = "TRANSLATOR_USER_NAME")
    private String translatorUserName;
    @Column(name = "SENT_TO_TR")
    @Temporal(TemporalType.TIMESTAMP)
    private Date sentToTr;
    @Column(name = "RECEIVED_FROM_TR")
    @Temporal(TemporalType.TIMESTAMP)
    private Date receivedFromTr;
    @Column(name = "FROM_LANG_ID")
    private Long fromLangId;
    @JoinColumn(name = "IDEA_ID", referencedColumnName = "IDEA_ID", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Idea idea;

    public IdeaTranslate() {
    }

    public IdeaTranslate(IdeaTranslatePK ideaTranslatePK) {
        this.ideaTranslatePK = ideaTranslatePK;
    }

    public IdeaTranslate(long ideaId, long langId) {
        this.ideaTranslatePK = new IdeaTranslatePK(ideaId, langId);
    }

    public IdeaTranslatePK getIdeaTranslatePK() {
        return ideaTranslatePK;
    }

    public void setIdeaTranslatePK(IdeaTranslatePK ideaTranslatePK) {
        this.ideaTranslatePK = ideaTranslatePK;
    }

    public String getTranslatorUserName() {
        return translatorUserName;
    }

    public void setTranslatorUserName(String translatorUserName) {
        this.translatorUserName = translatorUserName;
    }

    public Date getSentToTr() {
        return sentToTr;
    }

    public void setSentToTr(Date sentToTr) {
        this.sentToTr = sentToTr;
    }

    public Date getReceivedFromTr() {
        return receivedFromTr;
    }

    public void setReceivedFromTr(Date receivedFromTr) {
        this.receivedFromTr = receivedFromTr;
    }

    public Long getFromLangId() {
        return fromLangId;
    }

    public void setFromLangId(Long fromLangId) {
        this.fromLangId = fromLangId;
    }

    public Idea getIdea() {
        return idea;
    }

    public void setIdea(Idea idea) {
        this.idea = idea;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (ideaTranslatePK != null ? ideaTranslatePK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof IdeaTranslate)) {
            return false;
        }
        IdeaTranslate other = (IdeaTranslate) object;
        if ((this.ideaTranslatePK == null && other.ideaTranslatePK != null) || (this.ideaTranslatePK != null && !this.ideaTranslatePK.equals(other.ideaTranslatePK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.IdeaTranslate[ ideaTranslatePK=" + ideaTranslatePK + " ]";
    }
    
}
