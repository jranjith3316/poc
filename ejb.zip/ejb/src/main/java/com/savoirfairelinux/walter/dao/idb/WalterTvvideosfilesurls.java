/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.idb;

import com.savoirfairelinux.walter.dao.DatabaseConstants;
import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "WALTER_TVVIDEOSFILESURLS", catalog = "", schema = DatabaseConstants.IDB_SCHEMA)
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "WalterTvvideosfilesurls.findAll", query = "SELECT w FROM WalterTvvideosfilesurls w"),
  @NamedQuery(name = "WalterTvvideosfilesurls.findByTvvideoguid", query = "SELECT w FROM WalterTvvideosfilesurls w WHERE w.walterTvvideosfilesurlsPK.tvvideoguid = :tvvideoguid"),
  @NamedQuery(name = "WalterTvvideosfilesurls.findByTvvideoresolution", query = "SELECT w FROM WalterTvvideosfilesurls w WHERE w.walterTvvideosfilesurlsPK.tvvideoresolution = :tvvideoresolution"),
  @NamedQuery(name = "WalterTvvideosfilesurls.findByTvvideourl", query = "SELECT w FROM WalterTvvideosfilesurls w WHERE w.tvvideourl = :tvvideourl"),
  @NamedQuery(name = "WalterTvvideosfilesurls.findByTvvideofilename", query = "SELECT w FROM WalterTvvideosfilesurls w WHERE w.tvvideofilename = :tvvideofilename")})
public class WalterTvvideosfilesurls implements Serializable {
  private static final long serialVersionUID = 1L;
  @EmbeddedId
  protected WalterTvvideosfilesurlsPK walterTvvideosfilesurlsPK;
  @Size(max = 255)
  @Column(name = "TVVIDEOURL")
  private String tvvideourl;
  @Size(max = 255)
  @Column(name = "TVVIDEOFILENAME")
  private String tvvideofilename;
  @JoinColumn(name = "TVVIDEOGUID", referencedColumnName = "TVVIDEOGUID", insertable = false, updatable = false)
  @ManyToOne(optional = false)
  private WalterTvvideos walterTvvideos;

  public WalterTvvideosfilesurls() {
  }

  public WalterTvvideosfilesurls(WalterTvvideosfilesurlsPK walterTvvideosfilesurlsPK) {
    this.walterTvvideosfilesurlsPK = walterTvvideosfilesurlsPK;
  }

  public WalterTvvideosfilesurls(String tvvideoguid, long tvvideoresolution) {
    this.walterTvvideosfilesurlsPK = new WalterTvvideosfilesurlsPK(tvvideoguid, tvvideoresolution);
  }

  public WalterTvvideosfilesurlsPK getWalterTvvideosfilesurlsPK() {
    return walterTvvideosfilesurlsPK;
  }

  public void setWalterTvvideosfilesurlsPK(WalterTvvideosfilesurlsPK walterTvvideosfilesurlsPK) {
    this.walterTvvideosfilesurlsPK = walterTvvideosfilesurlsPK;
  }

  public String getTvvideourl() {
    return tvvideourl;
  }

  public void setTvvideourl(String tvvideourl) {
    this.tvvideourl = tvvideourl;
  }

  public String getTvvideofilename() {
    return tvvideofilename;
  }

  public void setTvvideofilename(String tvvideofilename) {
    this.tvvideofilename = tvvideofilename;
  }

  public WalterTvvideos getWalterTvvideos() {
    return walterTvvideos;
  }

  public void setWalterTvvideos(WalterTvvideos walterTvvideos) {
    this.walterTvvideos = walterTvvideos;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (walterTvvideosfilesurlsPK != null ? walterTvvideosfilesurlsPK.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof WalterTvvideosfilesurls)) {
      return false;
    }
    WalterTvvideosfilesurls other = (WalterTvvideosfilesurls) object;
    if ((this.walterTvvideosfilesurlsPK == null && other.walterTvvideosfilesurlsPK != null) || (this.walterTvvideosfilesurlsPK != null && !this.walterTvvideosfilesurlsPK.equals(other.walterTvvideosfilesurlsPK))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.idb.WalterTvvideosfilesurls[ walterTvvideosfilesurlsPK=" + walterTvvideosfilesurlsPK + " ]";
  }

}
