/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.globalcustomer.GlobalAccount;
import com.savoirfairelinux.walter.model.ReportState;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Set;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Cnt.findAll", query = "SELECT c FROM Cnt c"),
    @NamedQuery(name = "Cnt.findByCntId", query = "SELECT c FROM Cnt c WHERE c.cntId = :cntId"),
    @NamedQuery(name = "Cnt.findByCreatorUserName", query = "SELECT c FROM Cnt c WHERE c.creatorUserName = :creatorUserName"),
    @NamedQuery(name = "Cnt.findByEntryDate", query = "SELECT c FROM Cnt c WHERE c.entryDate = :entryDate"),
    @NamedQuery(name = "Cnt.findByOnStandby", query = "SELECT c FROM Cnt c WHERE c.onStandby = :onStandby"),
    @NamedQuery(name = "Cnt.findByPmUserName", query = "SELECT c FROM Cnt c WHERE c.pmUserName = :pmUserName"),
    @NamedQuery(name = "Cnt.findBySentToPm", query = "SELECT c FROM Cnt c WHERE c.sentToPm = :sentToPm"),
    @NamedQuery(name = "Cnt.findByReceivedFromPm", query = "SELECT c FROM Cnt c WHERE c.receivedFromPm = :receivedFromPm"),
    @NamedQuery(name = "Cnt.findByPublicationDate", query = "SELECT c FROM Cnt c WHERE c.publicationDate = :publicationDate"),
    @NamedQuery(name = "Cnt.findByExpectingImg", query = "SELECT c FROM Cnt c WHERE c.expectingImg = :expectingImg"),
    @NamedQuery(name = "Cnt.findByCntRef", query = "SELECT c FROM Cnt c WHERE c.cntRef = :cntRef"),
    @NamedQuery(name = "Cnt.findByValidFlag", query = "SELECT c FROM Cnt c WHERE c.validFlag = :validFlag"),
    @NamedQuery(name = "Cnt.findByPublished", query = "SELECT c FROM Cnt c WHERE c.published = :published"),
    @NamedQuery(name = "Cnt.findByCancelDate", query = "SELECT c FROM Cnt c WHERE c.cancelDate = :cancelDate"),
    @NamedQuery(name = "Cnt.findByOriginalLangId", query = "SELECT c FROM Cnt c WHERE c.originalLangId = :originalLangId"),
    @NamedQuery(name = "Cnt.findByCntType", query = "SELECT c FROM Cnt c WHERE c.cntType = :cntType"),
    @NamedQuery(name = "Cnt.findByShareable", query = "SELECT c FROM Cnt c WHERE c.shareable = :shareable"),
    @NamedQuery(name = "Cnt.findByModifiedByPm", query = "SELECT c FROM Cnt c WHERE c.modifiedByPm = :modifiedByPm"),
    @NamedQuery(name = "Cnt.findByCustomer", query = "SELECT c FROM Cnt c WHERE c.customer = :customer"),
    @NamedQuery(name = "Cnt.findByCity", query = "SELECT c FROM Cnt c WHERE c.city = :city"),
    @NamedQuery(name = "Cnt.findByPostalCode", query = "SELECT c FROM Cnt c WHERE c.postalCode = :postalCode"),
    @NamedQuery(name = "Cnt.findByPrimaryNaics", query = "SELECT c FROM Cnt c WHERE c.primaryNaics = :primaryNaics"),
    @NamedQuery(name = "Cnt.findByExtPmAdvice", query = "SELECT c FROM Cnt c WHERE c.extPmAdvice = :extPmAdvice"),
    @NamedQuery(name = "Cnt.findByExtPmAdviceComment", query = "SELECT c FROM Cnt c WHERE c.extPmAdviceComment = :extPmAdviceComment"),
    @NamedQuery(name = "Cnt.findByExtPublishDate", query = "SELECT c FROM Cnt c WHERE c.extPublishDate = :extPublishDate"),
    @NamedQuery(name = "Cnt.findByExtPmRejectDate", query = "SELECT c FROM Cnt c WHERE c.extPmRejectDate = :extPmRejectDate"),
    @NamedQuery(name = "Cnt.findByExtPmRejectComment", query = "SELECT c FROM Cnt c WHERE c.extPmRejectComment = :extPmRejectComment"),
    @NamedQuery(name = "Cnt.findByExtStatus", query = "SELECT c FROM Cnt c WHERE c.extStatus = :extStatus"),
    @NamedQuery(name = "Cnt.findByExtKeySale1Visible", query = "SELECT c FROM Cnt c WHERE c.extKeySale1Visible = :extKeySale1Visible"),
    @NamedQuery(name = "Cnt.findByExtKeySale2Visible", query = "SELECT c FROM Cnt c WHERE c.extKeySale2Visible = :extKeySale2Visible"),
    @NamedQuery(name = "Cnt.findByExtKeySale3Visible", query = "SELECT c FROM Cnt c WHERE c.extKeySale3Visible = :extKeySale3Visible"),
    @NamedQuery(name = "Cnt.findByExtKeySale4Visible", query = "SELECT c FROM Cnt c WHERE c.extKeySale4Visible = :extKeySale4Visible"),
    @NamedQuery(name = "Cnt.findByExtKeySale5Visible", query = "SELECT c FROM Cnt c WHERE c.extKeySale5Visible = :extKeySale5Visible"),
    @NamedQuery(name = "Cnt.findByExtCntCommentVisible", query = "SELECT c FROM Cnt c WHERE c.extCntCommentVisible = :extCntCommentVisible"),
    @NamedQuery(name = "Cnt.findByCopyFromId", query = "SELECT c FROM Cnt c WHERE c.copyFromId = :copyFromId"),
    @NamedQuery(name = "Cnt.findByCopyFromUser", query = "SELECT c FROM Cnt c WHERE c.copyFromUser = :copyFromUser"),
    @NamedQuery(name = "Cnt.findByCopyFromDate", query = "SELECT c FROM Cnt c WHERE c.copyFromDate = :copyFromDate"),
    @NamedQuery(name = "Cnt.findByPotentialGc", query = "SELECT c FROM Cnt c WHERE c.potentialGc = :potentialGc"),
    @NamedQuery(name = "Cnt.findByUrl", query = "SELECT c FROM Cnt c WHERE c.url = :url"),
    @NamedQuery(name = "Cnt.findByCreationDate", query = "SELECT c FROM Cnt c WHERE c.creationDate = :creationDate"),
    @NamedQuery(name = "Cnt.findByCancelBy", query = "SELECT c FROM Cnt c WHERE c.cancelBy = :cancelBy"),
    @NamedQuery(name = "Cnt.findByOrganization", query = "SELECT c FROM Cnt c WHERE c.organization = :organization"),
    @NamedQuery(name = "Cnt.findByRatingCount", query = "SELECT c FROM Cnt c WHERE c.ratingCount = :ratingCount"),
    @NamedQuery(name = "Cnt.findByRatingAvg", query = "SELECT c FROM Cnt c WHERE c.ratingAvg = :ratingAvg"),
    @NamedQuery(name = "Cnt.findByImageAttached", query = "SELECT c FROM Cnt c WHERE c.imageAttached = :imageAttached"),
    @NamedQuery(name = "Cnt.findByFileAttached", query = "SELECT c FROM Cnt c WHERE c.fileAttached = :fileAttached")})
public class Cnt implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "CNT_ID")
    @GeneratedValue(generator = "CNT_ID_SEQ", strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "CNT_ID_SEQ", sequenceName = "CNT_ID_SEQ", schema = DatabaseConstants.WALTERCB_SCHEMA, allocationSize = 1)
    private Long cntId;
    @Size(max = 256)
    @Column(name = "CREATOR_USER_NAME")
    private String creatorUserName;
    @Column(name = "ENTRY_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date entryDate;
    @Column(name = "ON_STANDBY", columnDefinition = "char")
    private String onStandby;
    @Size(max = 256)
    @Column(name = "PM_USER_NAME")
    private String pmUserName;
    @Column(name = "SENT_TO_PM")
    @Temporal(TemporalType.TIMESTAMP)
    private Date sentToPm;
    @Column(name = "RECEIVED_FROM_PM")
    @Temporal(TemporalType.TIMESTAMP)
    private Date receivedFromPm;
    @Column(name = "PUBLICATION_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date publicationDate;
    @Column(name = "EXPECTING_IMG", columnDefinition = "char")
    private String expectingImg;
    @Size(max = 20)
    @Column(name = "CNT_REF")
    private String cntRef;
    @Column(name = "VALID_FLAG")
    private Integer validFlag;
    @Column(name = "PUBLISHED", columnDefinition = "char")
    private String published;
    @Column(name = "CANCEL_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date cancelDate;
    @Column(name = "ORIGINAL_LANG_ID")
    private Long originalLangId;
    @Column(name = "CNT_TYPE", columnDefinition = "char")
    private String cntType;
    @Basic(optional = false)
    @NotNull
    @Column(name = "SHAREABLE", columnDefinition = "char")
    private String shareable;
    @Column(name = "MODIFIED_BY_PM", columnDefinition = "char")
    private String modifiedByPm;
    @Size(max = 200)
    private String customer;
    @Size(max = 40)
    private String city;
    @Size(max = 10)
    @Column(name = "POSTAL_CODE")
    private String postalCode;
    @Size(max = 6)
    @Column(name = "PRIMARY_NAICS")
    private String primaryNaics;
    @Column(name = "EXT_PM_ADVICE")
    private Short extPmAdvice;
    @Size(max = 100)
    @Column(name = "EXT_PM_ADVICE_COMMENT")
    private String extPmAdviceComment;
    @Column(name = "EXT_PUBLISH_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date extPublishDate;
    @Column(name = "EXT_PM_REJECT_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date extPmRejectDate;
    @Size(max = 100)
    @Column(name = "EXT_PM_REJECT_COMMENT")
    private String extPmRejectComment;
    @Column(name = "EXT_STATUS")
    private Short extStatus;
    @Column(name = "EXT_KEY_SALE_1_VISIBLE", columnDefinition = "char")
    private String extKeySale1Visible;
    @Column(name = "EXT_KEY_SALE_2_VISIBLE", columnDefinition = "char")
    private String extKeySale2Visible;
    @Column(name = "EXT_KEY_SALE_3_VISIBLE", columnDefinition = "char")
    private String extKeySale3Visible;
    @Column(name = "EXT_KEY_SALE_4_VISIBLE", columnDefinition = "char")
    private String extKeySale4Visible;
    @Column(name = "EXT_KEY_SALE_5_VISIBLE", columnDefinition = "char")
    private String extKeySale5Visible;
    @Column(name = "EXT_CNT_COMMENT_VISIBLE", columnDefinition = "char")
    private String extCntCommentVisible;
    @Column(name = "COPY_FROM_ID")
    private Long copyFromId;
    @Size(max = 256)
    @Column(name = "COPY_FROM_USER")
    private String copyFromUser;
    @Column(name = "COPY_FROM_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date copyFromDate;
    @Column(name = "COPY_STATUS", columnDefinition = "char")
    private String copyStatus;
    @Column(name = "POTENTIAL_GC", columnDefinition = "char")
    private String potentialGc;
    @Size(max = 515)
    private String url;
    @Column(name = "CREATION_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date creationDate;
    @Size(max = 256)
    @Column(name = "CANCEL_BY")
    private String cancelBy;
    @Size(max = 100)
    private String organization;
    @Basic(optional = true)
    @Column(name = "RATING_COUNT", nullable = true)
    private Integer ratingCount;
    @Basic(optional = true)
    @Column(name = "RATING_AVG")
    private BigDecimal ratingAvg;
    @Column(name = "IMAGE_ATTACHED")
    private Integer imageAttached;
    @Column(name = "FILE_ATTACHED")
    private Integer fileAttached;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "cnt")
    private List<CntTranslate> cntTranslateList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "cnt", orphanRemoval = true)
    private List<CntActivity> cntActivityList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "cnt", orphanRemoval = true)
    private List<CntMaterial> cntMaterialList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "cnt", orphanRemoval = true)
    private List<CntMachinery> cntMachineryList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "cnt")
    private List<CntCounter> cntCounterList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "cnt", orphanRemoval = true)
    private Set<CntPicture> cntPictureList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "cnt", orphanRemoval = true)
    private List<CntIndustry> cntIndustryList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "cnt", orphanRemoval = true)
    private List<CntProduct> cntProductList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "cnt")
    private Set<CntTxt> cntTxtList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "cnt")
    private Set<CntOpinion> cntOpinionList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "cnt", orphanRemoval = true)
    private List<CntCompetitor> cntCompetitorList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "cnt", orphanRemoval = true)
    private List<CntUrl> cntUrlList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "cnt")
    private List<CntFeedback> cntFeedbackList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "cnt")
    private List<CntFeedbackR> cntFeedbackRList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "cnt", orphanRemoval = true)
    private List<CntContaminant> cntContaminantList;
    @Transient
    private String objective;
    @Transient
    private String productName;
    @Transient
    private int read;
    @Transient
    private Long counter;

    public Cnt() {
    }

    public Cnt(Long cntId) {
        this.cntId = cntId;
    }

    public Cnt(Long cntId, String shareable) {
        this.cntId = cntId;
        this.shareable = shareable;
    }

    public Long getCntId() {
        return cntId;
    }

    public void setCntId(Long cntId) {
        this.cntId = cntId;
    }

    public String getCreatorUserName() {
        return creatorUserName;
    }

    public void setCreatorUserName(String creatorUserName) {
        this.creatorUserName = creatorUserName;
    }

    public Date getEntryDate() {
        return entryDate;
    }

    public void setEntryDate(Date entryDate) {
        this.entryDate = entryDate;
    }

    public String getOnStandby() {
        return onStandby;
    }

    public void setOnStandby(String onStandby) {
        this.onStandby = onStandby;
    }

    public String getPmUserName() {
        return pmUserName;
    }

    public void setPmUserName(String pmUserName) {
        this.pmUserName = pmUserName;
    }

    public Date getSentToPm() {
        return sentToPm;
    }

    public void setSentToPm(Date sentToPm) {
        this.sentToPm = sentToPm;
    }

    public Date getReceivedFromPm() {
        return receivedFromPm;
    }

    public void setReceivedFromPm(Date receivedFromPm) {
        this.receivedFromPm = receivedFromPm;
    }

    public Date getPublicationDate() {
        return publicationDate;
    }

    public void setPublicationDate(Date publicationDate) {
        this.publicationDate = publicationDate;
    }

    public String getExpectingImg() {
        return expectingImg;
    }

    public void setExpectingImg(String expectingImg) {
        this.expectingImg = expectingImg;
    }

    public String getCntRef() {
        return cntRef;
    }

    public void setCntRef(String cntRef) {
        this.cntRef = cntRef;
    }

    public Integer getValidFlag() {
        return validFlag;
    }

    public void setValidFlag(Integer validFlag) {
        this.validFlag = validFlag;
    }

    public String getPublished() {
        return published;
    }

    public void setPublished(String published) {
        this.published = published;
    }

    public Date getCancelDate() {
        return cancelDate;
    }

    public void setCancelDate(Date cancelDate) {
        this.cancelDate = cancelDate;
    }

    public Long getOriginalLangId() {
        return originalLangId;
    }

    public void setOriginalLangId(Long originalLangId) {
        this.originalLangId = originalLangId;
    }

    public String getCntType() {
        return cntType;
    }

    public void setCntType(String cntType) {
        this.cntType = cntType;
    }

    public String getShareable() {
        return shareable;
    }

    public void setShareable(String shareable) {
        this.shareable = shareable;
    }

    public String getModifiedByPm() {
        return modifiedByPm;
    }

    public void setModifiedByPm(String modifiedByPm) {
        this.modifiedByPm = modifiedByPm;
    }

    public String getCustomer() {
        return customer;
    }

    public void setCustomer(String customer) {
        this.customer = customer;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getPrimaryNaics() {
        return primaryNaics;
    }

    public void setPrimaryNaics(String primaryNaics) {
        this.primaryNaics = primaryNaics;
    }

    public Short getExtPmAdvice() {
        return extPmAdvice;
    }

    public void setExtPmAdvice(Short extPmAdvice) {
        this.extPmAdvice = extPmAdvice;
    }

    public String getExtPmAdviceComment() {
        return extPmAdviceComment;
    }

    public void setExtPmAdviceComment(String extPmAdviceComment) {
        this.extPmAdviceComment = extPmAdviceComment;
    }

    public Date getExtPublishDate() {
        return extPublishDate;
    }

    public void setExtPublishDate(Date extPublishDate) {
        this.extPublishDate = extPublishDate;
    }

    public Date getExtPmRejectDate() {
        return extPmRejectDate;
    }

    public void setExtPmRejectDate(Date extPmRejectDate) {
        this.extPmRejectDate = extPmRejectDate;
    }

    public String getExtPmRejectComment() {
        return extPmRejectComment;
    }

    public void setExtPmRejectComment(String extPmRejectComment) {
        this.extPmRejectComment = extPmRejectComment;
    }

    public Short getExtStatus() {
        return extStatus;
    }

    public void setExtStatus(Short extStatus) {
        this.extStatus = extStatus;
    }

    public String getExtKeySale1Visible() {
        return extKeySale1Visible;
    }

    public void setExtKeySale1Visible(String extKeySale1Visible) {
        this.extKeySale1Visible = extKeySale1Visible;
    }

    public String getExtKeySale2Visible() {
        return extKeySale2Visible;
    }

    public void setExtKeySale2Visible(String extKeySale2Visible) {
        this.extKeySale2Visible = extKeySale2Visible;
    }

    public String getExtKeySale3Visible() {
        return extKeySale3Visible;
    }

    public void setExtKeySale3Visible(String extKeySale3Visible) {
        this.extKeySale3Visible = extKeySale3Visible;
    }

    public String getExtKeySale4Visible() {
        return extKeySale4Visible;
    }

    public void setExtKeySale4Visible(String extKeySale4Visible) {
        this.extKeySale4Visible = extKeySale4Visible;
    }

    public String getExtKeySale5Visible() {
        return extKeySale5Visible;
    }

    public void setExtKeySale5Visible(String extKeySale5Visible) {
        this.extKeySale5Visible = extKeySale5Visible;
    }

    public String getExtCntCommentVisible() {
        return extCntCommentVisible;
    }

    public void setExtCntCommentVisible(String extCntCommentVisible) {
        this.extCntCommentVisible = extCntCommentVisible;
    }

    public Long getCopyFromId() {
        return copyFromId;
    }

    public void setCopyFromId(Long copyFromId) {
        this.copyFromId = copyFromId;
    }

    public String getCopyFromUser() {
        return copyFromUser;
    }

    public void setCopyFromUser(String copyFromUser) {
        this.copyFromUser = copyFromUser;
    }

    public Date getCopyFromDate() {
        return copyFromDate;
    }

    public void setCopyFromDate(Date copyFromDate) {
        this.copyFromDate = copyFromDate;
    }

    public String getCopyStatus() {
        return copyStatus;
    }

    public void setCopyStatus(String copyStatus) {
        this.copyStatus = copyStatus;
    }

    public String getPotentialGc() {
        return potentialGc;
    }

    public void setPotentialGc(String potentialGc) {
        this.potentialGc = potentialGc;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public String getCancelBy() {
        return cancelBy;
    }

    public void setCancelBy(String cancelBy) {
        this.cancelBy = cancelBy;
    }

    public String getOrganization() {
        return organization;
    }

    public void setOrganization(String organization) {
        this.organization = organization;
    }

    public Integer getRatingCount() {
        return ratingCount;
    }

    public void setRatingCount(Integer ratingCount) {
        this.ratingCount = ratingCount;
    }

    public BigDecimal getRatingAvg() {
        return ratingAvg;
    }

    public void setRatingAvg(BigDecimal ratingAvg) {
        this.ratingAvg = ratingAvg;
    }

    public Integer getImageAttached() {
        return imageAttached;
    }

    public void setImageAttached(Integer imageAttached) {
        this.imageAttached = imageAttached;
    }

    public Integer getFileAttached() {
        return fileAttached;
    }

    public void setFileAttached(Integer fileAttached) {
        this.fileAttached = fileAttached;
    }
    
    public ReportState getState() {
    	ReportState state = ReportState.UNSUBMIT;
    	if (entryDate == null) {
    		state = ReportState.UNSUBMIT;
    	} else if (validFlag != null && validFlag.equals(0)) {
    		state = ReportState.INVALID;
    	} else if (originalLangId != null && sentToPm == null) {
    		state = ReportState.PENDING_FOR_TRANSLATION;
    	} else if (receivedFromPm == null && sentToPm != null && validFlag == null) {
    		state = ReportState.PENDING_FOR_VALIDATION;
    	} else if (receivedFromPm != null && validFlag.equals(1)) {
    		state = ReportState.VALIDATE;
    	} else if (publicationDate == null && entryDate != null && validFlag == null) {
    		state = ReportState.SUBMIT;
    	} else if (publicationDate != null && entryDate != null) {
    		state = ReportState.PUBLISH;
    	}
    	return state;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cntId != null ? cntId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Cnt)) {
            return false;
        }
        Cnt other = (Cnt) object;
        if ((this.cntId == null && other.cntId != null) || (this.cntId != null && !this.cntId.equals(other.cntId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.Cnt[ cntId=" + cntId + " ]";
    }

    public String getObjective() {
        return objective;
    }

    public void setObjective(String objective) {
        this.objective = objective;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public int getRead() {
        return read;
    }

    public void setRead(int read) {
        this.read = read;
    }

    public Long getCounter() {
        return counter;
    }

    public void setCounter(Long counter) {
        this.counter = counter;
    }

    public List<CntTranslate> getCntTranslateList() {
        return cntTranslateList;
    }

    public void setCntTranslateList(List<CntTranslate> cntTranslateList) {
        this.cntTranslateList = cntTranslateList;
    }

    public List<CntActivity> getCntActivityList() {
        return cntActivityList;
    }

    public void setCntActivityList(List<CntActivity> cntActivityList) {
        this.cntActivityList = cntActivityList;
    }

    public List<CntMaterial> getCntMaterialList() {
        return cntMaterialList;
    }

    public void setCntMaterialList(List<CntMaterial> cntMaterialList) {
        this.cntMaterialList = cntMaterialList;
    }

    public List<CntMachinery> getCntMachineryList() {
        return cntMachineryList;
    }

    public void setCntMachineryList(List<CntMachinery> cntMachineryList) {
        this.cntMachineryList = cntMachineryList;
    }

    public List<CntCounter> getCntCounterList() {
        return cntCounterList;
    }

    public void setCntCounterList(List<CntCounter> cntCounterList) {
        this.cntCounterList = cntCounterList;
    }

    public Set<CntPicture> getCntPictureList() {
        return cntPictureList;
    }

    public void setCntPictureList(Set<CntPicture> cntPictureList) {
        this.cntPictureList = cntPictureList;
    }

    public List<CntIndustry> getCntIndustryList() {
        return cntIndustryList;
    }

    public void setCntIndustryList(List<CntIndustry> cntIndustryList) {
        this.cntIndustryList = cntIndustryList;
    }

    public List<CntProduct> getCntProductList() {
        return cntProductList;
    }

    public void setCntProductList(List<CntProduct> cntProductList) {
        this.cntProductList = cntProductList;
    }

    public Set<CntTxt> getCntTxtList() {
        return cntTxtList;
    }

    public void setCntTxtList(Set<CntTxt> cntTxtList) {
        this.cntTxtList = cntTxtList;
    }

    public Set<CntOpinion> getCntOpinionList() {
        return cntOpinionList;
    }

    public void setCntOpinionList(Set<CntOpinion> cntOpinionList) {
        this.cntOpinionList = cntOpinionList;
    }

    public List<CntCompetitor> getCntCompetitorList() {
        return cntCompetitorList;
    }

    public void setCntCompetitorList(List<CntCompetitor> cntCompetitorList) {
        this.cntCompetitorList = cntCompetitorList;
    }

    public List<CntUrl> getCntUrlList() {
        return cntUrlList;
    }

    public void setCntUrlList(List<CntUrl> cntUrlList) {
        this.cntUrlList = cntUrlList;
    }

    public List<CntFeedback> getCntFeedbackList() {
        return cntFeedbackList;
    }

    public void setCntFeedbackList(List<CntFeedback> cntFeedbackList) {
        this.cntFeedbackList = cntFeedbackList;
    }

    public List<CntContaminant> getCntContaminantList() {
        return cntContaminantList;
    }

    public void setCntContaminantList(List<CntContaminant> cntContaminantList) {
        this.cntContaminantList = cntContaminantList;
    }

    public List<CntFeedbackR> getCntFeedbackRList() {
        return cntFeedbackRList;
    }

    public void setCntFeedbackRList(List<CntFeedbackR> cntFeedbackRList) {
        this.cntFeedbackRList = cntFeedbackRList;
    }
}
