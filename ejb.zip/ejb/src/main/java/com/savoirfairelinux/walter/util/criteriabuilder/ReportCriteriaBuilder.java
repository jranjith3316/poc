package com.savoirfairelinux.walter.util.criteriabuilder;

import com.savoirfairelinux.walter.dao.waltercb.ULang;
import com.savoirfairelinux.walter.model.SearchReport;

import javax.persistence.EntityManager;
import java.util.Map;

public class ReportCriteriaBuilder extends CntCriteriaBuilder {

    protected SearchReport report;

    public ReportCriteriaBuilder(EntityManager entityManager, SearchReport report, ULang lang) {
        super(entityManager, lang);
        this.report = report;
    }

    @Override
    protected void buildSpecificQuery(StringBuilder queryBuilder, Map<String, Object> properties) {
        super.buildSpecificQuery(queryBuilder, properties);
        addOrganization2Criteria(queryBuilder, properties, report.getOrganization(), report.getOrganization2());
        addCntIdCriteria(queryBuilder, properties, report.getCntId());
        addLikeCriteria(queryBuilder, "cnt.cntRef", report.getReference());
        if (report.getType() != null) {
            addLikeCriteria(queryBuilder, "cnt.cntType", report.getType().getType());
        }
        addIndustryCriteria(queryBuilder, properties, report.getIndustry());
        addFromPublicationDateCriteria(queryBuilder, properties, report.getFromPublicationDate());
        addToPublicationDateCriteria(queryBuilder, properties, report.getToPublicationDate());
        addLikeCriteria(queryBuilder, "cnt.primaryNaics", report.getNaics());
        addLikeCriteria(queryBuilder, "cnt.creatorUserName", report.getReporterScreenName() != null ? report.getReporterScreenName().toUpperCase() : null);
        addContaminantCriteria(queryBuilder, properties, report.getContaminant());
        addMaterialCriteria(queryBuilder, properties, report.getMaterial());
        addActivityCriteria(queryBuilder, properties, report.getActivity());
        addCompetitorCriteria(queryBuilder, properties, report.getCompetitor());
        if (report.getTradename() != null) {
            addTradenameCriteria(queryBuilder, properties, report.getTradename());
        } else {
            addFranchiseCriteria(queryBuilder, properties, report.getFranchise());
        }
        addTranslateCriteria(queryBuilder, properties, report.getLanguage());
        addKeywordCriteria(queryBuilder, properties, report.getKeyWord());
        addLikeCriteria(queryBuilder, "cnt.customer", report.getCustomer());
        addFromRatingAvgCriteria(queryBuilder, properties, report.getFromRatingAvg());
        addToRatingAvgCriteria(queryBuilder, properties, report.getToRatingAvg());
        addStateCriteria(queryBuilder, properties, report.getState());
        addLikeCriteria(queryBuilder, "cnt.pmUserName", report.getPmScreenName() != null ? report.getPmScreenName().toUpperCase() : null);
    }
}
