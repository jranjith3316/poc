package com.savoirfairelinux.walter.model;

public enum IdeaState {

    DELETED(0),
    UNPUBLISH(1),
    CREATED(2),
    SUBMITTED(3),
    IN_TRANSLATION(4),
    TRANSLATED(5),
    TO_PUBLISH(6),
    OPEN_FOR_DISCUSSION(7),
    CONSIDERED(8),
    NOT_CONSIDERED(9),
    IN_DEVELOPMENT(10),
    NOT_LAUNCHED(11),
    LAUNCHED(12);
    private int id;

    IdeaState(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }
}
