/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.crossreferenceapp.model;
import java.io.Serializable;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
/**
 *
 * @author jsgill
 */
@XmlRootElement(name = "walterProductRequest")
public class WalterProductRequestApi implements Serializable {
  private static final long serialVersionUID = 3511338233023397895L;
  private String countryCode;
  private String langCode;
  private Long lastUpdate;

  public WalterProductRequestApi() {
  }

  public String getCountryCode() {
    return countryCode;
  }

  @XmlElement(name = "countryCode")
  public void setCountryCode(String countryCode) {
    this.countryCode = countryCode;
  }

  public String getLangCode() {
    return langCode;
  }

  @XmlElement(name = "langCode")
  public void setLangCode(String langCode) {
    this.langCode = langCode;
  }

  public Long getLastUpdate() {
    return lastUpdate;
  }

  @XmlElement(name = "lastUpdate", required = false)
  public void setLastUpdate(Long lastUpdate) {
    this.lastUpdate = lastUpdate;
  }



}
