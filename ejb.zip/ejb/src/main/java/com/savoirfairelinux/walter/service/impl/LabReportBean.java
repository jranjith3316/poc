/* 
 l * Copyright 2012 Savoir-faire Linux
 * 
 * This file is part of Walter-Portal.
 * 
 * Walter-Portal is free software: you can redistribute it and/or modify it under the terms of the 
 * GNU General Public License as published by the Free Software Foundation, either version 3 
 * of the License, or (at your option) any later version.
 * 
 * Walter-Portal is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with Walter-Portal. 
 * If not, see http://www.gnu.org/licenses/.
 */
package com.savoirfairelinux.walter.service.impl;

import com.savoirfairelinux.walter.dao.waltercb.*;
import com.savoirfairelinux.walter.model.*;
import com.savoirfairelinux.walter.service.LabReportBeanRemote;
import com.savoirfairelinux.walter.util.criteriabuilder.ErCriteriaBuilder;
import com.savoirfairelinux.walter.util.criteriabuilder.ErSubQueryCriteriaBuilder;
import com.savoirfairelinux.walter.util.criteriabuilder.QueryWrapper;
import org.hibernate.Hibernate;
import org.hibernate.transform.DistinctRootEntityResultTransformer;

import javax.annotation.security.PermitAll;
import javax.ejb.*;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import java.util.*;
import java.util.logging.Logger;

/**
 *
 * @author mgubaidullin
 * @author jderuere
 */
@Startup
@Stateless(name = "LabReportBean")
@TransactionManagement(TransactionManagementType.CONTAINER)
@PermitAll
@LocalBean
public class LabReportBean implements LabReportBeanRemote {

    public static final Logger LOG = Logger.getLogger(LabReportBean.class.getCanonicalName());
    @PersistenceContext(unitName = "waltershare")
    EntityManager entityManager;
    @EJB
    SingletonBean singletonBean;
    @EJB
    WalterBean walterBean;
    @EJB
    NotificationBean notificationBean;
    @EJB
    SolutionReportBean solutionReportBean;

    @Override
    @Interceptors({DebugInterceptor.class})
    public List<Er> search(SearchEr form, String userName, String organization, Long langId) throws Exception {
        List<Er> result = null;
        try {
            form.setOrganization(organization.equalsIgnoreCase(WalterOrganization.WALTER.getName()) ? WalterOrganization.WALTER : WalterOrganization.BIO_CIRCLE);
            ErCriteriaBuilder criteriaBuilder = new ErCriteriaBuilder(entityManager, form);
            result = criteriaBuilder.buildQuery().getQuery().getResultList();
            result = DistinctRootEntityResultTransformer.INSTANCE.transformList(result);
            QueryWrapper<Er> subQueryWrapper = new ErSubQueryCriteriaBuilder(entityManager, form).buildQuery();
            HashMap<Long, Long> counters = getRecentErCounters(userName, subQueryWrapper);

            for (Er er : result) {
                er.setCounter(counters.containsKey(er.getErId()) ? counters.get(er.getErId()) : 0L);

                for (ErTxt txt : er.getErTxtSet()) {
                    if (langId.equals(txt.getErTxtPK().getLangId())) {
                        er.setTitle(txt.getPartCleanDesc());
                        er.setCustomer(txt.getCustomerName());
                        er.setContactName(txt.getContactName());
                        break;
                    } else if (txt.getErTxtPK().getLangId() == ULang.ENGLISH_ID) {
                        er.setTitle(txt.getPartCleanDesc());
                        er.setCustomer(txt.getCustomerName());
                        er.setContactName(txt.getContactName());
                    }
                }
            }
        } catch (Exception e) {
            LOG.severe(e.getMessage());
        }
        return result;
    }

    @Interceptors({DebugInterceptor.class})
    private HashMap<Long, Long> getRecentErCounters(String userName, QueryWrapper<Er> queryWrapper) throws Exception {
        HashMap<Long, Long> result = new HashMap<Long, Long>();
        try {
            StringBuilder sql = new StringBuilder(singletonBean.getLabReportQuery("lab.report.read.counter"))
                    .append("AND er in (").append(queryWrapper.getQueryString()).append(")");

            TypedQuery<Object[]> query = entityManager.createQuery(sql.toString(), Object[].class);
            for (Map.Entry<String, Object> entry : queryWrapper.getProperties().entrySet()) {
                query.setParameter(entry.getKey(), entry.getValue());
            }

            List<Object[]> rows = query.setParameter("userName", userName.toUpperCase()).getResultList();
            for (Object[] row : rows) {
                Long cntId = ((Long) row[0]);
                Long counter = ((Long) row[1]);
                result.put(cntId, counter);
            }
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    @Interceptors({DebugInterceptor.class})
    public List<Er> getRecentReports(String organization, String userName, Long langId) throws Exception {
        List<Er> result;
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        calendar.add(Calendar.DAY_OF_MONTH, -190);
        SearchEr searchEr = new SearchEr();
        searchEr.setFromPublicationDate(calendar.getTime());
        searchEr.setState(LabReportState.PUBLISH);
        try {
            result = search(searchEr, userName, organization, langId);
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    @Interceptors({DebugInterceptor.class})
    public List<Er> getUnreadReports(String organization, String userName, Long langId) throws Exception {
        List<Er> result = new ArrayList<Er>();
        SearchEr searchEr = new SearchEr();
        searchEr.setState(LabReportState.PUBLISH);
        try {
            List<Er> temp = search(searchEr, userName, organization, langId);
            for (Er er : temp) {
                if (er.getCounter() == null || er.getCounter() == 0) {
                    result.add(er);
                }
            }
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    @Interceptors({DebugInterceptor.class})
    public List<Er> getMyUnsubmitReports(String organization, String userName, Long langId) throws Exception {
        List<Er> result;
        SearchEr searchEr = new SearchEr();
        searchEr.setCreatorScreenName(userName);
        searchEr.setState(LabReportState.UNSUBMIT);
        try {
            result = search(searchEr, userName, organization, langId);
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    @Interceptors({DebugInterceptor.class})
    public List<Er> getMySubmittedReports(String organization, String userName, Long langId) throws Exception {
        List<Er> result;
        SearchEr searchEr = new SearchEr();
        searchEr.setCreatorScreenName(userName);
        searchEr.setState(LabReportState.SUBMIT);
        try {
            result = search(searchEr, userName, organization, langId);
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    @Interceptors({DebugInterceptor.class})
    public List<Er> getMyPublishedReports(String organization, String userName, Long langId) throws Exception {
        List<Er> result;
        SearchEr searchEr = new SearchEr();
        searchEr.setCreatorScreenName(userName);
        searchEr.setState(LabReportState.PUBLISH);
        try {
            result = search(searchEr, userName, organization, langId);
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    @Interceptors({DebugInterceptor.class})
    public List<Er> getMyRequestPublishedReports(String organization, String userName, Long langId) throws Exception {
        List<Er> result;
        SearchEr searchEr = new SearchEr();
        searchEr.setRequesterScreenName(userName);
        searchEr.setState(LabReportState.PUBLISH);
        try {
            result = search(searchEr, userName, organization, langId);
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    @Interceptors({DebugInterceptor.class})
    public List<Er> getSubmittedReports(String organization, String userName, Long langId) throws Exception {
        List<Er> result;
        SearchEr searchEr = new SearchEr();
        searchEr.setState(LabReportState.SUBMIT);
        try {
            result = search(searchEr, userName, organization, langId);
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    @Interceptors({DebugInterceptor.class})
    public Er save(Er er, Country country, ULang language) throws Exception {
        er.setCreatorUserName(er.getCreatorUserName().toUpperCase());

        if (er.getErRef() == null && er.getErId() != null && country != null) {
            String code = country.getCountryCode();
            String reportId = Long.toString(er.getErId());
            int idDiff = 6 - reportId.length();
            if (idDiff <= 0) {
                reportId.substring(0, 6);
            } else {
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < idDiff; i++) sb.append("0");
                sb.append(reportId);
                reportId = sb.toString();
            }
            er.setErRef(code + reportId);
        }

        if (language != null) {
            er.setOriginalLangId(language.getLangId());
        }

        List<Tradename> tradenames = new ArrayList<Tradename>();
        for (ErTrial trial : er.getErTrialSet()) {
            for (ErTrialProduct product : trial.getCleaners()) {
                if (product.getTradenameguid() != null)
                    tradenames.add(new Tradename(product.getTradenameguid(), new Franchise(product.getFranchiseguid(), product.getFranchiseName()), product.getTradeName()));
            }
        }

        Er savedEr = walterBean.save(er);

        for (ErTrial trial : savedEr.getErTrialSet()) {
            for (ErTrialProduct product : trial.getCleaners()) {
                if (product.getTradenameguid() != null) {
                    for (Tradename tradename : tradenames) {
                        if (tradename.getTradenameId().equals(product.getTradenameguid()) && tradename.getFranchise().getFranchiseId().equals(product.getFranchiseguid())) {
                            product.setTradeName(tradename.getDescription());
                            product.setFranchiseName(tradename.getFranchise().getDescription());
                            break;
                        }
                    }
                }
            }
        }

        return savedEr;
    }

    @Override
    @Interceptors({DebugInterceptor.class})
    public Er submit(Er report) throws Exception {
        report.setSentToWs(new Date());
        Er result = save(report, null, null);
        notificationBean.sendNewLabReportNotification(result);
        return result;
    }

    @Override
    @Interceptors({DebugInterceptor.class})
    public void publish(Er report) throws Exception {
        report.setPublishedDate(new Date());
        report.setPublished("Y");
        for (ErTxt txt : report.getErTxtSet()) {
            if (txt.getErTxtPK().getLangId() == ULang.ENGLISH_ID) {
                txt.setPublishedDate(new Date());
                break;
            }
        }
        save(report, null, null);
        notificationBean.sendPublishedLabReportNotification(report);
    }

    @Override
    @Interceptors({DebugInterceptor.class})
    public Er getLabReport(long id, String organization, Long langId, String languageAbbreviation) throws Exception {
        Er result;
        try {
            SearchEr form = new SearchEr();
            form.setId(id);
            form.setOrganization(organization.equalsIgnoreCase(WalterOrganization.WALTER.getName()) ? WalterOrganization.WALTER : WalterOrganization.BIO_CIRCLE);

            ErCriteriaBuilder criteriaBuilder = new ErCriteriaBuilder(entityManager, form);
            result = criteriaBuilder.buildQuery().getQuery().getSingleResult();

            if (result != null) {
                Hibernate.initialize(result.getErTrialSet());
                Hibernate.initialize(result.getErContaminantSet());
                Hibernate.initialize(result.getErTxtSet());
                Hibernate.initialize(result.getErPictureList());

                QueryWrapper<Er> subQueryWrapper = new ErSubQueryCriteriaBuilder(entityManager, form).buildQuery();
                HashMap<Long, String> walterProductNames = getErWalterProductNames(languageAbbreviation, subQueryWrapper);
                HashMap<Long, String> cbProductNames = getErCbProductNames(subQueryWrapper, langId);

                for (ErTxt txt : result.getErTxtSet()) {
                    if (langId.equals(txt.getErTxtPK().getLangId())) {
                        result.setTitle(txt.getPartCleanDesc());
                        result.setCustomer(txt.getCustomerName());
                        result.setContactName(txt.getContactName());
                        break;
                    } else if (txt.getErTxtPK().getLangId() == ULang.ENGLISH_ID) {
                        result.setTitle(txt.getPartCleanDesc());
                        result.setCustomer(txt.getCustomerName());
                        result.setContactName(txt.getContactName());
                    }
                }

                for (ErTrial trial : result.getErTrialSet()) {
                    for (ErTrialProduct erTrialProduct : trial.getCleaners()) {
                        String walterProductName = walterProductNames.get(erTrialProduct.getTrialProductId());
                        String cbProductName = cbProductNames.get(erTrialProduct.getTrialProductId());
                        erTrialProduct.setTradeName((walterProductName != null ? walterProductName : "") + ((walterProductName != null && cbProductName != null ? ", " : "")) + (cbProductName != null ? cbProductName : ""));
                    }
                }
            } else {
                throw new Exception("you are not allowed to view this Lab. Report!");
            }
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    @Interceptors({DebugInterceptor.class})
    public ErCounter setCounter(Long id, String userName) throws Exception {
        ErCounter result;
        ErCounterPK ideaCounterPK = new ErCounterPK(id, userName.toUpperCase());
        try {
            result = entityManager.find(ErCounter.class, ideaCounterPK);
            if (result == null) {
                result = new ErCounter(ideaCounterPK);
                result.setFirstRead(new Date());
                result.setCounter(0L);
            }
            result.setLastRead(new Date());
            result.setCounter(result.getCounter() + 1);
            result = entityManager.merge(result);
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Override
    @Interceptors({DebugInterceptor.class})
    public List<Franchise> getWalterFranchises(String languageAbbreviation) throws Exception {
        List<Franchise> result = new ArrayList<Franchise>();
        try {
            HashMap<String, String> translations = solutionReportBean.getWalterFranchisesTranslation(languageAbbreviation);
            TypedQuery<Object[]> query = entityManager.createQuery(singletonBean.getLabReportQuery("lab.report.walter.franchises"), Object[].class);
            List<Object[]> rows = query.getResultList();
            for (Object[] row : rows) {
                String franchiseId = String.valueOf(row[0]);
                String description = String.valueOf(row[1]);
                description = translations.containsKey(description) ? translations.get(description) : description;
                result.add(new Franchise(franchiseId, description));
            }
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }

        Collections.sort(result, new Comparator<Franchise>() {
            @Override
            public int compare(Franchise f1, Franchise f2) {
                return f1.getDescription().compareTo(f2.getDescription());
            }
        });
        return result;
    }

    @Override
    @Interceptors({DebugInterceptor.class})
    public void cancel(Er report) throws Exception {
        report.setCancelDate(new Date());
        try {
            walterBean.save(report);
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
    }

    @Override
    @Interceptors({DebugInterceptor.class})
    public List<String> getCustomers(String organization, Long langId) {
        List<String> result;
        try {
            TypedQuery<String> query = entityManager.createQuery(singletonBean.getLabReportQuery("lab.report.walter.customers"), String.class)
                .setParameter("organization", organization)
                .setParameter("langId", langId);
            result = query.getResultList();
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            result = new ArrayList<String>();
        }
        return result;
    }

    @Interceptors({DebugInterceptor.class})
    private HashMap<Long, String> getErWalterProductNames(String languageAbbreviation, QueryWrapper<Er> queryWrapper) throws Exception {
        HashMap<Long, String> result = new HashMap<Long, String>();
        try {
            String tmp = singletonBean.getLabReportQuery("lab.report.walter.productnames");
            StringBuilder sql = new StringBuilder(tmp)
                    .append("AND erTrialProduct.erTrial.er in (").append(queryWrapper.getQueryString()).append(")");

            TypedQuery<Object[]> query = entityManager.createQuery(sql.toString(), Object[].class);
            for (Map.Entry<String, Object> entry : queryWrapper.getProperties().entrySet()) {
                query.setParameter(entry.getKey(), entry.getValue());
            }

            HashMap<String, String> translations = solutionReportBean.getWalterTradenamesTranslation(languageAbbreviation);

            List<Object[]> rows = query.getResultList();
            for (Object[] row : rows) {
                Long erTrialProductId = (Long) row[0];
                String name = String.valueOf(row[1]);
                name = translations.containsKey(name) ? translations.get(name) : name;

                if (result.containsKey(erTrialProductId)) {
                    result.put(erTrialProductId, result.get(erTrialProductId) + ", " + name);
                } else {
                    result.put(erTrialProductId, name);
                }
            }
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }

    @Interceptors({DebugInterceptor.class})
    private HashMap<Long, String> getErCbProductNames(QueryWrapper<Er> queryWrapper, Long langId) throws Exception {
        HashMap<Long, String> result = new HashMap<Long, String>();
        try {
            StringBuilder sql = new StringBuilder(singletonBean.getLabReportQuery("lab.report.biocircle.productnames"))
                    .append("AND erTrialProduct.erTrial.er in (").append(queryWrapper.getQueryString()).append(")");
            
            TypedQuery<Object[]> query = entityManager.createQuery(sql.toString(), Object[].class);
            for (Map.Entry<String, Object> entry : queryWrapper.getProperties().entrySet()) {
                query.setParameter(entry.getKey(), entry.getValue());
            }

            query.setParameter("langId", langId);
            
            List<Object[]> rows = query.getResultList();
            for (Object[] row : rows) {
                Long erTrialProductId = (Long) row[0];
                String name = String.valueOf(row[1]);

                if (result.containsKey(erTrialProductId)) {
                    result.put(erTrialProductId, result.get(erTrialProductId) + ", " + name);
                } else {
                    result.put(erTrialProductId, name);
                }
            }
        } catch (Exception e) {
            LOG.severe(e.getMessage());
            throw new Exception(e.getMessage());
        }
        return result;
    }
}