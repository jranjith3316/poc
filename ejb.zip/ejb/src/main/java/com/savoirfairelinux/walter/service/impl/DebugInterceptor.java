/*
 * Copyright 2012 Savoir-faire Linux
 *
 * This file is part of Walter-Portal.
 *
 * Walter-Portal is free software: you can redistribute it and/or modify it under the terms of the
 * GNU General Public License as published by the Free Software Foundation, either version 3
 * of the License, or (at your option) any later version.
 *
 * Walter-Portal is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with Walter-Portal.
 * If not, see http://www.gnu.org/licenses/.
 */
package com.savoirfairelinux.walter.service.impl;

import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

/**
 *
 * @author jbonjean
 *
 */
public class DebugInterceptor {

    public static final Logger LOG = Logger.getLogger(DebugInterceptor.class.getCanonicalName());

    @EJB
    SingletonBean singletonBean;

    public DebugInterceptor() throws IOException {
        FileHandler fileHandler = new FileHandler("walter-speed.log");
        LOG.addHandler(fileHandler);
    }

    @AroundInvoke
    public Object log(InvocationContext invocationContext) throws Exception {
        Level level = Level.INFO;
        long start = System.currentTimeMillis();
        Object object = invocationContext.proceed();
        long duration = System.currentTimeMillis() - start;

        String info = "";
        if (duration > 1000) level = Level.WARNING;

        if (duration > 100)
          LOG.log(level, info + "Method " + invocationContext.getMethod() + " execute in : " + duration + "ms \n");

        return object;
    }
}
