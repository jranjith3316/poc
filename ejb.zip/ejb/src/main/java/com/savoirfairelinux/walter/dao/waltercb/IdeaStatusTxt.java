/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "IDEA_STATUS_TXT", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "IdeaStatusTxt.findAll", query = "SELECT i FROM IdeaStatusTxt i"),
    @NamedQuery(name = "IdeaStatusTxt.findByStatusId", query = "SELECT i FROM IdeaStatusTxt i WHERE i.ideaStatusTxtPK.statusId = :statusId"),
    @NamedQuery(name = "IdeaStatusTxt.findByLangId", query = "SELECT i FROM IdeaStatusTxt i WHERE i.ideaStatusTxtPK.langId = :langId"),
    @NamedQuery(name = "IdeaStatusTxt.findByDescription", query = "SELECT i FROM IdeaStatusTxt i WHERE i.description = :description")})
public class IdeaStatusTxt implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected IdeaStatusTxtPK ideaStatusTxtPK;
    @Size(max = 50)
    private String description;
    @JoinColumn(name = "STATUS_ID", referencedColumnName = "STATUS_ID", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private IdeaStatus ideaStatus;

    public IdeaStatusTxt() {
    }

    public IdeaStatusTxt(IdeaStatusTxtPK ideaStatusTxtPK) {
        this.ideaStatusTxtPK = ideaStatusTxtPK;
    }

    public IdeaStatusTxt(Integer statusId, long langId) {
        this.ideaStatusTxtPK = new IdeaStatusTxtPK(statusId, langId);
    }

    public IdeaStatusTxtPK getIdeaStatusTxtPK() {
        return ideaStatusTxtPK;
    }

    public void setIdeaStatusTxtPK(IdeaStatusTxtPK ideaStatusTxtPK) {
        this.ideaStatusTxtPK = ideaStatusTxtPK;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public IdeaStatus getIdeaStatus() {
        return ideaStatus;
    }

    public void setIdeaStatus(IdeaStatus ideaStatus) {
        this.ideaStatus = ideaStatus;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (ideaStatusTxtPK != null ? ideaStatusTxtPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof IdeaStatusTxt)) {
            return false;
        }
        IdeaStatusTxt other = (IdeaStatusTxt) object;
        if ((this.ideaStatusTxtPK == null && other.ideaStatusTxtPK != null) || (this.ideaStatusTxtPK != null && !this.ideaStatusTxtPK.equals(other.ideaStatusTxtPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.IdeaStatusTxt[ ideaStatusTxtPK=" + ideaStatusTxtPK + " ]";
    }
    
}
