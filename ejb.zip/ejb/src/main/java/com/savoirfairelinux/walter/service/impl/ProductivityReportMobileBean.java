package com.savoirfairelinux.walter.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.security.PermitAll;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import com.savoirfairelinux.walter.dao.idb.OoInstances;
import com.savoirfairelinux.walter.dao.waltercb.Country;
import com.savoirfairelinux.walter.model.PowerTool;
import com.savoirfairelinux.walter.model.PrWalterProduct;
import com.savoirfairelinux.walter.model.ProductivityCountry;
import com.savoirfairelinux.walter.service.ProductivityReportMobileBeanRemote;

@Stateless(name = "ProductivityReportMobile")
@TransactionManagement(TransactionManagementType.CONTAINER)
@PermitAll
@LocalBean
public class ProductivityReportMobileBean implements ProductivityReportMobileBeanRemote{

	@PersistenceContext(unitName = "waltershare")
	EntityManager entityManager;
	
	@EJB
    SingletonBean singletonBean;

	@Override
	public List<PowerTool> getAllPowerTool(String webSiteCountryName) {
		List<OoInstances> instances = entityManager.createQuery("select trade"
				+ " from OoInstances trade,"
				+ " WalterProductsCountries wpc,"
				+ " OoInstances oo"
				+ " where wpc.productguid.productstatus = 'Active'"
				+ " and wpc.productguid = oo.instanceguid"
				+ " and oo.instancestatus = 'Active'"
				+ " and wpc.productguid.producttype = 'Product'"
				+ " and oo.classguid.classname = 'PowerTool'"
				+ " and wpc.topublish = 'Y'"
				+ " and wpc.countryguid.instancealternatekey = :country"
				+ " and wpc.productguid.deletedatetime is NULL"
				+ " and wpc.deletedatetime is NULL"
				+ " and trade.instanceguid = wpc.tradenameguid"
				, OoInstances.class).setParameter("country", webSiteCountryName)
				.getResultList();
		List<PowerTool> tools = new ArrayList<>(instances.size());
		for(OoInstances inst : instances) {
			tools.add(new PowerTool(inst.getInstanceguid(), inst.getInstancename()));
		}
		return tools;
	}

	/**
	 * This method was added like loadWalterProduct from ProductivityReportBean for mobile app.
	 * But the mobile app uses this method to load all product once (call this method for all products).
	 * So we leave here only the information that required for the mobile app to optimize it a bit.
	 */
	@Override
	public PrWalterProduct loadWalterProductPartially(PrWalterProduct product, String languageAbbreviation) {
		TypedQuery<String> query = entityManager.createQuery(singletonBean.getProductivityReportQuery("productivity.report.product.information"), String.class)
				.setParameter("productVersionGUID", product.getProductVersionGUID())
				.setParameter("franchiseClassesGuid", product.getProductLineClaassesguid());

		try {
			String diameter = query.setParameter("information", "Diameter").getSingleResult();
			product.setDiameter(diameter);
		} catch(NoResultException e) {
		}
		query = entityManager.createQuery(singletonBean.getProductivityReportQuery("productivity.report.product.otherInformation"), String.class);
		try {
			String grit = query.setParameter("information", "Grit")
					.setParameter("productVersionGUID", product.getProductVersionGUID())
					.setParameter("franchiseClassesGuid", product.getProductLineClaassesguid())
					.getSingleResult();

			String translation = getTranslation(grit, languageAbbreviation);
			if ( translation != null && !translation.equals("") ){
				grit = translation;
			}

			product.setGrit(grit);
		} catch(NoResultException e) {
		}
		return product;
	}


	public String getTranslation(String instanceguid, String languageAbbreviation) {
		String returnValue = "";
		try {
			returnValue = entityManager.createQuery(singletonBean.getProductivityReportQuery("productivity.report.getTranslation"), String.class)
					.setParameter("languageAbbreviation", languageAbbreviation)
					.setParameter("instanceguid", instanceguid)
					.getSingleResult();
		} catch(NoResultException e) {
		}
		return returnValue;
	}
	
	public List<ProductivityCountry> getAllCountries() {
		List<Country> res = entityManager.createNamedQuery("Country.findAll").getResultList();
		List<ProductivityCountry> out = new ArrayList<>(res.size());
		for(Country c : res) {
			out.add(new ProductivityCountry(c.getCountryId(), c.getDescription(), c.getCountryCode()));
		}
		return out;
	}

}




