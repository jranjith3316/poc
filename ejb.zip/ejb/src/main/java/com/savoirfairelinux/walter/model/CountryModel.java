package com.savoirfairelinux.walter.model;

/**
 *
 * @author jsgill
 */
public class CountryModel {
  private Long countryId;
  private String countryCode;
  private String countryName;

  public CountryModel(Long countryId, String countryCode, String countryName) {
    this.countryId = countryId;
    this.countryCode = countryCode;
    this.countryName = countryName;
  }

  public Long getCountryId() {
    return countryId;
  }

  public void setCountryId(Long countryId) {
    this.countryId = countryId;
  }

  public String getCountryCode() {
    return countryCode;
  }

  public void setCountryCode(String countryCode) {
    this.countryCode = countryCode;
  }

  public String getCountryName() {
    return countryName;
  }

  public void setCountryName(String countryName) {
    this.countryName = countryName;
  }


}
