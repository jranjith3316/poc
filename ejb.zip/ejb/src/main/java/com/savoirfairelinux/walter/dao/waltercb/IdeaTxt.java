/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import javax.persistence.*;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "IDEA_TXT", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "IdeaTxt.findAll", query = "SELECT i FROM IdeaTxt i"),
    @NamedQuery(name = "IdeaTxt.findByIdeaId", query = "SELECT i FROM IdeaTxt i WHERE i.ideaTxtPK.ideaId = :ideaId"),
    @NamedQuery(name = "IdeaTxt.findByLangId", query = "SELECT i FROM IdeaTxt i WHERE i.ideaTxtPK.langId = :langId"),
    @NamedQuery(name = "IdeaTxt.findByTitle", query = "SELECT i FROM IdeaTxt i WHERE i.title = :title"),
    @NamedQuery(name = "IdeaTxt.findByExplanation", query = "SELECT i FROM IdeaTxt i WHERE i.explanation = :explanation"),
    @NamedQuery(name = "IdeaTxt.findByConsideredComment", query = "SELECT i FROM IdeaTxt i WHERE i.consideredComment = :consideredComment"),
    @NamedQuery(name = "IdeaTxt.findByDevelopmentComment", query = "SELECT i FROM IdeaTxt i WHERE i.developmentComment = :developmentComment"),
    @NamedQuery(name = "IdeaTxt.findByLaunchedComment", query = "SELECT i FROM IdeaTxt i WHERE i.launchedComment = :launchedComment")})
public class IdeaTxt implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected IdeaTxtPK ideaTxtPK;
    @Size(max = 80)
    private String title;
    @Size(max = 1000)
    private String explanation;
    @Size(max = 500)
    @Column(name = "CONSIDERED_COMMENT")
    private String consideredComment;
    @Size(max = 500)
    @Column(name = "DEVELOPMENT_COMMENT")
    private String developmentComment;
    @Size(max = 500)
    @Column(name = "LAUNCHED_COMMENT")
    private String launchedComment;
    @JoinColumn(name = "IDEA_ID", referencedColumnName = "IDEA_ID", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Idea idea;

    public IdeaTxt() {
    }

    public IdeaTxt(IdeaTxt englishTxt, long langId) {
        this.ideaTxtPK = new IdeaTxtPK(englishTxt.getIdeaTxtPK().getIdeaId(), langId);
        this.idea = englishTxt.getIdea();
        this.title = englishTxt.getTitle();
        this.explanation = englishTxt.getExplanation();
        this.consideredComment = englishTxt.getConsideredComment();
        this.developmentComment = englishTxt.getDevelopmentComment();
        this.launchedComment = englishTxt.getLaunchedComment();
    }

    public IdeaTxt(IdeaTxtPK ideaTxtPK) {
        this.ideaTxtPK = ideaTxtPK;
    }

    public IdeaTxt(long ideaId, long langId) {
        this.ideaTxtPK = new IdeaTxtPK(ideaId, langId);
    }

    public IdeaTxtPK getIdeaTxtPK() {
        return ideaTxtPK;
    }

    public void setIdeaTxtPK(IdeaTxtPK ideaTxtPK) {
        this.ideaTxtPK = ideaTxtPK;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getExplanation() {
        return explanation;
    }

    public void setExplanation(String explanation) {
        this.explanation = explanation;
    }

    public String getConsideredComment() {
        return consideredComment;
    }

    public void setConsideredComment(String consideredComment) {
        this.consideredComment = consideredComment;
    }

    public String getDevelopmentComment() {
        return developmentComment;
    }

    public void setDevelopmentComment(String developmentComment) {
        this.developmentComment = developmentComment;
    }

    public String getLaunchedComment() {
        return launchedComment;
    }

    public void setLaunchedComment(String launchedComment) {
        this.launchedComment = launchedComment;
    }

    public Idea getIdea() {
        return idea;
    }

    public void setIdea(Idea idea) {
        this.idea = idea;
    }

    @PrePersist
    private void prePersist() {
        if (idea != null && ideaTxtPK != null) {
            ideaTxtPK.setIdeaId(idea.getIdeaId());
        }
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (ideaTxtPK != null ? ideaTxtPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof IdeaTxt)) {
            return false;
        }
        IdeaTxt other = (IdeaTxt) object;
        if ((this.ideaTxtPK == null && other.ideaTxtPK != null) || (this.ideaTxtPK != null && !this.ideaTxtPK.equals(other.ideaTxtPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.IdeaTxt[ ideaTxtPK=" + ideaTxtPK + " ]";
    }
    
}
