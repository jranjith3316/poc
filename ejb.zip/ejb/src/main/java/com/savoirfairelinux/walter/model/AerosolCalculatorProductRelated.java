/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.model;

import java.io.Serializable;

/**
 *
 * @author jsgill
 */
public class AerosolCalculatorProductRelated implements Serializable {

  AerosolCalculatorProduct product57F005;
  AerosolCalculatorProduct product57F008;
  AerosolCalculatorProduct product57F055;
  AerosolCalculatorProduct product57F058;
  AerosolCalculatorProduct product57G105;
  AerosolCalculatorProduct product57G108;
  AerosolCalculatorProduct product53X007;
  AerosolCalculatorProduct product53X008;
  AerosolCalculatorProduct product53C557;
  AerosolCalculatorProduct product53C558;

  public AerosolCalculatorProductRelated() {
    product57F005 = new AerosolCalculatorProduct("57F005", "57D110K", 40.00F, 10.40F, "57b110", 2, 300F, 10F);
    product57F008 = new AerosolCalculatorProduct("57F008", "57D210K", 208.00F, 55.00F, "57b110", 6, 300.00F, 10.00F);
    product57F055 = new AerosolCalculatorProduct("57F055", "57D120K", 40.00F, 10.40F, "57B115", 2, 300.00F, 10.00F);
    product57F058 = new AerosolCalculatorProduct("57F058", "57D220K", 208.00F, 55.00F, "57B115", 6,300.00F, 10.00F);
    product57G105 = new AerosolCalculatorProduct("57G105", "57D100AFCBB", 40.00F, 10.40F, "57B100", 2, 300.00F, 10.00F);
    product57G108 = new AerosolCalculatorProduct("57G108", "57D100AFCD", 208.00F, 55.00F, "57B100", 6, 300.00F, 10.00F);
    product53X007 = new AerosolCalculatorProduct("53X007", "53M012AFOBB", 20.00F, 5.20F, "53M132", 6, 400.00F, 13.50F);
    product53X008 = new AerosolCalculatorProduct("53X008", "53M012AFOD", 208.00F, 55.00F, "53M132", 6, 400.00F, 13.50F);
    product53C557 = new AerosolCalculatorProduct("53C557", "53M012AFPLP", 20.00F, 5.20F, "53M101", 6, 400.00F, 13.50F);
    product53C558 = new AerosolCalculatorProduct("53C558", "53M012AFPLD", 200.00F, 52.80F, "53M101", 6, 400.00F, 13.50F);

  }

  public AerosolCalculatorProduct getProduct57F005() {
    return product57F005;
  }

  public void setProduct57F005(AerosolCalculatorProduct product57F005) {
    this.product57F005 = product57F005;
  }

  public AerosolCalculatorProduct getProduct57F008() {
    return product57F008;
  }

  public void setProduct57F008(AerosolCalculatorProduct product57F008) {
    this.product57F008 = product57F008;
  }

  public AerosolCalculatorProduct getProduct57F055() {
    return product57F055;
  }

  public void setProduct57F055(AerosolCalculatorProduct product57F055) {
    this.product57F055 = product57F055;
  }

  public AerosolCalculatorProduct getProduct57F058() {
    return product57F058;
  }

  public void setProduct57F058(AerosolCalculatorProduct product57F058) {
    this.product57F058 = product57F058;
  }

  public AerosolCalculatorProduct getProduct57G105() {
    return product57G105;
  }

  public void setProduct57G105(AerosolCalculatorProduct product57G105) {
    this.product57G105 = product57G105;
  }

  public AerosolCalculatorProduct getProduct57G108() {
    return product57G108;
  }

  public void setProduct57G108(AerosolCalculatorProduct product57G108) {
    this.product57G108 = product57G108;
  }

  public AerosolCalculatorProduct getProduct53X007() {
    return product53X007;
  }

  public void setProduct53X007(AerosolCalculatorProduct product53X007) {
    this.product53X007 = product53X007;
  }

  public AerosolCalculatorProduct getProduct53X008() {
    return product53X008;
  }

  public void setProduct53X008(AerosolCalculatorProduct product53X008) {
    this.product53X008 = product53X008;
  }

  public AerosolCalculatorProduct getProduct53C557() {
    return product53C557;
  }

  public void setProduct53C557(AerosolCalculatorProduct product53C557) {
    this.product53C557 = product53C557;
  }

  public AerosolCalculatorProduct getProduct53C558() {
    return product53C558;
  }

  public void setProduct53C558(AerosolCalculatorProduct product53C558) {
    this.product53C558 = product53C558;
  }

}
