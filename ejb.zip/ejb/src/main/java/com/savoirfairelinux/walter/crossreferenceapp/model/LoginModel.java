/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.crossreferenceapp.model;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@XmlRootElement(name = "login")
public class LoginModel implements Serializable{
  private static final long serialVersionUID = 3511338233023397895L;
  private String error;
  private String countryCode;
  private long userId;
  private String printPdfLink;

  public String getError() {
    return error;
  }

  public void setError(String error) {
    this.error = error;
  }

  public String getCountryCode() {
    return countryCode;
  }

  public void setCountryCode(String countryCode) {
    this.countryCode = countryCode;
  }

  public long getUserId() {
    return userId;
  }

  public void setUserId(long userId) {
    this.userId = userId;
  }

  public String getPrintPdfLink() {
    return printPdfLink;
  }

  public void setPrintPdfLink(String printPdfLink) {
    this.printPdfLink = printPdfLink;
  }

}
