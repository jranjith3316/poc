/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import javax.persistence.*;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "IDEA_FEEDBACK_FILE_TXT", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "IdeaFeedbackFileTxt.findAll", query = "SELECT i FROM IdeaFeedbackFileTxt i"),
    @NamedQuery(name = "IdeaFeedbackFileTxt.findByFileId", query = "SELECT i FROM IdeaFeedbackFileTxt i WHERE i.ideaFeedbackFileTxtPK.fileId = :fileId"),
    @NamedQuery(name = "IdeaFeedbackFileTxt.findByLangId", query = "SELECT i FROM IdeaFeedbackFileTxt i WHERE i.ideaFeedbackFileTxtPK.langId = :langId"),
    @NamedQuery(name = "IdeaFeedbackFileTxt.findByFileTxt", query = "SELECT i FROM IdeaFeedbackFileTxt i WHERE i.fileTxt = :fileTxt")})
public class IdeaFeedbackFileTxt implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected IdeaFeedbackFileTxtPK ideaFeedbackFileTxtPK;
    @Size(max = 100)
    @Column(name = "FILE_TXT")
    private String fileTxt;
    @JoinColumn(name = "FILE_ID", referencedColumnName = "FILE_ID", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private IdeaFeedbackFile ideaFeedbackFile;

    public IdeaFeedbackFileTxt() {
    }

    public IdeaFeedbackFileTxt(IdeaFeedbackFileTxtPK ideaFeedbackFileTxtPK) {
        this.ideaFeedbackFileTxtPK = ideaFeedbackFileTxtPK;
    }

    public IdeaFeedbackFileTxt(long fileId, long langId) {
        this.ideaFeedbackFileTxtPK = new IdeaFeedbackFileTxtPK(fileId, langId);
    }

    public IdeaFeedbackFileTxtPK getIdeaFeedbackFileTxtPK() {
        return ideaFeedbackFileTxtPK;
    }

    public void setIdeaFeedbackFileTxtPK(IdeaFeedbackFileTxtPK ideaFeedbackFileTxtPK) {
        this.ideaFeedbackFileTxtPK = ideaFeedbackFileTxtPK;
    }

    public String getFileTxt() {
        return fileTxt;
    }

    public void setFileTxt(String fileTxt) {
        this.fileTxt = fileTxt;
    }

    public IdeaFeedbackFile getIdeaFeedbackFile() {
        return ideaFeedbackFile;
    }

    public void setIdeaFeedbackFile(IdeaFeedbackFile ideaFeedbackFile) {
        this.ideaFeedbackFile = ideaFeedbackFile;
    }

    @PrePersist
    private void prePersist() {
        if (ideaFeedbackFile != null && ideaFeedbackFileTxtPK != null) {
            ideaFeedbackFileTxtPK.setFileId(ideaFeedbackFile.getFileId());
        }
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (ideaFeedbackFileTxtPK != null ? ideaFeedbackFileTxtPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof IdeaFeedbackFileTxt)) {
            return false;
        }
        IdeaFeedbackFileTxt other = (IdeaFeedbackFileTxt) object;
        if ((this.ideaFeedbackFileTxtPK == null && other.ideaFeedbackFileTxtPK != null) || (this.ideaFeedbackFileTxtPK != null && !this.ideaFeedbackFileTxtPK.equals(other.ideaFeedbackFileTxtPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.IdeaFeedbackFileTxt[ ideaFeedbackFileTxtPK=" + ideaFeedbackFileTxtPK + " ]";
    }
    
}
