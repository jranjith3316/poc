/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import java.math.BigInteger;
import java.util.Set;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "IDEA_FEEDBACK_FILE", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "IdeaFeedbackFile.findAll", query = "SELECT i FROM IdeaFeedbackFile i"),
    @NamedQuery(name = "IdeaFeedbackFile.findByFeedbackId", query = "SELECT i FROM IdeaFeedbackFile i WHERE i.ideaFeedback.feedbackId = :feedbackId"),
    @NamedQuery(name = "IdeaFeedbackFile.findByFileId", query = "SELECT i FROM IdeaFeedbackFile i WHERE i.fileId = :fileId"),
    @NamedQuery(name = "IdeaFeedbackFile.findByExtVisible", query = "SELECT i FROM IdeaFeedbackFile i WHERE i.extVisible = :extVisible"),
    @NamedQuery(name = "IdeaFeedbackFile.findByOriginalFile", query = "SELECT i FROM IdeaFeedbackFile i WHERE i.originalFile = :originalFile"),
    @NamedQuery(name = "IdeaFeedbackFile.findByFiletype", query = "SELECT i FROM IdeaFeedbackFile i WHERE i.filetype = :filetype")})
public class IdeaFeedbackFile implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "FILE_ID")
    @GeneratedValue(generator = "IDEA_FEEDBACK_FILE_ID_SEQ", strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "IDEA_FEEDBACK_FILE_ID_SEQ", sequenceName = "IDEA_FEEDBACK_FILE_ID_SEQ", schema = DatabaseConstants.WALTERCB_SCHEMA, allocationSize = 1)
    private Long fileId;
    @Column(name = "EXT_VISIBLE")
    private Character extVisible;
    @Column(name = "ORIGINAL_FILE")
    private Character originalFile;
    @Size(max = 256)
    @Deprecated
    private String filetype;
    @Size(max = 350)
    @Column(name = "REAL_FILENAME")
    private String realFilename;
    @Size(max = 48)
    @Column(name = "MIME_TYPE")
    private String mimeType;
    @Column(name = "DOC_SIZE")
    private BigInteger docSize;
    @Lob
    @Column(name = "BLOB_CONTENT")
    private byte[] blobContent;
    @Size(max = 1)
    @Column(name = "TYPE")
    private String type;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "ideaFeedbackFile")
    private Set<IdeaFeedbackFileTxt> ideaFeedbackFileTxtSet;
    @JoinColumn(name = "FEEDBACK_ID", referencedColumnName = "FEEDBACK_ID", nullable = false)
    @ManyToOne(optional = false)
    private IdeaFeedback ideaFeedback;

    public IdeaFeedbackFile() {
    }

    public IdeaFeedbackFile(Long fileId) {
        this.fileId = fileId;
    }

    public Long getFileId() {
        return fileId;
    }

    public void setFileId(Long fileId) {
        this.fileId = fileId;
    }

    public Character getExtVisible() {
        return extVisible;
    }

    public void setExtVisible(Character extVisible) {
        this.extVisible = extVisible;
    }

    public Character getOriginalFile() {
        return originalFile;
    }

    public void setOriginalFile(Character originalFile) {
        this.originalFile = originalFile;
    }

    public String getFiletype() {
        return filetype;
    }

    public void setFiletype(String filetype) {
        this.filetype = filetype;
    }

    public String getRealFilename() {
        return realFilename;
    }

    public void setRealFilename(String realFilename) {
        this.realFilename = realFilename;
    }

    public String getMimeType() {
        return mimeType;
    }

    public void setMimeType(String mimeType) {
        this.mimeType = mimeType;
    }

    public BigInteger getDocSize() {
        return docSize;
    }

    public void setDocSize(BigInteger docSize) {
        this.docSize = docSize;
    }

    public byte[] getBlobContent() {
        return blobContent;
    }

    public void setBlobContent(byte[] blobContent) {
        this.blobContent = blobContent;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @XmlTransient
    public Set<IdeaFeedbackFileTxt> getIdeaFeedbackFileTxtSet() {
        return ideaFeedbackFileTxtSet;
    }

    public void setIdeaFeedbackFileTxtSet(Set<IdeaFeedbackFileTxt> ideaFeedbackFileTxtSet) {
        this.ideaFeedbackFileTxtSet = ideaFeedbackFileTxtSet;
    }

    public IdeaFeedback getIdeaFeedback() {
        return ideaFeedback;
    }

    public void setIdeaFeedback(IdeaFeedback ideaFeedback) {
        this.ideaFeedback = ideaFeedback;
    }

    @Override
    public int hashCode() {
        int hash = fileId != null ? fileId.hashCode() : 0;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof IdeaFeedbackFile)) {
            return false;
        }
        IdeaFeedbackFile other = (IdeaFeedbackFile) object;
        if ((this.fileId == null && other.fileId != null) || (this.fileId != null && !this.fileId.equals(other.fileId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.IdeaFeedbackFile[ fileId=" + fileId + " ]";
    }
    
}
