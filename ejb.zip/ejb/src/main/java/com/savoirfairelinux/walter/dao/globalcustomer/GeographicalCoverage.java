package com.savoirfairelinux.walter.dao.globalcustomer;

import com.savoirfairelinux.walter.dao.DatabaseConstants;
import com.savoirfairelinux.walter.dao.waltercb.Country;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Set;

/**
 * @author jderuere
 */
@Entity
@Table(name = "GEOGRAPHICAL_COVERAGE", schema = DatabaseConstants.WALTERCB_SCHEMA)
public class GeographicalCoverage implements Serializable {
    private static final long serialVersionUID = 1L;

    public static final long NATIONAL = 1;

    @Id
    @GeneratedValue(generator = "GEOGRAPHICAL_COVERAGE_ID_SEQ", strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "GEOGRAPHICAL_COVERAGE_ID_SEQ", sequenceName = "GEOGRAPHICAL_COVERAGE_ID_SEQ", schema = DatabaseConstants.WALTERCB_SCHEMA, allocationSize = 1)
    @Column(name = "GEOGRAPHICAL_COVERAGE_ID")
    private Long geographicalCoverageId;
    
    @Transient
    private String name;

    @OneToMany(mappedBy = "geographicalCoverage")
    private Set<Country> countries;

    public GeographicalCoverage() {
    }

    public Set<Country> getCountries() {
        return countries;
    }

    public void setCountries(Set<Country> countries) {
        this.countries = countries;
    }

    public Long getGeographicalCoverageId() {
        return geographicalCoverageId;
    }

    public void setGeographicalCoverageId(Long geographicalCoverageId) {
        this.geographicalCoverageId = geographicalCoverageId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (geographicalCoverageId!= null ? geographicalCoverageId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof GeographicalCoverage)) {
            return false;
        }
        GeographicalCoverage other = (GeographicalCoverage) object;
        if ((this.geographicalCoverageId == null && other.getGeographicalCoverageId() != null) || (this.geographicalCoverageId != null && !this.geographicalCoverageId.equals(other.geographicalCoverageId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.globalcustomer.GeographicalCoverage[ geographicalCoverageId=" + geographicalCoverageId + " ]";
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
