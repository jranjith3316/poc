package com.savoirfairelinux.walter.util.criteriabuilder;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.logging.Logger;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

public abstract class AbstractCriteriaBuilder<T> {

    public static final Logger LOG = Logger.getLogger(AbstractCriteriaBuilder.class.getCanonicalName());
    protected EntityManager entityManager;
    protected Class<T> aclClass;

	public AbstractCriteriaBuilder(EntityManager entityManager, Class<T> aclClass) {
		this.entityManager = entityManager;
		this.aclClass = aclClass;
	}

	public QueryWrapper<T> buildQuery() {
	    StringBuilder queryBuilder = new StringBuilder();
	    Map<String, Object> properties = new HashMap<String, Object>();

		initQuery(queryBuilder, properties);
		initJoinQuery(queryBuilder, properties);
		buildSpecificQuery(queryBuilder, properties);
		initOrderByQuery(queryBuilder, properties);

		TypedQuery<T> query = entityManager.createQuery(queryBuilder.toString(), aclClass);
		for (Entry<String, Object> property : properties.entrySet())
			query.setParameter(property.getKey(), property.getValue());

		return new QueryWrapper<T>(query, queryBuilder.toString(), properties);
	}

	protected void addLikeCriteria(StringBuilder query, String property, String value) {
		if (value != null && !value.isEmpty()) {
			query.append(" AND upper(").append(property).append(") LIKE '%").append(value.toUpperCase()).append("%' ");
		}
	}

	protected abstract void initQuery(StringBuilder queryBuilder, Map<String, Object> properties);

	protected abstract void initJoinQuery(StringBuilder queryBuilder, Map<String, Object> properties);

	protected abstract void buildSpecificQuery(StringBuilder queryBuilder, Map<String, Object> properties);

	protected abstract void initOrderByQuery(StringBuilder queryBuilder, Map<String, Object> properties);
}
