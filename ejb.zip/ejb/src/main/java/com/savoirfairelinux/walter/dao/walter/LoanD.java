/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.walter;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "LOAN_D", catalog = "", schema = DatabaseConstants.WALTER_SCHEMA)
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "LoanD.findAll", query = "SELECT l FROM LoanD l"),
  @NamedQuery(name = "LoanD.findByLoanId", query = "SELECT l FROM LoanD l WHERE l.loanDPK.loanId = :loanId"),
  @NamedQuery(name = "LoanD.findByExpenseRptId", query = "SELECT l FROM LoanD l WHERE l.loanDPK.expenseRptId = :expenseRptId"),
  @NamedQuery(name = "LoanD.findByAmountApplied", query = "SELECT l FROM LoanD l WHERE l.amountApplied = :amountApplied"),
  @NamedQuery(name = "LoanD.findByCreationDate", query = "SELECT l FROM LoanD l WHERE l.creationDate = :creationDate"),
  @NamedQuery(name = "LoanD.findByCreatedByUserName", query = "SELECT l FROM LoanD l WHERE l.createdByUserName = :createdByUserName"),
  @NamedQuery(name = "LoanD.findByGlCode", query = "SELECT l FROM LoanD l WHERE l.glCode = :glCode")})
public class LoanD implements Serializable {
  private static final long serialVersionUID = 1L;
  @EmbeddedId
  protected LoanDPK loanDPK;
  // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
  @Column(name = "AMOUNT_APPLIED")
  private BigDecimal amountApplied;
  @Column(name = "CREATION_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date creationDate;
  @Size(max = 256)
  @Column(name = "CREATED_BY_USER_NAME")
  private String createdByUserName;
  @Size(max = 10)
  @Column(name = "GL_CODE")
  private String glCode;
  @JoinColumn(name = "LOAN_ID", referencedColumnName = "LOAN_ID", insertable = false, updatable = false)
  @ManyToOne(optional = false)
  private Loan loan;

  public LoanD() {
  }

  public LoanD(LoanDPK loanDPK) {
    this.loanDPK = loanDPK;
  }

  public LoanD(long loanId, long expenseRptId) {
    this.loanDPK = new LoanDPK(loanId, expenseRptId);
  }

  public LoanDPK getLoanDPK() {
    return loanDPK;
  }

  public void setLoanDPK(LoanDPK loanDPK) {
    this.loanDPK = loanDPK;
  }

  public BigDecimal getAmountApplied() {
    return amountApplied;
  }

  public void setAmountApplied(BigDecimal amountApplied) {
    this.amountApplied = amountApplied;
  }

  public Date getCreationDate() {
    return creationDate;
  }

  public void setCreationDate(Date creationDate) {
    this.creationDate = creationDate;
  }

  public String getCreatedByUserName() {
    return createdByUserName;
  }

  public void setCreatedByUserName(String createdByUserName) {
    this.createdByUserName = createdByUserName;
  }

  public String getGlCode() {
    return glCode;
  }

  public void setGlCode(String glCode) {
    this.glCode = glCode;
  }

  public Loan getLoan() {
    return loan;
  }

  public void setLoan(Loan loan) {
    this.loan = loan;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (loanDPK != null ? loanDPK.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof LoanD)) {
      return false;
    }
    LoanD other = (LoanD) object;
    if ((this.loanDPK == null && other.loanDPK != null) || (this.loanDPK != null && !this.loanDPK.equals(other.loanDPK))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.walter.LoanD[ loanDPK=" + loanDPK + " ]";
  }
  
}
