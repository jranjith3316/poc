package com.savoirfairelinux.walter.model;

public enum NaicsLevel {

	LEVEL_1(2),
	LEVEL_2(3),
	LEVEL_3(6);
	
	private int length;
	
	private NaicsLevel(int length) {
		this.length = length;
	}

	public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}
}
