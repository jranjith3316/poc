/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import javax.persistence.*;
import javax.xml.bind.annotation.XmlRootElement;
import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "ER_CC_RECIPIENT", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "ErCcRecipient.findAll", query = "SELECT e FROM ErCcRecipient e"),
    @NamedQuery(name = "ErCcRecipient.findByErId", query = "SELECT e FROM ErCcRecipient e WHERE e.erCcRecipientPK.erId = :erId"),
    @NamedQuery(name = "ErCcRecipient.findByUserName", query = "SELECT e FROM ErCcRecipient e WHERE e.erCcRecipientPK.userName = :userName")})
public class ErCcRecipient implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected ErCcRecipientPK erCcRecipientPK;
    @JoinColumn(name = "ER_ID", referencedColumnName = "ER_ID", nullable = false, insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Er er;

    public ErCcRecipient() {
    }

    public ErCcRecipient(ErCcRecipientPK erCcRecipientPK) {
        this.erCcRecipientPK = erCcRecipientPK;
    }

    public ErCcRecipient(long erId, String userName) {
        this.erCcRecipientPK = new ErCcRecipientPK(erId, userName);
    }

    public ErCcRecipientPK getErCcRecipientPK() {
        return erCcRecipientPK;
    }

    public void setErCcRecipientPK(ErCcRecipientPK erCcRecipientPK) {
        this.erCcRecipientPK = erCcRecipientPK;
    }

    public Er getEr() {
        return er;
    }

    public void setEr(Er er) {
        this.er = er;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (erCcRecipientPK != null ? erCcRecipientPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ErCcRecipient)) {
            return false;
        }
        ErCcRecipient other = (ErCcRecipient) object;
        if ((this.erCcRecipientPK == null && other.erCcRecipientPK != null) || (this.erCcRecipientPK != null && !this.erCcRecipientPK.equals(other.erCcRecipientPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.ErCcRecipient[ erCcRecipientPK=" + erCcRecipientPK + " ]";
    }
    
}
