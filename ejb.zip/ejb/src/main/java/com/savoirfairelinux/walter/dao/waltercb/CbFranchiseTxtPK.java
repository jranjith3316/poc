/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

/**
 *
 * @author mgubaidullin
 */
@Embeddable
public class CbFranchiseTxtPK implements Serializable {
    @Basic(optional = false)
    @NotNull
    @Column(name = "FRANCHISE_ID")
    private short franchiseId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "LANG_ID")
    private long langId;

    public CbFranchiseTxtPK() {
    }

    public CbFranchiseTxtPK(short franchiseId, long langId) {
        this.franchiseId = franchiseId;
        this.langId = langId;
    }

    public short getFranchiseId() {
        return franchiseId;
    }

    public void setFranchiseId(short franchiseId) {
        this.franchiseId = franchiseId;
    }

    public long getLangId() {
        return langId;
    }

    public void setLangId(long langId) {
        this.langId = langId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) franchiseId;
        hash += (int) langId;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CbFranchiseTxtPK)) {
            return false;
        }
        CbFranchiseTxtPK other = (CbFranchiseTxtPK) object;
        if (this.franchiseId != other.franchiseId) {
            return false;
        }
        if (this.langId != other.langId) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.CbFranchiseTxtPK[ franchiseId=" + franchiseId + ", langId=" + langId + " ]";
    }
    
}
