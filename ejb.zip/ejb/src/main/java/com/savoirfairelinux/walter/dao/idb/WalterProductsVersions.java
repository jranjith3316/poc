/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.idb;

import com.savoirfairelinux.walter.dao.DatabaseConstants;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "WALTER_PRODUCTS_VERSIONS", catalog = "", schema = DatabaseConstants.IDB_SCHEMA)
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "WalterProductsVersions.findAll", query = "SELECT w FROM WalterProductsVersions w"),
  @NamedQuery(name = "WalterProductsVersions.findByProductversionguid", query = "SELECT w FROM WalterProductsVersions w WHERE w.productversionguid = :productversionguid"),
  @NamedQuery(name = "WalterProductsVersions.findByProductversion", query = "SELECT w FROM WalterProductsVersions w WHERE w.productversion = :productversion"),
  @NamedQuery(name = "WalterProductsVersions.findByDiscontinuemodel", query = "SELECT w FROM WalterProductsVersions w WHERE w.discontinuemodel = :discontinuemodel"),
  @NamedQuery(name = "WalterProductsVersions.findByDiscontinueservice", query = "SELECT w FROM WalterProductsVersions w WHERE w.discontinueservice = :discontinueservice"),
  @NamedQuery(name = "WalterProductsVersions.findByPartlist", query = "SELECT w FROM WalterProductsVersions w WHERE w.partlist = :partlist"),
  @NamedQuery(name = "WalterProductsVersions.findByVersionstatus", query = "SELECT w FROM WalterProductsVersions w WHERE w.versionstatus = :versionstatus"),
  @NamedQuery(name = "WalterProductsVersions.findByAdddatetime", query = "SELECT w FROM WalterProductsVersions w WHERE w.adddatetime = :adddatetime"),
  @NamedQuery(name = "WalterProductsVersions.findByDeletedatetime", query = "SELECT w FROM WalterProductsVersions w WHERE w.deletedatetime = :deletedatetime"),
  @NamedQuery(name = "WalterProductsVersions.findByUpdatedatetime", query = "SELECT w FROM WalterProductsVersions w WHERE w.updatedatetime = :updatedatetime"),
  @NamedQuery(name = "WalterProductsVersions.findByUpdatedatetimestatus", query = "SELECT w FROM WalterProductsVersions w WHERE w.updatedatetimestatus = :updatedatetimestatus")})
public class WalterProductsVersions implements Serializable {
  private static final long serialVersionUID = 1L;
  @Id
  @Basic(optional = false)
  @NotNull
  @Size(min = 1, max = 255)
  @Column(name = "PRODUCTVERSIONGUID")
  private String productversionguid;
  @Size(max = 255)
  @Column(name = "PRODUCTVERSION")
  private String productversion;
  @Column(name = "DISCONTINUEMODEL")
  @Temporal(TemporalType.TIMESTAMP)
  private Date discontinuemodel;
  @Column(name = "DISCONTINUESERVICE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date discontinueservice;
  @Size(max = 255)
  @Column(name = "PARTLIST")
  private String partlist;
  @Lob
  @Column(name = "PRODUCTGLOBALFIELD")
  private String productglobalfield;
  @Lob
  @Column(name = "VERSIONSUMMARY")
  private String versionsummary;
  @Lob
  @Column(name = "COMMENT_")
  private String comment;
  @Size(max = 255)
  @Column(name = "VERSIONSTATUS")
  private String versionstatus;
  @Column(name = "ADDDATETIME")
  @Temporal(TemporalType.TIMESTAMP)
  private Date adddatetime;
  @Column(name = "DELETEDATETIME")
  @Temporal(TemporalType.TIMESTAMP)
  private Date deletedatetime;
  @Column(name = "UPDATEDATETIME")
  @Temporal(TemporalType.TIMESTAMP)
  private Date updatedatetime;
  @Column(name = "UPDATEDATETIMESTATUS")
  @Temporal(TemporalType.TIMESTAMP)
  private Date updatedatetimestatus;
//  @OneToMany(mappedBy = "productversionguid")
//  private Set<WalterProductsDocuments> walterProductsDocumentsSet;
//  @OneToMany(mappedBy = "productversionguid")
//  private Set<WalterTvvideos> walterTvvideosSet;
//  @OneToMany(cascade = CascadeType.ALL, mappedBy = "productversionguid")
//  private Set<WalterProductsCountries> walterProductsCountriesSet;
  @JoinColumn(name = "PRODUCTGUID", referencedColumnName = "PRODUCTGUID")
    @ManyToOne(optional = false, fetch= FetchType.LAZY)
  private WalterProducts productguid;
  @JoinColumn(name = "PRODUCTVERSIONGUID", referencedColumnName = "INSTANCEGUID", insertable = false, updatable = false)
  @OneToOne(optional = false)
  private OoInstances ooInstances;

  public WalterProductsVersions() {
  }

  public WalterProductsVersions(String productversionguid) {
    this.productversionguid = productversionguid;
  }

  public String getProductversionguid() {
    return productversionguid;
  }

  public void setProductversionguid(String productversionguid) {
    this.productversionguid = productversionguid;
  }

  public String getProductversion() {
    return productversion;
  }

  public void setProductversion(String productversion) {
    this.productversion = productversion;
  }

  public Date getDiscontinuemodel() {
    return discontinuemodel;
  }

  public void setDiscontinuemodel(Date discontinuemodel) {
    this.discontinuemodel = discontinuemodel;
  }

  public Date getDiscontinueservice() {
    return discontinueservice;
  }

  public void setDiscontinueservice(Date discontinueservice) {
    this.discontinueservice = discontinueservice;
  }

  public String getPartlist() {
    return partlist;
  }

  public void setPartlist(String partlist) {
    this.partlist = partlist;
  }

  public String getProductglobalfield() {
    return productglobalfield;
  }

  public void setProductglobalfield(String productglobalfield) {
    this.productglobalfield = productglobalfield;
  }

  public String getVersionsummary() {
    return versionsummary;
  }

  public void setVersionsummary(String versionsummary) {
    this.versionsummary = versionsummary;
  }

  public String getComment() {
    return comment;
  }

  public void setComment(String comment) {
    this.comment = comment;
  }

  public String getVersionstatus() {
    return versionstatus;
  }

  public void setVersionstatus(String versionstatus) {
    this.versionstatus = versionstatus;
  }

  public Date getAdddatetime() {
    return adddatetime;
  }

  public void setAdddatetime(Date adddatetime) {
    this.adddatetime = adddatetime;
  }

  public Date getDeletedatetime() {
    return deletedatetime;
  }

  public void setDeletedatetime(Date deletedatetime) {
    this.deletedatetime = deletedatetime;
  }

  public Date getUpdatedatetime() {
    return updatedatetime;
  }

  public void setUpdatedatetime(Date updatedatetime) {
    this.updatedatetime = updatedatetime;
  }

  public Date getUpdatedatetimestatus() {
    return updatedatetimestatus;
  }

  public void setUpdatedatetimestatus(Date updatedatetimestatus) {
    this.updatedatetimestatus = updatedatetimestatus;
  }

//  @XmlTransient
//  public Set<WalterProductsDocuments> getWalterProductsDocumentsSet() {
//    return walterProductsDocumentsSet;
//  }
//
//  public void setWalterProductsDocumentsSet(Set<WalterProductsDocuments> walterProductsDocumentsSet) {
//    this.walterProductsDocumentsSet = walterProductsDocumentsSet;
//  }
//
//  @XmlTransient
//  public Set<WalterTvvideos> getWalterTvvideosSet() {
//    return walterTvvideosSet;
//  }
//
//  public void setWalterTvvideosSet(Set<WalterTvvideos> walterTvvideosSet) {
//    this.walterTvvideosSet = walterTvvideosSet;
//  }
//
//  @XmlTransient
//  public Set<WalterProductsCountries> getWalterProductsCountriesSet() {
//    return walterProductsCountriesSet;
//  }
//
//  public void setWalterProductsCountriesSet(Set<WalterProductsCountries> walterProductsCountriesSet) {
//    this.walterProductsCountriesSet = walterProductsCountriesSet;
//  }

  public WalterProducts getProductguid() {
    return productguid;
  }

  public void setProductguid(WalterProducts productguid) {
    this.productguid = productguid;
  }

  public OoInstances getOoInstances() {
    return ooInstances;
  }

  public void setOoInstances(OoInstances ooInstances) {
    this.ooInstances = ooInstances;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (productversionguid != null ? productversionguid.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof WalterProductsVersions)) {
      return false;
    }
    WalterProductsVersions other = (WalterProductsVersions) object;
    if ((this.productversionguid == null && other.productversionguid != null) || (this.productversionguid != null && !this.productversionguid.equals(other.productversionguid))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.idb.WalterProductsVersions[ productversionguid=" + productversionguid + " ]";
  }

}
