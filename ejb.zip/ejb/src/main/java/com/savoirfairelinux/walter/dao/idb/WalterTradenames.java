/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.idb;

import com.savoirfairelinux.walter.dao.DatabaseConstants;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "WALTER_TRADENAMES", catalog = "", schema = DatabaseConstants.IDB_SCHEMA)
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "WalterTradenames.findAll", query = "SELECT w FROM WalterTradenames w"),
  @NamedQuery(name = "WalterTradenames.findByTradenameguid", query = "SELECT w FROM WalterTradenames w WHERE w.tradenameguid = :tradenameguid"),
  @NamedQuery(name = "WalterTradenames.findByTradenametext", query = "SELECT w FROM WalterTradenames w WHERE w.tradenametext = :tradenametext"),
  @NamedQuery(name = "WalterTradenames.findByAdddatetime", query = "SELECT w FROM WalterTradenames w WHERE w.adddatetime = :adddatetime"),
  @NamedQuery(name = "WalterTradenames.findByDeletedatetime", query = "SELECT w FROM WalterTradenames w WHERE w.deletedatetime = :deletedatetime"),
  @NamedQuery(name = "WalterTradenames.findByUpdatedatetime", query = "SELECT w FROM WalterTradenames w WHERE w.updatedatetime = :updatedatetime")})
public class WalterTradenames implements Serializable {
  private static final long serialVersionUID = 1L;
  @Id
  @Basic(optional = false)
  @NotNull
  @Size(min = 1, max = 255)
  @Column(name = "TRADENAMEGUID")
  private String tradenameguid;
  @Size(max = 255)
  @Column(name = "TRADENAMETEXT")
  private String tradenametext;
  @Column(name = "ADDDATETIME")
  @Temporal(TemporalType.TIMESTAMP)
  private Date adddatetime;
  @Column(name = "DELETEDATETIME")
  @Temporal(TemporalType.TIMESTAMP)
  private Date deletedatetime;
  @Column(name = "UPDATEDATETIME")
  @Temporal(TemporalType.TIMESTAMP)
  private Date updatedatetime;
  @JoinColumn(name = "COMPANYGUID", referencedColumnName = "COMPANYGUID")
  @ManyToOne
  private WalterCompanies companyguid;
  @JoinColumn(name = "TRADENAMEGUID", referencedColumnName = "INSTANCEGUID", insertable = false, updatable = false)
  @OneToOne(optional = false)
  private OoInstances ooInstances;
  @JoinColumn(name = "PRODUCTLINEGUID", referencedColumnName = "INSTANCEGUID")
  @ManyToOne
  private OoInstances productlineguid;
//  @OneToMany(mappedBy = "tradenameguid")
//  private Set<WalterProductsCountries> walterProductsCountriesSet;

  public WalterTradenames() {
  }

  public WalterTradenames(String tradenameguid) {
    this.tradenameguid = tradenameguid;
  }

  public String getTradenameguid() {
    return tradenameguid;
  }

  public void setTradenameguid(String tradenameguid) {
    this.tradenameguid = tradenameguid;
  }

  public String getTradenametext() {
    return tradenametext;
  }

  public void setTradenametext(String tradenametext) {
    this.tradenametext = tradenametext;
  }

  public Date getAdddatetime() {
    return adddatetime;
  }

  public void setAdddatetime(Date adddatetime) {
    this.adddatetime = adddatetime;
  }

  public Date getDeletedatetime() {
    return deletedatetime;
  }

  public void setDeletedatetime(Date deletedatetime) {
    this.deletedatetime = deletedatetime;
  }

  public Date getUpdatedatetime() {
    return updatedatetime;
  }

  public void setUpdatedatetime(Date updatedatetime) {
    this.updatedatetime = updatedatetime;
  }

  public WalterCompanies getCompanyguid() {
    return companyguid;
  }

  public void setCompanyguid(WalterCompanies companyguid) {
    this.companyguid = companyguid;
  }

  public OoInstances getOoInstances() {
    return ooInstances;
  }

  public void setOoInstances(OoInstances ooInstances) {
    this.ooInstances = ooInstances;
  }

  public OoInstances getProductlineguid() {
    return productlineguid;
  }

  public void setProductlineguid(OoInstances productlineguid) {
    this.productlineguid = productlineguid;
  }

//  @XmlTransient
//  public Set<WalterProductsCountries> getWalterProductsCountriesSet() {
//    return walterProductsCountriesSet;
//  }
//
//  public void setWalterProductsCountriesSet(Set<WalterProductsCountries> walterProductsCountriesSet) {
//    this.walterProductsCountriesSet = walterProductsCountriesSet;
//  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (tradenameguid != null ? tradenameguid.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof WalterTradenames)) {
      return false;
    }
    WalterTradenames other = (WalterTradenames) object;
    if ((this.tradenameguid == null && other.tradenameguid != null) || (this.tradenameguid != null && !this.tradenameguid.equals(other.tradenameguid))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.idb.WalterTradenames[ tradenameguid=" + tradenameguid + " ]";
  }

}
