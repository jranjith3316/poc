/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import javax.persistence.*;
import javax.validation.constraints.Size;
import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;

/**
 *
 * @author jderuere
 */
@Entity
@Table(name = "PR_COMPANY", schema = DatabaseConstants.WALTERCB_SCHEMA)
@NamedQuery(name = "PrCompany.findAll", query = "SELECT pc FROM PrCompany pc")
public class PrCompany implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(generator = "PR_COMPANY_ID_SEQ", strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "PR_COMPANY_ID_SEQ", sequenceName = "PR_COMPANY_ID_SEQ", schema = DatabaseConstants.WALTERCB_SCHEMA, allocationSize = 1)
    @Column(name = "ID")
    private Long id;
    @Column(name = "NAME", nullable = false)
    private String name;
    @Column(name = "CONTACT_NAME")
    private String contactName;
    @Column(name = "ADDRESS", nullable = false)
    private String address;
    @Size(max = 40)
    @Column(name = "CITY", nullable = false)
    private String city;
    @Size(max = 10)
    @Column(name = "POSTAL_CODE")
    private String postalCode;
    @ManyToOne
    @JoinColumn(name = "COUNTRY_ID", nullable = false)
    private Country country;

    public PrCompany() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public Country getCountry() {
        return country;
    }

    public void setCountry(Country country) {
        this.country = country;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (getId() != null ? getId().hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PrCompany)) {
            return false;
        }
        PrCompany other = (PrCompany) object;
        if (this.getId() == null && other.getId() == null) {
            return this == other;
        }
        if ((this.getId() == null && other.getId() != null) || (this.getId() != null && !this.getId().equals(other.getId()))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.PrCompany[ id=" + id + " ]";
    }
}
