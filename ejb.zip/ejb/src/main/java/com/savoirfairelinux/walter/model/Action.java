/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.model;

import java.io.Serializable;

/**
 *
 * @author jsgill
 */
public class Action implements Serializable {

	private String actionGuid;
	private Franchise franchise;
	private String description;

  public Action(String actionGuid, Franchise franchise, String description) {
    this.actionGuid = actionGuid;
    this.franchise = franchise;
    this.description = description;
  }

  public String getActionGuid() {
    return actionGuid;
  }

  public void setActionGuid(String actionGuid) {
    this.actionGuid = actionGuid;
  }

  public Franchise getFranchise() {
    return franchise;
  }

  public void setFranchise(Franchise franchise) {
    this.franchise = franchise;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

}
