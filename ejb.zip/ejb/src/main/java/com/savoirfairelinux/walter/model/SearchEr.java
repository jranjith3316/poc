package com.savoirfairelinux.walter.model;

import com.savoirfairelinux.walter.dao.waltercb.UContaminant;
import com.savoirfairelinux.walter.dao.waltercb.ULang;

import java.io.Serializable;
import java.util.Date;

public class SearchEr implements Serializable {

    private Long id;
    private String reference;
    private UContaminant contaminant;
    private String customer;
    private String creatorScreenName;
    private String requesterScreenName;
    private String keyWord;
    private Date fromPublicationDate;
    private Date toPublicationDate;
    private LabReportState state;
    private WalterOrganization organization;
    private Franchise franchise;
    private Tradename tradename;
    private String otherCleaner;
    private Integer partsId;
    private ULang language;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public UContaminant getContaminant() {
        return contaminant;
    }

    public void setContaminant(UContaminant contaminant) {
        this.contaminant = contaminant;
    }

    public String getCustomer() {
        return customer;
    }

    public void setCustomer(String customer) {
        this.customer = customer;
    }

    public String getCreatorScreenName() {
        return creatorScreenName;
    }

    public void setCreatorScreenName(String creatorScreenName) {
        this.creatorScreenName = creatorScreenName;
    }

    public String getRequesterScreenName() {
        return requesterScreenName;
    }

    public void setRequesterScreenName(String requesterScreenName) {
        this.requesterScreenName = requesterScreenName;
    }

    public String getKeyWord() {
        return keyWord;
    }

    public void setKeyWord(String keyWord) {
        this.keyWord = keyWord;
    }

    public Date getFromPublicationDate() {
        return fromPublicationDate;
    }

    public void setFromPublicationDate(Date fromPublicationDate) {
        this.fromPublicationDate = fromPublicationDate;
    }

    public Date getToPublicationDate() {
        return toPublicationDate;
    }

    public void setToPublicationDate(Date toPublicationDate) {
        this.toPublicationDate = toPublicationDate;
    }

    public LabReportState getState() {
        return state;
    }

    public void setState(LabReportState state) {
        this.state = state;
    }

    public WalterOrganization getOrganization() {
        return organization;
    }

    public void setOrganization(WalterOrganization organization) {
        this.organization = organization;
    }

    public ULang getLanguage() {
        return language;
    }

    public void setLanguage(ULang language) {
        this.language = language;
    }

    public Franchise getFranchise() {
        return franchise;
    }

    public void setFranchise(Franchise franchise) {
        this.franchise = franchise;
    }

    public Tradename getTradename() {
        return tradename;
    }

    public void setTradename(Tradename tradename) {
        this.tradename = tradename;
    }

    public Integer getPartsId() {
        return partsId;
    }

    public void setPartsId(Integer partsId) {
        this.partsId = partsId;
    }

    public String getOtherCleaner() {
        return otherCleaner;
    }

    public void setOtherCleaner(String otherCleaner) {
        this.otherCleaner = otherCleaner;
    }
}
