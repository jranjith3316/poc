/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author jsgill
 */
@Embeddable
public class CountryRegionTxtPK implements Serializable {
    @Basic(optional = false)
    @NotNull
    @Column(name = "COUNTRY_ID")
    private long countryId;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "REGION_CODE")
    private String regionCode;
    @Basic(optional = false)
    @NotNull
    @Column(name = "LANG_ID")
    private long langId;

    public CountryRegionTxtPK() {
    }

    public CountryRegionTxtPK(long countryId, String regionCode, long langId) {
        this.countryId = countryId;
        this.regionCode = regionCode;
        this.langId = langId;
    }

    public long getCountryId() {
        return countryId;
    }

    public void setCountryId(long countryId) {
        this.countryId = countryId;
    }

    public String getRegionCode() {
        return regionCode;
    }

    public void setRegionCode(String regionCode) {
        this.regionCode = regionCode;
    }

    public long getLangId() {
        return langId;
    }

    public void setLangId(long langId) {
        this.langId = langId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) countryId;
        hash += (regionCode != null ? regionCode.hashCode() : 0);
        hash += (int) langId;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CountryRegionTxtPK)) {
            return false;
        }
        CountryRegionTxtPK other = (CountryRegionTxtPK) object;
        if (this.countryId != other.countryId) {
            return false;
        }
        if ((this.regionCode == null && other.regionCode != null) || (this.regionCode != null && !this.regionCode.equals(other.regionCode))) {
            return false;
        }
        if (this.langId != other.langId) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.CountryRegionTxtPK[ countryId=" + countryId + ", regionCode=" + regionCode + ", langId=" + langId + " ]";
    }
    
}
