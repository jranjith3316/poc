/* 
 * Copyright 2012 Savoir-faire Linux
 * 
 * This file is part of Walter-Portal.
 * 
 * Walter-Portal is free software: you can redistribute it and/or modify it under the terms of the 
 * GNU General Public License as published by the Free Software Foundation, either version 3 
 * of the License, or (at your option) any later version.
 * 
 * Walter-Portal is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with Walter-Portal. 
 * If not, see http://www.gnu.org/licenses/.
 */
package com.savoirfairelinux.walter.service;

import com.savoirfairelinux.walter.dao.globalcustomer.GaFacility;
import com.savoirfairelinux.walter.dao.globalcustomer.GaFeedback;
import com.savoirfairelinux.walter.dao.globalcustomer.GaFeedbackR;
import com.savoirfairelinux.walter.dao.globalcustomer.GlobalAccount;
import com.savoirfairelinux.walter.model.SearchGlobalAccount;

import javax.ejb.Remote;
import java.util.List;

/**
 * @author jderuere
 */
@Remote
public interface GlobalCustomerBeanRemote {

    public GlobalAccount save(GlobalAccount globalAccount);

    public List<GlobalAccount> search(SearchGlobalAccount searchGlobalAccount, String languageAbbreviature);

    public List<GlobalAccount> getRecent(String languageAbbreviature);

    public List<String> getGlobalAccountNames(String name);

    public GlobalAccount getGlobalAccount(String name);

    public GaFacility getFacility(Long facilityId) throws Exception;

    public GaFacility save(GaFacility facility);

    public GlobalAccount getGlobalAccount(Long gaId, String languageAbbreviature) throws Exception;

    public void reply(GaFeedbackR feedbackReply) throws Exception;

    public void feedBack(GaFeedback feedback) throws Exception;
}
