/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.walterproductivity;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;
import java.util.Set;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "ORDERS", catalog = "", schema = "WALTERPRODUCTIVITY")
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "Orders.findAll", query = "SELECT o FROM Orders o"),
  @NamedQuery(name = "Orders.findById", query = "SELECT o FROM Orders o WHERE o.id = :id"),
  @NamedQuery(name = "Orders.findByCreationDate", query = "SELECT o FROM Orders o WHERE o.creationDate = :creationDate"),
  @NamedQuery(name = "Orders.findByDeviceId", query = "SELECT o FROM Orders o WHERE o.deviceId = :deviceId"),
  @NamedQuery(name = "Orders.findByUpdateDate", query = "SELECT o FROM Orders o WHERE o.updateDate = :updateDate"),
  @NamedQuery(name = "Orders.findByUserId", query = "SELECT o FROM Orders o WHERE o.userId = :userId"),
  @NamedQuery(name = "Orders.findByContactAddress1", query = "SELECT o FROM Orders o WHERE o.contactAddress1 = :contactAddress1"),
  @NamedQuery(name = "Orders.findByContactAddress2", query = "SELECT o FROM Orders o WHERE o.contactAddress2 = :contactAddress2"),
  @NamedQuery(name = "Orders.findByContactCity", query = "SELECT o FROM Orders o WHERE o.contactCity = :contactCity"),
  @NamedQuery(name = "Orders.findByContactCountry", query = "SELECT o FROM Orders o WHERE o.contactCountry = :contactCountry"),
  @NamedQuery(name = "Orders.findByContactEmail", query = "SELECT o FROM Orders o WHERE o.contactEmail = :contactEmail"),
  @NamedQuery(name = "Orders.findByContactEnterprise", query = "SELECT o FROM Orders o WHERE o.contactEnterprise = :contactEnterprise"),
  @NamedQuery(name = "Orders.findByContactName", query = "SELECT o FROM Orders o WHERE o.contactName = :contactName"),
  @NamedQuery(name = "Orders.findByContactZip", query = "SELECT o FROM Orders o WHERE o.contactZip = :contactZip"),
  @NamedQuery(name = "Orders.findByMailBody", query = "SELECT o FROM Orders o WHERE o.mailBody = :mailBody"),
  @NamedQuery(name = "Orders.findByMailCopies", query = "SELECT o FROM Orders o WHERE o.mailCopies = :mailCopies"),
  @NamedQuery(name = "Orders.findByMailRecipients", query = "SELECT o FROM Orders o WHERE o.mailRecipients = :mailRecipients"),
  @NamedQuery(name = "Orders.findByMailSubject", query = "SELECT o FROM Orders o WHERE o.mailSubject = :mailSubject"),
  @NamedQuery(name = "Orders.findByResellerCompany", query = "SELECT o FROM Orders o WHERE o.resellerCompany = :resellerCompany"),
  @NamedQuery(name = "Orders.findByResellerContact", query = "SELECT o FROM Orders o WHERE o.resellerContact = :resellerContact"),
  @NamedQuery(name = "Orders.findByStatus", query = "SELECT o FROM Orders o WHERE o.status = :status"),
  @NamedQuery(name = "Orders.findByTotalPrice", query = "SELECT o FROM Orders o WHERE o.totalPrice = :totalPrice"),
  @NamedQuery(name = "Orders.findByUserScreenName", query = "SELECT o FROM Orders o WHERE o.userScreenName = :userScreenName")})
public class Orders implements Serializable {
  private static final long serialVersionUID = 1L;
  @Id
  @Basic(optional = false)
  @NotNull
  @Size(min = 1, max = 255)
  @Column(name = "ID")
  private String id;
  @Column(name = "CREATION_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date creationDate;
  @Size(max = 255)
  @Column(name = "DEVICE_ID")
  private String deviceId;
  @Column(name = "UPDATE_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date updateDate;
  @Column(name = "USER_ID")
  private BigInteger userId;
  @Size(max = 1000)
  @Column(name = "CONTACT_ADDRESS1")
  private String contactAddress1;
  @Size(max = 1000)
  @Column(name = "CONTACT_ADDRESS2")
  private String contactAddress2;
  @Size(max = 255)
  @Column(name = "CONTACT_CITY")
  private String contactCity;
  @Size(max = 255)
  @Column(name = "CONTACT_COUNTRY")
  private String contactCountry;
  @Size(max = 255)
  @Column(name = "CONTACT_EMAIL")
  private String contactEmail;
  @Size(max = 255)
  @Column(name = "CONTACT_ENTERPRISE")
  private String contactEnterprise;
  @Size(max = 255)
  @Column(name = "CONTACT_NAME")
  private String contactName;
  @Size(max = 255)
  @Column(name = "CONTACT_ZIP")
  private String contactZip;
  @Size(max = 255)
  @Column(name = "MAIL_BODY")
  private String mailBody;
  @Size(max = 255)
  @Column(name = "MAIL_COPIES")
  private String mailCopies;
  @Size(max = 255)
  @Column(name = "MAIL_RECIPIENTS")
  private String mailRecipients;
  @Size(max = 255)
  @Column(name = "MAIL_SUBJECT")
  private String mailSubject;
  @Size(max = 255)
  @Column(name = "RESELLER_COMPANY")
  private String resellerCompany;
  @Size(max = 255)
  @Column(name = "RESELLER_CONTACT")
  private String resellerContact;
  @Basic(optional = false)
  @NotNull
  @Size(min = 1, max = 255)
  @Column(name = "STATUS")
  private String status;
  // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
  @Column(name = "TOTAL_PRICE")
  private Double totalPrice;
  @Size(max = 255)
  @Column(name = "USER_SCREEN_NAME")
  private String userScreenName;
  @JoinColumn(name = "REPORT_ID", referencedColumnName = "ID")
  @ManyToOne
  private Reports reportId;
  @OneToMany(cascade = CascadeType.ALL, mappedBy = "orderId")
  private Set<OrdersDetail> ordersDetailSet;

  public Orders() {
  }

  public Orders(String id) {
    this.id = id;
  }

  public Orders(String id, String status) {
    this.id = id;
    this.status = status;
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public Date getCreationDate() {
    return creationDate;
  }

  public void setCreationDate(Date creationDate) {
    this.creationDate = creationDate;
  }

  public String getDeviceId() {
    return deviceId;
  }

  public void setDeviceId(String deviceId) {
    this.deviceId = deviceId;
  }

  public Date getUpdateDate() {
    return updateDate;
  }

  public void setUpdateDate(Date updateDate) {
    this.updateDate = updateDate;
  }

  public BigInteger getUserId() {
    return userId;
  }

  public void setUserId(BigInteger userId) {
    this.userId = userId;
  }

  public String getContactAddress1() {
    return contactAddress1;
  }

  public void setContactAddress1(String contactAddress1) {
    this.contactAddress1 = contactAddress1;
  }

  public String getContactAddress2() {
    return contactAddress2;
  }

  public void setContactAddress2(String contactAddress2) {
    this.contactAddress2 = contactAddress2;
  }

  public String getContactCity() {
    return contactCity;
  }

  public void setContactCity(String contactCity) {
    this.contactCity = contactCity;
  }

  public String getContactCountry() {
    return contactCountry;
  }

  public void setContactCountry(String contactCountry) {
    this.contactCountry = contactCountry;
  }

  public String getContactEmail() {
    return contactEmail;
  }

  public void setContactEmail(String contactEmail) {
    this.contactEmail = contactEmail;
  }

  public String getContactEnterprise() {
    return contactEnterprise;
  }

  public void setContactEnterprise(String contactEnterprise) {
    this.contactEnterprise = contactEnterprise;
  }

  public String getContactName() {
    return contactName;
  }

  public void setContactName(String contactName) {
    this.contactName = contactName;
  }

  public String getContactZip() {
    return contactZip;
  }

  public void setContactZip(String contactZip) {
    this.contactZip = contactZip;
  }

  public String getMailBody() {
    return mailBody;
  }

  public void setMailBody(String mailBody) {
    this.mailBody = mailBody;
  }

  public String getMailCopies() {
    return mailCopies;
  }

  public void setMailCopies(String mailCopies) {
    this.mailCopies = mailCopies;
  }

  public String getMailRecipients() {
    return mailRecipients;
  }

  public void setMailRecipients(String mailRecipients) {
    this.mailRecipients = mailRecipients;
  }

  public String getMailSubject() {
    return mailSubject;
  }

  public void setMailSubject(String mailSubject) {
    this.mailSubject = mailSubject;
  }

  public String getResellerCompany() {
    return resellerCompany;
  }

  public void setResellerCompany(String resellerCompany) {
    this.resellerCompany = resellerCompany;
  }

  public String getResellerContact() {
    return resellerContact;
  }

  public void setResellerContact(String resellerContact) {
    this.resellerContact = resellerContact;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public Double getTotalPrice() {
    return totalPrice;
  }

  public void setTotalPrice(Double totalPrice) {
    this.totalPrice = totalPrice;
  }

  public String getUserScreenName() {
    return userScreenName;
  }

  public void setUserScreenName(String userScreenName) {
    this.userScreenName = userScreenName;
  }

  public Reports getReportId() {
    return reportId;
  }

  public void setReportId(Reports reportId) {
    this.reportId = reportId;
  }

  @XmlTransient
  public Set<OrdersDetail> getOrdersDetailSet() {
    return ordersDetailSet;
  }

  public void setOrdersDetailSet(Set<OrdersDetail> ordersDetailSet) {
    this.ordersDetailSet = ordersDetailSet;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (id != null ? id.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof Orders)) {
      return false;
    }
    Orders other = (Orders) object;
    if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.walterproductivity.Orders[ id=" + id + " ]";
  }

}
