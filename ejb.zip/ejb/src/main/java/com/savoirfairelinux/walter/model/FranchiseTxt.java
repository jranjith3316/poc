package com.savoirfairelinux.walter.model;


import java.io.Serializable;

public class FranchiseTxt implements Serializable {

	private Short franchiseId;
	private String description;
        private Long langId;

	public FranchiseTxt(Short franchiseId, Long langId, String description) {
		this.franchiseId = franchiseId;
		this.description = description;
                this.langId = langId;
	}

	public Short getFranchiseId() {
		return franchiseId;
	}

	public void setFranchiseId(Short franchiseId) {
		this.franchiseId = franchiseId;
	}

	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}

    public Long getLangId() {
        return langId;
    }

    public void setLangId(Long langId) {
        this.langId = langId;
    }

}
