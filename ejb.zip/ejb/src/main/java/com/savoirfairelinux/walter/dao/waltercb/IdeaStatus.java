/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import java.util.Set;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "IDEA_STATUS", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "IdeaStatus.findAll", query = "SELECT i FROM IdeaStatus i"),
    @NamedQuery(name = "IdeaStatus.findByStatusId", query = "SELECT i FROM IdeaStatus i WHERE i.statusId = :statusId"),
    @NamedQuery(name = "IdeaStatus.findByArchiveAfter", query = "SELECT i FROM IdeaStatus i WHERE i.archiveAfter = :archiveAfter"),
    @NamedQuery(name = "IdeaStatus.findByEmailFirstCall", query = "SELECT i FROM IdeaStatus i WHERE i.emailFirstCall = :emailFirstCall"),
    @NamedQuery(name = "IdeaStatus.findByEmailReminderCall", query = "SELECT i FROM IdeaStatus i WHERE i.emailReminderCall = :emailReminderCall"),
    @NamedQuery(name = "IdeaStatus.findByEmailClose", query = "SELECT i FROM IdeaStatus i WHERE i.emailClose = :emailClose")})
public class IdeaStatus implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "STATUS_ID")
    private Integer statusId;
    @Column(name = "ARCHIVE_AFTER")
    private Integer archiveAfter;
    @Column(name = "EMAIL_FIRST_CALL")
    private Integer emailFirstCall;
    @Column(name = "EMAIL_REMINDER_CALL")
    private Integer emailReminderCall;
    @Column(name = "EMAIL_CLOSE")
    private Integer emailClose;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "ideaStatus")
    private Set<IdeaStatusTxt> ideaStatusTxtSet;

    public IdeaStatus() {
    }

    public IdeaStatus(Integer statusId) {
        this.statusId = statusId;
    }

    public Integer getStatusId() {
        return statusId;
    }

    public void setStatusId(Integer statusId) {
        this.statusId = statusId;
    }

    public Integer getArchiveAfter() {
        return archiveAfter;
    }

    public void setArchiveAfter(Integer archiveAfter) {
        this.archiveAfter = archiveAfter;
    }

    public Integer getEmailFirstCall() {
        return emailFirstCall;
    }

    public void setEmailFirstCall(Integer emailFirstCall) {
        this.emailFirstCall = emailFirstCall;
    }

    public Integer getEmailReminderCall() {
        return emailReminderCall;
    }

    public void setEmailReminderCall(Integer emailReminderCall) {
        this.emailReminderCall = emailReminderCall;
    }

    public Integer getEmailClose() {
        return emailClose;
    }

    public void setEmailClose(Integer emailClose) {
        this.emailClose = emailClose;
    }

    @XmlTransient
    public Set<IdeaStatusTxt> getIdeaStatusTxtSet() {
        return ideaStatusTxtSet;
    }

    public void setIdeaStatusTxtSet(Set<IdeaStatusTxt> ideaStatusTxtSet) {
        this.ideaStatusTxtSet = ideaStatusTxtSet;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (statusId != null ? statusId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof IdeaStatus)) {
            return false;
        }
        IdeaStatus other = (IdeaStatus) object;
        if ((this.statusId == null && other.statusId != null) || (this.statusId != null && !this.statusId.equals(other.statusId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.IdeaStatus[ statusId=" + statusId + " ]";
    }
    
}
