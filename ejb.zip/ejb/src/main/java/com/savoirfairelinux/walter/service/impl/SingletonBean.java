/*
 * Copyright 2012 Savoir-faire Linux
 *
 * This file is part of Walter-Portal.
 *
 * Walter-Portal is free software: you can redistribute it and/or modify it under the terms of the
 * GNU General Public License as published by the Free Software Foundation, either version 3
 * of the License, or (at your option) any later version.
 *
 * Walter-Portal is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with Walter-Portal.
 * If not, see http://www.gnu.org/licenses/.
 */
package com.savoirfairelinux.walter.service.impl;

import java.io.IOException;
import java.io.InputStream;
import java.lang.management.ManagementFactory;
import java.math.BigDecimal;
import java.util.InvalidPropertiesFormatException;
import java.util.Map;
import java.util.Properties;
import java.util.regex.Pattern;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Singleton;
import javax.ejb.Startup;

/**
 *
 * @author mgubaidullin
 */
@Startup
@Singleton
@LocalBean
public class SingletonBean {

    @EJB
    WalterBean walterBean;
    @EJB
    SolutionReportBean solutionReportBean;
    RosettaStoneBean rosettaStoneBean;
    ExpenseReportBean expenseReportBean;
    UserManagementBean userManagementBean;
    DailySaleBean dailySaleBean;
    AnalysisReportBean analysisReportBean;
    AerosolCalculatorBean aerosolCalculatorBean;
    GiveAwaysBean giveAwaysBean;
    DistributorLocatorBean distributorLocatorBean;
    CrossReferenceAppBean crossReferenceAppBean;
    private Properties solutionReportProperties;
    private Properties photoGalleryProperties;
    private Properties rosettaStoneProperties;
    private Properties globalCustomerProperties;
    private Properties expenseReportProperties;
    private Properties newIdeaProperties;
    private Properties labReportProperties;
    private Properties productivityReportProperties;
    private Properties userManagementProperties;
    private Properties dailySaleProperties;
    private Properties analysisReportProperties;
    private Properties videoGalleryProperties;
    private Properties productDashboardProperties;
    private Properties aerosolCalculatorProperties;
    private Properties giveAwaysProperties;
    private Properties distributorLocatorProperties;
    private Properties crossReferenceAppProperties;

    private boolean debug = false;
    private Map<Long, Map<BigDecimal, String>> naicsCustomersMap;

    @PostConstruct
    public void init() {
        try {
            loadProperties();
            naicsCustomersMap = solutionReportBean.fillNaicsCustomersMap();
            Pattern debugPattern = Pattern.compile("-Xdebubg|jdwp");
            for (String arg : ManagementFactory.getRuntimeMXBean().getInputArguments()) {
                if (debugPattern.matcher(arg).find()) {
                    debug = true;
                    break;
                }
            }
        } catch (Exception ex) {
          System.out.println("error: " + ex.getMessage());
        }
    }

    public String getRosettaStoneQuery(String queryKey) {
        return rosettaStoneProperties.getProperty(queryKey);
    }

    public String getSolutionReportQuery(String queryKey) {
        return solutionReportProperties.getProperty(queryKey);
    }

    public String getExpenseReportQuery(String queryKey) {
        return expenseReportProperties.getProperty(queryKey);
    }

    public String getPhotoGalleryQuery(String queryKey) {
        return photoGalleryProperties.getProperty(queryKey);
    }

    public String getGlobalCustomerQuery(String queryKey) {
        return globalCustomerProperties.getProperty(queryKey);
    }

    public String getNewIdeaQuery(String queryKey) {
        return newIdeaProperties.getProperty(queryKey);
    }

    public String getLabReportQuery(String queryKey) {
        return labReportProperties.getProperty(queryKey);
    }

    public String getProductivityReportQuery(String queryKey) {
        return productivityReportProperties.getProperty(queryKey);
    }

    public String getUserManagementQuery(String queryKey) {
        return userManagementProperties.getProperty(queryKey);
    }

    public String getDailySaleQuerys(String queryKey) {
      return dailySaleProperties.getProperty(queryKey);
    }

    public String getAnalysisReportQuerys(String queryKey) {
      return analysisReportProperties.getProperty(queryKey);
    }

    public String getVideoGalleryQuery(String queryKey) {
      return videoGalleryProperties.getProperty(queryKey);
    }

    public String getProductDashboardQuery(String queryKey) {
      return productDashboardProperties.getProperty(queryKey);
    }

    public String getAerosolCalculatorQuery(String queryKey) {
      return aerosolCalculatorProperties.getProperty(queryKey);
    }

    public String getGiveAwaysQuery(String queryKey) {
      return giveAwaysProperties.getProperty(queryKey);
    }

    public String getDistributorLocator(String queryKey) {
      return distributorLocatorProperties.getProperty(queryKey);
    }

    public String getCrossReferenceApp(String queryKey) {
      return crossReferenceAppProperties.getProperty(queryKey);
    }

    public void loadProperties() throws InvalidPropertiesFormatException, IOException {
        solutionReportProperties = new Properties();
        InputStream is = this.getClass().getClassLoader().getResourceAsStream("solution-report.xml");
        solutionReportProperties.loadFromXML(is);

        photoGalleryProperties = new Properties();
        is = this.getClass().getClassLoader().getResourceAsStream("photo-gallery.xml");
        photoGalleryProperties.loadFromXML(is);

        rosettaStoneProperties = new Properties();
        is = this.getClass().getClassLoader().getResourceAsStream("rosetta-stone.xml");
        rosettaStoneProperties.loadFromXML(is);

        globalCustomerProperties = new Properties();
        is = this.getClass().getClassLoader().getResourceAsStream("global-account.xml");
        globalCustomerProperties.loadFromXML(is);

        expenseReportProperties = new Properties();
        is = this.getClass().getClassLoader().getResourceAsStream("expense-report.xml");
        expenseReportProperties.loadFromXML(is);

        newIdeaProperties = new Properties();
        is = this.getClass().getClassLoader().getResourceAsStream("new-idea.xml");
        newIdeaProperties.loadFromXML(is);

        labReportProperties = new Properties();
        is = this.getClass().getClassLoader().getResourceAsStream("lab-report.xml");
        labReportProperties.loadFromXML(is);

        productivityReportProperties = new Properties();
        is = this.getClass().getClassLoader().getResourceAsStream("productivity-report.xml");
        productivityReportProperties.loadFromXML(is);

        userManagementProperties = new Properties();
        is = this.getClass().getClassLoader().getResourceAsStream("user-management.xml");
        userManagementProperties.loadFromXML(is);

        dailySaleProperties = new Properties();
        is = this.getClass().getClassLoader().getResourceAsStream("dailysale.xml");
        dailySaleProperties.loadFromXML(is);

        analysisReportProperties = new Properties();
        is = this.getClass().getClassLoader().getResourceAsStream("analysis-report.xml");
        analysisReportProperties.loadFromXML(is);

        videoGalleryProperties = new Properties();
        is = this.getClass().getClassLoader().getResourceAsStream("video-gallery.xml");
        videoGalleryProperties.loadFromXML(is);

        productDashboardProperties = new Properties();
        is = this.getClass().getClassLoader().getResourceAsStream("product-dashboard.xml");
        productDashboardProperties.loadFromXML(is);

        aerosolCalculatorProperties = new Properties();
        is = this.getClass().getClassLoader().getResourceAsStream("aerosol-calculator.xml");
        aerosolCalculatorProperties.loadFromXML(is);

        giveAwaysProperties = new Properties();
        is = this.getClass().getClassLoader().getResourceAsStream("give-aways.xml");
        giveAwaysProperties.loadFromXML(is);

        distributorLocatorProperties = new Properties();
        is = this.getClass().getClassLoader().getResourceAsStream("distributor-locator.xml");
        distributorLocatorProperties.loadFromXML(is);

        crossReferenceAppProperties = new Properties();
        is = this.getClass().getClassLoader().getResourceAsStream("cross-reference-app.xml");
        crossReferenceAppProperties.loadFromXML(is);
    }

    public boolean isDebug() {
        return debug;
    }

    public Map<Long, Map<BigDecimal, String>> getNaicsCustomersMap() {
        return naicsCustomersMap;
    }


}
