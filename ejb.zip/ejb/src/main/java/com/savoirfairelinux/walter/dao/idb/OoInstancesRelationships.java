/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.idb;

import com.savoirfairelinux.walter.dao.DatabaseConstants;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "OO_INSTANCES_RELATIONSHIPS", catalog = "", schema = DatabaseConstants.IDB_SCHEMA)
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "OoInstancesRelationships.findAll", query = "SELECT o FROM OoInstancesRelationships o"),
  @NamedQuery(name = "OoInstancesRelationships.findByRelationshiptype", query = "SELECT o FROM OoInstancesRelationships o WHERE o.relationshiptype = :relationshiptype"),
  @NamedQuery(name = "OoInstancesRelationships.findByRelationshipstatus", query = "SELECT o FROM OoInstancesRelationships o WHERE o.relationshipstatus = :relationshipstatus"),
  @NamedQuery(name = "OoInstancesRelationships.findByAdddatetime", query = "SELECT o FROM OoInstancesRelationships o WHERE o.adddatetime = :adddatetime"),
  @NamedQuery(name = "OoInstancesRelationships.findByDeletedatime", query = "SELECT o FROM OoInstancesRelationships o WHERE o.deletedatime = :deletedatime"),
  @NamedQuery(name = "OoInstancesRelationships.findByUpdatedatetime", query = "SELECT o FROM OoInstancesRelationships o WHERE o.updatedatetime = :updatedatetime"),
  @NamedQuery(name = "OoInstancesRelationships.findByEventuser", query = "SELECT o FROM OoInstancesRelationships o WHERE o.eventuser = :eventuser"),
  @NamedQuery(name = "OoInstancesRelationships.findByRelationshipguid", query = "SELECT o FROM OoInstancesRelationships o WHERE o.relationshipguid = :relationshipguid"),
  @NamedQuery(name = "OoInstancesRelationships.findByUpdatedatetimestatus", query = "SELECT o FROM OoInstancesRelationships o WHERE o.updatedatetimestatus = :updatedatetimestatus")})
public class OoInstancesRelationships implements Serializable {
  private static final long serialVersionUID = 1L;
  @Size(max = 255)
    @Column(name = "RELATIONSHIPTYPE", length = 255)
  private String relationshiptype;
  @Size(max = 255)
    @Column(name = "RELATIONSHIPSTATUS", length = 255)
  private String relationshipstatus;
  @Column(name = "ADDDATETIME")
  @Temporal(TemporalType.TIMESTAMP)
  private Date adddatetime;
  @Column(name = "DELETEDATIME")
  @Temporal(TemporalType.TIMESTAMP)
  private Date deletedatime;
  @Column(name = "UPDATEDATETIME")
  @Temporal(TemporalType.TIMESTAMP)
  private Date updatedatetime;
  @Size(max = 255)
    @Column(name = "EVENTUSER", length = 255)
  private String eventuser;
  @Id
  @Basic(optional = false)
  @NotNull
  @Size(min = 1, max = 255)
    @Column(name = "RELATIONSHIPGUID", nullable = false, length = 255)
  private String relationshipguid;
  @Column(name = "UPDATEDATETIMESTATUS")
  @Temporal(TemporalType.TIMESTAMP)
  private Date updatedatetimestatus;
  @JoinColumn(name = "FILTERINSTANCEGUID", referencedColumnName = "INSTANCEGUID")
  @ManyToOne
  private OoInstances filterinstanceguid;
    @JoinColumn(name = "CHILDINSTANCEGUID", referencedColumnName = "INSTANCEGUID", nullable = false)
  @ManyToOne(optional = false)
  private OoInstances childinstanceguid;
    @JoinColumn(name = "PARENTINSTANCEGUID", referencedColumnName = "INSTANCEGUID", nullable = false)
    @ManyToOne(optional = false)
    private OoInstances parentinstanceguid;

  public OoInstancesRelationships() {
  }

  public OoInstancesRelationships(String relationshipguid) {
    this.relationshipguid = relationshipguid;
  }

  public String getRelationshiptype() {
    return relationshiptype;
  }

  public void setRelationshiptype(String relationshiptype) {
    this.relationshiptype = relationshiptype;
  }

  public String getRelationshipstatus() {
    return relationshipstatus;
  }

  public void setRelationshipstatus(String relationshipstatus) {
    this.relationshipstatus = relationshipstatus;
  }

  public Date getAdddatetime() {
    return adddatetime;
  }

  public void setAdddatetime(Date adddatetime) {
    this.adddatetime = adddatetime;
  }

  public Date getDeletedatime() {
    return deletedatime;
  }

  public void setDeletedatime(Date deletedatime) {
    this.deletedatime = deletedatime;
  }

  public Date getUpdatedatetime() {
    return updatedatetime;
  }

  public void setUpdatedatetime(Date updatedatetime) {
    this.updatedatetime = updatedatetime;
  }

  public String getEventuser() {
    return eventuser;
  }

  public void setEventuser(String eventuser) {
    this.eventuser = eventuser;
  }

  public String getRelationshipguid() {
    return relationshipguid;
  }

  public void setRelationshipguid(String relationshipguid) {
    this.relationshipguid = relationshipguid;
  }

  public Date getUpdatedatetimestatus() {
    return updatedatetimestatus;
  }

  public void setUpdatedatetimestatus(Date updatedatetimestatus) {
    this.updatedatetimestatus = updatedatetimestatus;
  }

  public OoInstances getParentinstanceguid() {
    return parentinstanceguid;
  }

  public void setParentinstanceguid(OoInstances parentinstanceguid) {
    this.parentinstanceguid = parentinstanceguid;
  }

  public OoInstances getFilterinstanceguid() {
    return filterinstanceguid;
  }

  public void setFilterinstanceguid(OoInstances filterinstanceguid) {
    this.filterinstanceguid = filterinstanceguid;
  }

  public OoInstances getChildinstanceguid() {
    return childinstanceguid;
  }

  public void setChildinstanceguid(OoInstances childinstanceguid) {
    this.childinstanceguid = childinstanceguid;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (relationshipguid != null ? relationshipguid.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof OoInstancesRelationships)) {
      return false;
    }
    OoInstancesRelationships other = (OoInstancesRelationships) object;
    if ((this.relationshipguid == null && other.relationshipguid != null) || (this.relationshipguid != null && !this.relationshipguid.equals(other.relationshipguid))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.idb.OoInstancesRelationships[ relationshipguid=" + relationshipguid + " ]";
  }

}
