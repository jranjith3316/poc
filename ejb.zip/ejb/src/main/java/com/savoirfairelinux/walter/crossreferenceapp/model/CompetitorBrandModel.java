/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.crossreferenceapp.model;

import java.io.Serializable;
import java.util.List;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;

/**
 *
 * @author jsgill
 */
public class CompetitorBrandModel implements Serializable{
  private static final long serialVersionUID = 3511338233023397895L;
//  private long competitorId;
  private long brandId;
  private String BrandName;
  private List<CompetitorProductModel> competitorProducts;
  private CompetitorProductModel competitorProduct;

//  public long getCompetitorId() {
//    return competitorId;
//  }
//
//  public void setCompetitorId(long competitorId) {
//    this.competitorId = competitorId;
//  }

  public long getBrandId() {
    return brandId;
  }

  public void setBrandId(long brandId) {
    this.brandId = brandId;
  }

  public String getBrandName() {
    return BrandName;
  }

  public void setBrandName(String BrandName) {
    this.BrandName = BrandName;
  }

  @XmlElementWrapper
  @XmlElement(name="competitorProduct")
  public List<CompetitorProductModel> getCompetitorProducts() {
    return competitorProducts;
  }

  public void setCompetitorProducts(List<CompetitorProductModel> competitorProducts) {
    this.competitorProducts = competitorProducts;
  }

  public CompetitorProductModel getCompetitorProduct() {
    return competitorProduct;
  }

  public void setCompetitorProduct(CompetitorProductModel competitorProduct) {
    this.competitorProduct = competitorProduct;
  }

}
