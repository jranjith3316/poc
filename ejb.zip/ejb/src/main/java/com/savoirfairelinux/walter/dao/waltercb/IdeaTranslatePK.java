/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

/**
 *
 * @author mgubaidullin
 */
@Embeddable
public class IdeaTranslatePK implements Serializable {
    @Basic(optional = false)
    @NotNull
    @Column(name = "IDEA_ID")
    private long ideaId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "LANG_ID")
    private long langId;

    public IdeaTranslatePK() {
    }

    public IdeaTranslatePK(long ideaId, long langId) {
        this.ideaId = ideaId;
        this.langId = langId;
    }

    public long getIdeaId() {
        return ideaId;
    }

    public void setIdeaId(long ideaId) {
        this.ideaId = ideaId;
    }

    public long getLangId() {
        return langId;
    }

    public void setLangId(long langId) {
        this.langId = langId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) ideaId;
        hash += (int) langId;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof IdeaTranslatePK)) {
            return false;
        }
        IdeaTranslatePK other = (IdeaTranslatePK) object;
        if (this.ideaId != other.ideaId) {
            return false;
        }
        if (this.langId != other.langId) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.IdeaTranslatePK[ ideaId=" + ideaId + ", langId=" + langId + " ]";
    }
    
}
