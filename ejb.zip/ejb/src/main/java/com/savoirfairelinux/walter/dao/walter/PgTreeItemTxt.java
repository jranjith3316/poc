/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.walter;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "PG_TREE_ITEM_TXT", catalog = "", schema = DatabaseConstants.WALTER_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "PgTreeItemTxt.findAll", query = "SELECT p FROM PgTreeItemTxt p"),
    @NamedQuery(name = "PgTreeItemTxt.findByPgTreeCode", query = "SELECT p FROM PgTreeItemTxt p WHERE p.pgTreeItemTxtPK.pgTreeCode = :pgTreeCode"),
    @NamedQuery(name = "PgTreeItemTxt.findByItemId", query = "SELECT p FROM PgTreeItemTxt p WHERE p.pgTreeItemTxtPK.itemId = :itemId"),
    @NamedQuery(name = "PgTreeItemTxt.findByLangId", query = "SELECT p FROM PgTreeItemTxt p WHERE p.pgTreeItemTxtPK.langId = :langId"),
    @NamedQuery(name = "PgTreeItemTxt.findByItemDesc", query = "SELECT p FROM PgTreeItemTxt p WHERE p.itemDesc = :itemDesc"),
    @NamedQuery(name = "PgTreeItemTxt.findByTitleDesc", query = "SELECT p FROM PgTreeItemTxt p WHERE p.titleDesc = :titleDesc")})
public class PgTreeItemTxt implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected PgTreeItemTxtPK pgTreeItemTxtPK;
    @Size(max = 50)
    @Column(name = "ITEM_DESC", length = 50)
    private String itemDesc;
    @Size(max = 50)
    @Column(name = "TITLE_DESC", length = 50)
    private String titleDesc;
    @JoinColumns({
        @JoinColumn(name = "PG_TREE_CODE", referencedColumnName = "PG_TREE_CODE", nullable = false, insertable = false, updatable = false),
        @JoinColumn(name = "ITEM_ID", referencedColumnName = "ITEM_ID", nullable = false, insertable = false, updatable = false)})
    @ManyToOne(optional = false, fetch= FetchType.LAZY)
    private PgTreeItem pgTreeItem;

    public PgTreeItemTxt() {
    }

    public PgTreeItemTxt(PgTreeItemTxtPK pgTreeItemTxtPK) {
        this.pgTreeItemTxtPK = pgTreeItemTxtPK;
    }

    public PgTreeItemTxt(String pgTreeCode, int itemId, Integer langId) {
        this.pgTreeItemTxtPK = new PgTreeItemTxtPK(pgTreeCode, itemId, langId);
    }

    public PgTreeItemTxtPK getPgTreeItemTxtPK() {
        return pgTreeItemTxtPK;
    }

    public void setPgTreeItemTxtPK(PgTreeItemTxtPK pgTreeItemTxtPK) {
        this.pgTreeItemTxtPK = pgTreeItemTxtPK;
    }

    public String getItemDesc() {
        return itemDesc;
    }

    public void setItemDesc(String itemDesc) {
        this.itemDesc = itemDesc;
    }

    public String getTitleDesc() {
        return titleDesc;
    }

    public void setTitleDesc(String titleDesc) {
        this.titleDesc = titleDesc;
    }

    public PgTreeItem getPgTreeItem() {
        return pgTreeItem;
    }

    public void setPgTreeItem(PgTreeItem pgTreeItem) {
        this.pgTreeItem = pgTreeItem;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (pgTreeItemTxtPK != null ? pgTreeItemTxtPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PgTreeItemTxt)) {
            return false;
        }
        PgTreeItemTxt other = (PgTreeItemTxt) object;
        if ((this.pgTreeItemTxtPK == null && other.pgTreeItemTxtPK != null) || (this.pgTreeItemTxtPK != null && !this.pgTreeItemTxtPK.equals(other.pgTreeItemTxtPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.walter.PgTreeItemTxt[ pgTreeItemTxtPK=" + pgTreeItemTxtPK + " ]";
    }
    
}
