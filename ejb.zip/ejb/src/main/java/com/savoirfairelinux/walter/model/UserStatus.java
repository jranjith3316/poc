/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.model;

import java.io.Serializable;

/**
 *
 * @author jsgill
 */
public class UserStatus implements Serializable{

  private int statusId;
	private String statusName;

  public UserStatus(int statusId, String statusName) {
    this.statusId = statusId;
    this.statusName = statusName;
  }

  public int getStatusId() {
    return statusId;
  }

  public void setStatusId(int statusId) {
    this.statusId = statusId;
  }

  public String getStatusName() {
    return statusName;
  }

  public void setStatusName(String statusName) {
    this.statusName = statusName;
  }

  @Override
  public boolean equals(Object obj) {
    if (obj == null) {
      return false;
    } else if (this == obj) {
			return true;
		} else if (statusId == ((UserStatus) obj).getStatusId() ) {
      return true;
    }
    return false;
  }
  
  

}
