/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.walter;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;

/**
 *
 * @author mgubaidullin
 */
@Embeddable
public class ExpenseRptDPK implements Serializable {

    private static final long serialVersionUID = 1L;

    @Basic(optional = false)
    @NotNull
    @Column(name = "EXPENSE_RPT_ID", nullable = false)
    private long expenseRptId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "LINE_NUM", nullable = false)
    private short lineNum;

    public ExpenseRptDPK() {
    }

    public ExpenseRptDPK(long expenseRptId, short lineNum) {
        this.expenseRptId = expenseRptId;
        this.lineNum = lineNum;
    }

    public long getExpenseRptId() {
        return expenseRptId;
    }

    public void setExpenseRptId(long expenseRptId) {
        this.expenseRptId = expenseRptId;
    }

    public short getLineNum() {
        return lineNum;
    }

    public void setLineNum(short lineNum) {
        this.lineNum = lineNum;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) expenseRptId;
        hash += (int) lineNum;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ExpenseRptDPK)) {
            return false;
        }
        ExpenseRptDPK other = (ExpenseRptDPK) object;
        if (this.expenseRptId != other.expenseRptId) {
            return false;
        }
        if (this.lineNum != other.lineNum) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.walter.ExpenseRptDPK[ expenseRptId=" + expenseRptId + ", lineNum=" + lineNum + " ]";
    }
    
}
