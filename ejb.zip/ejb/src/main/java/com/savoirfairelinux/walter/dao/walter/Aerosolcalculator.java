/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.walter;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "AEROSOLCALCULATOR", catalog = "", schema = "WALTER")
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "Aerosolcalculator.findAll", query = "SELECT a FROM Aerosolcalculator a"),
  @NamedQuery(name = "Aerosolcalculator.findById", query = "SELECT a FROM Aerosolcalculator a WHERE a.id = :id"),
  @NamedQuery(name = "Aerosolcalculator.findByCreatorUserName", query = "SELECT a FROM Aerosolcalculator a WHERE a.creatorUserName = :creatorUserName"),
  @NamedQuery(name = "Aerosolcalculator.findByCreationDate", query = "SELECT a FROM Aerosolcalculator a WHERE a.creationDate = :creationDate"),
  @NamedQuery(name = "Aerosolcalculator.findByDeleteDate", query = "SELECT a FROM Aerosolcalculator a WHERE a.deleteDate = :deleteDate"),
  @NamedQuery(name = "Aerosolcalculator.findByCompanyName", query = "SELECT a FROM Aerosolcalculator a WHERE a.companyName = :companyName"),
  @NamedQuery(name = "Aerosolcalculator.findByPhone", query = "SELECT a FROM Aerosolcalculator a WHERE a.phone = :phone"),
  @NamedQuery(name = "Aerosolcalculator.findByAddress", query = "SELECT a FROM Aerosolcalculator a WHERE a.address = :address"),
  @NamedQuery(name = "Aerosolcalculator.findByEmail", query = "SELECT a FROM Aerosolcalculator a WHERE a.email = :email"),
  @NamedQuery(name = "Aerosolcalculator.findByUnit", query = "SELECT a FROM Aerosolcalculator a WHERE a.unit = :unit"),
  @NamedQuery(name = "Aerosolcalculator.findByCompBrand", query = "SELECT a FROM Aerosolcalculator a WHERE a.compBrand = :compBrand"),
  @NamedQuery(name = "Aerosolcalculator.findByCompProductName", query = "SELECT a FROM Aerosolcalculator a WHERE a.compProductName = :compProductName"),
  @NamedQuery(name = "Aerosolcalculator.findByCompAerosolTotal", query = "SELECT a FROM Aerosolcalculator a WHERE a.compAerosolTotal = :compAerosolTotal"),
  @NamedQuery(name = "Aerosolcalculator.findByCompPropellantAvg", query = "SELECT a FROM Aerosolcalculator a WHERE a.compPropellantAvg = :compPropellantAvg"),
  @NamedQuery(name = "Aerosolcalculator.findByCompPropellant", query = "SELECT a FROM Aerosolcalculator a WHERE a.compPropellant = :compPropellant"),
  @NamedQuery(name = "Aerosolcalculator.findByCompAerosolLiquid", query = "SELECT a FROM Aerosolcalculator a WHERE a.compAerosolLiquid = :compAerosolLiquid"),
  @NamedQuery(name = "Aerosolcalculator.findByCompSpecificGravity", query = "SELECT a FROM Aerosolcalculator a WHERE a.compSpecificGravity = :compSpecificGravity"),
  @NamedQuery(name = "Aerosolcalculator.findByCompUnusedResidue", query = "SELECT a FROM Aerosolcalculator a WHERE a.compUnusedResidue = :compUnusedResidue"),
  @NamedQuery(name = "Aerosolcalculator.findByCompCanYear", query = "SELECT a FROM Aerosolcalculator a WHERE a.compCanYear = :compCanYear"),
  @NamedQuery(name = "Aerosolcalculator.findByCompLiquidRequired", query = "SELECT a FROM Aerosolcalculator a WHERE a.compLiquidRequired = :compLiquidRequired"),
  @NamedQuery(name = "Aerosolcalculator.findByCompProductCost", query = "SELECT a FROM Aerosolcalculator a WHERE a.compProductCost = :compProductCost"),
  @NamedQuery(name = "Aerosolcalculator.findByCompDisposalCost", query = "SELECT a FROM Aerosolcalculator a WHERE a.compDisposalCost = :compDisposalCost"),
  @NamedQuery(name = "Aerosolcalculator.findByCompManpowerCost", query = "SELECT a FROM Aerosolcalculator a WHERE a.compManpowerCost = :compManpowerCost"),
  @NamedQuery(name = "Aerosolcalculator.findByCompTotalAerosolCost", query = "SELECT a FROM Aerosolcalculator a WHERE a.compTotalAerosolCost = :compTotalAerosolCost"),
  @NamedQuery(name = "Aerosolcalculator.findByCompCostLiter", query = "SELECT a FROM Aerosolcalculator a WHERE a.compCostLiter = :compCostLiter"),
  @NamedQuery(name = "Aerosolcalculator.findByCompTotalCost", query = "SELECT a FROM Aerosolcalculator a WHERE a.compTotalCost = :compTotalCost"),
  @NamedQuery(name = "Aerosolcalculator.findByWalterBrand", query = "SELECT a FROM Aerosolcalculator a WHERE a.walterBrand = :walterBrand"),
  @NamedQuery(name = "Aerosolcalculator.findByWalterProductName", query = "SELECT a FROM Aerosolcalculator a WHERE a.walterProductName = :walterProductName"),
  @NamedQuery(name = "Aerosolcalculator.findByWalterAerosolTotal", query = "SELECT a FROM Aerosolcalculator a WHERE a.walterAerosolTotal = :walterAerosolTotal"),
  @NamedQuery(name = "Aerosolcalculator.findByWalterPropellant", query = "SELECT a FROM Aerosolcalculator a WHERE a.walterPropellant = :walterPropellant"),
  @NamedQuery(name = "Aerosolcalculator.findByWalterBulkLiquid", query = "SELECT a FROM Aerosolcalculator a WHERE a.walterBulkLiquid = :walterBulkLiquid"),
  @NamedQuery(name = "Aerosolcalculator.findByWalterUnusedResidue", query = "SELECT a FROM Aerosolcalculator a WHERE a.walterUnusedResidue = :walterUnusedResidue"),
  @NamedQuery(name = "Aerosolcalculator.findByWalterLiquidNeed", query = "SELECT a FROM Aerosolcalculator a WHERE a.walterLiquidNeed = :walterLiquidNeed"),
  @NamedQuery(name = "Aerosolcalculator.findByWalterCostEachContainer", query = "SELECT a FROM Aerosolcalculator a WHERE a.walterCostEachContainer = :walterCostEachContainer"),
  @NamedQuery(name = "Aerosolcalculator.findByWalterCostLiter", query = "SELECT a FROM Aerosolcalculator a WHERE a.walterCostLiter = :walterCostLiter"),
  @NamedQuery(name = "Aerosolcalculator.findByWalterTotalLiquidCost", query = "SELECT a FROM Aerosolcalculator a WHERE a.walterTotalLiquidCost = :walterTotalLiquidCost"),
  @NamedQuery(name = "Aerosolcalculator.findByWalterInitialKitCost", query = "SELECT a FROM Aerosolcalculator a WHERE a.walterInitialKitCost = :walterInitialKitCost"),
  @NamedQuery(name = "Aerosolcalculator.findByWalterQuantityKitsRequired", query = "SELECT a FROM Aerosolcalculator a WHERE a.walterQuantityKitsRequired = :walterQuantityKitsRequired"),
  @NamedQuery(name = "Aerosolcalculator.findByWalterKitCostTotal", query = "SELECT a FROM Aerosolcalculator a WHERE a.walterKitCostTotal = :walterKitCostTotal"),
  @NamedQuery(name = "Aerosolcalculator.findByWalterRefillableSprayerCost", query = "SELECT a FROM Aerosolcalculator a WHERE a.walterRefillableSprayerCost = :walterRefillableSprayerCost"),
  @NamedQuery(name = "Aerosolcalculator.findByWalterQtyRefillableSprayer", query = "SELECT a FROM Aerosolcalculator a WHERE a.walterQtyRefillableSprayer = :walterQtyRefillableSprayer"),
  @NamedQuery(name = "Aerosolcalculator.findByWalterRefillableTotalCost", query = "SELECT a FROM Aerosolcalculator a WHERE a.walterRefillableTotalCost = :walterRefillableTotalCost"),
  @NamedQuery(name = "Aerosolcalculator.findByWalterTotalLiquidUsed", query = "SELECT a FROM Aerosolcalculator a WHERE a.walterTotalLiquidUsed = :walterTotalLiquidUsed"),
  @NamedQuery(name = "Aerosolcalculator.findByWalterDrumsPerYear", query = "SELECT a FROM Aerosolcalculator a WHERE a.walterDrumsPerYear = :walterDrumsPerYear"),
  @NamedQuery(name = "Aerosolcalculator.findByWalterTotalCostYear1", query = "SELECT a FROM Aerosolcalculator a WHERE a.walterTotalCostYear1 = :walterTotalCostYear1"),
  @NamedQuery(name = "Aerosolcalculator.findByWalterTotalCostYear2", query = "SELECT a FROM Aerosolcalculator a WHERE a.walterTotalCostYear2 = :walterTotalCostYear2"),
  @NamedQuery(name = "Aerosolcalculator.findBySavingYearDollardYear1", query = "SELECT a FROM Aerosolcalculator a WHERE a.savingYearDollardYear1 = :savingYearDollardYear1"),
  @NamedQuery(name = "Aerosolcalculator.findBySavingYearPourcentYear1", query = "SELECT a FROM Aerosolcalculator a WHERE a.savingYearPourcentYear1 = :savingYearPourcentYear1"),
  @NamedQuery(name = "Aerosolcalculator.findBySavingYearDollardYear2", query = "SELECT a FROM Aerosolcalculator a WHERE a.savingYearDollardYear2 = :savingYearDollardYear2"),
  @NamedQuery(name = "Aerosolcalculator.findBySavingYearPourcentYear2", query = "SELECT a FROM Aerosolcalculator a WHERE a.savingYearPourcentYear2 = :savingYearPourcentYear2"),
  @NamedQuery(name = "Aerosolcalculator.findByContactName", query = "SELECT a FROM Aerosolcalculator a WHERE a.contactName = :contactName"),
  @NamedQuery(name = "Aerosolcalculator.findByContactTitle", query = "SELECT a FROM Aerosolcalculator a WHERE a.contactTitle = :contactTitle"),
  @NamedQuery(name = "Aerosolcalculator.findByCompunit", query = "SELECT a FROM Aerosolcalculator a WHERE a.compunit = :compunit")})
public class Aerosolcalculator implements Serializable {
  private static final long serialVersionUID = 1L;
  @Id
  @Basic(optional = false)
  @NotNull
  @Column(name = "ID")
  private Long id;
  @Size(max = 255)
  @Column(name = "CREATOR_USER_NAME")
  private String creatorUserName;
  @Column(name = "CREATION_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date creationDate;
  @Column(name = "DELETE_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date deleteDate;
  @Size(max = 255)
  @Column(name = "COMPANY_NAME")
  private String companyName;
  // @Pattern(regexp="^\\(?(\\d{3})\\)?[- ]?(\\d{3})[- ]?(\\d{4})$", message="Invalid phone/fax format, should be as xxx-xxx-xxxx")//if the field contains phone or fax number consider using this annotation to enforce field validation
  @Size(max = 25)
  @Column(name = "PHONE")
  private String phone;
  @Size(max = 255)
  @Column(name = "ADDRESS")
  private String address;
  // @Pattern(regexp="[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?", message="Invalid email")//if the field contains email address consider using this annotation to enforce field validation
  @Size(max = 255)
  @Column(name = "EMAIL")
  private String email;
  @Size(max = 25)
  @Column(name = "UNIT")
  private String unit;
  @Size(max = 255)
  @Column(name = "COMP_BRAND")
  private String compBrand;
  @Size(max = 255)
  @Column(name = "COMP_PRODUCT_NAME")
  private String compProductName;
  // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
  @Column(name = "COMP_AEROSOL_TOTAL")
  private BigDecimal compAerosolTotal;
  @Column(name = "COMP_PROPELLANT_AVG")
  private BigDecimal compPropellantAvg;
  @Column(name = "COMP_PROPELLANT")
  private BigDecimal compPropellant;
  @Column(name = "COMP_AEROSOL_LIQUID")
  private BigDecimal compAerosolLiquid;
  @Column(name = "COMP_SPECIFIC_GRAVITY")
  private BigDecimal compSpecificGravity;
  @Column(name = "COMP_UNUSED_RESIDUE")
  private BigDecimal compUnusedResidue;
  @Column(name = "COMP_CAN_YEAR")
  private Long compCanYear;
  @Column(name = "COMP_LIQUID_REQUIRED")
  private BigDecimal compLiquidRequired;
  @Column(name = "COMP_PRODUCT_COST")
  private BigDecimal compProductCost;
  @Column(name = "COMP_DISPOSAL_COST")
  private BigDecimal compDisposalCost;
  @Column(name = "COMP_MANPOWER_COST")
  private BigDecimal compManpowerCost;
  @Column(name = "COMP_TOTAL_AEROSOL_COST")
  private BigDecimal compTotalAerosolCost;
  @Column(name = "COMP_COST_LITER")
  private BigDecimal compCostLiter;
  @Column(name = "COMP_TOTAL_COST")
  private BigDecimal compTotalCost;
  @Size(max = 255)
  @Column(name = "WALTER_BRAND")
  private String walterBrand;
  @Size(max = 255)
  @Column(name = "WALTER_PRODUCT_NAME")
  private String walterProductName;
  @Column(name = "WALTER_AEROSOL_TOTAL")
  private BigDecimal walterAerosolTotal;
  @Column(name = "WALTER_PROPELLANT")
  private BigDecimal walterPropellant;
  @Column(name = "WALTER_BULK_LIQUID")
  private BigDecimal walterBulkLiquid;
  @Column(name = "WALTER_UNUSED_RESIDUE")
  private BigDecimal walterUnusedResidue;
  @Column(name = "WALTER_LIQUID_NEED")
  private BigDecimal walterLiquidNeed;
  @Column(name = "WALTER_COST_EACH_CONTAINER")
  private BigDecimal walterCostEachContainer;
  @Column(name = "WALTER_COST_LITER")
  private BigDecimal walterCostLiter;
  @Column(name = "WALTER_TOTAL_LIQUID_COST")
  private BigDecimal walterTotalLiquidCost;
  @Column(name = "WALTER_INITIAL_KIT_COST")
  private BigDecimal walterInitialKitCost;
  @Column(name = "WALTER_QUANTITY_KITS_REQUIRED")
  private Integer walterQuantityKitsRequired;
  @Column(name = "WALTER_KIT_COST_TOTAL")
  private BigDecimal walterKitCostTotal;
  @Column(name = "WALTER_REFILLABLE_SPRAYER_COST")
  private BigDecimal walterRefillableSprayerCost;
  @Column(name = "WALTER_QTY_REFILLABLE_SPRAYER")
  private Integer walterQtyRefillableSprayer;
  @Column(name = "WALTER_REFILLABLE_TOTAL_COST")
  private BigDecimal walterRefillableTotalCost;
  @Column(name = "WALTER_TOTAL_LIQUID_USED")
  private BigDecimal walterTotalLiquidUsed;
  @Column(name = "WALTER_DRUMS_PER_YEAR")
  private BigDecimal walterDrumsPerYear;
  @Column(name = "WALTER_TOTAL_COST_YEAR_1")
  private BigDecimal walterTotalCostYear1;
  @Column(name = "WALTER_TOTAL_COST_YEAR_2")
  private BigDecimal walterTotalCostYear2;
  @Column(name = "SAVING_YEAR_DOLLARD_YEAR_1")
  private BigDecimal savingYearDollardYear1;
  @Column(name = "SAVING_YEAR_POURCENT_YEAR_1")
  private BigDecimal savingYearPourcentYear1;
  @Column(name = "SAVING_YEAR_DOLLARD_YEAR_2")
  private BigDecimal savingYearDollardYear2;
  @Column(name = "SAVING_YEAR_POURCENT_YEAR_2")
  private BigDecimal savingYearPourcentYear2;
  @Size(max = 255)
  @Column(name = "CONTACT_NAME")
  private String contactName;
  @Size(max = 256)
  @Column(name = "CONTACT_TITLE")
  private String contactTitle;
  @Size(max = 25)
  @Column(name = "COMPUNIT")
  private String compunit;

  public Aerosolcalculator() {
  }

  public Aerosolcalculator(Long id) {
    this.id = id;
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getCreatorUserName() {
    return creatorUserName;
  }

  public void setCreatorUserName(String creatorUserName) {
    this.creatorUserName = creatorUserName;
  }

  public Date getCreationDate() {
    return creationDate;
  }

  public void setCreationDate(Date creationDate) {
    this.creationDate = creationDate;
  }

  public Date getDeleteDate() {
    return deleteDate;
  }

  public void setDeleteDate(Date deleteDate) {
    this.deleteDate = deleteDate;
  }

  public String getCompanyName() {
    return companyName;
  }

  public void setCompanyName(String companyName) {
    this.companyName = companyName;
  }

  public String getPhone() {
    return phone;
  }

  public void setPhone(String phone) {
    this.phone = phone;
  }

  public String getAddress() {
    return address;
  }

  public void setAddress(String address) {
    this.address = address;
  }

  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public String getUnit() {
    return unit;
  }

  public void setUnit(String unit) {
    this.unit = unit;
  }

  public String getCompBrand() {
    return compBrand;
  }

  public void setCompBrand(String compBrand) {
    this.compBrand = compBrand;
  }

  public String getCompProductName() {
    return compProductName;
  }

  public void setCompProductName(String compProductName) {
    this.compProductName = compProductName;
  }

  public BigDecimal getCompAerosolTotal() {
    return compAerosolTotal;
  }

  public void setCompAerosolTotal(BigDecimal compAerosolTotal) {
    this.compAerosolTotal = compAerosolTotal;
  }

  public BigDecimal getCompPropellantAvg() {
    return compPropellantAvg;
  }

  public void setCompPropellantAvg(BigDecimal compPropellantAvg) {
    this.compPropellantAvg = compPropellantAvg;
  }

  public BigDecimal getCompPropellant() {
    return compPropellant;
  }

  public void setCompPropellant(BigDecimal compPropellant) {
    this.compPropellant = compPropellant;
  }

  public BigDecimal getCompAerosolLiquid() {
    return compAerosolLiquid;
  }

  public void setCompAerosolLiquid(BigDecimal compAerosolLiquid) {
    this.compAerosolLiquid = compAerosolLiquid;
  }

  public BigDecimal getCompSpecificGravity() {
    return compSpecificGravity;
  }

  public void setCompSpecificGravity(BigDecimal compSpecificGravity) {
    this.compSpecificGravity = compSpecificGravity;
  }

  public BigDecimal getCompUnusedResidue() {
    return compUnusedResidue;
  }

  public void setCompUnusedResidue(BigDecimal compUnusedResidue) {
    this.compUnusedResidue = compUnusedResidue;
  }

  public Long getCompCanYear() {
    return compCanYear;
  }

  public void setCompCanYear(Long compCanYear) {
    this.compCanYear = compCanYear;
  }

  public BigDecimal getCompLiquidRequired() {
    return compLiquidRequired;
  }

  public void setCompLiquidRequired(BigDecimal compLiquidRequired) {
    this.compLiquidRequired = compLiquidRequired;
  }

  public BigDecimal getCompProductCost() {
    return compProductCost;
  }

  public void setCompProductCost(BigDecimal compProductCost) {
    this.compProductCost = compProductCost;
  }

  public BigDecimal getCompDisposalCost() {
    return compDisposalCost;
  }

  public void setCompDisposalCost(BigDecimal compDisposalCost) {
    this.compDisposalCost = compDisposalCost;
  }

  public BigDecimal getCompManpowerCost() {
    return compManpowerCost;
  }

  public void setCompManpowerCost(BigDecimal compManpowerCost) {
    this.compManpowerCost = compManpowerCost;
  }

  public BigDecimal getCompTotalAerosolCost() {
    return compTotalAerosolCost;
  }

  public void setCompTotalAerosolCost(BigDecimal compTotalAerosolCost) {
    this.compTotalAerosolCost = compTotalAerosolCost;
  }

  public BigDecimal getCompCostLiter() {
    return compCostLiter;
  }

  public void setCompCostLiter(BigDecimal compCostLiter) {
    this.compCostLiter = compCostLiter;
  }

  public BigDecimal getCompTotalCost() {
    return compTotalCost;
  }

  public void setCompTotalCost(BigDecimal compTotalCost) {
    this.compTotalCost = compTotalCost;
  }

  public String getWalterBrand() {
    return walterBrand;
  }

  public void setWalterBrand(String walterBrand) {
    this.walterBrand = walterBrand;
  }

  public String getWalterProductName() {
    return walterProductName;
  }

  public void setWalterProductName(String walterProductName) {
    this.walterProductName = walterProductName;
  }

  public BigDecimal getWalterAerosolTotal() {
    return walterAerosolTotal;
  }

  public void setWalterAerosolTotal(BigDecimal walterAerosolTotal) {
    this.walterAerosolTotal = walterAerosolTotal;
  }

  public BigDecimal getWalterPropellant() {
    return walterPropellant;
  }

  public void setWalterPropellant(BigDecimal walterPropellant) {
    this.walterPropellant = walterPropellant;
  }

  public BigDecimal getWalterBulkLiquid() {
    return walterBulkLiquid;
  }

  public void setWalterBulkLiquid(BigDecimal walterBulkLiquid) {
    this.walterBulkLiquid = walterBulkLiquid;
  }

  public BigDecimal getWalterUnusedResidue() {
    return walterUnusedResidue;
  }

  public void setWalterUnusedResidue(BigDecimal walterUnusedResidue) {
    this.walterUnusedResidue = walterUnusedResidue;
  }

  public BigDecimal getWalterLiquidNeed() {
    return walterLiquidNeed;
  }

  public void setWalterLiquidNeed(BigDecimal walterLiquidNeed) {
    this.walterLiquidNeed = walterLiquidNeed;
  }

  public BigDecimal getWalterCostEachContainer() {
    return walterCostEachContainer;
  }

  public void setWalterCostEachContainer(BigDecimal walterCostEachContainer) {
    this.walterCostEachContainer = walterCostEachContainer;
  }

  public BigDecimal getWalterCostLiter() {
    return walterCostLiter;
  }

  public void setWalterCostLiter(BigDecimal walterCostLiter) {
    this.walterCostLiter = walterCostLiter;
  }

  public BigDecimal getWalterTotalLiquidCost() {
    return walterTotalLiquidCost;
  }

  public void setWalterTotalLiquidCost(BigDecimal walterTotalLiquidCost) {
    this.walterTotalLiquidCost = walterTotalLiquidCost;
  }

  public BigDecimal getWalterInitialKitCost() {
    return walterInitialKitCost;
  }

  public void setWalterInitialKitCost(BigDecimal walterInitialKitCost) {
    this.walterInitialKitCost = walterInitialKitCost;
  }

  public Integer getWalterQuantityKitsRequired() {
    return walterQuantityKitsRequired;
  }

  public void setWalterQuantityKitsRequired(Integer walterQuantityKitsRequired) {
    this.walterQuantityKitsRequired = walterQuantityKitsRequired;
  }

  public BigDecimal getWalterKitCostTotal() {
    return walterKitCostTotal;
  }

  public void setWalterKitCostTotal(BigDecimal walterKitCostTotal) {
    this.walterKitCostTotal = walterKitCostTotal;
  }

  public BigDecimal getWalterRefillableSprayerCost() {
    return walterRefillableSprayerCost;
  }

  public void setWalterRefillableSprayerCost(BigDecimal walterRefillableSprayerCost) {
    this.walterRefillableSprayerCost = walterRefillableSprayerCost;
  }

  public Integer getWalterQtyRefillableSprayer() {
    return walterQtyRefillableSprayer;
  }

  public void setWalterQtyRefillableSprayer(Integer walterQtyRefillableSprayer) {
    this.walterQtyRefillableSprayer = walterQtyRefillableSprayer;
  }

  public BigDecimal getWalterRefillableTotalCost() {
    return walterRefillableTotalCost;
  }

  public void setWalterRefillableTotalCost(BigDecimal walterRefillableTotalCost) {
    this.walterRefillableTotalCost = walterRefillableTotalCost;
  }

  public BigDecimal getWalterTotalLiquidUsed() {
    return walterTotalLiquidUsed;
  }

  public void setWalterTotalLiquidUsed(BigDecimal walterTotalLiquidUsed) {
    this.walterTotalLiquidUsed = walterTotalLiquidUsed;
  }

  public BigDecimal getWalterDrumsPerYear() {
    return walterDrumsPerYear;
  }

  public void setWalterDrumsPerYear(BigDecimal walterDrumsPerYear) {
    this.walterDrumsPerYear = walterDrumsPerYear;
  }

  public BigDecimal getWalterTotalCostYear1() {
    return walterTotalCostYear1;
  }

  public void setWalterTotalCostYear1(BigDecimal walterTotalCostYear1) {
    this.walterTotalCostYear1 = walterTotalCostYear1;
  }

  public BigDecimal getWalterTotalCostYear2() {
    return walterTotalCostYear2;
  }

  public void setWalterTotalCostYear2(BigDecimal walterTotalCostYear2) {
    this.walterTotalCostYear2 = walterTotalCostYear2;
  }

  public BigDecimal getSavingYearDollardYear1() {
    return savingYearDollardYear1;
  }

  public void setSavingYearDollardYear1(BigDecimal savingYearDollardYear1) {
    this.savingYearDollardYear1 = savingYearDollardYear1;
  }

  public BigDecimal getSavingYearPourcentYear1() {
    return savingYearPourcentYear1;
  }

  public void setSavingYearPourcentYear1(BigDecimal savingYearPourcentYear1) {
    this.savingYearPourcentYear1 = savingYearPourcentYear1;
  }

  public BigDecimal getSavingYearDollardYear2() {
    return savingYearDollardYear2;
  }

  public void setSavingYearDollardYear2(BigDecimal savingYearDollardYear2) {
    this.savingYearDollardYear2 = savingYearDollardYear2;
  }

  public BigDecimal getSavingYearPourcentYear2() {
    return savingYearPourcentYear2;
  }

  public void setSavingYearPourcentYear2(BigDecimal savingYearPourcentYear2) {
    this.savingYearPourcentYear2 = savingYearPourcentYear2;
  }

  public String getContactName() {
    return contactName;
  }

  public void setContactName(String contactName) {
    this.contactName = contactName;
  }

  public String getContactTitle() {
    return contactTitle;
  }

  public void setContactTitle(String contactTitle) {
    this.contactTitle = contactTitle;
  }

  public String getCompunit() {
    return compunit;
  }

  public void setCompunit(String compunit) {
    this.compunit = compunit;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (id != null ? id.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof Aerosolcalculator)) {
      return false;
    }
    Aerosolcalculator other = (Aerosolcalculator) object;
    if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.walter.Aerosolcalculator[ id=" + id + " ]";
  }

}
