/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.service.impl;

import com.savoirfairelinux.walter.dao.idb.OoBabelMembers;
import com.savoirfairelinux.walter.dao.idb.OoClasses;
import com.savoirfairelinux.walter.dao.idb.OoClassesMembers;
import com.savoirfairelinux.walter.dao.idb.OoInstances;
import com.savoirfairelinux.walter.dao.idb.OoInstancesMembersValues;
import com.savoirfairelinux.walter.dao.idb.OoInstancesRelationships;
import com.savoirfairelinux.walter.dao.idb.TemplateItem;
import com.savoirfairelinux.walter.dao.idb.TemplateTitle;
import com.savoirfairelinux.walter.dao.idb.WalterProductsCountries;
import com.savoirfairelinux.walter.dao.idb.WalterProductsDocuments;
import com.savoirfairelinux.walter.dao.idb.WalterProductsImages;
import com.savoirfairelinux.walter.dao.idb.WalterTvvideos;
import com.savoirfairelinux.walter.dao.waltercb.Cnt;
import com.savoirfairelinux.walter.dao.waltercb.CntTxt;
import com.savoirfairelinux.walter.dao.waltercb.ErTxt;
import com.savoirfairelinux.walter.dao.waltercb.IdeaTxt;
import com.savoirfairelinux.walter.service.ProductDashboardBeanRemote;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import javax.annotation.security.PermitAll;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
//import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author jsgill
 */
@Stateless(name = "ProductDashboardBean")
@TransactionManagement(TransactionManagementType.CONTAINER)
@PermitAll
@LocalBean
public class ProductDashboardBean implements ProductDashboardBeanRemote{
    public static final Logger LOG = Logger.getLogger(ProductDashboardBean.class.getCanonicalName());
    @PersistenceContext(unitName = "waltershare")
    EntityManager entityManager;
    @EJB
    SingletonBean singletonBean;
    @EJB
    WalterBean walterBean;

    @Override
//    @Interceptors(DebugInterceptor.class)
    public List<OoClasses> getFranchiseList() throws Exception {

      List<OoClasses> result = null;
      try {

        result = entityManager
                .createQuery(singletonBean.getProductDashboardQuery("product.dashboard.walter.franchises"), OoClasses.class)
                .getResultList();
      } catch (Exception e) {
        LOG.severe("getFranchiseList not found: " + e.getMessage());
        throw new Exception(e.getMessage());
      }
      return result;
    }

    @Override
//    @Interceptors(DebugInterceptor.class)
    public OoBabelMembers getFranchiseTranslation(String languageAbbreviation, String classguid) throws Exception {

      OoBabelMembers result = null;
      try {

        result = entityManager
                .createQuery(singletonBean.getProductDashboardQuery("product.dashboard.walter.franchises.translation"), OoBabelMembers.class)
                .setParameter("languageAbbreviation", languageAbbreviation)
                .setParameter("classGuid", classguid)
                .getSingleResult();
      } catch (Exception e) {
        LOG.severe("getFranchiseTranslation not found: " + e.getMessage());
        throw new Exception(e.getMessage());
      }
      return result;
    }    
    
    @Override
//    @Interceptors(DebugInterceptor.class)
    public OoInstances getFranchiseInstance(String classguid) throws Exception {

      OoInstances result = null;
      try {

        result = entityManager
                .createQuery(singletonBean.getProductDashboardQuery("product.dashboard.walter.franchisesInstance"), OoInstances.class)
                .setParameter("classguid", classguid)
                .getSingleResult();


      } catch (Exception e) {
        LOG.severe("getFranchiseInstance not found: " + e.getMessage());
        throw new Exception(e.getMessage());
      }
      return result;
    }

    @Override
//    @Interceptors(DebugInterceptor.class)
    public List<OoInstances> getTradeName(String franchiseGuid, String countryCode) throws Exception {

      List<OoInstances> result = null;
      try {

        result = entityManager
                .createQuery(singletonBean.getProductDashboardQuery("product.dashboard.walter.tradenames"), OoInstances.class)
                .setParameter("franchiseGuid", franchiseGuid)
                .setParameter("countryCode", countryCode)
                .getResultList();


      } catch (Exception e) {
        LOG.severe("getTradeName not found: " + e.getMessage());
        throw new Exception(e.getMessage());
      }
      return result;
    }

    @Override
//    @Interceptors(DebugInterceptor.class)
    public OoBabelMembers getInstanceNameTranslation(String languageAbbreviation, String instanceName, String instanceGuid) throws Exception {

      OoBabelMembers result = new OoBabelMembers();
      try {

        result = entityManager
                .createQuery(singletonBean.getProductDashboardQuery("product.dashboard.walter.instanceName.translation"), OoBabelMembers.class)
                .setParameter("languageAbbreviation", languageAbbreviation)
                .setParameter("instanceName", instanceName)
                .setParameter("instanceGuid", instanceGuid)
                .getSingleResult();
      } catch (Exception e) {
        LOG.warning("getInstanceNameTranslation not found for "+instanceName+": "+ instanceGuid + " " + e.getMessage());
      }
      return result;
    }    

    public OoBabelMembers getProductInfoTranslation(String languageAbbreviation, String countryCode, String fieldSearch, String productGuid) throws Exception {

      OoBabelMembers result = new OoBabelMembers();
      try {

        result = entityManager
                .createQuery(singletonBean.getProductDashboardQuery("product.dashboard.walter.productInfo.translation"), OoBabelMembers.class)
                .setParameter("languageAbbreviation", languageAbbreviation)
                .setParameter("countryCode", countryCode)
                .setParameter("fieldSearch", fieldSearch)
                .setParameter("productGuid", productGuid)
                .getSingleResult();

      } catch (Exception e) {
        LOG.warning("getProductInfoTranslation not found for "+fieldSearch+": "+ productGuid + " " + e.getMessage());
      }
      return result;
    }

    @Override
//    @Interceptors(DebugInterceptor.class)
    public WalterProductsCountries getWalterProductCountries(String countryCode, String tradenameGuid) throws Exception {

      List<WalterProductsCountries> result = new ArrayList<WalterProductsCountries>();
      try {

        result = entityManager
                .createQuery(singletonBean.getProductDashboardQuery("product.dashboard.walter.walterProductCountries"), WalterProductsCountries.class)
                .setParameter("countryCode", countryCode)
                .setParameter("tradenameGuid", tradenameGuid)
                .getResultList();

        if ( result.size() > 0 ){
          return result.get(0);
        }


      } catch (Exception e) {
        LOG.warning("getWalterProductCountries not found: "+ tradenameGuid + " " + e.getMessage());
        return new WalterProductsCountries();
      }
      return new WalterProductsCountries();

    }    

    @Override
//    @Interceptors(DebugInterceptor.class)
    public List<WalterProductsImages> getWalterProductImages(String countryCode, String productNumber) throws Exception {

      List<WalterProductsImages> result = new ArrayList<WalterProductsImages>();
      try {

        result = entityManager
                .createQuery(singletonBean.getProductDashboardQuery("product.dashboard.walter.walterProductImages"), WalterProductsImages.class)
                .setParameter("countryCode", countryCode)
                .setParameter("productNumber", productNumber)
                .getResultList();

      } catch (Exception e) {
        LOG.warning("getWalterProductImages not found: "+ productNumber + " " + e.getMessage());
      }
      return result;

    } 

    @Override
//    @Interceptors(DebugInterceptor.class)
    public List<String> getWalterProductRelation(String productNumber, String relationType, String className, String languageAbbreviation) throws Exception {

      List<OoInstances> ooInstanceList = new ArrayList<OoInstances>();
      List<String> result = new ArrayList<String>();
      try {

        ooInstanceList = entityManager
                .createQuery(singletonBean.getProductDashboardQuery("product.dashboard.walter.productrelation"), OoInstances.class)
                .setParameter("productNumber", productNumber)
                .setParameter("relationType", relationType)
                .getResultList();


        for ( OoInstances ooInstances : ooInstanceList ){
          OoBabelMembers OoBabelMembers = getInstanceNameTranslation(languageAbbreviation, className, ooInstances.getInstanceguid());

          if ( OoBabelMembers != null && OoBabelMembers.getMembervalue() != null && !OoBabelMembers.getMembervalue().equals("") ){
            result.add(OoBabelMembers.getMembervalue());
          }else{
            result.add(ooInstances.getInstancename());
          }
        }

      } catch (Exception e) {
        LOG.warning("getWalterProductRelation not found: "+ productNumber + " " + e.getMessage());
      }
      return result;

    } 

    @Override
//    @Interceptors(DebugInterceptor.class)
    public List<WalterTvvideos> getWalterProductVideo(WalterProductsCountries wpc, String languageAbbreviation) throws Exception {

      List<WalterTvvideos> result = new ArrayList<WalterTvvideos>();
      try {

        result = entityManager
                .createQuery(singletonBean.getProductDashboardQuery("product.dashboard.walter.productvideo"), WalterTvvideos.class)
                .setParameter("wpc", wpc)
                .setParameter("lang", languageAbbreviation)
                .getResultList();

      } catch (Exception e) {
        LOG.warning("getWalterProductVideo not found: " + e.getMessage());
      }
      return result;

    } 

    @Override
//    @Interceptors(DebugInterceptor.class)
    public List<WalterProductsDocuments> getWalterProductDocument(WalterProductsCountries wpc, String languageAbbreviation) throws Exception {

      List<WalterProductsDocuments> result = new ArrayList<WalterProductsDocuments>();
      try {

        result = entityManager
                .createQuery(singletonBean.getProductDashboardQuery("product.dashboard.walter.productdocument"), WalterProductsDocuments.class)
                .setParameter("wpc", wpc)
                .setParameter("lang", languageAbbreviation)
                .getResultList();

      } catch (Exception e) {
        LOG.warning("getWalterProductDocument not found: " + e.getMessage());
      }
      return result;

    } 

    @Override
//    @Interceptors(DebugInterceptor.class)
    public List<Object[]> getWalterProductListTool(String tradeGuid, String countryCode, String languageAbbreviation) throws Exception {

      List<Object[]> result = new ArrayList<Object[]>();
      try {

        result = entityManager
                .createQuery(singletonBean.getProductDashboardQuery("product.dashboard.walter.productListTool"), Object[].class)
                .setParameter("country", countryCode)
                .setParameter("tradeGuid", tradeGuid)
                .getResultList();

      } catch (Exception e) {
        LOG.warning("getWalterProductListTool not found: " + e.getMessage());
      }
      return result;

    } 

    @Override
//    @Interceptors(DebugInterceptor.class)
    public List<Object[]> getWalterProductListToolImage(String tradeGuid, String countryCode, String instanceGuid) throws Exception {

      List<Object[]> result = new ArrayList<Object[]>();
      try {

        result = entityManager
                .createQuery(singletonBean.getProductDashboardQuery("product.dashboard.walter.productListToolImage"), Object[].class)
                .setParameter("country", countryCode)
//                .setParameter("tradeGuid", tradeGuid)
                .setParameter("instanceGuid", instanceGuid)
                .getResultList();

      } catch (Exception e) {
        LOG.warning("getWalterProductListToolImage not found: " + e.getMessage());
      }
      return result;

    }

    @Override
//    @Interceptors(DebugInterceptor.class)
    public List<TemplateTitle> getWalterProductTemplateTitle(String templateName, short rowId) throws Exception {

      List<TemplateTitle> result = new ArrayList<TemplateTitle>();
      try {

        result = entityManager
                .createQuery(singletonBean.getProductDashboardQuery("product.dashboard.walter.title"), TemplateTitle.class)
                .setParameter("templateName", templateName)
                .setParameter("rowId", rowId)
                .getResultList();

      } catch (Exception e) {
        LOG.warning("getWalterProductTemplateTitle not found: " + e.getMessage());
      }
      return result;

    }    
    
    @Override
//    @Interceptors(DebugInterceptor.class)
    public List<TemplateItem> getWalterProductTemplateItem(String templateName, short rowId, short columnId) throws Exception {

      List<TemplateItem> result = new ArrayList<TemplateItem>();
      try {

        result = entityManager
                .createQuery(singletonBean.getProductDashboardQuery("product.dashboard.walter.templateItem"), TemplateItem.class)
                .setParameter("templateName", templateName)
                .setParameter("rowId", rowId)
                .setParameter("columnId", columnId)
                .getResultList();

      } catch (Exception e) {
        LOG.warning("getWalterProductTemplateItem not found: " + e.getMessage());
      }
      return result;

    }  

    
    @Override
//    @Interceptors(DebugInterceptor.class)
    public OoClassesMembers getOoClassesMembers(String memberguid) throws Exception {

      OoClassesMembers result = new OoClassesMembers();
      try {

        Query query = entityManager.createNamedQuery(OoClassesMembers.class.getSimpleName()+".findByMemberguid").setParameter("memberguid", memberguid);
        
        result = (OoClassesMembers) query.getSingleResult();

      } catch (Exception e) {
        LOG.warning("getOoClassesMembers not found: " + memberguid + " error: " + e.getMessage());
      }
      return result;

    }      
    
    @Override
//    @Interceptors(DebugInterceptor.class)
    public WalterProductsDocuments getWalterProductDocument(WalterProductsCountries wpc, String languageAbbreviation, String documentType) throws Exception {

      WalterProductsDocuments result = new WalterProductsDocuments();
      try {

        result = entityManager
                .createQuery(singletonBean.getProductDashboardQuery("product.dashboard.walter.productdocumentByType"), WalterProductsDocuments.class)
                .setParameter("wpc", wpc)
                .setParameter("lang", languageAbbreviation)
                .setParameter("documentType", documentType)
                .getSingleResult();

      } catch (Exception e) {
        LOG.warning("WalterProductsDocuments not found: " + e.getMessage());
      }
      return result;

    }
    
    @Override
//    @Interceptors(DebugInterceptor.class)
    public Object[] getWalterProductMesure(WalterProductsCountries wpc, String memberName, String unitType) throws Exception {

      Object[] result = null;

      try {
        result = entityManager
                .createQuery(singletonBean.getProductDashboardQuery("product.dashboard.walter.productMesureInfo"), Object[].class)
                .setParameter("productVersion", wpc.getProductversionguid().getProductversionguid())
                .setParameter("memberName", memberName)
                .setParameter("unitType", unitType)
                .getSingleResult();

      } catch (Exception e) {
        LOG.warning("getWalterProductMesure not found with memberName: " + memberName + " " + e.getMessage());
      }
      return result;

    }         

    @Override
//    @Interceptors(DebugInterceptor.class)
    public String getWalterProductMesureUniversal(WalterProductsCountries wpc, String memberName) throws Exception {

      String result = "";
      List<String> tmp = new ArrayList<String>();

      try {

        tmp  = entityManager
                .createQuery(singletonBean.getProductDashboardQuery("product.dashboard.walter.productMesureInfoUniversal"), String.class)
                .setParameter("productVersion", wpc.getProductversionguid().getProductversionguid())
                .setParameter("memberName", memberName)
                .getResultList();
        
        if ( tmp != null && tmp.size() > 0 ){
          result = tmp.get(0);
        }
        
      } catch (Exception e) {
        LOG.warning("getWalterProductMesureIniversal not found: " + e.getMessage());
      }
      return result;

    }     

    @Override
//    @Interceptors(DebugInterceptor.class)
    public List<WalterProductsCountries> getWalterProductListByTradeGuidToolGuid(String countryCode, String tradenameGuid, String toolGuid, String template) throws Exception {

      List<WalterProductsCountries> result = new ArrayList<WalterProductsCountries>();

      try {
        
        result  = entityManager
                .createQuery(singletonBean.getProductDashboardQuery("product.dashboard.walter.productList"), WalterProductsCountries.class)
                .setParameter("countryCode", countryCode)
                .setParameter("tradenameGuid", tradenameGuid)
                .setParameter("toolGuid", toolGuid)
                .setParameter("template", template)
                .getResultList();
        
      } catch (Exception e) {
        LOG.warning("getWalterProductListByTradeGuidToolGuid not found: " + e.getMessage());
      }
      return result;

    }      
    
    @Override
//    @Interceptors(DebugInterceptor.class)
    public List<CntTxt> getSolutionReport(String fanchiseGuid, String tradenameGuid, Long langId){
      List<CntTxt> cntList = new ArrayList<CntTxt>();
      
      try {

        cntList  = entityManager
                .createQuery(singletonBean.getProductDashboardQuery("product.dashboard.walter.solutionReport"), CntTxt.class)
                .setParameter("fanchiseGuid", fanchiseGuid)
                .setParameter("tradenameGuid", tradenameGuid)
                .setParameter("langId", langId)
                .setMaxResults(41).getResultList();
        
      } catch (Exception e) {
        LOG.warning("getSolutionReport not found: " + e.getMessage());
      }
     
      return cntList;
    }
    
    @Override
//    @Interceptors(DebugInterceptor.class)
    public List<ErTxt> getLabReport(String fanchiseGuid, String tradenameGuid, Long langId){
      List<ErTxt> erTxtList = new ArrayList<ErTxt>();
      
      try {

        erTxtList  = entityManager
                    .createQuery(singletonBean.getProductDashboardQuery("product.dashboard.walter.labReport"), ErTxt.class)
                    .setParameter("fanchiseGuid", fanchiseGuid)
                    .setParameter("tradenameGuid", tradenameGuid)
                    .setParameter("langId", langId)
                    .setMaxResults(41).getResultList();
        
      } catch (Exception e) {
        LOG.warning("getLabReport not found: " + e.getMessage());
      }
     
      return erTxtList;
    }    

        @Override
//    @Interceptors(DebugInterceptor.class)
    public List<IdeaTxt> getNewIdea(String fanchiseGuid, String tradenameGuid, Long langId){
      List<IdeaTxt> erTxtList = new ArrayList<IdeaTxt>();
      
      try {

        erTxtList  = entityManager
                    .createQuery(singletonBean.getProductDashboardQuery("product.dashboard.walter.newIdea"), IdeaTxt.class)
                    .setParameter("fanchiseGuid", fanchiseGuid)
                    .setParameter("tradenameGuid", tradenameGuid)
                    .setParameter("langId", langId)
                    .setMaxResults(41).getResultList();
        
      } catch (Exception e) {
        LOG.warning("getNewIdea not found: " + e.getMessage());
      }
     
      return erTxtList;
    }   

    @Override
//    @Interceptors(DebugInterceptor.class)
    public OoInstances getTradeNameInstance(String classguid, String tradeNameguid) throws Exception {

      OoInstances result = null;
      try {

        result = entityManager
                .createQuery(singletonBean.getProductDashboardQuery("product.dashboard.walter.TradeNameInstance"), OoInstances.class)
//                .setParameter("classguid", classguid)
                .setParameter("tradenameguid", tradeNameguid)
                .getSingleResult();


      } catch (Exception e) {
        LOG.severe("getTradeNameInstance not found: " + e.getMessage());
        throw new Exception(e.getMessage());
      }
      return result;
    }        

    @Override
//    @Interceptors(DebugInterceptor.class)
    public List<OoInstances> getActionInstance(String countryCode, String tradenameGuid) throws Exception {

      List<OoInstances> result = new ArrayList<OoInstances>();
      try {

        result = entityManager
                .createQuery(singletonBean.getProductDashboardQuery("prodcut.dashboard.walter.action"), OoInstances.class)
                .setParameter("countryCode", countryCode)
                .setParameter("tradenameGuid", tradenameGuid)
                .getResultList();


      } catch (Exception e) {
        LOG.severe("getTradeNameInstance not found: " + e.getMessage());
        throw new Exception(e.getMessage());
      }
      return result;
    }

    @Override
//    @Interceptors(DebugInterceptor.class)
    public List<OoInstances> getToolMaterialByFranchiseAction(String countryCode, String franchiseGuid, String actionGuid) throws Exception {

      List<OoInstances> result = new ArrayList<OoInstances>();
      try {

        result = entityManager
                .createQuery(singletonBean.getProductDashboardQuery("product.dashboard.walter.productToolByFranchiseAction"), OoInstances.class)
                .setParameter("countryCode", countryCode)
                .setParameter("franchiseGuid", franchiseGuid)
                .setParameter("actionGuid", actionGuid)
                .getResultList();


      } catch (Exception e) {
        LOG.severe("getToolMaterialByFranchiseAction not found: " + e.getMessage());
        throw new Exception(e.getMessage());
      }
      return result;
    }

    @Override
//    @Interceptors(DebugInterceptor.class)
    public List<OoInstances> getTradeNameByFranchiseActionTool(String countryCode, String franchiseGuid, String actionGuid, String toolGuid) throws Exception {

      List<OoInstances> result = new ArrayList<OoInstances>();
      try {

        result = entityManager
                .createQuery(singletonBean.getProductDashboardQuery("product.dashboard.walter.productTradeNameByFranchiseActionTool"), OoInstances.class)
                .setParameter("countryCode", countryCode)
                .setParameter("franchiseGuid", franchiseGuid)
                .setParameter("actionGuid", actionGuid)
                .setParameter("toolGuid", toolGuid)
                .getResultList();


      } catch (Exception e) {
        LOG.severe("getTradeNameByFranchiseActionTool not found: " + e.getMessage());
        throw new Exception(e.getMessage());
      }
      return result;
    }

}
