/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "IDEA_COUNTER", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "IdeaCounter.findAll", query = "SELECT i FROM IdeaCounter i"),
    @NamedQuery(name = "IdeaCounter.findByIdeaId", query = "SELECT i FROM IdeaCounter i WHERE i.ideaCounterPK.ideaId = :ideaId"),
    @NamedQuery(name = "IdeaCounter.findByUserName", query = "SELECT i FROM IdeaCounter i WHERE i.ideaCounterPK.userName = :userName"),
    @NamedQuery(name = "IdeaCounter.findByCounter", query = "SELECT i FROM IdeaCounter i WHERE i.counter = :counter"),
    @NamedQuery(name = "IdeaCounter.findByFirstRead", query = "SELECT i FROM IdeaCounter i WHERE i.firstRead = :firstRead"),
    @NamedQuery(name = "IdeaCounter.findByLastRead", query = "SELECT i FROM IdeaCounter i WHERE i.lastRead = :lastRead")})
public class IdeaCounter implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected IdeaCounterPK ideaCounterPK;
    private Long counter;
    @Column(name = "FIRST_READ")
    @Temporal(TemporalType.TIMESTAMP)
    private Date firstRead;
    @Column(name = "LAST_READ")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastRead;
    @JoinColumn(name = "IDEA_ID", referencedColumnName = "IDEA_ID", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Idea idea;

    public IdeaCounter() {
    }

    public IdeaCounter(IdeaCounterPK ideaCounterPK) {
        this.ideaCounterPK = ideaCounterPK;
    }

    public IdeaCounter(long ideaId, String userName) {
        this.ideaCounterPK = new IdeaCounterPK(ideaId, userName);
    }

    public IdeaCounterPK getIdeaCounterPK() {
        return ideaCounterPK;
    }

    public void setIdeaCounterPK(IdeaCounterPK ideaCounterPK) {
        this.ideaCounterPK = ideaCounterPK;
    }

    public Long getCounter() {
        return counter;
    }

    public void setCounter(Long counter) {
        this.counter = counter;
    }

    public Date getFirstRead() {
        return firstRead;
    }

    public void setFirstRead(Date firstRead) {
        this.firstRead = firstRead;
    }

    public Date getLastRead() {
        return lastRead;
    }

    public void setLastRead(Date lastRead) {
        this.lastRead = lastRead;
    }

    public Idea getIdea() {
        return idea;
    }

    public void setIdea(Idea idea) {
        this.idea = idea;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (ideaCounterPK != null ? ideaCounterPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof IdeaCounter)) {
            return false;
        }
        IdeaCounter other = (IdeaCounter) object;
        if ((this.ideaCounterPK == null && other.ideaCounterPK != null) || (this.ideaCounterPK != null && !this.ideaCounterPK.equals(other.ideaCounterPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.IdeaCounter[ ideaCounterPK=" + ideaCounterPK + " ]";
    }
    
}
