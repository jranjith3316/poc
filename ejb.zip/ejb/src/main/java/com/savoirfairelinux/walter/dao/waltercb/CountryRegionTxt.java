/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "COUNTRY_REGION_TXT", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CountryRegionTxt.findAll", query = "SELECT c FROM CountryRegionTxt c"),
    @NamedQuery(name = "CountryRegionTxt.findByCountryId", query = "SELECT c FROM CountryRegionTxt c WHERE c.countryRegionTxtPK.countryId = :countryId"),
    @NamedQuery(name = "CountryRegionTxt.findByRegionCode", query = "SELECT c FROM CountryRegionTxt c WHERE c.countryRegionTxtPK.regionCode = :regionCode"),
    @NamedQuery(name = "CountryRegionTxt.findByLangId", query = "SELECT c FROM CountryRegionTxt c WHERE c.countryRegionTxtPK.langId = :langId"),
    @NamedQuery(name = "CountryRegionTxt.findByRegionDesc", query = "SELECT c FROM CountryRegionTxt c WHERE c.regionDesc = :regionDesc")})
public class CountryRegionTxt implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected CountryRegionTxtPK countryRegionTxtPK;
    @Size(max = 40)
    @Column(name = "REGION_DESC")
    private String regionDesc;
    @JoinColumns({
        @JoinColumn(name = "COUNTRY_ID", referencedColumnName = "COUNTRY_ID", insertable = false, updatable = false),
        @JoinColumn(name = "REGION_CODE", referencedColumnName = "REGION_CODE", insertable = false, updatable = false)})
    @ManyToOne(optional = false)
    private CountryRegion countryRegion;

    public CountryRegionTxt() {
    }

    public CountryRegionTxt(CountryRegionTxtPK countryRegionTxtPK) {
        this.countryRegionTxtPK = countryRegionTxtPK;
    }

    public CountryRegionTxt(long countryId, String regionCode, long langId) {
        this.countryRegionTxtPK = new CountryRegionTxtPK(countryId, regionCode, langId);
    }

    public CountryRegionTxtPK getCountryRegionTxtPK() {
        return countryRegionTxtPK;
    }

    public void setCountryRegionTxtPK(CountryRegionTxtPK countryRegionTxtPK) {
        this.countryRegionTxtPK = countryRegionTxtPK;
    }

    public String getRegionDesc() {
        return regionDesc;
    }

    public void setRegionDesc(String regionDesc) {
        this.regionDesc = regionDesc;
    }

    public CountryRegion getCountryRegion() {
        return countryRegion;
    }

    public void setCountryRegion(CountryRegion countryRegion) {
        this.countryRegion = countryRegion;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (countryRegionTxtPK != null ? countryRegionTxtPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CountryRegionTxt)) {
            return false;
        }
        CountryRegionTxt other = (CountryRegionTxt) object;
        if ((this.countryRegionTxtPK == null && other.countryRegionTxtPK != null) || (this.countryRegionTxtPK != null && !this.countryRegionTxtPK.equals(other.countryRegionTxtPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.CountryRegionTxt[ countryRegionTxtPK=" + countryRegionTxtPK + " ]";
    }
    
}
