/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import java.math.BigDecimal;

/**
 *
 * @author jderuere
 */
@Entity
@Table(name = "ER_TRIAL_PRODUCT", schema = DatabaseConstants.WALTERCB_SCHEMA)
public class ErTrialProduct implements Serializable {
    @Id
    @NotNull
    @Column(name = "TRIAL_PRODUCT_ID", nullable = false)
    @GeneratedValue(generator = "TRIAL_PRODUCT_ID_SEQ", strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "TRIAL_PRODUCT_ID_SEQ", sequenceName = "TRIAL_PRODUCT_ID_SEQ", schema = DatabaseConstants.WALTERCB_SCHEMA, allocationSize = 1)
    private Long trialProductId;
    @JoinColumn(name = "TRIAL_ID", referencedColumnName = "TRIAL_ID")
    @ManyToOne(optional = false)
    private ErTrial erTrial;
    @Size(min = 1, max = 255)
    @Column(name = "FRANCHISEGUID")
    private String franchiseguid;
    @Size(min = 1, max = 50)
    @Column(name = "TRADENAMEGUID")
    private String tradenameguid;
    @Column(name = "CONCENTRATION", precision = 5, scale = 2)
    private BigDecimal concentration;
    @Column(name = "OTHER_PRODUCT")
    private String otherProduct;
    @Transient
    private String franchiseName;
    @Transient
    private String tradeName;

    public ErTrialProduct() {
    }

    public Long getTrialProductId() {
        return trialProductId;
    }

    public void setTrialProductId(Long trialProductId) {
        this.trialProductId = trialProductId;
    }

    public ErTrial getErTrial() {
        return erTrial;
    }

    public void setErTrial(ErTrial erTrial) {
        this.erTrial = erTrial;
    }

    public String getFranchiseguid() {
        return franchiseguid;
    }

    public void setFranchiseguid(String franchiseguid) {
        this.franchiseguid = franchiseguid;
    }

    public String getTradenameguid() {
        return tradenameguid;
    }

    public void setTradenameguid(String tradenameguid) {
        this.tradenameguid = tradenameguid;
    }

    public BigDecimal getConcentration() {
        return concentration;
    }

    public void setConcentration(BigDecimal concentration) {
        this.concentration = concentration;
    }

    public String getOtherProduct() {
        return otherProduct;
    }

    public void setOtherProduct(String otherProduct) {
        this.otherProduct = otherProduct;
    }

    public String getFranchiseName() {
        return franchiseName;
    }

    public void setFranchiseName(String franchiseName) {
        this.franchiseName = franchiseName;
    }

    public String getTradeName() {
        return tradeName;
    }

    public void setTradeName(String tradeName) {
        this.tradeName = tradeName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ErTrialProduct)) return false;

        ErTrialProduct that = (ErTrialProduct) o;

        if (trialProductId != null) return trialProductId.equals(that.trialProductId);
        else return this == that;
    }

    @Override
    public int hashCode() {
        return trialProductId != null ? trialProductId.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "ErTrialProduct{" +
                "trialProductId=" + trialProductId +
                ", erTrial=" + erTrial +
                ", franchiseguid='" + franchiseguid + '\'' +
                ", tradenameguid='" + tradenameguid + '\'' +
                ", concentration=" + concentration +
                ", otherProduct='" + otherProduct + '\'' +
                ", franchiseName='" + franchiseName + '\'' +
                ", tradeName='" + tradeName + '\'' +
                '}';
    }
}
