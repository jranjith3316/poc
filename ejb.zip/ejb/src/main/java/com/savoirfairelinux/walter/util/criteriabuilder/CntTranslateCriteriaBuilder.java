package com.savoirfairelinux.walter.util.criteriabuilder;

import com.savoirfairelinux.walter.dao.waltercb.CntTranslate;

import javax.persistence.EntityManager;
import java.util.Map;

public class CntTranslateCriteriaBuilder extends AbstractCriteriaBuilder<CntTranslate> {
	
	private String translatorName;
    private String organization;
		
	public CntTranslateCriteriaBuilder(EntityManager entityManager, String translatorName, String organization) {
		super(entityManager, CntTranslate.class);
		this.translatorName = translatorName;
        this.organization = organization;
	}
	
	@Override
	protected void initQuery(StringBuilder queryBuilder, Map<String, Object> properties) {
		queryBuilder.append("SELECT ctr FROM CntTranslate ctr ");
	}
	
	@Override
	protected void initJoinQuery(StringBuilder queryBuilder, Map<String, Object> properties) {
		queryBuilder.append(" LEFT OUTER JOIN ctr.cnt.cntTxtList txt ");
	}
	
	@Override
	protected void initOrderByQuery(StringBuilder queryBuilder,	Map<String, Object> properties) {
		queryBuilder.append(" ORDER BY ctr.cnt.creationDate ");		
	}

	@Override
	protected void buildSpecificQuery(StringBuilder queryBuilder, Map<String, Object> properties) {
		queryBuilder.append(" WHERE ctr.cnt.cancelDate IS NULL ")
			.append(" AND ctr.receivedFromTr IS NULL ")
			.append(" AND ctr.sentToTr IS NOT NULL ")
			.append(" AND ctr.cnt.entryDate IS NOT NULL ")
			.append(" AND ctr.cnt.publicationDate IS NULL ")
			.append(" AND (ctr.cnt.validFlag IS NULL OR ctr.cnt.validFlag = 1) ");

        if (organization != null) {
            queryBuilder.append(" AND ctr.cnt.organization = :organization ");
            properties.put("organization", organization);
        }
		addLikeCriteria(queryBuilder, "ctr.translatorUserName", translatorName != null ? translatorName.toUpperCase() : null);
	}
}
