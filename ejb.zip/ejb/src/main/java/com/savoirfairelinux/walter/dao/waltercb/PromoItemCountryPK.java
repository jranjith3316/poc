/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

/**
 *
 * @author jsgill
 */
@Embeddable
public class PromoItemCountryPK implements Serializable {
  @Basic(optional = false)
  @NotNull
  @Column(name = "ITEM_ID")
  private long itemId;
  @Basic(optional = false)
  @NotNull
  @Column(name = "COUNTRY_ID")
  private long countryId;

  public PromoItemCountryPK() {
  }

  public PromoItemCountryPK(long itemId, long countryId) {
    this.itemId = itemId;
    this.countryId = countryId;
  }

  public long getItemId() {
    return itemId;
  }

  public void setItemId(long itemId) {
    this.itemId = itemId;
  }

  public long getCountryId() {
    return countryId;
  }

  public void setCountryId(long countryId) {
    this.countryId = countryId;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (int) itemId;
    hash += (int) countryId;
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof PromoItemCountryPK)) {
      return false;
    }
    PromoItemCountryPK other = (PromoItemCountryPK) object;
    if (this.itemId != other.itemId) {
      return false;
    }
    if (this.countryId != other.countryId) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.waltercb.PromoItemCountryPK[ itemId=" + itemId + ", countryId=" + countryId + " ]";
  }

}
