/*
 * Copyright 2012 Savoir-faire Linux
 *
 * This file is part of Walter-Portal.
 *
 * Walter-Portal is free software: you can redistribute it and/or modify it under the terms of the
 * GNU General Public License as published by the Free Software Foundation, either version 3
 * of the License, or (at your option) any later version.
 *
 * Walter-Portal is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with Walter-Portal.
 * If not, see http://www.gnu.org/licenses/.
 */
package com.savoirfairelinux.walter.service.notification;

/**
 *
 * @author Julien Bonjean
 *
 *         This enum stores templates related information
 */

public enum NotificationTemplate {
	HEADER(true),
	FOOTER(true),
	HEADER_EXTERNAL(true),
	FOOTER_EXTERNAL(true),
	REPORT_SUBMITTED_CREATOR(true),
	REPORT_SUBMITTED_MANAGEMENT(false),
	REPORT_NEW_FEEDBACK(true),
  REPORT_TRANSLATION_PENDING(true),
  REPORT_TRANSLATION_FINISHED(true),
	REPORT_VALIDATION_PENDING(false),
	REPORT_VALIDATED(false),
  CUSTOMER_FACILITY_FEEDBACK(true),
  IDEA_TRANSLATION_PENDING(true),
  IDEA_NEW_FEEDBACK(true),
  IDEA_PUBLISHED(true),
  IDEA_SOON_CLOSED(true),
  IDEA_CLOSING(true),
  LAB_REPORT_SUBMITTED_CREATOR(true),
  LAB_REPORT_SUBMITTED_MANAGEMENT(false),
  LAB_REPORT_PUBLISHED(true),
  PRODUCTIVITY_REPORT_PUBLISHED(true),
  PRODUCTIVITY_REPORT_SUBMITTED(true),
  EXPENSE_REPORT_CREATOR_MANAGER(true),
  EXPENSE_REPORT_ACCOUNTING_CREATOR(true),
  EXPENSE_REPORT_ACCOUNTING_MANAGER(true),
  EXPENSE_REPORT_ACCOUNTING_CREATOR_MODIFIED(true),
  LOAN_FOUND_INACTIVE_USER(true),
  GIVEAWAYS_NEW_ORDER(true),
  MOBILE_PRODUCTIVITY_REPORT(true),
  MOBILE_PRODUCTIVITY_REPORT_ORDER(true);

    private final boolean html;

	public static final String PATH = "/templates/";
	public static final String EXTENSION = "tmpl";

	private NotificationTemplate(boolean html) {
		this.html = html;
	}

	public String getBodyTemplateName() {
		return name().toLowerCase() + "_body";
	}

	public String getSubjectTemplateName() {
		return name().toLowerCase() + "_subject";
	}

	public boolean isHtml() {
		return html;
	}
}