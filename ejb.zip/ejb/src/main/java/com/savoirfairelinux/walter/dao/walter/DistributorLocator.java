/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.walter;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import org.hibernate.annotations.Type;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "DISTRIBUTOR_LOCATOR", catalog = "", schema = "WALTER")
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "DistributorLocator.findAll", query = "SELECT d FROM DistributorLocator d"),
  @NamedQuery(name = "DistributorLocator.findByCustNum", query = "SELECT d FROM DistributorLocator d WHERE d.custNum = :custNum"),
  @NamedQuery(name = "DistributorLocator.findByShipNum", query = "SELECT d FROM DistributorLocator d WHERE d.shipNum = :shipNum"),
  @NamedQuery(name = "DistributorLocator.findByState", query = "SELECT d FROM DistributorLocator d WHERE d.state = :state"),
  @NamedQuery(name = "DistributorLocator.findByFacilityName", query = "SELECT d FROM DistributorLocator d WHERE d.facilityName = :facilityName"),
  @NamedQuery(name = "DistributorLocator.findByAddress", query = "SELECT d FROM DistributorLocator d WHERE d.address = :address"),
  @NamedQuery(name = "DistributorLocator.findByCity", query = "SELECT d FROM DistributorLocator d WHERE d.city = :city"),
  @NamedQuery(name = "DistributorLocator.findByPostalCode", query = "SELECT d FROM DistributorLocator d WHERE d.postalCode = :postalCode"),
  @NamedQuery(name = "DistributorLocator.findByCountry", query = "SELECT d FROM DistributorLocator d WHERE d.country = :country"),
  @NamedQuery(name = "DistributorLocator.findByPhone", query = "SELECT d FROM DistributorLocator d WHERE d.phone = :phone"),
  @NamedQuery(name = "DistributorLocator.findByFax", query = "SELECT d FROM DistributorLocator d WHERE d.fax = :fax"),
  @NamedQuery(name = "DistributorLocator.findByEmail", query = "SELECT d FROM DistributorLocator d WHERE d.email = :email"),
  @NamedQuery(name = "DistributorLocator.findByLatitude", query = "SELECT d FROM DistributorLocator d WHERE d.latitude = :latitude"),
  @NamedQuery(name = "DistributorLocator.findByLongitude", query = "SELECT d FROM DistributorLocator d WHERE d.longitude = :longitude"),
  @NamedQuery(name = "DistributorLocator.findByUuid", query = "SELECT d FROM DistributorLocator d WHERE d.uuid = :uuid"),
  @NamedQuery(name = "DistributorLocator.findByUpdated", query = "SELECT d FROM DistributorLocator d WHERE d.updated = :updated"),
  @NamedQuery(name = "DistributorLocator.findByGeoLocalNotWork", query = "SELECT d FROM DistributorLocator d WHERE d.geoLocalNotWork = :geoLocalNotWork"),
  @NamedQuery(name = "DistributorLocator.findByWebsite", query = "SELECT d FROM DistributorLocator d WHERE d.website = :website"),
  @NamedQuery(name = "DistributorLocator.findBySaGroup", query = "SELECT d FROM DistributorLocator d WHERE d.saGroup = :saGroup")})
public class DistributorLocator implements Serializable {
  private static final long serialVersionUID = 1L;
  @Size(max = 30)
  @Column(name = "CUST_NUM")
  private String custNum;
  @Size(max = 10)
  @Column(name = "SHIP_NUM")
  private String shipNum;
  @Size(max = 20)
  @Column(name = "STATE")
  private String state;
  @Size(max = 60)
  @Column(name = "FACILITY_NAME")
  private String facilityName;
  @Size(max = 150)
  @Column(name = "ADDRESS")
  private String address;
  @Size(max = 50)
  @Column(name = "CITY")
  private String city;
  @Size(max = 20)
  @Column(name = "POSTAL_CODE")
  private String postalCode;
  @Size(max = 13)
  @Column(name = "COUNTRY")
  private String country;
  // @Pattern(regexp="^\\(?(\\d{3})\\)?[- ]?(\\d{3})[- ]?(\\d{4})$", message="Invalid phone/fax format, should be as xxx-xxx-xxxx")//if the field contains phone or fax number consider using this annotation to enforce field validation
  @Size(max = 80)
  @Column(name = "PHONE")
  private String phone;
  // @Pattern(regexp="^\\(?(\\d{3})\\)?[- ]?(\\d{3})[- ]?(\\d{4})$", message="Invalid phone/fax format, should be as xxx-xxx-xxxx")//if the field contains phone or fax number consider using this annotation to enforce field validation
  @Size(max = 20)
  @Column(name = "FAX")
  private String fax;
  // @Pattern(regexp="[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?", message="Invalid email")//if the field contains email address consider using this annotation to enforce field validation
  @Size(max = 70)
  @Column(name = "EMAIL")
  private String email;
  // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
  @Column(name = "LATITUDE")
  private BigDecimal latitude;
  @Column(name = "LONGITUDE")
  private BigDecimal longitude;
  @Id
  @Size(max = 36)
  @Column(name = "UUID")
  private String uuid;
  @Type(type = "org.hibernate.type.YesNoType")
  @Column(name = "UPDATED", columnDefinition = "boolean default false", nullable = false)
  private Boolean updated;
  @Type(type = "org.hibernate.type.YesNoType")
  @Column(name = "GEO_LOCAL_NOT_WORK", columnDefinition = "boolean default false", nullable = false)
  private Boolean geoLocalNotWork;
  @Size(max = 150)
  @Column(name = "WEBSITE")
  private String website;
//  @Size(max = 4)
  @Column(name = "SA_GROUP")
  private String saGroup;

  public DistributorLocator() {
  }

  public DistributorLocator(String uuid) {
    this.uuid = uuid;
  }

  public String getCustNum() {
    return custNum;
  }

  public void setCustNum(String custNum) {
    this.custNum = custNum;
  }

  public String getShipNum() {
    return shipNum;
  }

  public void setShipNum(String shipNum) {
    this.shipNum = shipNum;
  }

  public String getState() {
    return state;
  }

  public void setState(String state) {
    this.state = state;
  }

  public String getFacilityName() {
    return facilityName;
  }

  public void setFacilityName(String facilityName) {
    this.facilityName = facilityName;
  }

  public String getAddress() {
    return address;
  }

  public void setAddress(String address) {
    this.address = address;
  }

  public String getCity() {
    return city;
  }

  public void setCity(String city) {
    this.city = city;
  }

  public String getPostalCode() {
    return postalCode;
  }

  public void setPostalCode(String postalCode) {
    this.postalCode = postalCode;
  }

  public String getCountry() {
    return country;
  }

  public void setCountry(String country) {
    this.country = country;
  }

  public String getPhone() {
    return phone;
  }

  public void setPhone(String phone) {
    this.phone = phone;
  }

  public String getFax() {
    return fax;
  }

  public void setFax(String fax) {
    this.fax = fax;
  }

  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public BigDecimal getLatitude() {
    return latitude;
  }

  public void setLatitude(BigDecimal latitude) {
    this.latitude = latitude;
  }

  public BigDecimal getLongitude() {
    return longitude;
  }

  public void setLongitude(BigDecimal longitude) {
    this.longitude = longitude;
  }

  public String getUuid() {
    return uuid;
  }

  public void setUuid(String uuid) {
    this.uuid = uuid;
  }

  public Boolean isUpdated() {
    return updated;
  }

  public void setUpdated(Boolean updated) {
    this.updated = updated;
  }

  public Boolean isGeoLocalNotWork() {
    return geoLocalNotWork;
  }

  public void setGeoLocalNotWork(Boolean geoLocalNotWork) {
    this.geoLocalNotWork = geoLocalNotWork;
  }

  public String getWebsite() {
    return website;
  }

  public void setWebsite(String website) {
    this.website = website;
  }

  public String getSaGroup() {
    return saGroup;
  }

  public void setSaGroup(String saGroup) {
    this.saGroup = saGroup;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (uuid != null ? uuid.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof DistributorLocator)) {
      return false;
    }
    DistributorLocator other = (DistributorLocator) object;
    if ((this.uuid == null && other.uuid != null) || (this.uuid != null && !this.uuid.equals(other.uuid))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.walter.DistributorLocator[ uuid=" + uuid + " ]";
  }

}
