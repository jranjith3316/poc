/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.jasper.model;

//import com.liferay.portal.model.User;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author jsgill
 */
public class JasperAerosolCalculator implements Serializable {


  private Long id;
//  private User user;
  private Date creationDate;
  private Date deleteDate;
  private String contactName;
  private String contactTitle;
  private String companyName;
  private String phone;
  private String address;
  private String email;
  private String unit;
  private String compBrand;
  private String compProductName;
  private BigDecimal compAerosolTotal;
  private BigDecimal compPropellantAvg;
  private BigDecimal compPropellant;
  private BigDecimal compAerosolLiquid;
  private BigDecimal compSpecificGravity;
  private BigDecimal compUnusedResidue;
  private Long compCanYear;
  private BigDecimal compLiquidRequired;
  private BigDecimal compProductCost;
  private BigDecimal compDisposalCost;
  private BigDecimal compManpowerCost;
  private BigDecimal compTotalAerosolCost;
  private BigDecimal compCostLiter;
  private BigDecimal compTotalCost;
  private String franchiseName;
  private String tradename;
  private String productNumber;
  private String productSize;
  private String productFormat;
  private BigDecimal walterAerosolTotal;
  private BigDecimal walterPropellant;
  private BigDecimal walterBulkLiquid;
  private BigDecimal walterUnusedResidue;
  private BigDecimal walterLiquidNeed;
  private BigDecimal walterCostEachContainer;
  private BigDecimal walterCostLiter;
  private BigDecimal walterTotalLiquidCost;
  private BigDecimal walterInitialKitCost;
  private Integer walterQuantityKitsRequired;
  private BigDecimal walterKitCostTotal;
  private BigDecimal walterRefillableSprayerCost;
  private Integer walterQtyRefillableSprayer;
  private BigDecimal walterRefillableTotalCost;
  private BigDecimal walterTotalLiquidUsed;
  private BigDecimal walterDrumsPerYear;
  private BigDecimal walterTotalCostYear1;
  private BigDecimal walterTotalCostYear2;
  private BigDecimal savingYearDollardYear1;
  private BigDecimal savingYearPourcentYear1;
  private BigDecimal savingYearDollardYear2;
  private BigDecimal savingYearPourcentYear2;

  private String logoHeader;
  private String logoFooter;
  private String logoISO;
  private String walterPhone;
  private String walterAddress;
  private String compUnit;
  private String costLiter;

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public Date getCreationDate() {
    return creationDate;
  }

  public void setCreationDate(Date creationDate) {
    this.creationDate = creationDate;
  }

  public Date getDeleteDate() {
    return deleteDate;
  }

  public void setDeleteDate(Date deleteDate) {
    this.deleteDate = deleteDate;
  }

  public String getContactName() {
    return contactName;
  }

  public void setContactName(String contactName) {
    this.contactName = contactName;
  }

  public String getContactTitle() {
    return contactTitle;
  }

  public void setContactTitle(String contactTitle) {
    this.contactTitle = contactTitle;
  }

  public String getCompanyName() {
    return companyName;
  }

  public void setCompanyName(String companyName) {
    this.companyName = companyName;
  }

  public String getPhone() {
    return phone;
  }

  public void setPhone(String phone) {
    this.phone = phone;
  }

  public String getAddress() {
    return address;
  }

  public void setAddress(String address) {
    this.address = address;
  }

  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public String getUnit() {
    return unit;
  }

  public void setUnit(String unit) {
    this.unit = unit;
  }

  public String getCompBrand() {
    return compBrand;
  }

  public void setCompBrand(String compBrand) {
    this.compBrand = compBrand;
  }

  public String getCompProductName() {
    return compProductName;
  }

  public void setCompProductName(String compProductName) {
    this.compProductName = compProductName;
  }

  public BigDecimal getCompAerosolTotal() {
    return compAerosolTotal;
  }

  public void setCompAerosolTotal(BigDecimal compAerosolTotal) {
    this.compAerosolTotal = compAerosolTotal;
  }

  public BigDecimal getCompPropellantAvg() {
    return compPropellantAvg;
  }

  public void setCompPropellantAvg(BigDecimal compPropellantAvg) {
    this.compPropellantAvg = compPropellantAvg;
  }

  public BigDecimal getCompPropellant() {
    return compPropellant;
  }

  public void setCompPropellant(BigDecimal compPropellant) {
    this.compPropellant = compPropellant;
  }

  public BigDecimal getCompAerosolLiquid() {
    return compAerosolLiquid;
  }

  public void setCompAerosolLiquid(BigDecimal compAerosolLiquid) {
    this.compAerosolLiquid = compAerosolLiquid;
  }

  public BigDecimal getCompSpecificGravity() {
    return compSpecificGravity;
  }

  public void setCompSpecificGravity(BigDecimal compSpecificGravity) {
    this.compSpecificGravity = compSpecificGravity;
  }

  public BigDecimal getCompUnusedResidue() {
    return compUnusedResidue;
  }

  public void setCompUnusedResidue(BigDecimal compUnusedResidue) {
    this.compUnusedResidue = compUnusedResidue;
  }

  public Long getCompCanYear() {
    return compCanYear;
  }

  public void setCompCanYear(Long compCanYear) {
    this.compCanYear = compCanYear;
  }

  public BigDecimal getCompLiquidRequired() {
    return compLiquidRequired;
  }

  public void setCompLiquidRequired(BigDecimal compLiquidRequired) {
    this.compLiquidRequired = compLiquidRequired;
  }

  public BigDecimal getCompProductCost() {
    return compProductCost;
  }

  public void setCompProductCost(BigDecimal compProductCost) {
    this.compProductCost = compProductCost;
  }

  public BigDecimal getCompDisposalCost() {
    return compDisposalCost;
  }

  public void setCompDisposalCost(BigDecimal compDisposalCost) {
    this.compDisposalCost = compDisposalCost;
  }

  public BigDecimal getCompManpowerCost() {
    return compManpowerCost;
  }

  public void setCompManpowerCost(BigDecimal compManpowerCost) {
    this.compManpowerCost = compManpowerCost;
  }

  public BigDecimal getCompTotalAerosolCost() {
    return compTotalAerosolCost;
  }

  public void setCompTotalAerosolCost(BigDecimal compTotalAerosolCost) {
    this.compTotalAerosolCost = compTotalAerosolCost;
  }

  public BigDecimal getCompCostLiter() {
    return compCostLiter;
  }

  public void setCompCostLiter(BigDecimal compCostLiter) {
    this.compCostLiter = compCostLiter;
  }

  public BigDecimal getCompTotalCost() {
    return compTotalCost;
  }

  public void setCompTotalCost(BigDecimal compTotalCost) {
    this.compTotalCost = compTotalCost;
  }

  public String getFranchiseName() {
    return franchiseName;
  }

  public void setFranchiseName(String franchiseName) {
    this.franchiseName = franchiseName;
  }

  public String getTradename() {
    return tradename;
  }

  public void setTradename(String tradename) {
    this.tradename = tradename;
  }

  public String getProductNumber() {
    return productNumber;
  }

  public void setProductNumber(String productNumber) {
    this.productNumber = productNumber;
  }

  public String getProductSize() {
    return productSize;
  }

  public void setProductSize(String productSize) {
    this.productSize = productSize;
  }

  public String getProductFormat() {
    return productFormat;
  }

  public void setProductFormat(String productFormat) {
    this.productFormat = productFormat;
  }

  public BigDecimal getWalterAerosolTotal() {
    return walterAerosolTotal;
  }

  public void setWalterAerosolTotal(BigDecimal walterAerosolTotal) {
    this.walterAerosolTotal = walterAerosolTotal;
  }

  public BigDecimal getWalterPropellant() {
    return walterPropellant;
  }

  public void setWalterPropellant(BigDecimal walterPropellant) {
    this.walterPropellant = walterPropellant;
  }

  public BigDecimal getWalterBulkLiquid() {
    return walterBulkLiquid;
  }

  public void setWalterBulkLiquid(BigDecimal walterBulkLiquid) {
    this.walterBulkLiquid = walterBulkLiquid;
  }

  public BigDecimal getWalterUnusedResidue() {
    return walterUnusedResidue;
  }

  public void setWalterUnusedResidue(BigDecimal walterUnusedResidue) {
    this.walterUnusedResidue = walterUnusedResidue;
  }

  public BigDecimal getWalterLiquidNeed() {
    return walterLiquidNeed;
  }

  public void setWalterLiquidNeed(BigDecimal walterLiquidNeed) {
    this.walterLiquidNeed = walterLiquidNeed;
  }

  public BigDecimal getWalterCostEachContainer() {
    return walterCostEachContainer;
  }

  public void setWalterCostEachContainer(BigDecimal walterCostEachContainer) {
    this.walterCostEachContainer = walterCostEachContainer;
  }

  public BigDecimal getWalterCostLiter() {
    return walterCostLiter;
  }

  public void setWalterCostLiter(BigDecimal walterCostLiter) {
    this.walterCostLiter = walterCostLiter;
  }

  public BigDecimal getWalterTotalLiquidCost() {
    return walterTotalLiquidCost;
  }

  public void setWalterTotalLiquidCost(BigDecimal walterTotalLiquidCost) {
    this.walterTotalLiquidCost = walterTotalLiquidCost;
  }

  public BigDecimal getWalterInitialKitCost() {
    return walterInitialKitCost;
  }

  public void setWalterInitialKitCost(BigDecimal walterInitialKitCost) {
    this.walterInitialKitCost = walterInitialKitCost;
  }

  public Integer getWalterQuantityKitsRequired() {
    return walterQuantityKitsRequired;
  }

  public void setWalterQuantityKitsRequired(Integer walterQuantityKitsRequired) {
    this.walterQuantityKitsRequired = walterQuantityKitsRequired;
  }

  public BigDecimal getWalterKitCostTotal() {
    return walterKitCostTotal;
  }

  public void setWalterKitCostTotal(BigDecimal walterKitCostTotal) {
    this.walterKitCostTotal = walterKitCostTotal;
  }

  public BigDecimal getWalterRefillableSprayerCost() {
    return walterRefillableSprayerCost;
  }

  public void setWalterRefillableSprayerCost(BigDecimal walterRefillableSprayerCost) {
    this.walterRefillableSprayerCost = walterRefillableSprayerCost;
  }

  public Integer getWalterQtyRefillableSprayer() {
    return walterQtyRefillableSprayer;
  }

  public void setWalterQtyRefillableSprayer(Integer walterQtyRefillableSprayer) {
    this.walterQtyRefillableSprayer = walterQtyRefillableSprayer;
  }

  public BigDecimal getWalterRefillableTotalCost() {
    return walterRefillableTotalCost;
  }

  public void setWalterRefillableTotalCost(BigDecimal walterRefillableTotalCost) {
    this.walterRefillableTotalCost = walterRefillableTotalCost;
  }

  public BigDecimal getWalterTotalLiquidUsed() {
    return walterTotalLiquidUsed;
  }

  public void setWalterTotalLiquidUsed(BigDecimal walterTotalLiquidUsed) {
    this.walterTotalLiquidUsed = walterTotalLiquidUsed;
  }

  public BigDecimal getWalterDrumsPerYear() {
    return walterDrumsPerYear;
  }

  public void setWalterDrumsPerYear(BigDecimal walterDrumsPerYear) {
    this.walterDrumsPerYear = walterDrumsPerYear;
  }

  public BigDecimal getWalterTotalCostYear1() {
    return walterTotalCostYear1;
  }

  public void setWalterTotalCostYear1(BigDecimal walterTotalCostYear1) {
    this.walterTotalCostYear1 = walterTotalCostYear1;
  }

  public BigDecimal getWalterTotalCostYear2() {
    return walterTotalCostYear2;
  }

  public void setWalterTotalCostYear2(BigDecimal walterTotalCostYear2) {
    this.walterTotalCostYear2 = walterTotalCostYear2;
  }

  public BigDecimal getSavingYearDollardYear1() {
    return savingYearDollardYear1;
  }

  public void setSavingYearDollardYear1(BigDecimal savingYearDollardYear1) {
    this.savingYearDollardYear1 = savingYearDollardYear1;
  }

  public BigDecimal getSavingYearPourcentYear1() {
    return savingYearPourcentYear1;
  }

  public void setSavingYearPourcentYear1(BigDecimal savingYearPourcentYear1) {
    this.savingYearPourcentYear1 = savingYearPourcentYear1;
  }

  public BigDecimal getSavingYearDollardYear2() {
    return savingYearDollardYear2;
  }

  public void setSavingYearDollardYear2(BigDecimal savingYearDollardYear2) {
    this.savingYearDollardYear2 = savingYearDollardYear2;
  }

  public BigDecimal getSavingYearPourcentYear2() {
    return savingYearPourcentYear2;
  }

  public void setSavingYearPourcentYear2(BigDecimal savingYearPourcentYear2) {
    this.savingYearPourcentYear2 = savingYearPourcentYear2;
  }

  public String getLogoHeader() {
    return logoHeader;
  }

  public void setLogoHeader(String logoHeader) {
    this.logoHeader = logoHeader;
  }

  public String getLogoFooter() {
    return logoFooter;
  }

  public void setLogoFooter(String logoFooter) {
    this.logoFooter = logoFooter;
  }

  public String getLogoISO() {
    return logoISO;
  }

  public void setLogoISO(String logoISO) {
    this.logoISO = logoISO;
  }

  public String getWalterPhone() {
    return walterPhone;
  }

  public void setWalterPhone(String walterPhone) {
    this.walterPhone = walterPhone;
  }

  public String getWalterAddress() {
    return walterAddress;
  }

  public void setWalterAddress(String walterAddress) {
    this.walterAddress = walterAddress;
  }

  public String getCompUnit() {
    return compUnit;
  }

  public void setCompUnit(String compUnit) {
    this.compUnit = compUnit;
  }

  public String getCostLiter() {
    return costLiter;
  }

  public void setCostLiter(String costLiter) {
    this.costLiter = costLiter;
  }


}
