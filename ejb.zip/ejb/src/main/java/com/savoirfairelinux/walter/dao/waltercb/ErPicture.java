/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import java.math.BigInteger;
import java.util.Set;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "ER_PICTURE", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "ErPicture.findAll", query = "SELECT e FROM ErPicture e"),
    @NamedQuery(name = "ErPicture.findByErId", query = "SELECT e FROM ErPicture e WHERE e.er.erId = :erId"),
    @NamedQuery(name = "ErPicture.findByPictureId", query = "SELECT e FROM ErPicture e WHERE e.pictureId = :pictureId")})
public class ErPicture implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @NotNull
    @Column(name = "PICTURE_ID", nullable = false)
    @GeneratedValue(generator = "ER_PICTURE_ID_SEQ", strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "ER_PICTURE_ID_SEQ", sequenceName = "ER_PICTURE_ID_SEQ", schema = DatabaseConstants.WALTERCB_SCHEMA, allocationSize = 1)
    private Long pictureId;
    @Size(max = 350)
    @Column(name = "REAL_FILENAME")
    private String realFilename;
    @Size(max = 48)
    @Column(name = "MIME_TYPE")
    private String mimeType;
    @Column(name = "DOC_SIZE")
    private BigInteger docSize;
    @Lob
    @Column(name = "BLOB_CONTENT")
    private byte[] blobContent;
    @Size(max = 1)
    @Column(name = "TYPE")
    private String type;
    @Basic(optional = false)
    @NotNull
    @Column(name = "PICTURE_SEQ", nullable = false)
    private long pictureSeq;
    @JoinColumn(name = "ER_ID", referencedColumnName = "ER_ID", nullable = false)
    @ManyToOne(optional = false)
    private Er er;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "erPicture", fetch = FetchType.EAGER)
    private Set<ErPictureTxt> erPictureTxtSet;

    public ErPicture() {
    }

    public ErPicture(long pictureId) {
        this.pictureId = pictureId;
    }

    public String getRealFilename() {
        return realFilename;
    }

    public void setRealFilename(String realFilename) {
        this.realFilename = realFilename;
    }

    public String getMimeType() {
        return mimeType;
    }

    public void setMimeType(String mimeType) {
        this.mimeType = mimeType;
    }

    public BigInteger getDocSize() {
        return docSize;
    }

    public void setDocSize(BigInteger docSize) {
        this.docSize = docSize;
    }

    public byte[] getBlobContent() {
        return blobContent;
    }

    public void setBlobContent(byte[] blobContent) {
        this.blobContent = blobContent;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public long getPictureSeq() {
        return pictureSeq;
    }

    public void setPictureSeq(long pictureSeq) {
        this.pictureSeq = pictureSeq;
    }

    public Long getPictureId() {
        return pictureId;
    }

    public void setPictureId(Long pictureId) {
        this.pictureId = pictureId;
    }

    public Er getEr() {
        return er;
    }

    public void setEr(Er er) {
        this.er = er;
    }

    @XmlTransient
    public Set<ErPictureTxt> getErPictureTxtSet() {
        return erPictureTxtSet;
    }

    public void setErPictureTxtSet(Set<ErPictureTxt> erPictureTxtSet) {
        this.erPictureTxtSet = erPictureTxtSet;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (pictureId != null ? pictureId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ErPicture)) {
            return false;
        }
        ErPicture other = (ErPicture) object;
        if ((this.pictureId == null && other.pictureId != null) || (this.pictureId != null && !this.pictureId.equals(other.pictureId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.ErPicture[ erPictureId=" + pictureId + " ]";
    }
}
