package com.savoirfairelinux.walter.model;

public enum DocumentType {

	PICTURE ("I"),
	DOCUMENT ("F");
	
	private String type;
	
	private DocumentType(String type) {
		this.type = type;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
}
