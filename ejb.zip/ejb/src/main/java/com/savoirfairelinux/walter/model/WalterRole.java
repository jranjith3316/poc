package com.savoirfairelinux.walter.model;

public enum WalterRole {

    // Waltershare Roles
    TRANSLATOR("Translator", 2),
    PRODUCT_MANAGER("Product Manager", 2),
    MAINTENANCE("Maintenance", 2),
    MANAGEMENT("Management", 2),
    CONTRIBUTOR("Contributor", 2),
    GLOBAL_ACCOUNT_CHAMPION("Global Account Champion", 1),// Regular
    KEY_CONTACT("Key Contact", 1),// Regular
    INTERNATIONAL_KEY_CONTACT("International Key Contact", 1),// Regular
    SALE_REPRESENTATIVE("Sale Representative", 2),
    MOBILE("Mobile", 1), // Regular
    PHOTO_GALLERY_EDITOR("PhotoGalleryEditor", 2),
    EXPENSE_REPORT_INTERNET("Expense Report Internet", 2),
    EXPENSE_REPORT_TRAVEL_CAR("Expense Report Travel Car", 2),
    EXPENSE_REPORT_MEAL_ADMINISTRATION("Expense Report Meal Administration", 2),
    EXPENSE_REPORT_ADMINISTRATION("Expense Report Administration", 2),
    EXPENSE_REPORT_HOTEL_MAX("Expense Report Hotel Max", 2),
    LAB_REPORT_CREATOR("Lab Report Creator", 1),// Regular
    QUALITY_CONTROLLER("Quality Controller", 2),
    VIDEO_GALLERY_EDITOR("VideoGalleryEditor", 2),
    HUMAN_RESSOURCE("Human Ressource", 2),
    CARE_SERVICE_TECHNICIAN("Care Service Technician", 2),
    GIVEAWAYS_USER_SEND_ORDER("GiveAways received email", 2);
    private String name;
    private int type;

    private WalterRole(String name, int type) {
        this.name = name;
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public int getType() {
        return type;
    }

}
