package com.savoirfairelinux.walter.util.criteriabuilder;

import java.util.Map;

import javax.persistence.TypedQuery;

public class QueryWrapper<T> {

	private TypedQuery<T> query;
	
	private String queryString;
	
	private Map<String, Object> properties;

	public QueryWrapper(TypedQuery<T> query, String queryString, Map<String, Object> properties) {
		this.query = query;
		this.queryString = queryString;
		this.properties = properties;
	}

	public TypedQuery<T> getQuery() {
		return query;
	}

	public String getQueryString() {
		return queryString;
	}

	public Map<String, Object> getProperties() {
		return properties;
	}
}
