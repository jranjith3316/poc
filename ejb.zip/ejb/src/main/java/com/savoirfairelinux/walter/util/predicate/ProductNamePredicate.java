package com.savoirfairelinux.walter.util.predicate;

import com.savoirfairelinux.walter.dao.globalcustomer.GaProduct;
import org.apache.commons.collections.Predicate;

/**
 * @author jderuere
 */
public class ProductNamePredicate implements Predicate {

    private Long productId;

    @Override
    public boolean evaluate(Object o) {
        GaProduct product = (GaProduct) o;
        return productId.equals(product.getGaProductId());
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }
}
