/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

/**
 *
 * @author mgubaidullin
 */
@Embeddable
public class UContaminantPK implements Serializable {
    @Basic(optional = false)
    @NotNull
    @Column(name = "CONTAMINANT_ID")
    private long contaminantId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "LANG_ID")
    private long langId;

    public UContaminantPK() {
    }

    public UContaminantPK(long contaminantId, long langId) {
        this.contaminantId = contaminantId;
        this.langId = langId;
    }

    public long getContaminantId() {
        return contaminantId;
    }

    public void setContaminantId(long contaminantId) {
        this.contaminantId = contaminantId;
    }

    public long getLangId() {
        return langId;
    }

    public void setLangId(long langId) {
        this.langId = langId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) contaminantId;
        hash += (int) langId;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof UContaminantPK)) {
            return false;
        }
        UContaminantPK other = (UContaminantPK) object;
        if (this.contaminantId != other.contaminantId) {
            return false;
        }
        if (this.langId != other.langId) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.UContaminantPK[ contaminantId=" + contaminantId + ", langId=" + langId + " ]";
    }
    
}
