/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "COUNTRY_STATE_TXT", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CountryStateTxt.findAll", query = "SELECT c FROM CountryStateTxt c"),
    @NamedQuery(name = "CountryStateTxt.findByCountryId", query = "SELECT c FROM CountryStateTxt c WHERE c.countryStateTxtPK.countryId = :countryId"),
    @NamedQuery(name = "CountryStateTxt.findByStateCode", query = "SELECT c FROM CountryStateTxt c WHERE c.countryStateTxtPK.stateCode = :stateCode"),
    @NamedQuery(name = "CountryStateTxt.findByLangId", query = "SELECT c FROM CountryStateTxt c WHERE c.countryStateTxtPK.langId = :langId"),
    @NamedQuery(name = "CountryStateTxt.findByStateDesc", query = "SELECT c FROM CountryStateTxt c WHERE c.stateDesc = :stateDesc")})
public class CountryStateTxt implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected CountryStateTxtPK countryStateTxtPK;
    @Size(max = 40)
    @Column(name = "STATE_DESC")
    private String stateDesc;
    @JoinColumns({
        @JoinColumn(name = "COUNTRY_ID", referencedColumnName = "COUNTRY_ID", insertable = false, updatable = false),
        @JoinColumn(name = "STATE_CODE", referencedColumnName = "STATE_CODE", insertable = false, updatable = false)})
    @ManyToOne(optional = false)
    private CountryState countryState;

    public CountryStateTxt() {
    }

    public CountryStateTxt(CountryStateTxtPK countryStateTxtPK) {
        this.countryStateTxtPK = countryStateTxtPK;
    }

    public CountryStateTxt(long countryId, String stateCode, long langId) {
        this.countryStateTxtPK = new CountryStateTxtPK(countryId, stateCode, langId);
    }

    public CountryStateTxtPK getCountryStateTxtPK() {
        return countryStateTxtPK;
    }

    public void setCountryStateTxtPK(CountryStateTxtPK countryStateTxtPK) {
        this.countryStateTxtPK = countryStateTxtPK;
    }

    public String getStateDesc() {
        return stateDesc;
    }

    public void setStateDesc(String stateDesc) {
        this.stateDesc = stateDesc;
    }

    public CountryState getCountryState() {
        return countryState;
    }

    public void setCountryState(CountryState countryState) {
        this.countryState = countryState;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (countryStateTxtPK != null ? countryStateTxtPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CountryStateTxt)) {
            return false;
        }
        CountryStateTxt other = (CountryStateTxt) object;
        if ((this.countryStateTxtPK == null && other.countryStateTxtPK != null) || (this.countryStateTxtPK != null && !this.countryStateTxtPK.equals(other.countryStateTxtPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.CountryStateTxt[ countryStateTxtPK=" + countryStateTxtPK + " ]";
    }
    
}
