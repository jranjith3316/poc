/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import javax.persistence.*;
import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import java.util.Set;

/**
 *
 * @author jderuere
 */
@Entity
@Table(name = "U_COMPETITOR_BRAND", schema = DatabaseConstants.WALTERCB_SCHEMA)
@NamedQueries({
        @NamedQuery(name = "UCompetitorBrand.findAll", query = "SELECT cb FROM UCompetitorBrand cb")})
public class UCompetitorBrand implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(generator = "COMPETITOR_BRAND_ID_SEQ", strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "COMPETITOR_BRAND_ID_SEQ", sequenceName = "COMPETITOR_BRAND_ID_SEQ", schema = DatabaseConstants.WALTERCB_SCHEMA, allocationSize = 1)
    @Column(name = "ID")
    private Long id;
    @Column(name = "NAME")
    private String name;
    @ManyToOne(optional = false, cascade = { CascadeType.PERSIST, CascadeType.MERGE })
    @JoinColumn(name = "COMPETITOR_ID", referencedColumnName = "COMPETITOR_ID", nullable = false)
    private UCompetitor competitor;
    @Fetch(FetchMode.SUBSELECT)
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "brand", orphanRemoval = true)
    private Set<UCompetitorProduct> products;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public UCompetitor getCompetitor() {
        return competitor;
    }

    public void setCompetitor(UCompetitor competitor) {
        this.competitor = competitor;
    }

    public Set<UCompetitorProduct> getProducts() {
        return products;
    }

    public void setProducts(Set<UCompetitorProduct> products) {
        this.products = products;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof UCompetitorBrand)) {
            return false;
        }
        UCompetitorBrand other = (UCompetitorBrand) object;
        if (this.getId() == null && other.getId() == null) {
            return this == other;
        }
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.UCompetitorBrand[ id=" + id + " ]";
    }
}
