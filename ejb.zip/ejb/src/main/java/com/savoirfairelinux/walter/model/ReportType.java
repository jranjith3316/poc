package com.savoirfairelinux.walter.model;

public enum ReportType {

	ALL(""),
	SUCCESS_STORY("S"),
	PRODUCT_ADVISORY("A"),
  MOBILE_PRODUCTIVITY_REPORT("MPR"),
  WALTERSHARE_PRODUCTIVITY_REPORT("WPR");

	private String type;

	private ReportType(String code) {
		this.type = code;
	}

	public String getType() {
		return type;
	}

	public static ReportType getByType(String type) {
		for (ReportType reportType : ReportType.values()) {
			if (type.equals(reportType.getType())) {
				return reportType;
			}
		}
		return null;
	}
}