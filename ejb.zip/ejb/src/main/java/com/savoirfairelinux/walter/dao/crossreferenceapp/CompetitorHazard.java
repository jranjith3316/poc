/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.crossreferenceapp;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "COMPETITOR_HAZARD", catalog = "", schema = "CROSSREFERENCEAPP")
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "CompetitorHazard.findAll", query = "SELECT c FROM CompetitorHazard c"),
  @NamedQuery(name = "CompetitorHazard.findByCompetitorId", query = "SELECT c FROM CompetitorHazard c WHERE c.competitorHazardPK.competitorId = :competitorId"),
  @NamedQuery(name = "CompetitorHazard.findByBrandId", query = "SELECT c FROM CompetitorHazard c WHERE c.competitorHazardPK.brandId = :brandId"),
  @NamedQuery(name = "CompetitorHazard.findByProductId", query = "SELECT c FROM CompetitorHazard c WHERE c.competitorHazardPK.productId = :productId"),
  @NamedQuery(name = "CompetitorHazard.findByCountryId", query = "SELECT c FROM CompetitorHazard c WHERE c.competitorHazardPK.countryId = :countryId"),
  @NamedQuery(name = "CompetitorHazard.findByClassname", query = "SELECT c FROM CompetitorHazard c WHERE c.competitorHazardPK.classname = :classname"),
  @NamedQuery(name = "CompetitorHazard.findByInstanceguid", query = "SELECT c FROM CompetitorHazard c WHERE c.competitorHazardPK.instanceguid = :instanceguid"),
  @NamedQuery(name = "CompetitorHazard.findByCreatedUserName", query = "SELECT c FROM CompetitorHazard c WHERE c.createdUserName = :createdUserName"),
  @NamedQuery(name = "CompetitorHazard.findByCreatedDate", query = "SELECT c FROM CompetitorHazard c WHERE c.createdDate = :createdDate"),
  @NamedQuery(name = "CompetitorHazard.findByUpdatedUserName", query = "SELECT c FROM CompetitorHazard c WHERE c.updatedUserName = :updatedUserName"),
  @NamedQuery(name = "CompetitorHazard.findByUpdatedDate", query = "SELECT c FROM CompetitorHazard c WHERE c.updatedDate = :updatedDate")})
public class CompetitorHazard implements Serializable {
  private static final long serialVersionUID = 1L;
  @EmbeddedId
  protected CompetitorHazardPK competitorHazardPK;
  @Size(max = 255)
  @Column(name = "CREATED_USER_NAME")
  private String createdUserName;
  @Column(name = "CREATED_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date createdDate;
  @Size(max = 255)
  @Column(name = "UPDATED_USER_NAME")
  private String updatedUserName;
  @Column(name = "UPDATED_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date updatedDate;

  public CompetitorHazard() {
  }

  public CompetitorHazard(CompetitorHazardPK competitorHazardPK) {
    this.competitorHazardPK = competitorHazardPK;
  }

  public CompetitorHazard(long competitorId, long brandId, long productId, long countryId, String classname, String instanceguid) {
    this.competitorHazardPK = new CompetitorHazardPK(competitorId, brandId, productId, countryId, classname, instanceguid);
  }

  public CompetitorHazardPK getCompetitorHazardPK() {
    return competitorHazardPK;
  }

  public void setCompetitorHazardPK(CompetitorHazardPK competitorHazardPK) {
    this.competitorHazardPK = competitorHazardPK;
  }

  public String getCreatedUserName() {
    return createdUserName;
  }

  public void setCreatedUserName(String createdUserName) {
    this.createdUserName = createdUserName;
  }

  public Date getCreatedDate() {
    return createdDate;
  }

  public void setCreatedDate(Date createdDate) {
    this.createdDate = createdDate;
  }

  public String getUpdatedUserName() {
    return updatedUserName;
  }

  public void setUpdatedUserName(String updatedUserName) {
    this.updatedUserName = updatedUserName;
  }

  public Date getUpdatedDate() {
    return updatedDate;
  }

  public void setUpdatedDate(Date updatedDate) {
    this.updatedDate = updatedDate;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (competitorHazardPK != null ? competitorHazardPK.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof CompetitorHazard)) {
      return false;
    }
    CompetitorHazard other = (CompetitorHazard) object;
    if ((this.competitorHazardPK == null && other.competitorHazardPK != null) || (this.competitorHazardPK != null && !this.competitorHazardPK.equals(other.competitorHazardPK))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.crossreferenceapp.CompetitorHazard[ competitorHazardPK=" + competitorHazardPK + " ]";
  }

}
