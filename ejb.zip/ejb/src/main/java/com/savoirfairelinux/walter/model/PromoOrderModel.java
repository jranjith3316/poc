/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author jsgill
 */
public class PromoOrderModel implements Serializable {
  private Long orderId;
  private Date creationDate;
  private BigDecimal total;

  public PromoOrderModel() {
  }

  public PromoOrderModel(Long orderId, Date creationDate, BigDecimal total) {
    this.orderId = orderId;
    this.creationDate = creationDate;
    this.total = total;
  }

  public Long getOrderId() {
    return orderId;
  }

  public void setOrderId(Long orderId) {
    this.orderId = orderId;
  }

  public Date getCreationDate() {
    return creationDate;
  }

  public void setCreationDate(Date creationDate) {
    this.creationDate = creationDate;
  }

  public BigDecimal getTotal() {
    return total;
  }

  public void setTotal(BigDecimal total) {
    this.total = total;
  }



}
