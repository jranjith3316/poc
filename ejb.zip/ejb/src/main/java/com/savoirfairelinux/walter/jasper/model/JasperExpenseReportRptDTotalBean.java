/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.jasper.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

/**
 *
 * @author jsgill
 */
public class JasperExpenseReportRptDTotalBean implements Serializable {
//  private List<JasperExpenseRptDBean> jasperExpenseRptDBean;
  private BigDecimal subtotal;
  private BigDecimal tip;
  private BigDecimal tax1;
  private BigDecimal tax2;
  private BigDecimal tax3;
  private BigDecimal total;

//  public List<JasperExpenseRptDBean> getJasperExpenseRptDBean() {
//    return jasperExpenseRptDBean;
//  }
//
//  public void setJasperExpenseRptDBean(List<JasperExpenseRptDBean> jasperExpenseRptDBean) {
//    this.jasperExpenseRptDBean = jasperExpenseRptDBean;
//  }

  public BigDecimal getSubtotal() {
    return subtotal;
  }

  public void setSubtotal(BigDecimal subtotal) {
    this.subtotal = subtotal;
  }

  public BigDecimal getTip() {
    return tip;
  }

  public void setTip(BigDecimal tip) {
    this.tip = tip;
  }

  public BigDecimal getTax1() {
    return tax1;
  }

  public void setTax1(BigDecimal tax1) {
    this.tax1 = tax1;
  }

  public BigDecimal getTax2() {
    return tax2;
  }

  public void setTax2(BigDecimal tax2) {
    this.tax2 = tax2;
  }

  public BigDecimal getTax3() {
    return tax3;
  }

  public void setTax3(BigDecimal tax3) {
    this.tax3 = tax3;
  }

  public BigDecimal getTotal() {
    return total;
  }

  public void setTotal(BigDecimal total) {
    this.total = total;
  }

}