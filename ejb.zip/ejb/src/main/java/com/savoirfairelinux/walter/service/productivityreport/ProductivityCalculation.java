package com.savoirfairelinux.walter.service.productivityreport;

import com.savoirfairelinux.walter.dao.waltercb.ProductivityReport;

/**
 * @author jderuere
 */
public interface ProductivityCalculation {

    void compute(ProductivityReport report);
}
