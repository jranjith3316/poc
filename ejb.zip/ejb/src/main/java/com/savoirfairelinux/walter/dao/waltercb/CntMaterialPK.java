/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

/**
 *
 * @author mgubaidullin
 */
@Embeddable
public class CntMaterialPK implements Serializable {
    @Basic(optional = false)
    @NotNull
    @Column(name = "CNT_ID")
    private long cntId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "MATERIAL_ID")
    private long materialId;

    public CntMaterialPK() {
    }

    public CntMaterialPK(long cntId, long materialId) {
        this.cntId = cntId;
        this.materialId = materialId;
    }

    public long getCntId() {
        return cntId;
    }

    public void setCntId(long cntId) {
        this.cntId = cntId;
    }

    public long getMaterialId() {
        return materialId;
    }

    public void setMaterialId(long materialId) {
        this.materialId = materialId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) cntId;
        hash += (int) materialId;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CntMaterialPK)) {
            return false;
        }
        CntMaterialPK other = (CntMaterialPK) object;
        if (this.cntId != other.cntId) {
            return false;
        }
        if (this.materialId != other.materialId) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.CntMaterialPK[ cntId=" + cntId + ", materialId=" + materialId + " ]";
    }
    
}
