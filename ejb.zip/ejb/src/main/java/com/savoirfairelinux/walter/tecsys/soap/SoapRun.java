/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.util.ArrayList;
import java.util.List;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 *
 * @author jsgill
 */
public class SoapRun {

  private String url = "https://lxwstapp1.tecsys.cloud/walter_96x_prod/ws/DmsWebService";
  private String wsURL = "http://ws.dms.tecsys.com/";
  private String wscURL = "wsclient.dms.tecsys.com";
  private String userName;
  private String password;
  private String viewName;
  private List<Parameter> paramList;

  public static void main(String args[]) {

    SoapRun soap = new SoapRun();
    soap.run();


  }


  private void run(){
        try{

      setUserName("wsoa");
      setPassword("passxxxxxxx");
      setViewName("DmsAvailQtySoaJw");

      List<Parameter> paramList = new ArrayList<Parameter>();
      paramList.add(new Parameter("Item", "11T042"));
      paramList.add(new Parameter("Warehouse", "MTL;TOR;EDM;VAN"));
      setParamList(paramList);

      Document doc = searchRequest();

//      NodeList nodeList =  doc.getElementsByTagName("DmsAvailQtySoaJw");
//
////      for (int index=0;  nodeList.getLength() <= index ; index++){
//        System.out.println("nodeList.item(index): " + nodeList.item(0));
////      }

//      if ( nodeList. . getLength() != 0 ){{
//
//      }
//
//      if ( nodeList. . getLength() != 0 ){
//        AvailableUPCDTO av = new AvailableUPCDTO();
//        av.setItem_num(nodeList.item(0).getTextContent());
//
//        availableUPCDTO.add(av);
//        System.out.println("Tecsys DmsAvailUpcSoaJw found Item: " + nodeList.item(0).getTextContent());
//      }



    }catch(Exception e) {
      e.printStackTrace();
    }
  }


  public String getUrl() {
    return url;
  }

  public void setUrl(String url) {
    this.url = url;
  }

  public String getWsURL() {
    return wsURL;
  }

  public void setWsURL(String wsURL) {
    this.wsURL = wsURL;
  }

  public String getWscURL() {
    return wscURL;
  }

  public void setWscURL(String wscURL) {
    this.wscURL = wscURL;
  }

  public String getUserName() {
    return userName;
  }

  public void setUserName(String userName) {
    this.userName = userName;
  }

  public String getPassword() {
    return password;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  public String getViewName() {
    return viewName;
  }

  public void setViewName(String viewName) {
    this.viewName = viewName;
  }

  public List<Parameter> getParamList() {
    return paramList;
  }

  public void setParamList(List<Parameter> paramList) {
    this.paramList = paramList;
  }

  public Document searchRequest() {
    Document doc = null;
    try {
      SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory.newInstance();
      SOAPConnection soapConnection = soapConnectionFactory.createConnection();

      SOAPMessage soapResponse = soapConnection.call(createSOAPRequest(), url);
      SOAPPart soapPart = soapResponse.getSOAPPart();
      // SOAP Envelope
      SOAPEnvelope envelope = soapPart.getEnvelope();
      doc = envelope.getOwnerDocument();


      NodeList nodeList =  doc.getElementsByTagName("DmsAvailQtySoaJw");

      System.out.println("");
      System.out.println("");
      System.out.println("");
      System.out.println("");
      System.out.println("start the loop");

      if (nodeList != null) {
         int length = nodeList.getLength();
         for (int i = 1; i < length; i++) { //need to start at 1 the first one are the search criteria
           if (nodeList.item(i).getNodeType() == Node.ELEMENT_NODE) {
             Element el = (Element) nodeList.item(i);
             if (el.getNodeName().contains("DmsAvailQtySoaJw")) {
               System.out.println("");
               System.out.println("");
               System.out.println("");
               System.out.println("el: " + el);

               System.out.println("el.getElementsByTagName(\"AvailableQuantityToAllocate\").item(0).getTextContent(): " + el.getElementsByTagName("AvailableQuantityToAllocate").item(0).getTextContent().toString());
               String availableQuantityToAllocate = el.getElementsByTagName("AvailableQuantityToAllocate").item(0).getTextContent().toString();

               Double dd = Double.parseDouble(availableQuantityToAllocate);
//               quantity += dd.intValue();
               System.out.println("availableQuantityToAllocate: " +availableQuantityToAllocate);

//               System.out.println("quantity: " + quantity);

             }
           }
         }
      }


//      NodeList nl =  doc.getElementsByTagName("DmsAvailQtySoaJw");
//
//      if (nl != null) {
//         int length = nl.getLength();
//         for (int i = 1; i < length; i++) {
//           if (nl.item(i).getNodeType() == Node.ELEMENT_NODE) {
//             Element el = (Element) nl.item(i);
//             if (el.getNodeName().contains("DmsAvailQtySoaJw")) {
//               String Item = el.getElementsByTagName("Item").item(0).getTextContent();
//               String Warehouse = el.getElementsByTagName("Warehouse").item(0).getTextContent();
//               String Organization = el.getElementsByTagName("Organization").item(0).getTextContent();
//               String AvailableQuantityToAllocate = el.getElementsByTagName("AvailableQuantityToAllocate").item(0).getTextContent();
//
//               System.out.println("Item: " + Item);
//               System.out.println("Warehouse: " + Warehouse);
////               System.out.println("Organization: " + Organization);
//               System.out.println("AvailableQuantityToAllocate: " + AvailableQuantityToAllocate);
//             }
//           }
//         }
//      }


//        System.out.println("");
//        System.out.println("");
//        System.out.println("nodeList.item(index): " + nodeList.getLength());
//      for (int index=1;  nodeList.getLength() >= index ; index++){
//        Node node = nodeList.item(index);
//        Element element = (Element) node;
//        System.out.println("element: " + element);
//        System.out.println("element.getElementsByTagName(\"AvailableQuantityToAllocate\").toString(): " + element.getElementsByTagName("AvailableQuantityToAllocate").toString());
//        System.out.println("element.getElementsByTagName(\"AvailableQuantityToAllocate\").getLength(): " + element.getElementsByTagName("AvailableQuantityToAllocate").getLength());
////        System.out.println("element.getElementsByTagName(\"AvailableQuantityToAllocate\").item(0).getNodeValue(): " + element.getElementsByTagName("AvailableQuantityToAllocate").item(1).getNodeValue());
//      }


      soapResponse.writeTo(System.out);
    } catch (SOAPException ex) {
      ex.printStackTrace();
////      System.out.println("ex: " + ex);
    } catch (UnsupportedOperationException ex) {
//      System.out.println("ex: " + ex);
      ex.printStackTrace();
    } catch (Exception ex) {
//      System.out.println("ex: " + ex);
      ex.printStackTrace();
    }
    return doc;
  }

  private SOAPMessage createSOAPRequest() throws Exception {
    MessageFactory messageFactory = MessageFactory.newInstance();
    SOAPMessage soapMessage = messageFactory.createMessage();
    SOAPPart soapPart = soapMessage.getSOAPPart();
    // SOAP Envelope
    SOAPEnvelope envelope = soapPart.getEnvelope();
//    envelope.addNamespaceDeclaration("example", serverURI);
    envelope.addNamespaceDeclaration("ws", getWsURL());
    envelope.addNamespaceDeclaration("wsc", getWscURL());

    SOAPBody soapBody = envelope.getBody();

    SOAPElement soapBodyElem = soapBody.addChildElement("search", "wsc");

    SOAPElement argElement = soapBodyElem.addChildElement("arg0");

    SOAPElement soapBodyElem1 = argElement.addChildElement("userName");
    soapBodyElem1.addTextNode(getUserName());
    SOAPElement soapBodyElem2 = argElement.addChildElement("password");
    soapBodyElem2.addTextNode(getPassword());

    SOAPElement criteriaElement = argElement.addChildElement("criteria");

    SOAPElement viewNameElement = criteriaElement.addChildElement(getViewName());

    for (Parameter param : getParamList()) {
      SOAPElement param1Element = viewNameElement.addChildElement(param.getParamName());
      param1Element.addTextNode(param.getValue());
    }

    MimeHeaders headers = soapMessage.getMimeHeaders();
//    headers.addHeader("SOAPAction", serverURI + "VerifyEmail");

    soapMessage.saveChanges();

    /* Print the request message */
    System.out.println("Request SOAP Message:");
    soapMessage.writeTo(System.out);
    System.out.println("");
    System.out.println("------");

    return soapMessage;
  }


  public class Parameter {
    private String paramName;
    private String value;

    public String getParamName() {
      return paramName;
    }

    public void setParamName(String paramName) {
      this.paramName = paramName;
    }

    public String getValue() {
      return value;
    }

    public void setValue(String value) {
      this.value = value;
    }

    public Parameter(String paramName, String value) {
      this.paramName = paramName;
      this.value = value;
    }
  }

}
