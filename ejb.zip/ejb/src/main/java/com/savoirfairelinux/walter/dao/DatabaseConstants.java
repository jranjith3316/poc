package com.savoirfairelinux.walter.dao;

/**
 *
 * @author mgubaidullin
 */
public class DatabaseConstants {

    public static final String IDB_SCHEMA = "INTLDB";
    public static final String WALTER_SCHEMA = "WALTER";
    public static final String WALTERCB_SCHEMA = "WALTERCB";

}
