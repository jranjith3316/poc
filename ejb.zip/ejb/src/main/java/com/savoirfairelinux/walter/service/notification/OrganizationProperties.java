/* 
 * Copyright 2012 Savoir-faire Linux
 * 
 * This file is part of Walter-Portal.
 * 
 * Walter-Portal is free software: you can redistribute it and/or modify it under the terms of the 
 * GNU General Public License as published by the Free Software Foundation, either version 3 
 * of the License, or (at your option) any later version.
 * 
 * Walter-Portal is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with Walter-Portal. 
 * If not, see http://www.gnu.org/licenses/.
 */
package com.savoirfairelinux.walter.service.notification;

/**
 *
 * @author jbonjean
 *
 * This enum stores organization related properties. XXX: This properties should
 * not be hard-coded, maybe we should use expando. Nevertheless I still
 * hard-coded them because they are not supposed to change. TBD...
 */
public enum OrganizationProperties {

    WALTER("Walter",
    "walter-email-logo.png",
    "WalterShare",
    "waltershare@walter.com",
    "walter",
    "walter"),
    BIO_CIRCLE("BioCircle",
    "biocircle-email-logo.png",
    "Bio-Circle",
    "bcshare@bio-circle.de",
    "cb",
    "biocircle");
    private final String name;
    private final String logoFileName;
    private final String managementName;
    private final String managementEmail;
    private final String dbname;
    private final String cssClass;

    private OrganizationProperties(String name, String logoFileName, String managementName, String managementEmail,
            String dbname, String backgroundColor) {
        this.name = name;
        this.logoFileName = logoFileName;
        this.managementName = managementName;
        this.managementEmail = managementEmail;
        this.dbname = dbname;
        this.cssClass = backgroundColor;
    }

    public String getName() {
        return name;
    }

    public String getManagementName() {
        return managementName;
    }

    public String getManagementEmail() {
        return managementEmail;
    }

    public String getDbname() {
        return dbname;
    }

    public String getCssClass() {
        return cssClass;
    }

    public String getLogoFileName() {
        return logoFileName;
    }
}