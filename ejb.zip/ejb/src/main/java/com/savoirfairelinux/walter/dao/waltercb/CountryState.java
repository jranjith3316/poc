/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "COUNTRY_STATE", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CountryState.findAll", query = "SELECT c FROM CountryState c"),
    @NamedQuery(name = "CountryState.findByCountryId", query = "SELECT c FROM CountryState c WHERE c.countryStatePK.countryId = :countryId"),
    @NamedQuery(name = "CountryState.findByStateCode", query = "SELECT c FROM CountryState c WHERE c.countryStatePK.stateCode = :stateCode"),
    @NamedQuery(name = "CountryState.findByTaxCode1", query = "SELECT c FROM CountryState c WHERE c.taxCode1 = :taxCode1"),
    @NamedQuery(name = "CountryState.findByTaxCode2", query = "SELECT c FROM CountryState c WHERE c.taxCode2 = :taxCode2"),
    @NamedQuery(name = "CountryState.findByTaxCode3", query = "SELECT c FROM CountryState c WHERE c.taxCode3 = :taxCode3")})
public class CountryState implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected CountryStatePK countryStatePK;
    @Size(max = 10)
    @Column(name = "TAX_CODE_1")
    private String taxCode1;
    @Size(max = 10)
    @Column(name = "TAX_CODE_2")
    private String taxCode2;
    @Size(max = 10)
    @Column(name = "TAX_CODE_3")
    private String taxCode3;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "countryState")
    private Set<CountryStateTxt> countryStateTxtSet;
    @JoinColumn(name = "COUNTRY_ID", referencedColumnName = "COUNTRY_ID", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Country country;

    public CountryState() {
    }

    public CountryState(CountryStatePK countryStatePK) {
        this.countryStatePK = countryStatePK;
    }

    public CountryState(long countryId, String stateCode) {
        this.countryStatePK = new CountryStatePK(countryId, stateCode);
    }

    public CountryStatePK getCountryStatePK() {
        return countryStatePK;
    }

    public void setCountryStatePK(CountryStatePK countryStatePK) {
        this.countryStatePK = countryStatePK;
    }

    public String getTaxCode1() {
        return taxCode1;
    }

    public void setTaxCode1(String taxCode1) {
        this.taxCode1 = taxCode1;
    }

    public String getTaxCode2() {
        return taxCode2;
    }

    public void setTaxCode2(String taxCode2) {
        this.taxCode2 = taxCode2;
    }

    public String getTaxCode3() {
        return taxCode3;
    }

    public void setTaxCode3(String taxCode3) {
        this.taxCode3 = taxCode3;
    }

    @XmlTransient
    public Set<CountryStateTxt> getCountryStateTxtSet() {
        return countryStateTxtSet;
    }

    public void setCountryStateTxtSet(Set<CountryStateTxt> countryStateTxtSet) {
        this.countryStateTxtSet = countryStateTxtSet;
    }

    public Country getCountry() {
        return country;
    }

    public void setCountry(Country country) {
        this.country = country;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (countryStatePK != null ? countryStatePK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CountryState)) {
            return false;
        }
        CountryState other = (CountryState) object;
        if ((this.countryStatePK == null && other.countryStatePK != null) || (this.countryStatePK != null && !this.countryStatePK.equals(other.countryStatePK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.CountryState[ countryStatePK=" + countryStatePK + " ]";
    }
    
}
