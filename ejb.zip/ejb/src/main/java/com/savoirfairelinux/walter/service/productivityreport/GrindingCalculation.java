package com.savoirfairelinux.walter.service.productivityreport;

import com.savoirfairelinux.walter.dao.waltercb.ProductivityReport;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * @author jderuere
 */
public class GrindingCalculation implements ProductivityCalculation {

    @Override
    public void compute(ProductivityReport report) {
        BigDecimal yearlyUsage = BigDecimal.valueOf(report.getYearlyUsage());
        BigDecimal annualRemovedMaterial = yearlyUsage.multiply(BigDecimal.valueOf(report.getCompetitorResult().getRemovedMaterial()));
        BigDecimal walterRequiredQuantity = annualRemovedMaterial.divide(BigDecimal.valueOf(report.getWalterResult().getRemovedMaterial()), 2, RoundingMode.HALF_UP);
//                .multiply(BigDecimal.valueOf(report.getCompetitorResult().getLife()).divide(BigDecimal.valueOf(report.getWalterResult().getLife()), 2, RoundingMode.HALF_UP));

        BigDecimal competitorCost = BigDecimal.valueOf(report.getCompetitorPrice()).multiply(yearlyUsage);
        BigDecimal competitorManHourRequired = yearlyUsage.multiply((BigDecimal.valueOf(report.getCompetitorResult().getLife()).add(BigDecimal.valueOf(5))).divide(BigDecimal.valueOf(60), 2, RoundingMode.HALF_UP));
        BigDecimal competitorLabourCost = competitorManHourRequired.multiply(BigDecimal.valueOf(report.getHourlyLaborRate()));

        BigDecimal walterCost = BigDecimal.valueOf(report.getWalterPrice()).multiply(walterRequiredQuantity);
        BigDecimal walterManHourRequired = walterRequiredQuantity.multiply((BigDecimal.valueOf(report.getWalterResult().getLife()).add(BigDecimal.valueOf(5))).divide(BigDecimal.valueOf(60), 2, RoundingMode.HALF_UP));
        BigDecimal walterLabourCost = walterManHourRequired.multiply(BigDecimal.valueOf(report.getHourlyLaborRate()));

        report.setCompetitorAnnualRemovedMaterial(annualRemovedMaterial.doubleValue());
        report.setWalterWheelsQuantity(walterRequiredQuantity.setScale(0, RoundingMode.UP).intValue());
        report.setCompetitorProductCost(competitorCost.setScale(2, RoundingMode.HALF_UP).doubleValue());
        report.setCompetitorManHoursRequired(competitorManHourRequired.setScale(0, RoundingMode.HALF_UP).intValue());
        report.setCompetitorLabourCost(competitorLabourCost.setScale(2, RoundingMode.HALF_UP).doubleValue());
        report.setWalterProductCost(walterCost.setScale(2, RoundingMode.HALF_UP).doubleValue());
        report.setWalterManHoursRequired(walterManHourRequired.setScale(0, RoundingMode.HALF_UP).intValue());
        report.setWalterLabourCost(walterLabourCost.setScale(2, RoundingMode.HALF_UP).doubleValue());
    }
}