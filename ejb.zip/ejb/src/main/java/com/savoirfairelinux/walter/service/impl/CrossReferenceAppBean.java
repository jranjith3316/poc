/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.service.impl;

import com.savoirfairelinux.walter.crossreferenceapp.model.CompetitorBrandModel;
import com.savoirfairelinux.walter.crossreferenceapp.model.CompetitorModel;
import com.savoirfairelinux.walter.crossreferenceapp.model.CompetitorProductModel;
import com.savoirfairelinux.walter.crossreferenceapp.model.CompetitorWalterProductModel;
import com.savoirfairelinux.walter.crossreferenceapp.model.DocumentModel;
import com.savoirfairelinux.walter.crossreferenceapp.model.HazardModel;
import com.savoirfairelinux.walter.crossreferenceapp.model.OoInstancesModel;
import com.savoirfairelinux.walter.crossreferenceapp.model.ServerConstants;
import com.savoirfairelinux.walter.crossreferenceapp.model.WalterProductModel;
import com.savoirfairelinux.walter.crossreferenceapp.rest.APIRestApp;
import com.savoirfairelinux.walter.dao.crossreferenceapp.Action;
import com.savoirfairelinux.walter.dao.crossreferenceapp.Competitor;
import com.savoirfairelinux.walter.dao.crossreferenceapp.CompetitorBrand;
import com.savoirfairelinux.walter.dao.crossreferenceapp.CompetitorBrandPK;
import com.savoirfairelinux.walter.dao.crossreferenceapp.CompetitorCounter;
import com.savoirfairelinux.walter.dao.crossreferenceapp.CompetitorCounterPK;
import com.savoirfairelinux.walter.dao.crossreferenceapp.CompetitorHazard;
import com.savoirfairelinux.walter.dao.crossreferenceapp.CompetitorProduct;
import com.savoirfairelinux.walter.dao.crossreferenceapp.CompetitorWalterProduct;
import com.savoirfairelinux.walter.dao.crossreferenceapp.Diluent;
import com.savoirfairelinux.walter.dao.idb.OoClasses;
import com.savoirfairelinux.walter.dao.idb.OoInstances;
import com.savoirfairelinux.walter.dao.waltercb.Country;
import com.savoirfairelinux.walter.dao.waltercb.ULang;
import com.savoirfairelinux.walter.model.Image;
import com.savoirfairelinux.walter.service.CrossReferenceAppBeanRemote;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.TimeZone;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.security.PermitAll;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author jsgill
 */
@Stateless(name = "CrossReferenceAppBean")
@TransactionManagement(TransactionManagementType.CONTAINER)
@PermitAll
@LocalBean
public class CrossReferenceAppBean implements CrossReferenceAppBeanRemote {

  public static final Logger LOG = Logger.getLogger(CrossReferenceAppBean.class.getCanonicalName());
  @PersistenceContext(unitName = "waltershare")
  EntityManager entityManager;
  @EJB
  SingletonBean singletonBean;
  @EJB
  WalterBean walterBean;
  ResourceBundle messages;

  @Override
  @Interceptors(DebugInterceptor.class)
  public List<CompetitorModel> getCompetitor(String langCode, String countryCode, Date date){
    List<CompetitorModel> competitorModelList = new ArrayList<>();

    try {
      Locale locale = new Locale(langCode, countryCode);
      ULang uLang = walterBean.getULang(langCode);
      messages = ResourceBundle.getBundle("resources/MessagesBundle", locale);

      List<Competitor> competitorList = getCompetitorList();

      for (Competitor competitor : competitorList) {
        CompetitorModel cm = new CompetitorModel();
        cm.setCompetitorId(competitor.getCompetitorId());
        cm.setCompetitorName(competitor.getName());

        List<CompetitorBrand> competitorBrands = getCompetitorBrandList(competitor.getCompetitorId());
        List<CompetitorBrandModel> competitorBrandModels = new ArrayList<>();
        for (CompetitorBrand competitorBrand : competitorBrands) {
          CompetitorBrandModel competitorBrandModel = new CompetitorBrandModel();
          competitorBrandModel.setBrandId(competitorBrand.getCompetitorBrandPK().getBrandId());
          competitorBrandModel.setBrandName(competitorBrand.getName());

          List<CompetitorProduct> competitorProducts = getCompetitorBrandProductList(competitor.getCompetitorId(), competitorBrand.getCompetitorBrandPK().getBrandId(), countryCode, date, false);
          List<CompetitorProductModel> competitorProductModels = new ArrayList<>();

          for (CompetitorProduct competitorProduct : competitorProducts) {
            competitorProductModels.add(transfertCompetitorProduct(competitorProduct, uLang, langCode, countryCode));

          }
          if ( competitorProducts.size() > 0 ) {
            competitorBrandModel.setCompetitorProducts(competitorProductModels);
            competitorBrandModels.add(competitorBrandModel);
          }
        }
        if ( competitorBrandModels.size() > 0 ) {
          cm.setCompetitorBrands(competitorBrandModels);
          competitorModelList.add(cm);
        }
      }

    } catch (Exception ex) {
//      ex.printStackTrace();
      Logger.getLogger(APIRestApp.class.getName()).log(Level.SEVERE, null, ex);
    }
    return competitorModelList;
  }

  private CompetitorProductModel transfertCompetitorProduct(CompetitorProduct competitorProduct, ULang uLang, String langCode, String countryCode){

    CompetitorProductModel competitorProductModel = new CompetitorProductModel();
    competitorProductModel.setBrandId(competitorProduct.getCompetitorProductPK().getBrandId());
    competitorProductModel.setCompetitorId(competitorProduct.getCompetitorProductPK().getCompetitorId());
    competitorProductModel.setProductId(competitorProduct.getCompetitorProductPK().getProductId());
    try{
    competitorProductModel.setDateVerified(String.format("%1$td-%1$tb-%1$tY", competitorProduct.getDateVerified()));

    }catch(Exception e){
      e.printStackTrace();
    }
//

    if ( competitorProduct.getRealFilename() != null )
    competitorProductModel.setProductImage(ServerConstants.IMAGES_CROSSREFERENCEAPP_DOMAIN+"/"+competitorProduct.getRealFilename());

    if (competitorProduct.getDiluentId() != null) {
      Diluent diluent = getDiluent(uLang.getLangId(), competitorProduct.getDiluentId());
      competitorProductModel.setDiluation(getValue(competitorProduct.getDiluationRatio()) + " " + diluent.getName());
    } else {
      competitorProductModel.setDiluation("");
    }

    competitorProductModel.setElementCorrosion((competitorProduct.getElementCorrosion() != null && competitorProduct.getElementCorrosion().equals('N')) ? false : true);
    competitorProductModel.setElementEnvironment((competitorProduct.getElementEnvironment() != null && competitorProduct.getElementEnvironment().equals('N')) ? false : true);
    competitorProductModel.setElementExclamation((competitorProduct.getElementExclamation() != null && competitorProduct.getElementExclamation().equals('N')) ? false : true);
    competitorProductModel.setElementExplodingBomb((competitorProduct.getElementExplodingBomb() != null && competitorProduct.getElementExplodingBomb().equals('N')) ? false : true);
    competitorProductModel.setElementFlame((competitorProduct.getElementFlame() != null && competitorProduct.getElementFlame().equals('N')) ? false : true);
    competitorProductModel.setElementFlameCircle((competitorProduct.getElementFlameCircle() != null && competitorProduct.getElementFlameCircle().equals('N')) ? false : true);
    competitorProductModel.setElementGasCylinder((competitorProduct.getElementGasCylinder() != null && competitorProduct.getElementGasCylinder().equals('N')) ? false : true);
    competitorProductModel.setElementHealth((competitorProduct.getElementHealth() != null && competitorProduct.getElementHealth().equals('N')) ? false : true);
    competitorProductModel.setElementSkull((competitorProduct.getElementSkull() != null && competitorProduct.getElementSkull().equals('N')) ? false : true);

    competitorProductModel.setEnvironmentalHazards(getHazard(competitorProduct, "EnvironmentalHazard", langCode));
    competitorProductModel.setHealthHazards(getHazard(competitorProduct, "HealthHazard", langCode));
    competitorProductModel.setPhysicalHazards(getHazard(competitorProduct, "PhysicalHazard", langCode));

    if (competitorProduct.getFormat() != null) {
      competitorProductModel.setFormat(getInstanceTraduction(langCode, competitorProduct.getFormat(), "Name"));
    } else {
      competitorProductModel.setFormat("");
    }

    if (competitorProduct.getMetricUnitGuid() != null) {
      String unit = getInstanceTraduction(langCode, competitorProduct.getMetricUnitGuid(), "Name");
      String size = getValue(competitorProduct.getMetricSize());
      if (!size.equals("")) {
        competitorProductModel.setMetricSize(size + " " + unit);
      }
    }

    if (competitorProduct.getImperialUnitGuid() != null) {
      String unit = getInstanceTraduction(langCode, competitorProduct.getImperialUnitGuid(), "Name");
      String size = getValue(competitorProduct.getImperialSize());
      if (!size.equals("")) {
        competitorProductModel.setImperialSize(size + " " + unit);
      }
    }

    List<String> materialGuidList = getMaterialGuidList(competitorProduct.getCompetitorProductPK().getCompetitorId(), competitorProduct.getCompetitorProductPK().getBrandId(),
                                              competitorProduct.getCompetitorProductPK().getProductId(), competitorProduct.getCompetitorProductPK().getCountryId(), langCode);

//            List<String> materialList = new ArrayList<>();
//
//            for (String materialGuid : materialGuidList) {
//              String translation = getInstanceTraduction(langCode, materialGuid, "Name");
//              materialList.add(translation);
//            }

    competitorProductModel.setMaterials(materialGuidList);

    competitorProductModel.setApplications(getApplicationList(competitorProduct.getCompetitorProductPK().getCompetitorId(), competitorProduct.getCompetitorProductPK().getBrandId(),
                                                              competitorProduct.getCompetitorProductPK().getProductId(), competitorProduct.getCompetitorProductPK().getCountryId(), langCode));

    String ph = getValue(competitorProduct.getPhLower());
    if (ph.equals("")) {
      ph = getValue(competitorProduct.getPhHight());
    } else if (!getValue(competitorProduct.getPhHight()).equals("")) {
      ph += " - " + getValue(competitorProduct.getPhHight());
    }

    competitorProductModel.setPh(ph);

    competitorProductModel.setProductNumber(getValue(competitorProduct.getProductNumber()));

    competitorProductModel.setProp65(getInstanceTraduction(langCode, getValue(competitorProduct.getProp65()), "Name"));

    DocumentModel sdsDocument = new DocumentModel(getValue(competitorProduct.getSdsUrl()), getMessage("labelMobileCrossAppDocument"));
    DocumentModel tdsDocument = new DocumentModel(getValue(competitorProduct.getTdsUrl()), getMessage("labelMobileCrossAppDocument"));

    if ( sdsDocument.getUrl() != null && !sdsDocument.getUrl().equals("") ){
      competitorProductModel.setSdsDocument(sdsDocument);
    }

    if ( tdsDocument.getUrl() != null && !tdsDocument.getUrl().equals("") ){
      competitorProductModel.setTdsDocument(tdsDocument);
    }

    String temperatureMetric = checkTempIsMinus(getValue(competitorProduct.getTemperatureMin()), " C°");
    String temperatureImperial = checkTempIsMinus(getTemperatureImperial(getValue(competitorProduct.getTemperatureMin())), " F°");
    if (temperatureMetric.equals("")) {
      temperatureMetric = checkTempIsMinus(getValue(competitorProduct.getTemperatureMax()), " C°");
      temperatureImperial = checkTempIsMinus(getTemperatureImperial(getValue(competitorProduct.getTemperatureMax())), " F°");

//      if ( !temperatureMetric.equals("") ){
//        temperatureMetric = temperatureMetric + " C°";
//      }
//
//      if ( !temperatureImperial.equals("") ){
//        temperatureImperial = temperatureImperial + " F°";
//      }

    } else if (!getValue(competitorProduct.getTemperatureMax()).equals("")) {
      temperatureMetric += " - " + checkTempIsMinus(getValue(competitorProduct.getTemperatureMax()), " C°");
      temperatureImperial += " - " + checkTempIsMinus(getTemperatureImperial(getValue(competitorProduct.getTemperatureMax())), "F°");
    }

    competitorProductModel.setMetricTemperature(temperatureMetric);
    competitorProductModel.setImperialTemperature(temperatureImperial);
    competitorProductModel.setUpc(getValue(competitorProduct.getUpc()));
    competitorProductModel.setVoc(getValue(competitorProduct.getVoc()) + " " + getValue(competitorProduct.getVocUnitGuid()));

    List<String> certifications = getCertificationIconList(competitorProduct.getCompetitorProductPK().getCompetitorId(), competitorProduct.getCompetitorProductPK().getBrandId(),
                                                           competitorProduct.getCompetitorProductPK().getProductId(), competitorProduct.getCompetitorProductPK().getCountryId());
//            List<String> certificationList = new ArrayList<>();
//            for (OoInstances oo : ooCertifications) {
//
//
//
//
//              String translation = getInstanceTraduction(langCode, oo.getInstanceguid(), "Icon");
//              certificationList.add(translation);
//            }
    competitorProductModel.setCertifications(certifications);

    List<CompetitorWalterProduct> competitorWalterProducts = getCompetitorWalterProduct(competitorProduct.getCompetitorProductPK().getCompetitorId(), competitorProduct.getCompetitorProductPK().getBrandId(),
            competitorProduct.getCompetitorProductPK().getProductId(), competitorProduct.getCompetitorProductPK().getCountryId());

    List<CompetitorWalterProductModel> competitorWalterProductModels = new ArrayList<>();

    for (CompetitorWalterProduct competitorWalterProduct : competitorWalterProducts) {
      String action = getActionText(competitorWalterProduct.getCompetitorWalterProductPK().getCategoryId(), uLang.getLangId());

      CompetitorWalterProductModel cwpm = new CompetitorWalterProductModel(action, competitorWalterProduct.getCompetitorWalterProductPK().getProductNumber(),
                                                                           getTradename(countryCode, langCode, competitorWalterProduct.getCompetitorWalterProductPK().getProductNumber()));
      competitorWalterProductModels.add(cwpm);
    }
    competitorProductModel.setCompetitorWalterProducts(competitorWalterProductModels);

    return competitorProductModel;
  }

  public void setMessages(ResourceBundle messages) {
    this.messages = messages;
  }

  public String getMessage(String key) {
    try {
      return messages.getString(key);
    } catch (Exception ex) {
      ex.printStackTrace();
      return key;
    }

  }

  /**
   *
   * Format the temperature with () when temperature are minus
   *
   */
  private String checkTempIsMinus(String temperature, String unit){
    if ( temperature != null && !temperature.equals("") ) {
      try{
        Float temp = Float.parseFloat(temperature);
        if ( temp < 0 ) {
          temperature = "("+temperature+unit+")";
        } else {
          temperature= temperature + unit;
        }
      } catch ( Exception e ) {

      }
    }

    return temperature;
  }

  @Interceptors(DebugInterceptor.class)
  public List<HazardModel> getHazard(CompetitorProduct cp, String parentHazard, String langCode) {
    List<HazardModel> hazardModels = new ArrayList<>();
    try {

      List<Object[]> objectList = entityManager.createNativeQuery(singletonBean.getCrossReferenceApp("competitorHazard.getHazard"))
                                               .setParameter("competitorId", cp.getCompetitorProductPK().getCompetitorId())
                                               .setParameter("brandId", cp.getCompetitorProductPK().getBrandId())
                                               .setParameter("productId", cp.getCompetitorProductPK().getProductId())
                                               .setParameter("countryId", cp.getCompetitorProductPK().getCountryId())
                                               .setParameter("parentClassName", parentHazard)
                                               .setParameter("langCode", langCode)
                                               .getResultList();

      for ( Object[] object : objectList ){
        String valueName = object[0].toString();
        String labelName = object[1].toString();

        HazardModel hm = new HazardModel();
        hm.setLabel(labelName);
        hm.setValue(valueName);

        hazardModels.add(hm);

      }

    } catch (Exception e) {
      LOG.severe("getHazard: " + e.getMessage());
        e.printStackTrace();
    }
    return hazardModels;
  }

  @Interceptors(DebugInterceptor.class)
  public List<Object[]> getHazardList(CompetitorProduct cp, String langCode) {
    List<Object[]> objectList = new ArrayList<>();
    try {

      objectList = entityManager.createNativeQuery(singletonBean.getCrossReferenceApp("competitorHazard.getHazardList"))
                                               .setParameter("competitorId", cp.getCompetitorProductPK().getCompetitorId())
                                               .setParameter("brandId", cp.getCompetitorProductPK().getBrandId())
                                               .setParameter("productId", cp.getCompetitorProductPK().getProductId())
                                               .setParameter("countryId", cp.getCompetitorProductPK().getCountryId())
                                               .setParameter("langCode", langCode)
                                               .getResultList();

    } catch (Exception e) {
      LOG.severe("getHazard: " + e.getMessage());
        e.printStackTrace();
    }
    return objectList;
  }

  public String getValue(Object object) {
    String value = "";
    if (object != null) {
      value = object.toString();
    }

    return (value != null) ? value : "";
  }

  public String getTemperatureImperial(Object object) {
    float imperial = 0;
    String returnValue = "";
    try {
      float metric = Float.parseFloat(object.toString());
      imperial = (metric*1.8F)+32F;
      DecimalFormat df = new DecimalFormat("#.##");
      returnValue = String.valueOf(df.format(imperial));
    } catch (NumberFormatException e) {
//      System.out.println("getTemperatureImperial: " + e.getMessage());
      if ( object != null ){
        returnValue = object.toString();
      }
    }

    return returnValue;
  }

  @Override
  @Interceptors(DebugInterceptor.class)
  public List<Competitor> getCompetitorList() {
    List<Competitor> competitor = new ArrayList<>();

    try {

      competitor = entityManager.createQuery(singletonBean.getCrossReferenceApp("Competitor.getAll"), Competitor.class)
                                .getResultList();

    } catch (Exception e) {
      LOG.severe("getCompetitorList: " + e.getMessage());
////        e.printStackTrace();
    }

    return competitor;
  }
  @Override
  @Interceptors(DebugInterceptor.class)
  public List<CompetitorBrand> getCompetitorBrandList(Long competitorId) {
    List<CompetitorBrand> competitorBrand = new ArrayList<>();

    try {

      competitorBrand = entityManager.createQuery(singletonBean.getCrossReferenceApp("CompetitorBrand.getAll"), CompetitorBrand.class)
                                     .setParameter("competitorId", competitorId)
                                     .getResultList();

    } catch (Exception e) {
      LOG.severe("getCompetitorBrandList: " + e.getMessage());
//        e.printStackTrace();
    }

    return competitorBrand;
  }

  @Override
  @Interceptors(DebugInterceptor.class)
  public List<CompetitorProduct> getCompetitorBrandProductList(Long competitorId, Long brandId, String countryCode, Date date, boolean findOtherCountry) {
    List<CompetitorProduct> competitorProducts = new ArrayList<>();

    try {

      if ( findOtherCountry == false ) {
        if ( date == null ) {
          competitorProducts = entityManager.createQuery(singletonBean.getCrossReferenceApp("CompetitorProduct.getAllForApp"), CompetitorProduct.class)
                                            .setParameter("competitorId", competitorId)
                                            .setParameter("brandId", brandId)
                                            .setParameter("countryCode", countryCode)
                                            .getResultList();
        } else {
          List<Object[]> objects = entityManager.createNativeQuery(singletonBean.getCrossReferenceApp("CompetitorProduct.getUpdatedWithWalterProduct"))
                                                .setParameter("competitorId", competitorId)
                                                .setParameter("brandId", brandId)
                                                .setParameter("countryCode", countryCode)
                                                .setParameter("lastUpdated", date)
                                                .getResultList();

          for ( Object[] object : objects ){
            List<CompetitorProduct> competitorProductTemps = new ArrayList<>();

            long competitorIdTemp = Long.parseLong(object[0].toString());
            long brandIdTemp = Long.parseLong(object[1].toString());;
            long productIdTemp = Long.parseLong(object[2].toString());
            long countryIdTemp = Long.parseLong(object[3].toString());;

            competitorProductTemps = entityManager.createQuery(singletonBean.getCrossReferenceApp("CompetitorProduct.getUpdatedForApp"), CompetitorProduct.class)
                                              .setParameter("competitorId", competitorIdTemp)
                                              .setParameter("brandId", brandIdTemp)
                                              .setParameter("productId", productIdTemp)
                                              .setParameter("countryId", countryIdTemp)
                                              .getResultList();

            competitorProducts.addAll(competitorProductTemps);

          }
        }

      } else {
        competitorProducts = entityManager.createQuery(singletonBean.getCrossReferenceApp("CompetitorProduct.getAllForManage"), CompetitorProduct.class)
                                          .setParameter("competitorId", competitorId)
                                          .setParameter("brandId", brandId)
                                          .setParameter("countryCode", countryCode)
                                          .getResultList();

      }
    } catch (Exception e) {
      LOG.severe("getCompetitorBrandProductList: " + e.getMessage());
//        e.printStackTrace();
    }

    return competitorProducts;
  }

  @Override
  @Interceptors(DebugInterceptor.class)
  public CompetitorProduct getCompetitorBrandProduct(Long competitorId, Long brandId, Long productId, Long countryId) {
    CompetitorProduct competitorProducts = new CompetitorProduct(competitorId, brandId, productId, countryId);

    try {

      competitorProducts = entityManager.createQuery(singletonBean.getCrossReferenceApp("CompetitorProduct.getByPrimaryKey"), CompetitorProduct.class)
                                        .setParameter("competitorId", competitorId)
                                        .setParameter("brandId", brandId)
                                        .setParameter("productId", productId)
                                        .setParameter("countryId", countryId)
                                        .getSingleResult();

    } catch (Exception e) {
      LOG.severe("getCompetitorBrandProduct: " + e.getMessage());
//        e.printStackTrace();
    }

    return competitorProducts;
  }

  @Override
  @Interceptors(DebugInterceptor.class)
  public List<OoInstances> getMaterialList(Long competitorId, Long brandId, Long productId, Long countryId) {
    List<OoInstances> oo = new ArrayList<>();

    try {

      oo = entityManager.createQuery(singletonBean.getCrossReferenceApp("Material.getByProductId"), OoInstances.class)
                        .setParameter("competitorId", competitorId)
                        .setParameter("brandId", brandId)
                        .setParameter("productId", productId)
                        .setParameter("countryId", countryId)
                        .getResultList();

    } catch (Exception e) {
      LOG.severe("getMaterialList: " + e.getMessage());
//        e.printStackTrace();
    }

    return oo;
  }

  @Interceptors(DebugInterceptor.class)
  public List<String> getMaterialGuidList(Long competitorId, Long brandId, Long productId, Long countryId, String langCode) {
    List<String> materialGuid = new ArrayList<>();

    try {

      materialGuid = entityManager.createNativeQuery(singletonBean.getCrossReferenceApp("Material.getinstanceguid"))
                                  .setParameter("competitorId", competitorId)
                                  .setParameter("brandId", brandId)
                                  .setParameter("productId", productId)
                                  .setParameter("countryId", countryId)
                                  .setParameter("langCode", langCode)
                                  .getResultList();

    } catch (Exception e) {
      LOG.severe("getMaterialGuidList: " + e.getMessage());
        e.printStackTrace();
    }

    return materialGuid;
  }

  @Interceptors(DebugInterceptor.class)
  public List<CompetitorWalterProduct> getCompetitorWalterProduct(Long competitorId, Long brandId, Long productId, Long countryId){
    List<CompetitorWalterProduct> competitorWalterProducts = new ArrayList<>();

    try {

      competitorWalterProducts = entityManager.createQuery(singletonBean.getCrossReferenceApp("CompetitorWalterProduct.getByProductId"), CompetitorWalterProduct.class)
                                              .setParameter("competitorId", competitorId)
                                              .setParameter("brandId", brandId)
                                              .setParameter("productId", productId)
                                              .setParameter("countryId", countryId)
                                              .getResultList();

    } catch (Exception e) {
      LOG.severe("getCompetitorWalterProduct: " + e.getMessage());
//        e.printStackTrace();
    }

    return competitorWalterProducts;
  }


  @Override
  @Interceptors(DebugInterceptor.class)
  public List<OoInstances> getCertificationList(Long competitorId, Long brandId, Long productId, Long countryId) {
    List<OoInstances> oo = new ArrayList<>();

    try {

      oo = entityManager.createQuery(singletonBean.getCrossReferenceApp("Certification.getByProductId"), OoInstances.class)
                        .setParameter("competitorId", competitorId)
                        .setParameter("brandId", brandId)
                        .setParameter("productId", productId)
                        .setParameter("countryId", countryId)
                        .getResultList();

    } catch (Exception e) {
      LOG.severe("getCertificationList: " + e.getMessage());
//        e.printStackTrace();
    }

    return oo;
  }

  @Override
  @Interceptors(DebugInterceptor.class)
  public List<String> getCertificationIconList(Long competitorId, Long brandId, Long productId, Long countryId) {
    List<String> certifications = new ArrayList<>();
    List<String> temps = new ArrayList<>();

    try {

      temps = entityManager.createNativeQuery(singletonBean.getCrossReferenceApp("Certification.getCertificationIcon"))
                        .setParameter("competitorId", competitorId)
                        .setParameter("brandId", brandId)
                        .setParameter("productId", productId)
                        .setParameter("countryId", countryId)
                        .getResultList();

      for ( String certification : temps ) {
        certifications.add(ServerConstants.IMAGES_DOMAIN+"/icons/white_"+certification.replace(".png" ,".jpg"));

      }

    } catch (Exception e) {
      LOG.severe("getCertificationIconList: " + e.getMessage());
//        e.printStackTrace();
    }

    return certifications;
  }

  @Interceptors(DebugInterceptor.class)
  public List<String> getApplicationList(Long competitorId, Long brandId, Long productId, Long countryId, String langCode) {
    List<String> applications = new ArrayList<>();

    try {

      applications = entityManager.createNativeQuery(singletonBean.getCrossReferenceApp("Application.getTranslation"))
                                        .setParameter("competitorId", competitorId)
                                        .setParameter("brandId", brandId)
                                        .setParameter("productId", productId)
                                        .setParameter("countryId", countryId)
                                        .setParameter("langCode", langCode)
                                        .getResultList();

//      for ( String guid : guids ){
//        String application = getInstanceTraduction(langCode, guid, "Name");
//        applications.add(application);
//
//      }



    } catch (Exception e) {
      LOG.severe("getApplicationList: " + e.getMessage());
//        e.printStackTrace();
    }

    return applications;
  }

  @Override
  @Interceptors(DebugInterceptor.class)
  public List<OoInstances> getApplicationInstances(Long competitorId, Long brandId, Long productId, Long countryId) {
    List<OoInstances> applications = new ArrayList<>();

    try {

      applications = entityManager.createQuery(singletonBean.getCrossReferenceApp("Application.getinstanceguid"))
                                  .setParameter("competitorId", competitorId)
                                  .setParameter("brandId", brandId)
                                  .setParameter("productId", productId)
                                  .setParameter("countryId", countryId)
                                  .getResultList();

    } catch (Exception e) {
      LOG.severe("getApplicationInstances: " + e.getMessage());
//        e.printStackTrace();
    }

    return applications;
  }

  @Override
  @Interceptors(DebugInterceptor.class)
  public List<Country> getCountryList() {
    List<Country> countryList = new ArrayList<>();

    try {

      countryList = entityManager.createQuery(singletonBean.getCrossReferenceApp("Country.getAll"), Country.class)
                                 .getResultList();

    } catch (Exception e) {
      LOG.severe("getCountryList: " + e.getMessage());
//        e.printStackTrace();
    }

    return countryList;
  }

  @Override
  @Interceptors(DebugInterceptor.class)
  public Competitor saveCompetitor(Competitor competitor) {
    try {

      if (competitor.getCompetitorId() == 0L) {
        Object competitorId = entityManager.createNativeQuery(singletonBean.getCrossReferenceApp("Competitor.nextSequence")).getSingleResult();
        competitor.setCompetitorId(Long.parseLong(competitorId.toString()));
      }
      competitor = walterBean.save(competitor);

    } catch (Exception ex) {
      LOG.severe("saveCompetitor: " + ex.getMessage());
//      ex.printStackTrace();
    }
    return competitor;
  }

  @Override
  @Interceptors(DebugInterceptor.class)
  public CompetitorBrand saveCompetitorBrand(CompetitorBrand competitorBrand) {
    try {

      if (competitorBrand.getCompetitorBrandPK().getBrandId() == 0L) {
        Object brandId = entityManager.createNativeQuery(singletonBean.getCrossReferenceApp("CompetitorBrand.nextSequence")).getSingleResult();
        competitorBrand.setCompetitorBrandPK(new CompetitorBrandPK(competitorBrand.getCompetitorBrandPK().getCompetitorId(), Long.parseLong(brandId.toString())));
      }
      competitorBrand = walterBean.save(competitorBrand);

    } catch (Exception ex) {
      LOG.severe("saveCompetitorBrand: " + ex.getMessage());
//      ex.printStackTrace();
    }
    return competitorBrand;
  }

    @Override
  @Interceptors(DebugInterceptor.class)
  public CompetitorProduct saveCompetitorProduct(CompetitorProduct competitorProduct){
    CompetitorProduct cp = new CompetitorProduct();
    try {

      cp = entityManager.merge(competitorProduct);

    } catch (Exception ex) {
      LOG.severe("saveCompetitorProduct: " + ex.getMessage());
//      ex.printStackTrace();
    }
    return cp;
  }

  @Override
  @Interceptors(DebugInterceptor.class)
  public List<OoInstances> getInstanceByClassname(String classname) {
    List<OoInstances> ooList = new ArrayList<>();

    try {

      ooList = entityManager.createQuery(singletonBean.getCrossReferenceApp("OoInstance.getByClassName"))
                            .setParameter("classname", classname)
                            .getResultList();

    } catch (Exception ex) {
      LOG.severe("getInstanceByClassname: " + ex.getMessage());
//      ex.printStackTrace();
    }

    return ooList;
  }

  @Override
  @Interceptors(DebugInterceptor.class)
  public List<OoInstances> getInstanceByClassname(String classname, String relationType) {
    List<OoInstances> ooList = new ArrayList<>();

    try {

      ooList = entityManager.createQuery(singletonBean.getCrossReferenceApp("OoInstance.getByClassnameRelationType"))
                            .setParameter("classname", classname)
                            .setParameter("relationType", relationType)
                            .getResultList();

    } catch (Exception ex) {
      LOG.severe("getInstanceByClassname: " + ex.getMessage());
//      ex.printStackTrace();
    }

    return ooList;
  }

  @Override
  @Interceptors(DebugInterceptor.class)
  public List<OoInstances> getMesure(String dimension) {
    List<OoInstances> ooList = new ArrayList<>();

    try {

      ooList = entityManager.createQuery(singletonBean.getCrossReferenceApp("OoInstance.getMesureType"))
                            .setParameter("dimension", dimension)
                            .getResultList();

    } catch (Exception ex) {
      LOG.severe("getMesure: " + ex.getMessage());
//      ex.printStackTrace();
    }

    return ooList;
  }

  @Override
  @Interceptors(DebugInterceptor.class)
  public List<OoClasses> getOoClassesByParentName(String parentName) {
    List<OoClasses> ocList = new ArrayList<>();

    try {

      ocList = entityManager.createQuery(singletonBean.getCrossReferenceApp("OoClasses.getByParentName"))
                            .setParameter("parentName", parentName)
                            .getResultList();

    } catch (Exception ex) {
      LOG.severe("getOoClassesByParentName: " + ex.getMessage());
//      ex.printStackTrace();
    }

    return ocList;
  }

  @Override
  @Interceptors(DebugInterceptor.class)
  public OoClasses getOoClasses(String className) {
    OoClasses oc = new OoClasses();
    try {

      oc = entityManager.createQuery(singletonBean.getCrossReferenceApp("OoClasses.getByClassName"), OoClasses.class)
                        .setParameter("className", className)
                        .getSingleResult();

    } catch (Exception ex) {
      LOG.severe("getOoClasses: " + ex.getMessage());
//      ex.printStackTrace();
    }
    return oc;
  }

  @Override
  @Interceptors(DebugInterceptor.class)
  public List<Diluent> getDiluentList(Long langId) {
    List<Diluent> diluentList = new ArrayList<>();

    try {

      diluentList = entityManager.createQuery(singletonBean.getCrossReferenceApp("Diluent.getAll"))
                                 .setParameter("langId", langId)
                                 .getResultList();

    } catch (Exception ex) {
      LOG.severe("getDiluentList: " + ex.getMessage());
//      ex.printStackTrace();
    }

    return diluentList;
  }

  @Override
  @Interceptors(DebugInterceptor.class)
  public Diluent getDiluent(Long langId, Long diluentId) {
    Diluent diluent = new Diluent();

    try {

      diluent = entityManager.createQuery(singletonBean.getCrossReferenceApp("Diluent.getById"), Diluent.class)
                             .setParameter("langId", langId)
                             .setParameter("diluentId", diluentId)
                             .getSingleResult();

    } catch (Exception ex) {
      LOG.severe("getDiluent: " + ex.getMessage());
//      ex.printStackTrace();
    }

    return diluent;
  }

  @Override
  @Interceptors(DebugInterceptor.class)
  public Long getNextProductId() {
    Long productId = 0L;
    try {

      Object object = entityManager.createNativeQuery(singletonBean.getCrossReferenceApp("competitorProductId.getNextVal"))
              .getSingleResult();

      productId = Long.parseLong(object.toString());

    } catch (Exception ex) {
      LOG.severe("getNextProductId: " + ex.getMessage());
//      ex.printStackTrace();
    }

    return productId;
  }

  @Override
  @Interceptors(DebugInterceptor.class)
  public String getInstanceTraduction(String langCode, String instanceguid, String memberName) {

    return getInstanceTraduction(null, langCode, instanceguid, memberName);
  }

  @Override
  @Interceptors(DebugInterceptor.class)
  public String getInstanceTraduction(String countryCode, String langCode, String instanceGuid, String memberName) {
    String traduction = "";
    Object object = null;

    try {

      if ( countryCode == null ) {
        object = entityManager.createNativeQuery(singletonBean.getCrossReferenceApp("ooInstance.getTranslation"))
                              .setParameter("instanceguid", instanceGuid)
                              .setParameter("langCode", langCode)
                              .setParameter("memberName", memberName)
                              .getSingleResult();
      } else {
        object = entityManager.createNativeQuery(singletonBean.getCrossReferenceApp("ooInstance.getTranslationCountryCode"))
                              .setParameter("instanceguid", instanceGuid)
                              .setParameter("langCode", langCode)
                              .setParameter("countryCode", countryCode)
                              .setParameter("memberName", memberName)
                              .getSingleResult();
      }

    } catch (Exception ex) {
//      ex.printStackTrace();
//      LOG.warning(ex.getMessage());
    }

    if (object != null && !object.toString().equals("")) {
//      if ( object instanceof Clob){
        traduction = object.toString();

////////        try {
////////          traduction = cl.getSubString(1, (int)cl.length() );
////////        } catch (SQLException ex) {
//          Logger.getLogger(CrossReferenceAppBean.class.getName()).log(Level.SEVERE, null, ex);
////////        }
//
//      } else {
//        traduction = object.toString();
//      }
    } else {
      OoInstancesModel oo;
      try {
        oo = getOoInstance(instanceGuid);
        traduction = oo.getInstancename();
      } catch (Exception ex) {
//        Logger.getLogger(CrossReferenceAppBean.class.getName()).log(Level.SEVERE, null, ex);
      }

    }

    return traduction != null ? traduction : "";
  }

  @Override
  @Interceptors(DebugInterceptor.class)
  public List<CompetitorHazard> getByHazardType(long competitorId, long brandId, long productId, long countryId, String parentClassName) {
    List<CompetitorHazard> chList = new ArrayList<>();
    try {

      chList = entityManager.createQuery(singletonBean.getCrossReferenceApp("competitorHazard.getByHazardType"), CompetitorHazard.class)
                            .setParameter("competitorId", competitorId)
                            .setParameter("brandId", brandId)
                            .setParameter("productId", productId)
                            .setParameter("countryId", countryId)
                            .setParameter("parentClassName", parentClassName)
                            .getResultList();

    } catch (Exception ex) {
      LOG.severe("getByHazardType: " + ex.getMessage());
//      ex.printStackTrace();
    }
    return chList;
  }

//  public List<CompetitorHazard> getByHazardType(long competitorId, long brandId, long productId, long countryId, String parentClassName) {
//    List<CompetitorHazard> chList = new ArrayList<>();
//    try {
//
//      chList = entityManager.createQuery(singletonBean.getCrossReferenceApp("competitorHazard.getByHazardType"), CompetitorHazard.class)
//                            .setParameter("competitorId", competitorId)
//                            .setParameter("brandId", brandId)
//                            .setParameter("productId", productId)
//                            .setParameter("countryId", countryId)
//                            .setParameter("parentClassName", parentClassName)
//                            .getResultList();
//
//    } catch (Exception ex) {
////      LOG.severe(ex.getMessage());
////      ex.printStackTrace();
//    }
//    return chList;
//  }

  @Override
  @Interceptors(DebugInterceptor.class)
  public void deleteMaterial(long competitorId, long brandId, long productId, long countryId) {

    try {

      entityManager.createQuery(singletonBean.getCrossReferenceApp("CompetitorMaterial.deleteByKey"))
                   .setParameter("competitorId", competitorId)
                   .setParameter("brandId", brandId)
                   .setParameter("productId", productId)
                   .setParameter("countryId", countryId)
                   .executeUpdate();

    } catch (Exception ex) {
      LOG.severe("deleteMaterial: " + ex.getMessage());
//      ex.printStackTrace();
    }

  }

  @Override
  @Interceptors(DebugInterceptor.class)
  public void deleteCertification(long competitorId, long brandId, long productId, long countryId) {

    try {

      entityManager.createQuery(singletonBean.getCrossReferenceApp("CompetitorCertification.deleteByKey"))
                   .setParameter("competitorId", competitorId)
                   .setParameter("brandId", brandId)
                   .setParameter("productId", productId)
                   .setParameter("countryId", countryId)
                   .executeUpdate();

    } catch (Exception ex) {
      LOG.severe("deleteCertification: " + ex.getMessage());
//      ex.printStackTrace();
    }

  }

  @Interceptors(DebugInterceptor.class)
  public void deleteCompetitorWalterProduct(long competitorId, long brandId, long productId, long countryId) {

    try {

      entityManager.createQuery(singletonBean.getCrossReferenceApp("CompetitorWalterProduct.deleteByKey"))
                   .setParameter("competitorId", competitorId)
                   .setParameter("brandId", brandId)
                   .setParameter("productId", productId)
                   .setParameter("countryId", countryId)
                   .executeUpdate();

    } catch (Exception ex) {
      LOG.severe("deleteCompetitorWalterProduct: " + ex.getMessage());
//      ex.printStackTrace();
    }

  }

  @Override
  @Interceptors(DebugInterceptor.class)
  public void deleteApplication(long competitorId, long brandId, long productId, long countryId) {

    try {

      entityManager.createQuery(singletonBean.getCrossReferenceApp("CompetitorApplication.deleteByKey"))
                   .setParameter("competitorId", competitorId)
                   .setParameter("brandId", brandId)
                   .setParameter("productId", productId)
                   .setParameter("countryId", countryId)
                   .executeUpdate();

    } catch (Exception ex) {
      LOG.severe("deleteApplication: " + ex.getMessage());
//      ex.printStackTrace();
    }

  }

  @Interceptors(DebugInterceptor.class)
  public List<Action> getActionList(long langId) {
    List<Action> actionList = new ArrayList<>();
    try {

      actionList = entityManager.createQuery(singletonBean.getCrossReferenceApp("Action.getAll"), Action.class)
                                .setParameter("langId", langId)
                                .getResultList();

    } catch (Exception ex) {
      LOG.severe("getActionList: " + ex.getMessage());
//      ex.printStackTrace();
    }
    return actionList;
  }

  @Override
  @Interceptors(DebugInterceptor.class)
  public Action getAction(long actionId, long langId) {
    Action action = new Action();
    try {

      action = entityManager.createQuery(singletonBean.getCrossReferenceApp("Action.getById"), Action.class)
                                .setParameter("langId", langId)
                                .setParameter("actionId", actionId)
                                .getSingleResult();

    } catch (Exception ex) {
      LOG.severe("getAction: " + ex.getMessage());
//      ex.printStackTrace();
    }
    return action;
  }

  @Override
  @Interceptors(DebugInterceptor.class)
  public String getActionText(long actionId, long langId) {
    String action = "";
    try {

      Object object = entityManager.createNativeQuery(singletonBean.getCrossReferenceApp("Action.getByIdText"))
                                   .setParameter("langId", langId)
                                   .setParameter("actionId", actionId)
                                   .getSingleResult();

      if ( object != null ) {
        action = object.toString();
      }

    } catch (Exception ex) {
      LOG.severe("getActionText: " + ex.getMessage());
//      ex.printStackTrace();
    }
    return action;
  }

  @Override
  @Interceptors(DebugInterceptor.class)
  public Action saveAction(Action action) {
    if (action.getActionPK().getActionId() == 0) {
      Object id = entityManager.createNativeQuery(singletonBean.getCrossReferenceApp("Action.getNextId")).getSingleResult();
      action.getActionPK().setActionId(Long.parseLong(id.toString()));
    }
    entityManager.merge(action);

    return action;
  }

  @Override
  @Interceptors(DebugInterceptor.class)
  public List<String> getWalterProductNumberList(String countryCode) {
    List<String> productNumbers = new ArrayList<>();
    try {
      if ( countryCode == null ) {
        countryCode = "CA";
      }

      List<Object> objects = entityManager.createNativeQuery(singletonBean.getCrossReferenceApp("WalterProduct.getProductNumber"))
                                          .setParameter("countryCode", countryCode)
                                          .getResultList();

      for (Object object : objects) {
        productNumbers.add(object.toString());
      }

    } catch (Exception ex) {
      LOG.severe("getWalterProductNumberList: " + ex.getMessage());
//      ex.printStackTrace();
    }
    return productNumbers;
  }

  @Override
  @Interceptors(DebugInterceptor.class)
  public List<WalterProductModel> getWalterProductList(String countryCode, String langCode, Date lastUpdated) {
    List<WalterProductModel> walterProductModels = new ArrayList<>();
    try {
      if ( countryCode == null ) {
        countryCode = "CA";
      }

      List<Object[]> objects = new ArrayList<>();

      if ( lastUpdated != null ){
        objects = entityManager.createNativeQuery(singletonBean.getCrossReferenceApp("WalterProduct.getProductInformationFromDate"))
                                          .setParameter("countryCode", countryCode)
                                          .setParameter("lastUpdate", lastUpdated)
                                          .getResultList();


      } else {
        objects = entityManager.createNativeQuery(singletonBean.getCrossReferenceApp("WalterProduct.getProductInformation"))
                               .setParameter("countryCode", countryCode)
                               .getResultList();
      }

      for (Object[] object : objects) {
//      Object[] object = objects.get(0);
        walterProductModels.add(getWalterProduct(countryCode, langCode, object));
      }

    } catch (Exception ex) {
      LOG.severe(ex.getMessage());
      ex.printStackTrace();
    }
    return walterProductModels;
  }

  @Override
  @Interceptors(DebugInterceptor.class)
  public WalterProductModel getWalterProduct(String countryCode, String langCode, String productNumber) {
    WalterProductModel walterProductModel = new WalterProductModel();
    try {
      if ( countryCode == null ) {
        countryCode = "CA";
      }

      List<Object[]> objects = new ArrayList<>();

      objects = entityManager.createNativeQuery(singletonBean.getCrossReferenceApp("WalterProduct.getSingleProductInformation"))
                                        .setParameter("countryCode", countryCode)
                                        .setParameter("productNumber", productNumber)
                                        .getResultList();

      for (Object[] object : objects) {
//      Object[] object = objects.get(0);
        walterProductModel = getWalterProduct(countryCode, langCode, object);
      }

    } catch (Exception ex) {
      LOG.severe("getWalterProduct: " + ex.getMessage());
      ex.printStackTrace();
    }
    return walterProductModel;
  }

  public WalterProductModel getWalterProduct(String countryCode, String langCode, Object[] object){
    WalterProductModel walterProductModel = new WalterProductModel();
    try {
      if ( countryCode == null ) {
        countryCode = "CA";
      }

      if ( langCode.equals("es") ){
        langCode = "esMX";
      }

//        wp.productnumber, wpc.productguid, wpc.productversionguid, wpc.listprice, wpc.tradenameguid, wpc.descriptionguid, wpc.longdescriptionguid
      String productNumber = object[0].toString();
      String productguid =  object[1].toString();
      String productversionguid =  object[2].toString();
//      String listprice =  ( object[3] != null ? object[3].toString() : "" );

      String tradename =  ( object[4] != null ? getInstanceTraduction(null, langCode, object[4].toString(), "Tradenametext") : "" );
      String description =  ( object[5] != null ? getInstanceTraduction(countryCode, langCode, object[5].toString(), "Name") : "" );

//      String longdescription =  ( object[6] != null ? getInstanceTraduction(countryCode, langCode, object[6].toString(), "Name") : "" );
      String upcCode = ( object[7] != null ? object[7].toString() : "" );
      String actionGuid = ( object[8] != null ? object[8].toString() : "" );

      String format = getMemberValue(productversionguid, "Format");

      OoInstancesModel elementCorrosion = getOoInstance(getMemberValue(productversionguid, "ElementCorrosion"));
      OoInstancesModel elementEnvironment = getOoInstance(getMemberValue(productversionguid, "ElementEnvironment"));
      OoInstancesModel elementExclamation = getOoInstance(getMemberValue(productversionguid, "ElementExclamation"));
      OoInstancesModel elementExplodingBomb = getOoInstance(getMemberValue(productversionguid, "ElementExplodingBomb"));
      OoInstancesModel elementFlame = getOoInstance(getMemberValue(productversionguid, "ElementFlame"));
      OoInstancesModel elementFlameCircle = getOoInstance(getMemberValue(productversionguid, "ElementFlameCircle"));
      OoInstancesModel elementGasCylinder = getOoInstance(getMemberValue(productversionguid, "ElementGasCylinder"));
      OoInstancesModel elementHealth = getOoInstance(getMemberValue(productversionguid, "ElementHealth"));
      OoInstancesModel elementSkull = getOoInstance(getMemberValue(productversionguid, "ElementSkull"));

      walterProductModel.setElementCorrosion(( elementCorrosion != null && elementCorrosion.getInstancename() != null && elementCorrosion.getInstancename().equals("Yes") ) ? true : false);
      walterProductModel.setElementEnvironment(( elementEnvironment != null && elementEnvironment.getInstancename() != null && elementEnvironment.getInstancename().equals("Yes") ) ? true : false);
      walterProductModel.setElementExclamation(( elementExclamation != null && elementExclamation.getInstancename() != null && elementExclamation.getInstancename().equals("Yes") ) ? true : false);
      walterProductModel.setElementExplodingBomb(( elementExplodingBomb != null && elementExplodingBomb.getInstancename() != null && elementExplodingBomb.getInstancename().equals("Yes") ) ? true : false);
      walterProductModel.setElementFlame(( elementFlame != null && elementFlame.getInstancename() != null && elementFlame.getInstancename().equals("Yes") ) ? true : false);
      walterProductModel.setElementFlameCircle(( elementFlameCircle != null && elementFlameCircle.getInstancename() != null && elementFlameCircle.getInstancename().equals("Yes") ) ? true : false);
      walterProductModel.setElementGasCylinder(( elementGasCylinder != null && elementGasCylinder.getInstancename() != null && elementGasCylinder.getInstancename().equals("Yes") ) ? true : false);
      walterProductModel.setElementHealth(( elementHealth != null && elementHealth.getInstancename() != null && elementHealth.getInstancename().equals("Yes") ) ? true : false);
      walterProductModel.setElementSkull(( elementSkull != null && elementSkull.getInstancename() != null && elementSkull.getInstancename().equals("Yes") ) ? true : false);

      walterProductModel.setProductNumber(productNumber);
      walterProductModel.setDescription(description);
      walterProductModel.setTradename(tradename);
      walterProductModel.setUpc(upcCode);
      walterProductModel.setFormat( ( format != null && !format.equals("")) ? getInstanceTraduction(langCode, format, "Name") : "" );
      walterProductModel.setAction(( actionGuid != null && !actionGuid.equals("")) ? getInstanceTraduction(langCode, actionGuid, "Name") : "" );

      OoInstancesModel ooProduct = getOoInstance(productguid);

      walterProductModel.setMetricSize(getMesure(productversionguid, "Size_", "Metric", ooProduct.getClassguid(), langCode));
      walterProductModel.setImperialSize(getMesure(productversionguid, "Size_", "Imperial", ooProduct.getClassguid(), langCode));
      walterProductModel.setImperialTemperature(getMesure(productversionguid, "Temperature", "Imperial", ooProduct.getClassguid(), langCode));

//      if ( walterProductModel.getImperialTemperature() != null &&  !walterProductModel.getImperialTemperature().equals("")){
//        walterProductModel.setImperialTemperature(walterProductModel.getImperialTemperature());
//      }

      walterProductModel.setMetricTemperature(getMesure(productversionguid, "Temperature", "Metric", ooProduct.getClassguid(), langCode));

//      if ( walterProductModel.getMetricTemperature() != null &&  !walterProductModel.getMetricTemperature().equals("")){
//        walterProductModel.setMetricTemperature(walterProductModel.getMetricTemperature());
//      }

      walterProductModel.setVoc(getMemberValue(productversionguid, "VOCLevel"));
      walterProductModel.setPh(getMemberValue(productversionguid, "PH"));
      walterProductModel.setDiluation(getMesure(productversionguid, "Dilution", "", ooProduct.getClassguid(), langCode));

      walterProductModel.setMsdsDocument(getDocument(countryCode, langCode, productversionguid, "msds"));
      walterProductModel.setTdsDocument(getDocument(countryCode, langCode, productversionguid, "TechnicalDataSheet"));

      walterProductModel.setMaterials(getRelationship(countryCode, langCode, productNumber, "M"));
      walterProductModel.setCertifications(getWalterProductCertification(countryCode, langCode, productNumber));
      walterProductModel.setHealthHazards(getHazard(countryCode, langCode, productNumber, "HealthHazard"));
      walterProductModel.setPhysicalHazards(getHazard(countryCode, langCode, productNumber, "PhysicalHazard"));
      walterProductModel.setEnvironmentalHazards(getHazard(countryCode, langCode, productNumber, "EnvironmentalHazard"));

      walterProductModel.setApplications(getRelationship(countryCode, langCode, productNumber, "a"));

      String prop65 = getMemberValue(productversionguid, "Prop65");

      walterProductModel.setProp65(( prop65 != null && !prop65.equals("")) ? getInstanceTraduction(langCode, prop65, "Name") : "" );

      List<Image> images = getProductImages(productguid, productversionguid, countryCode, "Catalogue", langCode);

      if ( images.size() > 0 ){
        walterProductModel.setImageUrl( images.get(0).getUrlForLargeImage() + images.get(0).getNameForLargeImage() );

      }
    } catch (Exception ex) {
      Logger.getLogger(CrossReferenceAppBean.class.getName()).log(Level.SEVERE, null, ex);
    }

    return walterProductModel;
  }



  @Override
  @Interceptors(DebugInterceptor.class)
  public List<String> getWalterProductDeletedList(String countryCode, String langCode, Date lastUpdated) {
    List<String> walterProduct = new ArrayList<>();
    try {
      if ( countryCode == null ) {
        countryCode = "CA";
      }

      List<String> productNumbers = new ArrayList<>();


      productNumbers = entityManager.createNativeQuery(singletonBean.getCrossReferenceApp("WalterProduct.getProductDeletedFromDate"))
                             .setParameter("countryCode", countryCode)
                             .setParameter("lastUpdate", lastUpdated)
                             .getResultList();

      for (String productNumber : productNumbers) {
        walterProduct.add(productNumber);
      }

    } catch (Exception ex) {
      LOG.severe(ex.getMessage());
      ex.printStackTrace();
    }
    return walterProduct;
  }

  @Interceptors(DebugInterceptor.class)
  private String getMemberValue(String instanceguid, String memberName){
    String value = "";

    try {

      Object object = entityManager.createNativeQuery(singletonBean.getCrossReferenceApp("OoInstancesMembersValues.getValue"))
                                   .setParameter("instanceguid", instanceguid)
                                   .setParameter("memberName", memberName)
                                   .getSingleResult();

      if ( object != null ){
        value = object.toString();
      }

    } catch (Exception ex) {
//      LOG.severe("getMemberValue: " + ex.getMessage());
    }
    return value;
  }

  @Interceptors(DebugInterceptor.class)
  private String getMesure(String instanceguid, String memberName, String mesureType, String franchiseGuid, String langCode){
    String value = "";

    try {
      List<Object[]> objects = entityManager.createNativeQuery(singletonBean.getCrossReferenceApp("OoInstancesMembersValues.getDimension"))
                                            .setParameter("instanceguid", instanceguid)
                                            .setParameter("memberName", memberName)
                                            .setParameter("mesureType", mesureType)
                                            .setParameter("franchiseGuid", franchiseGuid)
                                            .getResultList();

      if ( objects.size() == 0 && (mesureType == null || !mesureType.equals("Metric") && !mesureType.equals("Imperial"))) {
        objects = entityManager.createNativeQuery(singletonBean.getCrossReferenceApp("OoInstancesMembersValues.getUniversal"))
                               .setParameter("instanceguid", instanceguid)
                               .setParameter("memberName", memberName)
                               .setParameter("franchiseGuid", franchiseGuid)
                               .getResultList();
      }

      if ( objects != null && objects.size() > 0 ){
        Object[] object = objects.get(0);
        value = object[0].toString();
        String unit = getInstanceTraduction(langCode, object[1].toString(), "Name");
        if ( unit != null ){
          value = value + " " + unit;
        }

      }

    } catch (Exception ex) {

//      if ( memberName.equals("Temperature") )
      LOG.severe("getMesure: " + ex.getMessage());
//      ex.printStackTrace();
    }
    return value;
  }

  @Interceptors(DebugInterceptor.class)
  private DocumentModel getDocument(String countryCode, String langCode, String productVersionGuid, String documentType){

    DocumentModel documentModel = new DocumentModel();

    try {
      List<Object[]> objects = entityManager.createNativeQuery(singletonBean.getCrossReferenceApp("WalterProductDocument.getDocumentPath"))
                                           .setParameter("countryCode", countryCode)
                                           .setParameter("langCode", langCode)
                                           .setParameter("productVersionGuid", productVersionGuid)
                                           .setParameter("documentType", documentType)
                                           .getResultList();

      if ( objects.size() > 0) {
        Object[] object = objects.get(0);
        documentModel.setUrl(ServerConstants.DOCUMENTS_DOMAIN + object[0].toString());
        documentModel.setDocumentName(object[1].toString());
      }

    } catch (Exception ex) {
      LOG.severe("getDocument: " + ex.getMessage());
    }
    return documentModel;
  }

  private List<Image> getProductImages(String productGuid, String productVersionGuid, String countryCode, String documentType, String language) {

    List<Image> imageList = new ArrayList<Image>();

    List<Object[]> objList = new ArrayList<Object[]>();

    try {
      objList = entityManager.createNativeQuery(singletonBean.getCrossReferenceApp("product.image"))
              .setParameter("productVersionGuid", productVersionGuid)
              .setParameter("countryCode", countryCode)
              .setParameter("documentType", documentType)
              .getResultList();

      for (Object[] obj : objList) {
        String defaultImage = (obj[0] != null) ? obj[0].toString() : "";
        String fileguid = (obj[1] != null) ? obj[1].toString() : "";
        String fileName = (obj[2] != null) ? obj[2].toString() : "";
        String companyName = (obj[3] != null) ? obj[3].toString() : "";
        String country = (obj[4] != null) ? obj[4].toString() : "";
        String productLine = (obj[5] != null) ? obj[5].toString() : "";
        String url = (obj[6] != null) ? obj[6].toString() : "";

        String domain = ServerConstants.IMAGES_DOMAIN;
        url = domain + "/" + country.toLowerCase() + "/" + productLine.toLowerCase() + url;

        Image image = new Image(defaultImage, fileName, url, null, null);

        List<Object[]> objImageSizeList = entityManager.createNativeQuery(singletonBean.getCrossReferenceApp("product.image.child"))
                .setParameter("parentFileGuid", fileguid)
                .getResultList();

        for (Object[] objImageSize : objImageSizeList) {
          String filenameSize = objImageSize[0].toString();
          String urlSize = objImageSize[1].toString();
          String documentTypeSize = objImageSize[2].toString();
          urlSize = domain +  "/" + country.toLowerCase() + "/" + productLine.toLowerCase() + urlSize;

          if (documentTypeSize.contains("60")) {
            image.setNameForSmallImage(filenameSize);
            image.setUrlForSmallImage(urlSize);
          } else if (documentTypeSize.contains("200")) {
            image.setNameForMediumImage(filenameSize);
            image.setUrlForMediumImage(urlSize);
          } else if (documentTypeSize.contains("335")) {
            image.setNameForLargeImage(filenameSize);
            image.setUrlForLargeImage(urlSize);
          } else if (documentTypeSize.contains("650")) {
            image.setNameForXLargeImage(filenameSize);
            image.setUrlForXLargeImage(urlSize);
          }
        }

        imageList.add(image);
      }

    } catch (Exception e) {
      LOG.warning("getProductImages not found: " + e.getMessage());
    }

    return imageList;
  }

  @Interceptors(DebugInterceptor.class)
  private List<String> getRelationship(String countryCode, String langCode, String productNumber, String relationType){
    List<String> values = new ArrayList<>();

    try {
      List<Object> objects = entityManager.createNativeQuery(singletonBean.getCrossReferenceApp("OoInstancesRelationships.getRelation"))
                                          .setParameter("countryCode", countryCode)
                                          .setParameter("productNumber", productNumber)
                                          .setParameter("relationType", relationType)
                                          .getResultList();
      for ( Object object : objects ){
        String translation = getInstanceTraduction(langCode, object.toString(), "Name");
        values.add(translation);
      }

    } catch (Exception ex) {
      LOG.severe("getRelationship: " + ex.getMessage());
    }
    return values;
  }

  @Interceptors(DebugInterceptor.class)
  private List<String> getFilterRelationship(String countryCode, String langCode, String productNumber, String filterName){
    List<String> values = new ArrayList<>();

    try {
      List<Object> objects = entityManager.createNativeQuery(singletonBean.getCrossReferenceApp("OoInstancesRelationships.getFilterRelation"))
                                          .setParameter("countryCode", countryCode)
                                          .setParameter("productNumber", productNumber)
                                          .setParameter("filterName", filterName)
                                          .getResultList();
      for ( Object object : objects ){
        String translation = getInstanceTraduction(langCode, object.toString(), "Name");
        values.add(translation);
      }

    } catch (Exception ex) {
      LOG.severe("getFilterRelationship: " + ex.getMessage());
    }
    return values;
  }

  @Interceptors(DebugInterceptor.class)
  private List<String> getWalterProductCertification(String countryCode, String langCode, String productNumber){
    List<String> values = new ArrayList<>();

    try {
      List<Object> objects = entityManager.createNativeQuery(singletonBean.getCrossReferenceApp("OoInstancesRelationships.getWalterCertificationlogo"))
                                          .setParameter("countryCode", countryCode)
                                          .setParameter("productNumber", productNumber)
                                          .getResultList();
      for ( Object object : objects ){
        values.add(ServerConstants.IMAGES_DOMAIN+"/icons/"+object.toString());
      }

    } catch (Exception ex) {
      LOG.severe("getFilterRelationship: " + ex.getMessage());
    }
    return values;
  }


  @Interceptors(DebugInterceptor.class)
  private List<HazardModel> getHazard(String countryCode, String langCode, String productNumber, String hazardType){
    List<HazardModel> hazardModels = new ArrayList<>();

    try {
      List<Object[]> objects = entityManager.createNativeQuery(singletonBean.getCrossReferenceApp("OoInstancesRelationships.getHazard"))
                                          .setParameter("countryCode", countryCode)
                                          .setParameter("productNumber", productNumber)
                                          .setParameter("hazardType", hazardType)
                                          .getResultList();

      for ( Object[] object : objects ){
        String labelName = getInstanceTraduction(langCode, getInstanceByName(hazardType, object[0].toString()), "Name");
        String value = getInstanceTraduction(langCode, object[1].toString(), "Name");

        HazardModel hm = new HazardModel();
        hm.setLabel(labelName);
        hm.setValue(value);

        hazardModels.add(hm);
      }

    } catch (Exception ex) {
      LOG.severe("getHazard: " + ex.getMessage());
    }
    return hazardModels;
  }

  @Interceptors(DebugInterceptor.class)
  private String getInstanceByName(String classname, String instancealternatekey){
    String value = "";

    try {
      Object object = entityManager.createQuery(singletonBean.getCrossReferenceApp("OoInstances.getByClassnameInstancealternatekey"))
                                   .setParameter("classname", classname)
                                   .setParameter("instancealternatekey", instancealternatekey)
                                   .getSingleResult();

      if ( object != null ){
        value = object.toString();
      }

    } catch (Exception ex) {
      LOG.severe("getInstanceByName: " + ex.getMessage());
    }
    return value;
  }

  private OoInstancesModel getOoInstance(String instanceguid) throws Exception{
    OoInstancesModel oo = new OoInstancesModel();

    try {
      List<Object[]> objects = entityManager.createNativeQuery(singletonBean.getCrossReferenceApp("OoInstances.getByinstanceguid"))
                                            .setParameter("instanceguid", instanceguid)
                                            .getResultList();

      if ( objects.size() > 0 ){
        oo.setInstanceguid(objects.get(0)[0].toString());
        oo.setInstancealternatekey(( objects.get(0)[1] != null ) ? objects.get(0)[1].toString() : "");
        oo.setInstancename(( objects.get(0)[2] != null ) ? objects.get(0)[2].toString() : "");
        oo.setClassguid(objects.get(0)[3].toString());

      }

    } catch (Exception ex) {
      LOG.severe("getOoInstance: " + ex.getMessage());
    }

    return oo;//walterBean.getWalterById(OoInstances.class, instanceguid);
  }

  @Interceptors(DebugInterceptor.class)
  public boolean insertCounter(long competitorId, long brandId, long productId, String countryCode, String userName){
    boolean valid = false;

    CompetitorCounter cc = new CompetitorCounter();
    Country country = new Country();

    try {

      country = entityManager.createQuery(singletonBean.getCrossReferenceApp("country.getByCountryCode"), Country.class)
                             .setParameter("countryCode", countryCode)
                             .getSingleResult();


      cc = entityManager.createQuery(singletonBean.getCrossReferenceApp("competitor_counter.checkExist"), CompetitorCounter.class)
                        .setParameter("competitorId", competitorId)
                        .setParameter("brandId", brandId)
                        .setParameter("productId", productId)
                        .setParameter("countryId", country.getCountryId())
                        .setParameter("userName", userName)
                        .getSingleResult();

    } catch (Exception ex) {
      LOG.severe("insertCounter: " + ex.getMessage());
    }

    Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
    cal.setTimeZone(TimeZone.getTimeZone("America/Montreal"));
    Date date = cal.getTime();

    if ( cc != null && cc.getCompetitorCounterPK() != null && cc.getCompetitorCounterPK().getBrandId() != 0L ) {
      cc.setCounter(cc.getCounter() + 1L);
      cc.setLastRequest(date);
      entityManager.persist(cc);
    } else {
      cc = new CompetitorCounter();
      cc.setCompetitorCounterPK(new CompetitorCounterPK(competitorId, brandId, productId, country.getCountryId(), userName));
      cc.setCounter(1L);
      cc.setFirstRequest(date);
      cc.setLastRequest(date);
      entityManager.merge(cc);
    }

    valid = true;

    return valid;
  }

  @Interceptors(DebugInterceptor.class)
  public String getTradename(String countryCode, String langCode, String productnumber){
    String tradename = "";

    try {
      tradename = (String) entityManager.createNativeQuery(singletonBean.getCrossReferenceApp("walterProduct.getTradenameGuid"))
                                          .setParameter("countryCode", countryCode)
                                          .setParameter("productnumber", productnumber)
                                          .setParameter("langCode", langCode)
                                          .getSingleResult();

//      if ( tradenameGuid != null ){
//        tradename = getInstanceTraduction(countryCode, langCode, tradenameGuid, "Name");
//      }

    } catch (Exception ex) {
      LOG.severe("getTradename: " + ex.getMessage() + " productnumber: '" + productnumber+"'");
    }

    return tradename;
  }

  @Interceptors(DebugInterceptor.class)
  public CompetitorModel getCompetitor(Long productId, String langCode, String countryCode, String userName){

    CompetitorModel competitorModel = new CompetitorModel();

    try {

      Long countryId = (long) walterBean.getUPerson(userName).getCountryId();

      List<Object[]> objects =  entityManager.createNativeQuery(singletonBean.getCrossReferenceApp("competitor_product.getPrimaryKey"))
                                             .setParameter("productId", productId)
                                             .setParameter("countryId", countryId)
                                             .getResultList();

      Locale locale = new Locale(langCode, countryCode);
      ULang uLang = walterBean.getULang(langCode);
      messages = ResourceBundle.getBundle("resources/MessagesBundle", locale);

      if ( objects.size() > 0 ) {
        Object[] object = objects.get(0);
        long competitorId = Long.parseLong(object[0].toString());
        long brandId = Long.parseLong(object[1].toString());
        String brandName = object[2].toString();
        String competitorName = object[3].toString();

        competitorModel.setCompetitorId(competitorId);
        competitorModel.setCompetitorName(competitorName);

        CompetitorBrandModel competitorBrandModel = new CompetitorBrandModel();
        competitorBrandModel.setBrandId(brandId);
        competitorBrandModel.setBrandName(brandName);

        CompetitorProduct cp = getCompetitorBrandProduct(competitorId, brandId, productId, countryId);
        competitorBrandModel.setCompetitorProduct(transfertCompetitorProduct(cp, uLang, langCode, countryCode));
        competitorModel.setCompetitorBrand(competitorBrandModel);

      }

    } catch (Exception ex) {
      LOG.severe("getCompetitor: " + ex.getMessage());
    }

    return competitorModel;
  }

  @Interceptors(DebugInterceptor.class)
  public List<CompetitorModel> getCompetitorInformation(String countryCode, String langCode, Date date){

    List<CompetitorModel> cmList = new ArrayList<>();
    try {
      Locale locale = new Locale(langCode, countryCode);
      ULang uLang = walterBean.getULang(langCode);
      ResourceBundle messages = ResourceBundle.getBundle("resources/MessagesBundle", locale);
      setMessages(messages);

      List<Object[]> objectList = entityManager.createQuery(singletonBean.getCrossReferenceApp("compettior.getAllInformation"))
                                           .setParameter("countryCode", countryCode)
                                           .getResultList();

      if ( date != null ) {
        objectList = entityManager.createQuery(singletonBean.getCrossReferenceApp("compettior.getAllInformationByDate"))
                                  .setParameter("countryCode", countryCode)
                                  .setParameter("updateDate", date)
                                  .getResultList();
      }

      long competitorId = 0;
      long brandId = 0;

      CompetitorModel competitorModel = new CompetitorModel();
      List<CompetitorBrandModel> competitorBrandModels = new ArrayList<>();
      List<CompetitorProductModel> competitorProductModels = new ArrayList<>();

      CompetitorBrandModel cbm = new CompetitorBrandModel();
      CompetitorProductModel competitorProductModel = new CompetitorProductModel();

      int nbr = 0;

      for ( Object[] object : objectList ) {
        Competitor competitor = (Competitor )object[0];
        CompetitorBrand competitorBrand = (CompetitorBrand )object[1];
        CompetitorProduct competitorProduct = (CompetitorProduct )object[2];

        if ( competitorId == 0 ){
          competitorId = competitor.getCompetitorId();
          competitorModel.setCompetitorId(competitor.getCompetitorId());
          competitorModel.setCompetitorName(competitor.getName());
        }

        if ( brandId == 0 ){
          brandId = competitorBrand.getCompetitorBrandPK().getBrandId();
          cbm.setBrandId(competitorBrand.getCompetitorBrandPK().getBrandId());
          cbm.setBrandName(competitorBrand.getName());
        }

        if ((competitorBrand.getCompetitorBrandPK().getBrandId() != brandId && competitorBrand.getCompetitorBrandPK().getCompetitorId() == competitorId ) ) {
          cbm.setCompetitorProducts(competitorProductModels);
          competitorBrandModels.add(cbm);
          cbm = new CompetitorBrandModel();
          competitorProductModels = new ArrayList<>();
          brandId = competitorBrand.getCompetitorBrandPK().getBrandId();
          cbm.setBrandId(competitorBrand.getCompetitorBrandPK().getBrandId());
          cbm.setBrandName(competitorBrand.getName());
        }

        if ( competitor.getCompetitorId() != competitorId ) {
          cbm.setCompetitorProducts(competitorProductModels);
          competitorBrandModels.add(cbm);
          cbm = new CompetitorBrandModel();
          competitorProductModels = new ArrayList<>();
          brandId = competitorBrand.getCompetitorBrandPK().getBrandId();
          cbm.setBrandId(competitorBrand.getCompetitorBrandPK().getBrandId());
          cbm.setBrandName(competitorBrand.getName());

          competitorId = competitor.getCompetitorId();
          competitorModel.setCompetitorBrands(competitorBrandModels);
          cmList.add(competitorModel);
          competitorBrandModels = new ArrayList<>();
          competitorModel = new CompetitorModel();
          competitorModel.setCompetitorId(competitor.getCompetitorId());
          competitorModel.setCompetitorName(competitor.getName());
        }

        competitorProductModel = new CompetitorProductModel();
        competitorProductModel.setBrandId(competitorProduct.getCompetitorProductPK().getBrandId());
        competitorProductModel.setCompetitorId(competitorProduct.getCompetitorProductPK().getCompetitorId());
        competitorProductModel.setProductId(competitorProduct.getCompetitorProductPK().getProductId());



        if ( competitorProduct.getRealFilename() != null )
        competitorProductModel.setProductImage(ServerConstants.IMAGES_CROSSREFERENCEAPP_DOMAIN+"/"+competitorProduct.getRealFilename());

        if (competitorProduct.getDiluentId() != null) {
          Diluent diluent = getDiluent(uLang.getLangId(), competitorProduct.getDiluentId());
          competitorProductModel.setDiluation(getValue(competitorProduct.getDiluationRatio()) + " " + diluent.getName());
        }

        competitorProductModel.setElementCorrosion((competitorProduct.getElementCorrosion() != null && competitorProduct.getElementCorrosion().equals('N')) ? false : true);
        competitorProductModel.setElementEnvironment((competitorProduct.getElementEnvironment() != null && competitorProduct.getElementEnvironment().equals('N')) ? false : true);
        competitorProductModel.setElementExclamation((competitorProduct.getElementExclamation() != null && competitorProduct.getElementExclamation().equals('N')) ? false : true);
        competitorProductModel.setElementExplodingBomb((competitorProduct.getElementExplodingBomb() != null && competitorProduct.getElementExplodingBomb().equals('N')) ? false : true);
        competitorProductModel.setElementFlame((competitorProduct.getElementFlame() != null && competitorProduct.getElementFlame().equals('N')) ? false : true);
        competitorProductModel.setElementFlameCircle((competitorProduct.getElementFlameCircle() != null && competitorProduct.getElementFlameCircle().equals('N')) ? false : true);
        competitorProductModel.setElementGasCylinder((competitorProduct.getElementGasCylinder() != null && competitorProduct.getElementGasCylinder().equals('N')) ? false : true);
        competitorProductModel.setElementHealth((competitorProduct.getElementHealth() != null && competitorProduct.getElementHealth().equals('N')) ? false : true);
        competitorProductModel.setElementSkull((competitorProduct.getElementSkull() != null && competitorProduct.getElementSkull().equals('N')) ? false : true);

        List<Object[]> hazardList = getHazardList(competitorProduct, langCode);

        List<HazardModel> environmentalHazardList = new ArrayList<>();
        List<HazardModel> healthHazardList = new ArrayList<>();
        List<HazardModel> physicalHazardList = new ArrayList<>();

        for ( Object[] hazard : hazardList ){
          String parentName = hazard[0].toString();
          String valueName = hazard[1].toString();
          String labelName = hazard[2].toString();

          if ( parentName.equals("EnvironmentalHazard") ) {
            environmentalHazardList.add(new HazardModel(labelName, valueName));
          } else if ( parentName.equals("HealthHazard") ) {
            healthHazardList.add(new HazardModel(labelName, valueName));
          } else if ( parentName.equals("PhysicalHazard") ) {
            physicalHazardList.add(new HazardModel(labelName, valueName));
          }
        }

        competitorProductModel.setEnvironmentalHazards(environmentalHazardList);
        competitorProductModel.setHealthHazards(healthHazardList);
        competitorProductModel.setPhysicalHazards(physicalHazardList);

        if (competitorProduct.getFormat() != null) {
          competitorProductModel.setFormat(getInstanceTraduction(langCode, competitorProduct.getFormat(), "Name"));
        }

        if (competitorProduct.getMetricUnitGuid() != null) {
          String unit = getInstanceTraduction(langCode, competitorProduct.getMetricUnitGuid(), "Name");
          String size = getValue(competitorProduct.getMetricSize());
          if (!size.equals("")) {
            competitorProductModel.setMetricSize(size + " " + unit);
          }
        }

        if (competitorProduct.getImperialUnitGuid() != null) {
          String unit = getInstanceTraduction(langCode, competitorProduct.getImperialUnitGuid(), "Name");
          String size = getValue(competitorProduct.getImperialSize());
          if (!size.equals("")) {
            competitorProductModel.setImperialSize(size + " " + unit);
          }
        }

        List<String> materialGuidList = getMaterialGuidList(competitorProduct.getCompetitorProductPK().getCompetitorId(), competitorProduct.getCompetitorProductPK().getBrandId(),
                                                  competitorProduct.getCompetitorProductPK().getProductId(), competitorProduct.getCompetitorProductPK().getCountryId(), langCode);

        competitorProductModel.setMaterials(materialGuidList);
//
        competitorProductModel.setApplications(getApplicationList(competitorProduct.getCompetitorProductPK().getCompetitorId(), competitorProduct.getCompetitorProductPK().getBrandId(),
                                                                  competitorProduct.getCompetitorProductPK().getProductId(), competitorProduct.getCompetitorProductPK().getCountryId(), langCode));

        String ph = getValue(competitorProduct.getPhLower());
        if (ph.equals("")) {
          ph = getValue(competitorProduct.getPhHight());
        } else if (!getValue(competitorProduct.getPhHight()).equals("")) {
          ph += " - " + getValue(competitorProduct.getPhHight());
        }

        competitorProductModel.setPh(ph);

        competitorProductModel.setProductNumber(getValue(competitorProduct.getProductNumber()));
//        System.out.println("competitorProduct.getProp65(): " +competitorProduct.getProp65());
//        System.out.println("getValue(competitorProduct.getProp65()): " + getValue(competitorProduct.getProp65()));
//        System.out.println("getInstanceTraduction(langCode, getValue(competitorProduct.getProp65()), \"Name\"): " + getInstanceTraduction(langCode, getValue(competitorProduct.getProp65()), "Name"));
        competitorProductModel.setProp65(getInstanceTraduction(langCode, getValue(competitorProduct.getProp65()), "Name"));

        DocumentModel sdsDocument = new DocumentModel(getValue(competitorProduct.getSdsUrl()), getMessage("labelMobileCrossAppDocument"));
        DocumentModel tdsDocument = new DocumentModel(getValue(competitorProduct.getTdsUrl()), getMessage("labelMobileCrossAppDocument"));

        if ( sdsDocument.getUrl() != null && !sdsDocument.getUrl().equals("") ){
          competitorProductModel.setSdsDocument(sdsDocument);
        }

        if ( tdsDocument.getUrl() != null && !tdsDocument.getUrl().equals("") ){
          competitorProductModel.setTdsDocument(tdsDocument);
        }

        String temperatureMetric = checkTempIsMinus(getValue(competitorProduct.getTemperatureMin()), " C°");
        String temperatureImperial = checkTempIsMinus(getTemperatureImperial(getValue(competitorProduct.getTemperatureMin())), " F°");
        if (temperatureMetric.equals("")) {
          temperatureMetric = checkTempIsMinus(getValue(competitorProduct.getTemperatureMax()), " C°");
          temperatureImperial = checkTempIsMinus(getTemperatureImperial(getValue(competitorProduct.getTemperatureMax())), " F°");

    //      if ( !temperatureMetric.equals("") ){
    //        temperatureMetric = temperatureMetric + " C°";
    //      }
    //
    //      if ( !temperatureImperial.equals("") ){
    //        temperatureImperial = temperatureImperial + " F°";
    //      }

        } else if (!getValue(competitorProduct.getTemperatureMax()).equals("")) {
          temperatureMetric += " - " + checkTempIsMinus(getValue(competitorProduct.getTemperatureMax()), " C°");
          temperatureImperial += " - " + checkTempIsMinus(getTemperatureImperial(getValue(competitorProduct.getTemperatureMax())), "F°");
        }

        competitorProductModel.setMetricTemperature(temperatureMetric);
        competitorProductModel.setImperialTemperature(temperatureImperial);
        competitorProductModel.setUpc(getValue(competitorProduct.getUpc()));
        competitorProductModel.setVoc(getValue(competitorProduct.getVoc()) + " " + getValue(competitorProduct.getVocUnitGuid()));

        List<String> certifications = getCertificationIconList(competitorProduct.getCompetitorProductPK().getCompetitorId(), competitorProduct.getCompetitorProductPK().getBrandId(),
                                                                                     competitorProduct.getCompetitorProductPK().getProductId(), competitorProduct.getCompetitorProductPK().getCountryId());

        competitorProductModel.setCertifications(certifications);

        List<CompetitorWalterProduct> competitorWalterProducts = getCompetitorWalterProduct(competitorProduct.getCompetitorProductPK().getCompetitorId(), competitorProduct.getCompetitorProductPK().getBrandId(),
                competitorProduct.getCompetitorProductPK().getProductId(), competitorProduct.getCompetitorProductPK().getCountryId());

        List<CompetitorWalterProductModel> competitorWalterProductModels = new ArrayList<>();

        for (CompetitorWalterProduct competitorWalterProduct : competitorWalterProducts) {
          String action = getActionText(competitorWalterProduct.getCompetitorWalterProductPK().getCategoryId(), uLang.getLangId());

          CompetitorWalterProductModel cwpm = new CompetitorWalterProductModel(action, competitorWalterProduct.getCompetitorWalterProductPK().getProductNumber(),
                                                                              getTradename(countryCode, langCode, competitorWalterProduct.getCompetitorWalterProductPK().getProductNumber()));
          competitorWalterProductModels.add(cwpm);
        }
        competitorProductModel.setCompetitorWalterProducts(competitorWalterProductModels);

        competitorProductModels.add(competitorProductModel);

      }

      cbm.setCompetitorProducts(competitorProductModels);
      competitorBrandModels.add(cbm);
      cbm = new CompetitorBrandModel();
      competitorProductModels = new ArrayList<>();
      competitorModel.setCompetitorBrands(competitorBrandModels);
      cmList.add(competitorModel);
    } catch (Exception ex) {
      Logger.getLogger(CrossReferenceAppBean.class.getName()).log(Level.SEVERE, null, ex);
    }
    return cmList;
  }


  public List<Object[]> getCompetitorList(Long countryId, String keyword){
    List<Object[]> object = new ArrayList<>();
    try {
      String sql = singletonBean.getCrossReferenceApp("CompetitorProduct.searchByKeyword");

      if ( countryId != null ) {
        sql = sql +  " and cp.competitorProductPK.countryId like :countryId";
        object = entityManager.createQuery(sql)
                              .setParameter("countryId",countryId)
                              .setParameter("keyword", "%"+keyword.toLowerCase()+"%")
                              .getResultList();
      } else {
        object= entityManager.createQuery(sql)
                             .setParameter("keyword", "%"+keyword.toLowerCase()+"%")
                             .getResultList();
      }




    } catch (Exception ex) {
      LOG.severe("getCompetitorList: " + ex.getMessage());
    }

    return object;
  }





}