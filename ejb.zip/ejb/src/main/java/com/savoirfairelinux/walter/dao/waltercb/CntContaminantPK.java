/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

/**
 *
 * @author mgubaidullin
 */
@Embeddable
public class CntContaminantPK implements Serializable {
    @Basic(optional = false)
    @NotNull
    @Column(name = "CNT_ID")
    private long cntId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "CONTAMINANT_ID")
    private long contaminantId;

    public CntContaminantPK() {
    }

    public CntContaminantPK(long cntId, long contaminantId) {
        this.cntId = cntId;
        this.contaminantId = contaminantId;
    }

    public long getCntId() {
        return cntId;
    }

    public void setCntId(long cntId) {
        this.cntId = cntId;
    }

    public long getContaminantId() {
        return contaminantId;
    }

    public void setContaminantId(long contaminantId) {
        this.contaminantId = contaminantId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) cntId;
        hash += (int) contaminantId;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CntContaminantPK)) {
            return false;
        }
        CntContaminantPK other = (CntContaminantPK) object;
        if (this.cntId != other.cntId) {
            return false;
        }
        if (this.contaminantId != other.contaminantId) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.CntContaminantPK[ cntId=" + cntId + ", contaminantId=" + contaminantId + " ]";
    }
    
}
