/*
 * Copyright 2012 Savoir-faire Linux
 *
 * This file is part of Walter-Portal.
 *
 * Walter-Portal is free software: you can redistribute it and/or modify it under the terms of the
 * GNU General Public License as published by the Free Software Foundation, either version 3
 * of the License, or (at your option) any later version.
 *
 * Walter-Portal is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with Walter-Portal.
 * If not, see http://www.gnu.org/licenses/.
 */
package com.savoirfairelinux.walter.service;

import com.savoirfairelinux.walter.dao.walter.UPerson;
import com.savoirfairelinux.walter.dao.waltercb.CountryStateTxt;
import com.savoirfairelinux.walter.dao.waltercb.ULang;
import java.util.List;
import javax.ejb.Remote;

/**
 *
 * @author mgubaidullin
 */
@Remote
public interface WalterBeanRemote {

  public <T> T save(T coreObject) throws Exception;

  public <T> T getWalterById(Class<T> aclClass, String id) throws Exception;

  public <T> List<T> getAllWalter(Class<T> aclClass) throws Exception;

  /**
   * Get all objects from a table filter by the language they are attached
   *
   * @param aclClass
   * @param langId
   * @return
   * @throws Exception - If no language is attached to this object
   */
  public <T> List<T> getAllWalterByLanguage(Class<T> aclClass, Long langId) throws Exception;

  public <T> List<T> getAllWalterByCountry(Class<T> aclClass, Integer countryId) throws Exception;

  public Long getDbLanguageId(String httpLang) throws Exception;

  public String getIdbAbbreviation(String httpLang) throws Exception;

  public String getWebSiteCountryName(String userName) throws Exception;

  public Long getWebSiteCountryId(String userName) throws Exception;

  public ULang getULang(String languageAbbreviation) throws Exception;

  public List<ULang> getAllULangOrderById() throws Exception;

  public UPerson getUPerson(String userName) throws Exception;

  List<UPerson> getUPersons(String managerName) throws Exception;

  public List<CountryStateTxt> getCountryStateTxtList(Long countryId, Long langId) throws Exception;

  public String getNewGuid() throws Exception;
}
