/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.model.PrWalterProduct;

import javax.persistence.*;
import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author jderuere
 */
@Entity
@Table(name = "PR_RESULT", schema = DatabaseConstants.WALTERCB_SCHEMA)
public class PrResult implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(generator = "PR_RESULT_ID_SEQ", strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "PR_RESULT_ID_SEQ", sequenceName = "PR_RESULT_ID_SEQ", schema = DatabaseConstants.WALTERCB_SCHEMA, allocationSize = 1)
    @Column(name = "ID")
    private Long id;
    @Column(name = "WALTER_PRODUCT_NUMBER")
    private String walterProductNumber;
    @ManyToOne(cascade = { CascadeType.PERSIST, CascadeType.MERGE })
    @JoinColumn(name = "COMPETITOR_PRODUCT")
    private UCompetitorProduct competitorProduct;
    @ManyToOne
    @JoinColumn(name = "MATERIAL", referencedColumnName = "ID")
    private UMaterialTool materialTool;
    @ManyToOne
    @JoinColumn(name = "TOOL", referencedColumnName = "ID")
    private UTool tool;
    @Column(name = "REMOVED_MATERIAL", precision = 1)
    private Double removedMaterial;
    @Column(name = "LIFE", precision = 2)
    private Double life;
    @Column(name = "CUTS_NUMBER")
    private Integer cutsNumber;
    @Column(name = "TIME_PER_CUT", precision = 1)
    private Double timePerCut;
    @Column(name = "AMPERAGE", precision = 1)
    private Double amperage;
    @Column(name = "OPERATOR")
    private String operatorScreenName;
    @Column(name = "TESTER")
    private String testerScreenName;
    @Column(name = "CREATE_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date date;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "result", orphanRemoval = true)
    private Set<PrPicture> pictures = new HashSet<PrPicture>();

    @Transient
    private PrWalterProduct walterProduct;


    public PrResult() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public UMaterialTool getMaterialTool() {
        return materialTool;
    }

    public void setMaterialTool(UMaterialTool materialTool) {
        this.materialTool = materialTool;
    }

    public String getWalterProductNumber() {
        return walterProductNumber;
    }

    public void setWalterProductNumber(String walterProductNumber) {
        this.walterProductNumber = walterProductNumber;
    }

    public UCompetitorProduct getCompetitorProduct() {
        return competitorProduct;
    }

    public void setCompetitorProduct(UCompetitorProduct competitorProduct) {
        this.competitorProduct = competitorProduct;
    }

    public Integer getCutsNumber() {
        return cutsNumber;
    }

    public void setCutsNumber(Integer cutsNumber) {
        this.cutsNumber = cutsNumber;
    }

    public Double getRemovedMaterial() {
        return removedMaterial;
    }

    public void setRemovedMaterial(Double removedMaterial) {
        this.removedMaterial = removedMaterial;
    }

    public Double getLife() {
        return life;
    }

    public void setLife(Double life) {
        this.life = life;
    }

    public Double getTimePerCut() {
        return timePerCut;
    }

    public void setTimePerCut(Double timePerCut) {
        this.timePerCut = timePerCut;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getOperatorScreenName() {
        return operatorScreenName;
    }

    public void setOperatorScreenName(String operatorScreenName) {
        this.operatorScreenName = operatorScreenName;
    }

    public String getTesterScreenName() {
        return testerScreenName;
    }

    public void setTesterScreenName(String testerScreenName) {
        this.testerScreenName = testerScreenName;
    }

    public Double getAmperage() {
        return amperage;
    }

    public void setAmperage(Double amperage) {
        this.amperage = amperage;
    }

    public UTool getTool() {
        return tool;
    }

    public void setTool(UTool tool) {
        this.tool = tool;
    }

    public PrWalterProduct getWalterProduct() {
        return walterProduct;
    }

    public void setWalterProduct(PrWalterProduct walterProduct) {
        if (walterProduct != null) this.walterProductNumber = walterProduct.getProductNumber();
        this.walterProduct = walterProduct;
    }

    public Set<PrPicture> getPictures() {
        return pictures;
    }

    public void setPictures(Set<PrPicture> pictures) {
        this.pictures = pictures;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PrResult)) {
            return false;
        }
        PrResult other = (PrResult) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.PrResult[ id=" + id + " ]";
    }
}
