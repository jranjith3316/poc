/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.util;

import com.liferay.portal.kernel.workflow.WorkflowConstants;
import com.savoirfairelinux.walter.dao.walter.DistributorLocator;
import com.savoirfairelinux.walter.service.impl.DistributorLocatorBean;
import com.savoirfairelinux.walter.service.impl.SingletonBean;
import com.walter.liferay.portal.kernel.repository.model.FileEntrySoap;
import com.walter.liferay.portal.model.UserSoap;
import com.walter.liferay.portal.service.ServiceContext;
import com.walter.liferay.portal.service.http.UserServiceSoap;
import com.walter.liferay.portal.service.http.UserServiceSoapServiceLocator;
import com.walter.liferay.portlet.documentlibrary.model.DLFolderSoap;
import com.walter.liferay.portlet.documentlibrary.service.http.DLAppServiceSoap;
import com.walter.liferay.portlet.documentlibrary.service.http.DLAppServiceSoapServiceLocator;
import com.walter.liferay.portlet.documentlibrary.service.http.DLFolderServiceSoap;
import com.walter.liferay.portlet.documentlibrary.service.http.DLFolderServiceSoapServiceLocator;
import java.io.IOException;
import java.net.URL;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.security.PermitAll;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author jsgill
 */
@TransactionManagement(TransactionManagementType.CONTAINER)
@PermitAll
@LocalBean
public class UploadDistributorLocator {

  public static final Logger LOG = Logger.getLogger(UploadDistributorLocator.class.getCanonicalName());
  @PersistenceContext(unitName = "waltershare")
  EntityManager entityManager;
  @EJB
  SingletonBean singletonBean;
  @EJB
  DistributorLocatorBean distributorLocatorBean;



  private CSV csv;

  public UploadDistributorLocator() {

  }
  /**
   * create the file for canada and usa
   */
  public void createDistributorLocator(){
    updateCSV(new String[]{"Canada","USA"});
    uploadLiferay("distributorlocator@walter.com", "wlt5977", 89101, "distributorLocator");
  }

  /**
   * Upload distributorLocator for Canada and USA
   */
  private void updateCSV(String[] countryList) {
    String columnName = "\"Fcilty_typ\",\"State\",\"Fcilty_nam\",\"Shp_num_an\",\"Shp_centre\",\"Street_add\",\"Locality\",\"Postcode\",\"Country\",\"Phone\",\"Fax\",\"email\",\"website\",\"Hrs_of_bus\",\"Display_wd\",\"Fcilty_typ_2\",\"Xcoord\",\"Ycoord\",\"uuid\",\"result\"";

    csv = null;
    try {

      csv = new CSV("export1.csv", "", columnName, ',', '"');



      List<DistributorLocator> dlList = new ArrayList<>();

      for ( String country : countryList ){
        List<DistributorLocator> dlListTemp = distributorLocatorBean.getDistributorList("", country, false);
        dlList.addAll(dlListTemp);
      }

      for (DistributorLocator dl : dlList) {

        List<String> stList = new ArrayList<>();

        stList.add("");
        stList.add((dl.getState() != null) ? dl.getState() : "");
        stList.add((dl.getFacilityName() != null) ? dl.getFacilityName() : "");
        stList.add((dl.getCustNum() != null) ? dl.getCustNum() : "");
        stList.add((dl.getShipNum() != null) ? dl.getShipNum() : "");
        stList.add((dl.getAddress() != null) ? dl.getAddress() : "");
        stList.add((dl.getCity() != null) ? dl.getCity() : "");
        stList.add((dl.getPostalCode() != null) ? dl.getPostalCode() : "");
        stList.add((dl.getCountry() != null) ? dl.getCountry() : "");
        stList.add((dl.getPhone() != null) ? dl.getPhone() : "");
        stList.add((dl.getFax() != null) ? dl.getFax() : "");
        stList.add((dl.getEmail() != null) ? dl.getEmail() : "");
        stList.add("");
        stList.add("");
        stList.add("");
        stList.add("");
        stList.add((dl.getLongitude() != null) ? dl.getLongitude().toString() : "");
        stList.add((dl.getLatitude() != null) ? dl.getLatitude().toString() : "");
        stList.add(dl.getUuid());

        csv.writeLine(stList);

      }
      csv.saveFile();
      csv.closeFile();
    } catch (IOException ex) {
      LOG.getLogger(UploadDistributorLocator.class.getName()).log(Level.SEVERE, null, ex);
    }

  }

  private void uploadLiferay(String username, String password, long groupId, String fileName) {
    try {
      UserServiceSoapServiceLocator locatorUser = new UserServiceSoapServiceLocator();
      String login = username;
      UserServiceSoap userSoap = locatorUser.getPortal_UserService(_getURL(login, password, "Portal_UserService"));
      UserSoap soapUserModel = userSoap.getCurrentUser();
      System.out.println(" getEmailAddress:" + soapUserModel.getEmailAddress());

      DLFolderServiceSoapServiceLocator folderLocator = new DLFolderServiceSoapServiceLocator();
      DLFolderServiceSoap dlSoap = folderLocator.getPortlet_DL_DLFolderService(_getURL(login, password, "Portlet_DL_DLFolderService"));
      DLFolderSoap dlfolder = dlSoap.getFolder(groupId, 0, "distributorLocatorPromo");

      DLAppServiceSoapServiceLocator serviceLocator = new DLAppServiceSoapServiceLocator();
      DLAppServiceSoap dls = serviceLocator.getPortlet_DL_DLAppService(_getURL(login, password, "Portlet_DL_DLAppService"));

      byte[] bytes = csv.getBaos().toByteArray();

      ServiceContext serviceContext = new ServiceContext();
      serviceContext.setWorkflowAction(WorkflowConstants.ACTION_PUBLISH);
      serviceContext.setAddGuestPermissions(true);
      serviceContext.setScopeGroupId(dlfolder.getGroupId());//   ScopeGroupId(dlfolder.getGroupId());
      serviceContext.setCompanyId(soapUserModel.getCompanyId());
      serviceContext.setUserId(soapUserModel.getUserId());

      FileEntrySoap fileExist = null;

      try {
        fileExist = dls.getFileEntry(dlfolder.getGroupId(), dlfolder.getFolderId(), fileName);
      } catch (RemoteException rmi) {
        // check if file exist udate else add
      }

      if (fileExist != null && fileExist.getFileEntryId() != 0) {
        dls.updateFileEntry(fileExist.getFileEntryId(), fileName, "text/csv", fileName, "", fileExist.getVersion(), false, bytes, serviceContext);
      } else {
        FileEntrySoap newFile = dls.addFileEntry(dlfolder.getRepositoryId(), dlfolder.getFolderId(), fileName, "text/csv", fileName, "", null, bytes, serviceContext);
      }

    } catch (Exception e) {
      System.out.println("e.getMessage(): " + e.getMessage());
    }
  }

  private static URL _getURL(String remoteUser, String password, String serviceName) throws Exception {
    String url = "https://" + remoteUser + ":" + password + "@walter.com:8443/api/axis/" + serviceName;

    return new URL(url);
  }
}
