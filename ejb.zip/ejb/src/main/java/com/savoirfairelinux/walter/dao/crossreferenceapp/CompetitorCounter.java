/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.crossreferenceapp;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "COMPETITOR_COUNTER", catalog = "", schema = "CROSSREFERENCEAPP")
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "CompetitorCounter.findAll", query = "SELECT c FROM CompetitorCounter c"),
  @NamedQuery(name = "CompetitorCounter.findByCompetitorId", query = "SELECT c FROM CompetitorCounter c WHERE c.competitorCounterPK.competitorId = :competitorId"),
  @NamedQuery(name = "CompetitorCounter.findByBrandId", query = "SELECT c FROM CompetitorCounter c WHERE c.competitorCounterPK.brandId = :brandId"),
  @NamedQuery(name = "CompetitorCounter.findByProductId", query = "SELECT c FROM CompetitorCounter c WHERE c.competitorCounterPK.productId = :productId"),
  @NamedQuery(name = "CompetitorCounter.findByCountryId", query = "SELECT c FROM CompetitorCounter c WHERE c.competitorCounterPK.countryId = :countryId"),
  @NamedQuery(name = "CompetitorCounter.findByUsername", query = "SELECT c FROM CompetitorCounter c WHERE c.competitorCounterPK.username = :username"),
  @NamedQuery(name = "CompetitorCounter.findByCounter", query = "SELECT c FROM CompetitorCounter c WHERE c.counter = :counter"),
  @NamedQuery(name = "CompetitorCounter.findByFirstRequest", query = "SELECT c FROM CompetitorCounter c WHERE c.firstRequest = :firstRequest"),
  @NamedQuery(name = "CompetitorCounter.findByLastRequest", query = "SELECT c FROM CompetitorCounter c WHERE c.lastRequest = :lastRequest")})
public class CompetitorCounter implements Serializable {
  private static final long serialVersionUID = 1L;
  @EmbeddedId
  protected CompetitorCounterPK competitorCounterPK;
  @Column(name = "COUNTER")
  private Long counter;
  @Column(name = "FIRST_REQUEST")
  @Temporal(TemporalType.TIMESTAMP)
  private Date firstRequest;
  @Column(name = "LAST_REQUEST")
  @Temporal(TemporalType.TIMESTAMP)
  private Date lastRequest;

  public CompetitorCounter() {
  }

  public CompetitorCounter(CompetitorCounterPK competitorCounterPK) {
    this.competitorCounterPK = competitorCounterPK;
  }

  public CompetitorCounter(long competitorId, long brandId, long productId, long countryId, String username) {
    this.competitorCounterPK = new CompetitorCounterPK(competitorId, brandId, productId, countryId, username);
  }

  public CompetitorCounterPK getCompetitorCounterPK() {
    return competitorCounterPK;
  }

  public void setCompetitorCounterPK(CompetitorCounterPK competitorCounterPK) {
    this.competitorCounterPK = competitorCounterPK;
  }

  public Long getCounter() {
    return counter;
  }

  public void setCounter(Long counter) {
    this.counter = counter;
  }

  public Date getFirstRequest() {
    return firstRequest;
  }

  public void setFirstRequest(Date firstRequest) {
    this.firstRequest = firstRequest;
  }

  public Date getLastRequest() {
    return lastRequest;
  }

  public void setLastRequest(Date lastRequest) {
    this.lastRequest = lastRequest;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (competitorCounterPK != null ? competitorCounterPK.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof CompetitorCounter)) {
      return false;
    }
    CompetitorCounter other = (CompetitorCounter) object;
    if ((this.competitorCounterPK == null && other.competitorCounterPK != null) || (this.competitorCounterPK != null && !this.competitorCounterPK.equals(other.competitorCounterPK))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.crossreferenceapp.CompetitorCounter[ competitorCounterPK=" + competitorCounterPK + " ]";
  }

}
