/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.walter;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author mgubaidullin
 */
@Embeddable
public class PgTreeItemPK implements Serializable {
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "PG_TREE_CODE", nullable = false, length = 10)
    private String pgTreeCode;
    @Basic(optional = false)
    @NotNull
    @Column(name = "ITEM_ID", nullable = false)
    private int itemId;

    public PgTreeItemPK() {
    }

    public PgTreeItemPK(String pgTreeCode, int itemId) {
        this.pgTreeCode = pgTreeCode;
        this.itemId = itemId;
    }

    public String getPgTreeCode() {
        return pgTreeCode;
    }

    public void setPgTreeCode(String pgTreeCode) {
        this.pgTreeCode = pgTreeCode;
    }

    public int getItemId() {
        return itemId;
    }

    public void setItemId(int itemId) {
        this.itemId = itemId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (pgTreeCode != null ? pgTreeCode.hashCode() : 0);
        hash += (int) itemId;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PgTreeItemPK)) {
            return false;
        }
        PgTreeItemPK other = (PgTreeItemPK) object;
        if ((this.pgTreeCode == null && other.pgTreeCode != null) || (this.pgTreeCode != null && !this.pgTreeCode.equals(other.pgTreeCode))) {
            return false;
        }
        if (this.itemId != other.itemId) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.walter.PgTreeItemPK[ pgTreeCode=" + pgTreeCode + ", itemId=" + itemId + " ]";
    }
    
}
