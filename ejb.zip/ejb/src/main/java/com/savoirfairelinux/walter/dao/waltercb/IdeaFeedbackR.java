/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "IDEA_FEEDBACK_R", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "IdeaFeedbackR.findAll", query = "SELECT i FROM IdeaFeedbackR i"),
    @NamedQuery(name = "IdeaFeedbackR.findByFeedbackId", query = "SELECT i FROM IdeaFeedbackR i WHERE i.ideaFeedback.feedbackId = :feedbackId"),
    @NamedQuery(name = "IdeaFeedbackR.findByReplyId", query = "SELECT i FROM IdeaFeedbackR i WHERE i.replyId = :replyId"),
    @NamedQuery(name = "IdeaFeedbackR.findByReplyDescription", query = "SELECT i FROM IdeaFeedbackR i WHERE i.replyDescription = :replyDescription"),
    @NamedQuery(name = "IdeaFeedbackR.findByCreatedDate", query = "SELECT i FROM IdeaFeedbackR i WHERE i.createdDate = :createdDate"),
    @NamedQuery(name = "IdeaFeedbackR.findByReplyUserName", query = "SELECT i FROM IdeaFeedbackR i WHERE i.replyUserName = :replyUserName")})
public class IdeaFeedbackR implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @GeneratedValue(generator = "IDEA_FEEDBACK_R_ID_SEQ", strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "IDEA_FEEDBACK_R_ID_SEQ", sequenceName = "IDEA_FEEDBACK_R_ID_SEQ", schema = DatabaseConstants.WALTERCB_SCHEMA, allocationSize = 1)
    @Column(name = "REPLY_ID")
    private Long replyId;
    @Size(max = 1000)
    @Column(name = "REPLY_DESCRIPTION")
    private String replyDescription;
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;
    @Size(max = 256)
    @Column(name = "REPLY_USER_NAME")
    private String replyUserName;
    @JoinColumn(name = "FEEDBACK_ID", referencedColumnName = "FEEDBACK_ID", nullable =  false)
    @ManyToOne(optional = false)
    private IdeaFeedback ideaFeedback;

    public IdeaFeedbackR() {
    }

    public IdeaFeedbackR(Long replyId) {
        this.replyId = replyId;
    }

    public Long getReplyId() {
        return replyId;
    }

    public void setReplyId(Long replyId) {
        this.replyId = replyId;
    }

    public String getReplyDescription() {
        return replyDescription;
    }

    public void setReplyDescription(String replyDescription) {
        this.replyDescription = replyDescription;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getReplyUserName() {
        return replyUserName;
    }

    public void setReplyUserName(String replyUserName) {
        this.replyUserName = replyUserName;
    }

    public IdeaFeedback getIdeaFeedback() {
        return ideaFeedback;
    }

    public void setIdeaFeedback(IdeaFeedback ideaFeedback) {
        this.ideaFeedback = ideaFeedback;
    }

    @Override
    public int hashCode() {
        int hash = replyId != null ? replyId.hashCode() : 0;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof IdeaFeedbackR)) {
            return false;
        }
        IdeaFeedbackR other = (IdeaFeedbackR) object;
        if ((this.replyId == null && other.replyId != null) || (this.replyId != null && !this.replyId.equals(other.replyId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.IdeaFeedbackR[ replyId=" + replyId + " ]";
    }
}
