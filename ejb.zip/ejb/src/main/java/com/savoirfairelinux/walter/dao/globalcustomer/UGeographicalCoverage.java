package com.savoirfairelinux.walter.dao.globalcustomer;

import com.savoirfairelinux.walter.dao.DatabaseConstants;
import javax.persistence.*;
import java.io.Serializable;

/**
 * @author jderuere
 */
@Entity
@Table(name = "U_GEOGRAPHICAL_COVERAGE", schema = DatabaseConstants.WALTERCB_SCHEMA, uniqueConstraints = @UniqueConstraint(name = "UGC_UNIQUE", columnNames = { "LANG_ID", "GEOGRAPHICAL_COVERAGE" }))
@NamedQueries({
        @NamedQuery(name = "UGeographicalCoverage.findAll", query = "SELECT u FROM UGeographicalCoverage u"),
        @NamedQuery(name = "UGeographicalCoverage.findByLangId", query = "SELECT u FROM UGeographicalCoverage u WHERE u.langId = :langId"),
        @NamedQuery(name = "UGeographicalCoverage.findByDescription", query = "SELECT u FROM UGeographicalCoverage u WHERE u.description = :description")})
public class UGeographicalCoverage implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(generator = "U_GEOGRAPHICAL_COVERAGE_ID_SEQ", strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "U_GEOGRAPHICAL_COVERAGE_ID_SEQ", sequenceName = "U_GEOGRAPHICAL_COVERAGE_ID_SEQ", schema = DatabaseConstants.WALTERCB_SCHEMA, allocationSize = 1)
    @Column(name = "U_GEOGRAPHICAL_COVERAGE_ID")
    private Long uGeographicalCoverageId;

    @Column(name = "LANG_ID", nullable = false)
    private long langId;

    @ManyToOne(optional = false)
    @JoinColumn(name = "GEOGRAPHICAL_COVERAGE", referencedColumnName = "GEOGRAPHICAL_COVERAGE_ID")
    private GeographicalCoverage geographicalCoverage;

    @Column(name = "DESCRIPTION")
    private String description;

    public UGeographicalCoverage() {
    }

    public Long getuGeographicalCoverageId() {
        return uGeographicalCoverageId;
    }

    public void setuGeographicalCoverageId(Long uGeographicalCoverageId) {
        this.uGeographicalCoverageId = uGeographicalCoverageId;
    }

    public long getLangId() {
        return langId;
    }

    public void setLangId(long langId) {
        this.langId = langId;
    }

    public GeographicalCoverage getGeographicalCoverage() {
        return geographicalCoverage;
    }

    public void setGeographicalCoverage(GeographicalCoverage geographicalCoverage) {
        this.geographicalCoverage = geographicalCoverage;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (uGeographicalCoverageId!= null ? uGeographicalCoverageId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof UGeographicalCoverage)) {
            return false;
        }
        UGeographicalCoverage other = (UGeographicalCoverage) object;
        if ((this.uGeographicalCoverageId == null && other.getuGeographicalCoverageId() != null) || (this.uGeographicalCoverageId != null && !this.uGeographicalCoverageId.equals(other.getuGeographicalCoverageId()))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.globalcustomer.UGeographicalCoverage[ uGeographicalCoverageId=" + uGeographicalCoverageId + " ]";
    }
}
