/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

/**
 *
 * @author jsgill
 */
@Embeddable
public class PromoOrderItemPK implements Serializable {
  @Basic(optional = false)
  @NotNull
  @Column(name = "ORDER_ID")
  private long orderId;
  @Basic(optional = false)
  @NotNull
  @Column(name = "LINE_ID")
  private long lineId;
  @Basic(optional = false)
  @NotNull
  @Column(name = "ITEM_ID")
  private long itemId;

  public PromoOrderItemPK() {
  }

  public PromoOrderItemPK(long orderId, long lineId, long itemId) {
    this.orderId = orderId;
    this.lineId = lineId;
    this.itemId = itemId;
  }

  public long getOrderId() {
    return orderId;
  }

  public void setOrderId(long orderId) {
    this.orderId = orderId;
  }

  public long getLineId() {
    return lineId;
  }

  public void setLineId(long lineId) {
    this.lineId = lineId;
  }

  public long getItemId() {
    return itemId;
  }

  public void setItemId(long itemId) {
    this.itemId = itemId;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (int) orderId;
    hash += (int) lineId;
    hash += (int) itemId;
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof PromoOrderItemPK)) {
      return false;
    }
    PromoOrderItemPK other = (PromoOrderItemPK) object;
    if (this.orderId != other.orderId) {
      return false;
    }
    if (this.lineId != other.lineId) {
      return false;
    }
    if (this.itemId != other.itemId) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.waltercb.PromoOrderItemPK[ orderId=" + orderId + ", lineId=" + lineId + ", itemId=" + itemId + " ]";
  }

}
