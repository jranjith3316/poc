/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.crossreferenceapp.model;

/**
 *
 * @author jsgill
 */
public class ServerConstants {
    public static final String DOCUMENTS_DOMAIN = "http://documents.walter.com/webform/documents/walter";
    public static final String IMAGES_DOMAIN = "http://images.walter.com/webform/images/walter";
    public static final String IMAGES_CROSSREFERENCEAPP_DOMAIN = "http://images.walter.com/webform/images/crossreferenceapp";
}
