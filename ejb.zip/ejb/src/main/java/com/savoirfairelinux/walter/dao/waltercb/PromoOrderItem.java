/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "PROMO_ORDER_ITEM", catalog = "", schema = "WALTERcb")
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "PromoOrderItem.findAll", query = "SELECT p FROM PromoOrderItem p"),
  @NamedQuery(name = "PromoOrderItem.findByOrderId", query = "SELECT p FROM PromoOrderItem p WHERE p.promoOrderItemPK.orderId = :orderId"),
  @NamedQuery(name = "PromoOrderItem.findByLineId", query = "SELECT p FROM PromoOrderItem p WHERE p.promoOrderItemPK.lineId = :lineId"),
  @NamedQuery(name = "PromoOrderItem.findByItemId", query = "SELECT p FROM PromoOrderItem p WHERE p.promoOrderItemPK.itemId = :itemId"),
  @NamedQuery(name = "PromoOrderItem.findByPriceEach", query = "SELECT p FROM PromoOrderItem p WHERE p.priceEach = :priceEach"),
  @NamedQuery(name = "PromoOrderItem.findByExtraPriceEach", query = "SELECT p FROM PromoOrderItem p WHERE p.extraPriceEach = :extraPriceEach"),
  @NamedQuery(name = "PromoOrderItem.findByQuantity", query = "SELECT p FROM PromoOrderItem p WHERE p.quantity = :quantity"),
  @NamedQuery(name = "PromoOrderItem.findByImageName", query = "SELECT p FROM PromoOrderItem p WHERE p.imageName = :imageName"),
  @NamedQuery(name = "PromoOrderItem.findByDescription", query = "SELECT p FROM PromoOrderItem p WHERE p.description = :description")})
public class PromoOrderItem implements Serializable {
  private static final long serialVersionUID = 1L;
  @EmbeddedId
  protected PromoOrderItemPK promoOrderItemPK;
  // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
  @Column(name = "PRICE_EACH")
  private BigDecimal priceEach;
  @Column(name = "EXTRA_PRICE_EACH")
  private BigDecimal extraPriceEach;
  @Column(name = "QUANTITY")
  private Integer quantity;
  @Lob
  @Column(name = "IMAGE")
  private byte[] image;
  @Size(max = 255)
  @Column(name = "IMAGE_NAME")
  private String imageName;
  @Size(max = 1000)
  @Column(name = "DESCRIPTION")
  private String description;
  @JoinColumn(name = "ORDER_ID", referencedColumnName = "ORDER_ID", insertable = false, updatable = false)
  @ManyToOne(optional = false)
  private PromoOrder promoOrder;
  @JoinColumn(name = "ITEM_ID", referencedColumnName = "ITEM_ID", insertable = false, updatable = false)
  @ManyToOne(optional = false)
  private PromoItem promoItem;

  public PromoOrderItem() {
  }

  public PromoOrderItem(PromoOrderItemPK promoOrderItemPK) {
    this.promoOrderItemPK = promoOrderItemPK;
  }

  public PromoOrderItem(long orderId, long lineId, long itemId) {
    this.promoOrderItemPK = new PromoOrderItemPK(orderId, lineId, itemId);
  }

  public PromoOrderItemPK getPromoOrderItemPK() {
    return promoOrderItemPK;
  }

  public void setPromoOrderItemPK(PromoOrderItemPK promoOrderItemPK) {
    this.promoOrderItemPK = promoOrderItemPK;
  }

  public BigDecimal getPriceEach() {
    return priceEach;
  }

  public void setPriceEach(BigDecimal priceEach) {
    this.priceEach = priceEach;
  }

  public BigDecimal getExtraPriceEach() {
    return extraPriceEach;
  }

  public void setExtraPriceEach(BigDecimal extraPriceEach) {
    this.extraPriceEach = extraPriceEach;
  }

  public Integer getQuantity() {
    return quantity;
  }

  public void setQuantity(Integer quantity) {
    this.quantity = quantity;
  }

  public byte[] getImage() {
    return image;
  }

  public void setImage(byte[] image) {
    this.image = image;
  }

  public String getImageName() {
    return imageName;
  }

  public void setImageName(String imageName) {
    this.imageName = imageName;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public PromoOrder getPromoOrder() {
    return promoOrder;
  }

  public void setPromoOrder(PromoOrder promoOrder) {
    this.promoOrder = promoOrder;
  }

  public PromoItem getPromoItem() {
    return promoItem;
  }

  public void setPromoItem(PromoItem promoItem) {
    this.promoItem = promoItem;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (promoOrderItemPK != null ? promoOrderItemPK.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof PromoOrderItem)) {
      return false;
    }
    PromoOrderItem other = (PromoOrderItem) object;
    if ((this.promoOrderItemPK == null && other.promoOrderItemPK != null) || (this.promoOrderItemPK != null && !this.promoOrderItemPK.equals(other.promoOrderItemPK))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.waltercb.PromoOrderItem[ promoOrderItemPK=" + promoOrderItemPK + " ]";
  }

}
