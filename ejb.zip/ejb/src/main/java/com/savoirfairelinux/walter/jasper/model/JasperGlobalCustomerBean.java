/* 
 * Copyright 2013 Savoir-faire Linux
 * 
 * This file is part of Walter-Portal.
 * 
 * Walter-Portal is free software: you can redistribute it and/or modify it under the terms of the 
 * GNU General Public License as published by the Free Software Foundation, either version 3 
 * of the License, or (at your option) any later version.
 * 
 * Walter-Portal is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with Walter-Portal. 
 * If not, see http://www.gnu.org/licenses/.
 */
package com.savoirfairelinux.walter.jasper.model;

import java.io.InputStream;
import java.io.Serializable;
import java.util.List;

/**
 * 
 * @author jbonjean
 * 
 */
public class JasperGlobalCustomerBean implements Serializable {
    private String accountName;
    private InputStream logo;
    private String organization;
    private List<JasperGeographicalCoverageBean> customersAreas;
    private List<JasperGeographicalCoverageBean> notCustomersAreas;
    private List<JasperSolutionsReportSimpleBean> reports;

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public InputStream getLogo() {
        return logo;
    }

    public void setLogo(InputStream logo) {
        this.logo = logo;
    }

    public String getOrganization() {
        return organization;
    }

    public void setOrganization(String organization) {
        this.organization = organization;
    }

    public List<JasperGeographicalCoverageBean> getCustomersAreas() {
        return customersAreas;
    }

    public void setCustomersAreas(List<JasperGeographicalCoverageBean> customersAreas) {
        this.customersAreas = customersAreas;
    }

    public List<JasperGeographicalCoverageBean> getNotCustomersAreas() {
        return notCustomersAreas;
    }

    public void setNotCustomersAreas(List<JasperGeographicalCoverageBean> notCustomersAreas) {
        this.notCustomersAreas = notCustomersAreas;
    }

    public List<JasperSolutionsReportSimpleBean> getReports() {
        return reports;
    }

    public void setReports(List<JasperSolutionsReportSimpleBean> reports) {
        this.reports = reports;
    }
}
