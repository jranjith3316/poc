/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author jsgill
 */
@Embeddable
public class CountryTaxTxtPK implements Serializable {
    @Basic(optional = false)
    @NotNull
    @Column(name = "COUNTRY_ID")
    private long countryId;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "TAX_CODE")
    private String taxCode;
    @Basic(optional = false)
    @NotNull
    @Column(name = "LANG_ID")
    private long langId;

    public CountryTaxTxtPK() {
    }

    public CountryTaxTxtPK(long countryId, String taxCode, long langId) {
        this.countryId = countryId;
        this.taxCode = taxCode;
        this.langId = langId;
    }

    public long getCountryId() {
        return countryId;
    }

    public void setCountryId(long countryId) {
        this.countryId = countryId;
    }

    public String getTaxCode() {
        return taxCode;
    }

    public void setTaxCode(String taxCode) {
        this.taxCode = taxCode;
    }

    public long getLangId() {
        return langId;
    }

    public void setLangId(long langId) {
        this.langId = langId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) countryId;
        hash += (taxCode != null ? taxCode.hashCode() : 0);
        hash += (int) langId;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CountryTaxTxtPK)) {
            return false;
        }
        CountryTaxTxtPK other = (CountryTaxTxtPK) object;
        if (this.countryId != other.countryId) {
            return false;
        }
        if ((this.taxCode == null && other.taxCode != null) || (this.taxCode != null && !this.taxCode.equals(other.taxCode))) {
            return false;
        }
        if (this.langId != other.langId) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.CountryTaxTxtPK[ countryId=" + countryId + ", taxCode=" + taxCode + ", langId=" + langId + " ]";
    }
    
}
