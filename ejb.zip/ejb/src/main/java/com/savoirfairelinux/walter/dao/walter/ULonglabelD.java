/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.walter;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "U_LONGLABEL_D", catalog = "", schema = DatabaseConstants.WALTER_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "ULonglabelD.findAll", query = "SELECT u FROM ULonglabelD u"),
    @NamedQuery(name = "ULonglabelD.findByLabelId", query = "SELECT u FROM ULonglabelD u WHERE u.uLonglabelDPK.labelId = :labelId"),
    @NamedQuery(name = "ULonglabelD.findByLangId", query = "SELECT u FROM ULonglabelD u WHERE u.uLonglabelDPK.langId = :langId"),
    @NamedQuery(name = "ULonglabelD.findByLabelDesc", query = "SELECT u FROM ULonglabelD u WHERE u.labelDesc = :labelDesc")})
public class ULonglabelD implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected ULonglabelDPK uLonglabelDPK;
    @Size(max = 2000)
    @Column(name = "LABEL_DESC")
    private String labelDesc;
    @JoinColumn(name = "LABEL_ID", referencedColumnName = "LABEL_ID", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private ULonglabel uLonglabel;

    public ULonglabelD() {
    }

    public ULonglabelD(ULonglabelDPK uLonglabelDPK) {
        this.uLonglabelDPK = uLonglabelDPK;
    }

    public ULonglabelD(long labelId, long langId) {
        this.uLonglabelDPK = new ULonglabelDPK(labelId, langId);
    }

    public ULonglabelDPK getULonglabelDPK() {
        return uLonglabelDPK;
    }

    public void setULonglabelDPK(ULonglabelDPK uLonglabelDPK) {
        this.uLonglabelDPK = uLonglabelDPK;
    }

    public String getLabelDesc() {
        return labelDesc;
    }

    public void setLabelDesc(String labelDesc) {
        this.labelDesc = labelDesc;
    }

    public ULonglabel getULonglabel() {
        return uLonglabel;
    }

    public void setULonglabel(ULonglabel uLonglabel) {
        this.uLonglabel = uLonglabel;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (uLonglabelDPK != null ? uLonglabelDPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ULonglabelD)) {
            return false;
        }
        ULonglabelD other = (ULonglabelD) object;
        if ((this.uLonglabelDPK == null && other.uLonglabelDPK != null) || (this.uLonglabelDPK != null && !this.uLonglabelDPK.equals(other.uLonglabelDPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.ULonglabelD[ uLonglabelDPK=" + uLonglabelDPK + " ]";
    }
    
}
