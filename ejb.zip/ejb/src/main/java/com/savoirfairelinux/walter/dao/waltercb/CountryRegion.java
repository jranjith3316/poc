/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "COUNTRY_REGION", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CountryRegion.findAll", query = "SELECT c FROM CountryRegion c"),
    @NamedQuery(name = "CountryRegion.findByCountryId", query = "SELECT c FROM CountryRegion c WHERE c.countryRegionPK.countryId = :countryId"),
    @NamedQuery(name = "CountryRegion.findByRegionCode", query = "SELECT c FROM CountryRegion c WHERE c.countryRegionPK.regionCode = :regionCode"),
    @NamedQuery(name = "CountryRegion.findByHotelMaxAmt", query = "SELECT c FROM CountryRegion c WHERE c.hotelMaxAmt = :hotelMaxAmt")})
public class CountryRegion implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected CountryRegionPK countryRegionPK;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "HOTEL_MAX_AMT")
    private BigDecimal hotelMaxAmt;
    @JoinColumn(name = "COUNTRY_ID", referencedColumnName = "COUNTRY_ID", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Country country;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "countryRegion")
    private Set<CountryRegionTxt> countryRegionTxtSet;

    public CountryRegion() {
    }

    public CountryRegion(CountryRegionPK countryRegionPK) {
        this.countryRegionPK = countryRegionPK;
    }

    public CountryRegion(long countryId, String regionCode) {
        this.countryRegionPK = new CountryRegionPK(countryId, regionCode);
    }

    public CountryRegionPK getCountryRegionPK() {
        return countryRegionPK;
    }

    public void setCountryRegionPK(CountryRegionPK countryRegionPK) {
        this.countryRegionPK = countryRegionPK;
    }

    public BigDecimal getHotelMaxAmt() {
        return hotelMaxAmt;
    }

    public void setHotelMaxAmt(BigDecimal hotelMaxAmt) {
        this.hotelMaxAmt = hotelMaxAmt;
    }

    public Country getCountry() {
        return country;
    }

    public void setCountry(Country country) {
        this.country = country;
    }

    @XmlTransient
    public Set<CountryRegionTxt> getCountryRegionTxtSet() {
        return countryRegionTxtSet;
    }

    public void setCountryRegionTxtSet(Set<CountryRegionTxt> countryRegionTxtSet) {
        this.countryRegionTxtSet = countryRegionTxtSet;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (countryRegionPK != null ? countryRegionPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CountryRegion)) {
            return false;
        }
        CountryRegion other = (CountryRegion) object;
        if ((this.countryRegionPK == null && other.countryRegionPK != null) || (this.countryRegionPK != null && !this.countryRegionPK.equals(other.countryRegionPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.CountryRegion[ countryRegionPK=" + countryRegionPK + " ]";
    }
    
}
