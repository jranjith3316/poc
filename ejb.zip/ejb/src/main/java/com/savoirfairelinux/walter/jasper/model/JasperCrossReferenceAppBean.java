/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.jasper.model;

import com.savoirfairelinux.walter.crossreferenceapp.model.HazardModel;
import java.io.Serializable;
import java.util.List;

/**
 *
 * @author jsgill
 */
public class JasperCrossReferenceAppBean implements Serializable {
  private String headerImage;
  private String headerImageLogo;
  private String countryCode;
  private String creatorName;
  private String creatorImage;
  private String creatorEmail;

  /** Competitor product information **/
  private String competitorName;
  private String competitorProductName;
  private String competitorProductNumber;
  private String competitorUpc;
  private String competitorFormat;
  private String competitorMetricSize;
  private String competitorImperialSize;
  private String competitorImperialTemperature;
  private String competitorMetricTemperature;
  private String competitorVoc;
  private String competitorPh;
  private String competitorSdsDocumentUrl;
  private String competitorSdsDocumentName;
  private String competitorTdsDocumentUrl;
  private String competitorTdsDocumentName;
  private String competitorProp65;
  private String competitorDiluation;
  private List<String> competitorMaterials;
  private List<HazardModel> competitorPhysicalHazards;
  private List<HazardModel> competitorHealthHazards;
  private List<HazardModel> competitorEnvironmentalHazards;
  private List<String> competitorCertifications;
  private String competitorProductImage;
  private List<String> competitorApplications;
  private List<String> competitorElements;
  private String dateVerified;

  /** Walter Product Information **/
  private String walterTradename;
  private String walterProductNumber;
  private String walterUpc;
  private String walterFormat;
  private String walterMetricSize;
  private String walterImperialSize;
  private String walterMetricTemperature;
  private String walterImperialTemperature;
  private String walterVoc;
  private String walterPH;
  private String walterProp65;
  private String walterDiluation;
  private String walterImageUrl;
  private String walterAction;
  private List<String> walterElements;

  private List<String> walterMaterials;
  private List<HazardModel> walterPhysicalHazards;
  private List<HazardModel> walterHealthHazards;
  private List<HazardModel> walterEnvironmentalHazards;
  private List<String> walterCertifications;
  private String walterProductImage;
  private List<String> walterApplications;
  private String walterSdsDocumentUrl;
  private String walterSdsDocumentName;
  private String walterTdsDocumentUrl;
  private String walterTdsDocumentName;

  private String urlElementFlame;
  private String urlElementGasCylinder;
  private String urlElementCorrosion;
  private String urlElementExclamation;
  private String urlElementHealth;
  private String urlElementEnvironment;
  private String urlElementSkull;
  private String urlElementFlameCircle;
  private String urlElementExplodingBomb;

  public String getHeaderImage() {
    return headerImage;
  }

  public void setHeaderImage(String headerImage) {
    this.headerImage = headerImage;
  }

  public String getHeaderImageLogo() {
    return headerImageLogo;
  }

  public void setHeaderImageLogo(String headerImageLogo) {
    this.headerImageLogo = headerImageLogo;
  }

  public String getCountryCode() {
    return countryCode;
  }

  public void setCountryCode(String countryCode) {
    this.countryCode = countryCode;
  }

  public String getCreatorName() {
    return creatorName;
  }

  public void setCreatorName(String creatorName) {
    this.creatorName = creatorName;
  }

  public String getCreatorImage() {
    return creatorImage;
  }

  public void setCreatorImage(String creatorImage) {
    this.creatorImage = creatorImage;
  }

  public String getCreatorEmail() {
    return creatorEmail;
  }

  public void setCreatorEmail(String creatorEmail) {
    this.creatorEmail = creatorEmail;
  }

  public String getCompetitorName() {
    return competitorName;
  }

  public void setCompetitorName(String competitorName) {
    this.competitorName = competitorName;
  }

  public String getCompetitorProductName() {
    return competitorProductName;
  }

  public void setCompetitorProductName(String competitorProductName) {
    this.competitorProductName = competitorProductName;
  }

  public String getCompetitorProductNumber() {
    return competitorProductNumber;
  }

  public void setCompetitorProductNumber(String competitorProductNumber) {
    this.competitorProductNumber = competitorProductNumber;
  }

  public String getCompetitorUpc() {
    return competitorUpc;
  }

  public void setCompetitorUpc(String competitorUpc) {
    this.competitorUpc = competitorUpc;
  }

  public String getCompetitorFormat() {
    return competitorFormat;
  }

  public void setCompetitorFormat(String competitorFormat) {
    this.competitorFormat = competitorFormat;
  }

  public String getCompetitorMetricSize() {
    return competitorMetricSize;
  }

  public void setCompetitorMetricSize(String competitorMetricSize) {
    this.competitorMetricSize = competitorMetricSize;
  }

  public String getCompetitorImperialSize() {
    return competitorImperialSize;
  }

  public void setCompetitorImperialSize(String competitorImperialSize) {
    this.competitorImperialSize = competitorImperialSize;
  }

  public String getCompetitorImperialTemperature() {
    return competitorImperialTemperature;
  }

  public void setCompetitorImperialTemperature(String competitorImperialTemperature) {
    this.competitorImperialTemperature = competitorImperialTemperature;
  }

  public String getCompetitorMetricTemperature() {
    return competitorMetricTemperature;
  }

  public void setCompetitorMetricTemperature(String competitorMetricTemperature) {
    this.competitorMetricTemperature = competitorMetricTemperature;
  }

  public String getCompetitorVoc() {
    return competitorVoc;
  }

  public void setCompetitorVoc(String competitorVoc) {
    this.competitorVoc = competitorVoc;
  }

  public String getCompetitorPh() {
    return competitorPh;
  }

  public void setCompetitorPh(String competitorPh) {
    this.competitorPh = competitorPh;
  }

  public String getCompetitorSdsDocumentUrl() {
    return competitorSdsDocumentUrl;
  }

  public void setCompetitorSdsDocumentUrl(String competitorSdsDocumentUrl) {
    this.competitorSdsDocumentUrl = competitorSdsDocumentUrl;
  }

  public String getCompetitorSdsDocumentName() {
    return competitorSdsDocumentName;
  }

  public void setCompetitorSdsDocumentName(String competitorSdsDocumentName) {
    this.competitorSdsDocumentName = competitorSdsDocumentName;
  }

  public String getCompetitorTdsDocumentUrl() {
    return competitorTdsDocumentUrl;
  }

  public void setCompetitorTdsDocumentUrl(String competitorTdsDocumentUrl) {
    this.competitorTdsDocumentUrl = competitorTdsDocumentUrl;
  }

  public String getCompetitorTdsDocumentName() {
    return competitorTdsDocumentName;
  }

  public void setCompetitorTdsDocumentName(String competitorTdsDocumentName) {
    this.competitorTdsDocumentName = competitorTdsDocumentName;
  }

  public String getCompetitorProp65() {
    return competitorProp65;
  }

  public void setCompetitorProp65(String competitorProp65) {
    this.competitorProp65 = competitorProp65;
  }

  public String getCompetitorDiluation() {
    return competitorDiluation;
  }

  public void setCompetitorDiluation(String competitorDiluation) {
    this.competitorDiluation = competitorDiluation;
  }

  public List<String> getCompetitorMaterials() {
    return competitorMaterials;
  }

  public void setCompetitorMaterials(List<String> competitorMaterials) {
    this.competitorMaterials = competitorMaterials;
  }

  public List<HazardModel> getCompetitorPhysicalHazards() {
    return competitorPhysicalHazards;
  }

  public void setCompetitorPhysicalHazards(List<HazardModel> competitorPhysicalHazards) {
    this.competitorPhysicalHazards = competitorPhysicalHazards;
  }

  public List<HazardModel> getCompetitorHealthHazards() {
    return competitorHealthHazards;
  }

  public void setCompetitorHealthHazards(List<HazardModel> competitorHealthHazards) {
    this.competitorHealthHazards = competitorHealthHazards;
  }

  public List<HazardModel> getCompetitorEnvironmentalHazards() {
    return competitorEnvironmentalHazards;
  }

  public void setCompetitorEnvironmentalHazards(List<HazardModel> competitorEnvironmentalHazards) {
    this.competitorEnvironmentalHazards = competitorEnvironmentalHazards;
  }

  public List<String> getCompetitorCertifications() {
    return competitorCertifications;
  }

  public void setCompetitorCertifications(List<String> competitorCertifications) {
    this.competitorCertifications = competitorCertifications;
  }

  public String getCompetitorProductImage() {
    return competitorProductImage;
  }

  public void setCompetitorProductImage(String competitorProductImage) {
    this.competitorProductImage = competitorProductImage;
  }

  public List<String> getCompetitorApplications() {
    return competitorApplications;
  }

  public void setCompetitorApplications(List<String> competitorApplications) {
    this.competitorApplications = competitorApplications;
  }

  public List<String> getCompetitorElements() {
    return competitorElements;
  }

  public void setCompetitorElements(List<String> competitorElements) {
    this.competitorElements = competitorElements;
  }

  public String getDateVerified() {
    return dateVerified;
  }

  public void setDateVerified(String dateVerified) {
    this.dateVerified = dateVerified;
  }

  public String getWalterTradename() {
    return walterTradename;
  }

  public void setWalterTradename(String walterTradename) {
    this.walterTradename = walterTradename;
  }

  public String getWalterProductNumber() {
    return walterProductNumber;
  }

  public void setWalterProductNumber(String walterProductNumber) {
    this.walterProductNumber = walterProductNumber;
  }

  public String getWalterUpc() {
    return walterUpc;
  }

  public void setWalterUpc(String walterUpc) {
    this.walterUpc = walterUpc;
  }

  public String getWalterFormat() {
    return walterFormat;
  }

  public void setWalterFormat(String walterFormat) {
    this.walterFormat = walterFormat;
  }

  public String getWalterMetricSize() {
    return walterMetricSize;
  }

  public void setWalterMetricSize(String walterMetricSize) {
    this.walterMetricSize = walterMetricSize;
  }

  public String getWalterImperialSize() {
    return walterImperialSize;
  }

  public void setWalterImperialSize(String walterImperialSize) {
    this.walterImperialSize = walterImperialSize;
  }

  public String getWalterMetricTemperature() {
    return walterMetricTemperature;
  }

  public void setWalterMetricTemperature(String walterMetricTemperature) {
    this.walterMetricTemperature = walterMetricTemperature;
  }

  public String getWalterImperialTemperature() {
    return walterImperialTemperature;
  }

  public void setWalterImperialTemperature(String walterImperialTemperature) {
    this.walterImperialTemperature = walterImperialTemperature;
  }

  public String getWalterVoc() {
    return walterVoc;
  }

  public void setWalterVoc(String walterVoc) {
    this.walterVoc = walterVoc;
  }

  public String getWalterPH() {
    return walterPH;
  }

  public void setWalterPH(String walterPH) {
    this.walterPH = walterPH;
  }

  public String getWalterProp65() {
    return walterProp65;
  }

  public void setWalterProp65(String walterProp65) {
    this.walterProp65 = walterProp65;
  }

  public String getWalterDiluation() {
    return walterDiluation;
  }

  public void setWalterDiluation(String walterDiluation) {
    this.walterDiluation = walterDiluation;
  }

  public String getWalterImageUrl() {
    return walterImageUrl;
  }

  public void setWalterImageUrl(String walterImageUrl) {
    this.walterImageUrl = walterImageUrl;
  }

  public String getWalterAction() {
    return walterAction;
  }

  public void setWalterAction(String walterAction) {
    this.walterAction = walterAction;
  }

  public List<String> getWalterElements() {
    return walterElements;
  }

  public void setWalterElements(List<String> walterElements) {
    this.walterElements = walterElements;
  }

  public List<String> getWalterMaterials() {
    return walterMaterials;
  }

  public void setWalterMaterials(List<String> walterMaterials) {
    this.walterMaterials = walterMaterials;
  }

  public List<HazardModel> getWalterPhysicalHazards() {
    return walterPhysicalHazards;
  }

  public void setWalterPhysicalHazards(List<HazardModel> walterPhysicalHazards) {
    this.walterPhysicalHazards = walterPhysicalHazards;
  }

  public List<HazardModel> getWalterHealthHazards() {
    return walterHealthHazards;
  }

  public void setWalterHealthHazards(List<HazardModel> walterHealthHazards) {
    this.walterHealthHazards = walterHealthHazards;
  }

  public List<HazardModel> getWalterEnvironmentalHazards() {
    return walterEnvironmentalHazards;
  }

  public void setWalterEnvironmentalHazards(List<HazardModel> walterEnvironmentalHazards) {
    this.walterEnvironmentalHazards = walterEnvironmentalHazards;
  }

  public List<String> getWalterCertifications() {
    return walterCertifications;
  }

  public void setWalterCertifications(List<String> walterCertifications) {
    this.walterCertifications = walterCertifications;
  }

  public String getWalterProductImage() {
    return walterProductImage;
  }

  public void setWalterProductImage(String walterProductImage) {
    this.walterProductImage = walterProductImage;
  }

  public List<String> getWalterApplications() {
    return walterApplications;
  }

  public void setWalterApplications(List<String> walterApplications) {
    this.walterApplications = walterApplications;
  }

  public String getWalterSdsDocumentUrl() {
    return walterSdsDocumentUrl;
  }

  public void setWalterSdsDocumentUrl(String walterSdsDocumentUrl) {
    this.walterSdsDocumentUrl = walterSdsDocumentUrl;
  }

  public String getWalterSdsDocumentName() {
    return walterSdsDocumentName;
  }

  public void setWalterSdsDocumentName(String walterSdsDocumentName) {
    this.walterSdsDocumentName = walterSdsDocumentName;
  }

  public String getWalterTdsDocumentUrl() {
    return walterTdsDocumentUrl;
  }

  public void setWalterTdsDocumentUrl(String walterTdsDocumentUrl) {
    this.walterTdsDocumentUrl = walterTdsDocumentUrl;
  }

  public String getWalterTdsDocumentName() {
    return walterTdsDocumentName;
  }

  public void setWalterTdsDocumentName(String walterTdsDocumentName) {
    this.walterTdsDocumentName = walterTdsDocumentName;
  }

  public String getUrlElementFlame() {
    return urlElementFlame;
  }

  public void setUrlElementFlame(String urlElementFlame) {
    this.urlElementFlame = urlElementFlame;
  }

  public String getUrlElementGasCylinder() {
    return urlElementGasCylinder;
  }

  public void setUrlElementGasCylinder(String urlElementGasCylinder) {
    this.urlElementGasCylinder = urlElementGasCylinder;
  }

  public String getUrlElementCorrosion() {
    return urlElementCorrosion;
  }

  public void setUrlElementCorrosion(String urlElementCorrosion) {
    this.urlElementCorrosion = urlElementCorrosion;
  }

  public String getUrlElementExclamation() {
    return urlElementExclamation;
  }

  public void setUrlElementExclamation(String urlElementExclamation) {
    this.urlElementExclamation = urlElementExclamation;
  }

  public String getUrlElementHealth() {
    return urlElementHealth;
  }

  public void setUrlElementHealth(String urlElementHealth) {
    this.urlElementHealth = urlElementHealth;
  }

  public String getUrlElementEnvironment() {
    return urlElementEnvironment;
  }

  public void setUrlElementEnvironment(String urlElementEnvironment) {
    this.urlElementEnvironment = urlElementEnvironment;
  }

  public String getUrlElementSkull() {
    return urlElementSkull;
  }

  public void setUrlElementSkull(String urlElementSkull) {
    this.urlElementSkull = urlElementSkull;
  }

  public String getUrlElementFlameCircle() {
    return urlElementFlameCircle;
  }

  public void setUrlElementFlameCircle(String urlElementFlameCircle) {
    this.urlElementFlameCircle = urlElementFlameCircle;
  }

  public String getUrlElementExplodingBomb() {
    return urlElementExplodingBomb;
  }

  public void setUrlElementExplodingBomb(String urlElementExplodingBomb) {
    this.urlElementExplodingBomb = urlElementExplodingBomb;
  }

}
