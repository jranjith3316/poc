/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.model.PrPictureType;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.InputStream;
import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import java.math.BigInteger;
import java.util.Set;

/**
 *
 * @author jderuere
 */
@Entity
@Table(name = "PR_PICTURE", schema = DatabaseConstants.WALTERCB_SCHEMA)
public class PrPicture implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @NotNull
    @Column(name = "PICTURE_ID")
	@GeneratedValue(generator = "PR_PICTURE_ID_SEQ", strategy = GenerationType.SEQUENCE)
	@SequenceGenerator(name = "PR_PICTURE_ID_SEQ", sequenceName = "PR_PICTURE_ID_SEQ", schema = DatabaseConstants.WALTERCB_SCHEMA, allocationSize = 1)
    private Long pictureId;
    @Size(max = 350)
    @Column(name = "FILENAME")
    private String filename;
    @Size(max = 48)
    @Column(name = "MIME_TYPE")
    private String mimeType;
    @Column(name = "DOC_SIZE")
    private BigInteger docSize;
    @Lob
    @Column(name = "BLOB_CONTENT")
    private byte[] blobContent;

    /**
     * To make it works with JasperReports
     */
    @Transient
    private InputStream blobContentInputStream;

    @Enumerated(EnumType.STRING)
    private PrPictureType type;
    @JoinColumn(name = "RESULT_ID", referencedColumnName = "ID")
    @ManyToOne
    private PrResult result;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "picture", orphanRemoval = true)
    private Set<PrPictureTxt> pictureTexts;

    @Transient
    private PrPictureTxt currentPictureText;

    public PrPicture() {
    }

    public PrPicture(Long pictureId) {
        this.pictureId = pictureId;
    }

    public Long getPictureId() {
        return pictureId;
    }

    public void setPictureId(Long pictureId) {
        this.pictureId = pictureId;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getMimeType() {
        return mimeType;
    }

    public void setMimeType(String mimeType) {
        this.mimeType = mimeType;
    }

    public BigInteger getDocSize() {
        return docSize;
    }

    public void setDocSize(BigInteger docSize) {
        this.docSize = docSize;
    }

    public  byte[] getBlobContent() {
        return blobContent;
    }

    public void setBlobContent( byte[] blobContent) {
        this.blobContent = blobContent;
    }

    public PrPictureType getType() {
        return type;
    }

    public void setType(PrPictureType type) {
        this.type = type;
    }

    public PrResult getResult() {
        return result;
    }

    public void setResult(PrResult result) {
        this.result = result;
    }

    public Set<PrPictureTxt> getPictureTexts() {
        return pictureTexts;
    }

    public void setPictureTexts(Set<PrPictureTxt> pictureTexts) {
        this.pictureTexts = pictureTexts;
    }

    public PrPictureTxt getCurrentPictureText() {
        return currentPictureText;
    }

    public void setCurrentPictureText(PrPictureTxt currentPictureText) {
        this.currentPictureText = currentPictureText;
    }

    public InputStream getBlobContentInputStream() {
        return blobContentInputStream;
    }

    public void setBlobContentInputStream(InputStream blobContentInputStream) {
        this.blobContentInputStream = blobContentInputStream;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (pictureId != null ? pictureId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof PrPicture)) {
            return false;
        }
        PrPicture other = (PrPicture) object;
        if (this.pictureId == null && other.pictureId == null) {
        	return this == other;
        } else if ((this.pictureId == null && other.pictureId != null) || (this.pictureId != null && !this.pictureId.equals(other.pictureId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.PrPicture[ pictureId=" + pictureId + " ]";
    }
}
