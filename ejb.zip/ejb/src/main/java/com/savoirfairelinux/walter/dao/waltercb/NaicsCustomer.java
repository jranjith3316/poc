/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "NAICS_CUSTOMER", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "NaicsCustomer.findAll", query = "SELECT n FROM NaicsCustomer n"),
    @NamedQuery(name = "NaicsCustomer.findByCountryId", query = "SELECT n FROM NaicsCustomer n WHERE n.countryId = :countryId"),
    @NamedQuery(name = "NaicsCustomer.findByCompanyName", query = "SELECT n FROM NaicsCustomer n WHERE n.companyName = :companyName"),
    @NamedQuery(name = "NaicsCustomer.findByBusinessName", query = "SELECT n FROM NaicsCustomer n WHERE n.businessName = :businessName"),
    @NamedQuery(name = "NaicsCustomer.findByAddress1", query = "SELECT n FROM NaicsCustomer n WHERE n.address1 = :address1"),
    @NamedQuery(name = "NaicsCustomer.findByAddress2", query = "SELECT n FROM NaicsCustomer n WHERE n.address2 = :address2"),
    @NamedQuery(name = "NaicsCustomer.findByCity", query = "SELECT n FROM NaicsCustomer n WHERE n.city = :city"),
    @NamedQuery(name = "NaicsCustomer.findByProvince", query = "SELECT n FROM NaicsCustomer n WHERE n.province = :province"),
    @NamedQuery(name = "NaicsCustomer.findByPostalCode", query = "SELECT n FROM NaicsCustomer n WHERE n.postalCode = :postalCode"),
    @NamedQuery(name = "NaicsCustomer.findByPhone", query = "SELECT n FROM NaicsCustomer n WHERE n.phone = :phone"),
    @NamedQuery(name = "NaicsCustomer.findByFax", query = "SELECT n FROM NaicsCustomer n WHERE n.fax = :fax"),
    @NamedQuery(name = "NaicsCustomer.findByWebSite", query = "SELECT n FROM NaicsCustomer n WHERE n.webSite = :webSite"),
    @NamedQuery(name = "NaicsCustomer.findByEmail", query = "SELECT n FROM NaicsCustomer n WHERE n.email = :email"),
    @NamedQuery(name = "NaicsCustomer.findByPrimaryNaics", query = "SELECT n FROM NaicsCustomer n WHERE n.primaryNaics = :primaryNaics"),
    @NamedQuery(name = "NaicsCustomer.findBySecondaryNaics", query = "SELECT n FROM NaicsCustomer n WHERE n.secondaryNaics = :secondaryNaics"),
    @NamedQuery(name = "NaicsCustomer.findByBusiness", query = "SELECT n FROM NaicsCustomer n WHERE n.business = :business"),
    @NamedQuery(name = "NaicsCustomer.findByProducts", query = "SELECT n FROM NaicsCustomer n WHERE n.products = :products"),
    @NamedQuery(name = "NaicsCustomer.findByEmpCount", query = "SELECT n FROM NaicsCustomer n WHERE n.empCount = :empCount"),
    @NamedQuery(name = "NaicsCustomer.findByIsManual", query = "SELECT n FROM NaicsCustomer n WHERE n.isManual = :isManual"),
    @NamedQuery(name = "NaicsCustomer.findById", query = "SELECT n FROM NaicsCustomer n WHERE n.id = :id")})
public class NaicsCustomer implements Serializable {
    private static final long serialVersionUID = 1L;
    @Column(name = "COUNTRY_ID")
    private Long countryId;
    @Size(max = 100)
    @Column(name = "COMPANY_NAME")
    private String companyName;
    @Size(max = 200)
    @Column(name = "BUSINESS_NAME")
    private String businessName;
    @Size(max = 40)
    @Column(name = "ADDRESS1")
    private String address1;
    @Size(max = 40)
    @Column(name = "ADDRESS2")
    private String address2;
    @Size(max = 40)
    @Column(name = "CITY")
    private String city;
    @Size(max = 20)
    @Column(name = "PROVINCE")
    private String province;
    @Size(max = 20)
    @Column(name = "POSTAL_CODE")
    private String postalCode;
    // @Pattern(regexp="^\\(?(\\d{3})\\)?[- ]?(\\d{3})[- ]?(\\d{4})$", message="Invalid phone/fax format, should be as xxx-xxx-xxxx")//if the field contains phone or fax number consider using this annotation to enforce field validation
    @Size(max = 20)
    @Column(name = "PHONE")
    private String phone;
    // @Pattern(regexp="^\\(?(\\d{3})\\)?[- ]?(\\d{3})[- ]?(\\d{4})$", message="Invalid phone/fax format, should be as xxx-xxx-xxxx")//if the field contains phone or fax number consider using this annotation to enforce field validation
    @Size(max = 20)
    @Column(name = "FAX")
    private String fax;
    @Size(max = 100)
    @Column(name = "WEB_SITE")
    private String webSite;
    // @Pattern(regexp="[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?", message="Invalid email")//if the field contains email address consider using this annotation to enforce field validation
    @Size(max = 50)
    @Column(name = "EMAIL")
    private String email;
    @Size(max = 6)
    @Column(name = "PRIMARY_NAICS")
    private String primaryNaics;
    @Size(max = 6)
    @Column(name = "SECONDARY_NAICS")
    private String secondaryNaics;
    @Size(max = 80)
    @Column(name = "BUSINESS")
    private String business;
    @Size(max = 500)
    @Column(name = "PRODUCTS")
    private String products;
    @Column(name = "EMP_COUNT")
    private Integer empCount;
    @Column(name = "IS_MANUAL")
    private Character isManual;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "PLANT_SIZE")
    private BigDecimal plantSize;
    @Column(name = "SALES_RANGE")
    private String saleRange;
    @Column(name = "YEAR_ESTABLISHED")
    private Integer yearEstablished;
    @Column(name = "EXPORT_INDICATOR")
    private char exportIndicator;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "ID")
    private BigDecimal id;

    public NaicsCustomer() {
    }

    public NaicsCustomer(BigDecimal id) {
        this.id = id;
    }

    public Long getCountryId() {
		return countryId;
	}

	public void setCountryId(Long countryId) {
		this.countryId = countryId;
	}

	public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getBusinessName() {
        return businessName;
    }

    public void setBusinessName(String businessName) {
        this.businessName = businessName;
    }

    public String getAddress1() {
        return address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getFax() {
        return fax;
    }

    public void setFax(String fax) {
        this.fax = fax;
    }

    public String getWebSite() {
        return webSite;
    }

    public void setWebSite(String webSite) {
        this.webSite = webSite;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPrimaryNaics() {
        return primaryNaics;
    }

    public void setPrimaryNaics(String primaryNaics) {
        this.primaryNaics = primaryNaics;
    }

    public String getSecondaryNaics() {
        return secondaryNaics;
    }

    public void setSecondaryNaics(String secondaryNaics) {
        this.secondaryNaics = secondaryNaics;
    }

    public String getBusiness() {
        return business;
    }

    public void setBusiness(String business) {
        this.business = business;
    }

    public String getProducts() {
        return products;
    }

    public void setProducts(String products) {
        this.products = products;
    }

    public Integer getEmpCount() {
        return empCount;
    }

    public void setEmpCount(Integer empCount) {
        this.empCount = empCount;
    }

    public Character getIsManual() {
        return isManual;
    }

    public void setIsManual(Character isManual) {
        this.isManual = isManual;
    }

    public BigDecimal getId() {
        return id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }

    public BigDecimal getPlantSize() {
        return plantSize;
    }

    public void setPlantSize(BigDecimal plantSize) {
        this.plantSize = plantSize;
    }

    public String getSaleRange() {
        return saleRange;
    }

    public void setSaleRange(String saleRange) {
        this.saleRange = saleRange;
    }

    public Integer getYearEstablished() {
        return yearEstablished;
    }

    public void setYearEstablished(Integer yearEstablished) {
        this.yearEstablished = yearEstablished;
    }

    public char getExportIndicator() {
        return exportIndicator;
    }

    public void setExportIndicator(char exportIndicator) {
        this.exportIndicator = exportIndicator;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof NaicsCustomer)) {
            return false;
        }
        NaicsCustomer other = (NaicsCustomer) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.NaicsCustomer[ id=" + id + " ]";
    }
    
}
