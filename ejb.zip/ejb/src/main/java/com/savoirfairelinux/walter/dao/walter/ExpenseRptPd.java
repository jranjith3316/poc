/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.walter;

import javax.persistence.*;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "EXPENSE_RPT_PD", catalog = "", schema = DatabaseConstants.WALTER_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "ExpenseRptPd.findAll", query = "SELECT e FROM ExpenseRptPd e"),
    @NamedQuery(name = "ExpenseRptPd.findByExpenseRptId", query = "SELECT e FROM ExpenseRptPd e WHERE e.expenseRptPdPK.expenseRptId = :expenseRptId"),
    @NamedQuery(name = "ExpenseRptPd.findByLineNum", query = "SELECT e FROM ExpenseRptPd e WHERE e.expenseRptPdPK.lineNum = :lineNum"),
    @NamedQuery(name = "ExpenseRptPd.findByPerDiemAmt", query = "SELECT e FROM ExpenseRptPd e WHERE e.perDiemAmt = :perDiemAmt"),
    @NamedQuery(name = "ExpenseRptPd.findByPerDiemPaidDate", query = "SELECT e FROM ExpenseRptPd e WHERE e.perDiemPaidDate = :perDiemPaidDate"),
    @NamedQuery(name = "ExpenseRptPd.findByPdPaidByUserName", query = "SELECT e FROM ExpenseRptPd e WHERE e.pdPaidByUserName = :pdPaidByUserName")})
public class ExpenseRptPd implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected ExpenseRptDPK expenseRptPdPK;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "PER_DIEM_AMT", precision = 12, scale = 2)
    private BigDecimal perDiemAmt;
    @Column(name = "PER_DIEM_PAID_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date perDiemPaidDate;
    @Size(max = 256)
    @Column(name = "PD_PAID_BY_USER_NAME", length = 256)
    private String pdPaidByUserName;
    @JoinColumns({
        @JoinColumn(name = "EXPENSE_RPT_ID", referencedColumnName = "EXPENSE_RPT_ID", nullable = false, insertable = false, updatable = false),
        @JoinColumn(name = "LINE_NUM", referencedColumnName = "LINE_NUM", nullable = false, insertable = false, updatable = false)})
    @OneToOne(optional = false)
    private ExpenseRptD expenseRptD;

    public ExpenseRptPd() {
    }

    public ExpenseRptPd(ExpenseRptDPK expenseRptPdPK) {
        this.expenseRptPdPK = expenseRptPdPK;
    }

    public ExpenseRptPd(long expenseRptId, short lineNum) {
        this.expenseRptPdPK = new ExpenseRptDPK(expenseRptId, lineNum);
    }

    public ExpenseRptDPK getExpenseRptPdPK() {
        return expenseRptPdPK;
    }

    public void setExpenseRptPdPK(ExpenseRptDPK expenseRptPdPK) {
        this.expenseRptPdPK = expenseRptPdPK;
    }

    public BigDecimal getPerDiemAmt() {
        return perDiemAmt;
    }

    public void setPerDiemAmt(BigDecimal perDiemAmt) {
        this.perDiemAmt = perDiemAmt;
    }

    public Date getPerDiemPaidDate() {
        return perDiemPaidDate;
    }

    public void setPerDiemPaidDate(Date perDiemPaidDate) {
        this.perDiemPaidDate = perDiemPaidDate;
    }

    public String getPdPaidByUserName() {
        return pdPaidByUserName;
    }

    public void setPdPaidByUserName(String pdPaidByUserName) {
        this.pdPaidByUserName = pdPaidByUserName;
    }

    public ExpenseRptD getExpenseRptD() {
        return expenseRptD;
    }

    public void setExpenseRptD(ExpenseRptD expenseRptD) {
        this.expenseRptD = expenseRptD;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (expenseRptPdPK != null ? expenseRptPdPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ExpenseRptPd)) {
            return false;
        }
        ExpenseRptPd other = (ExpenseRptPd) object;
        if ((this.expenseRptPdPK == null && other.expenseRptPdPK != null) || (this.expenseRptPdPK != null && !this.expenseRptPdPK.equals(other.expenseRptPdPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.walter.ExpenseRptPd[ expenseRptPdPK=" + expenseRptPdPK + " ]";
    }
    
}
