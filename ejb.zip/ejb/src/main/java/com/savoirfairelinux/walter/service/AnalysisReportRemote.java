/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.service;

import com.savoirfairelinux.walter.dao.waltercb.Country;
import com.savoirfairelinux.walter.model.AnalysisReportByMonth;
import com.savoirfairelinux.walter.model.AnalysisSearchSolRptCreated;
import com.savoirfairelinux.walter.model.AnalysisSolRptCreated;
import com.savoirfairelinux.walter.model.MobileProductivityReportModel;
import com.savoirfairelinux.walter.model.ProductivityReportModel;
import java.util.Date;
import java.util.List;
import javax.ejb.Remote;

/**
 *
 * @author jsgill
 */
@Remote
public interface AnalysisReportRemote {
  public List<AnalysisSolRptCreated> getSolRptCreatedList(AnalysisSearchSolRptCreated form) throws Exception;

  public AnalysisReportByMonth getAnalysisReportByMonth(AnalysisSearchSolRptCreated form, String userName) throws Exception;

  public List<AnalysisSolRptCreated> getFeedbackCreated(AnalysisSearchSolRptCreated form) throws Exception;

  public List<AnalysisSolRptCreated> getSolutionReportRead(AnalysisSearchSolRptCreated form) throws Exception;

  public List<Country> getCountries();

  public List<ProductivityReportModel> getProductivityReport(Date fromDate, Date toDate, Country country);

  public List<MobileProductivityReportModel> getMobileProductivityReport(Date fromDate, Date toDate, Country country);



}
