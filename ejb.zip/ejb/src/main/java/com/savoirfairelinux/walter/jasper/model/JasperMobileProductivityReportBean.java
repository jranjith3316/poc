/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.jasper.model;

import java.io.Serializable;
import java.util.Locale;

/**
 *
 * @author jsgill
 */
public class JasperMobileProductivityReportBean implements Serializable {
//$V{FormatterFloat}.format($F{shopRate}.doubleValue())
  //$V{FormatterInteger}.format($F{shopRate}.doubleValue())
  private String headerImage;
  private String headerImageSecondPage;
  private String logoHeaderImage;
  private String logoHeaderImageSecondPage;
  private String iconImageSecondPage;
  private String walterLogo;
  private String vsLogo;
  private String applicationName;
  private String material;
  private String com;
  private String comBackingNumber;
  private Double comBackingPadPrice;
  private Double comDiameter;
  private Double comEndUserPrice;
  private String comGrit;
  private Long comNumberOfYears;
  private String comOtherPowerTools;
  private String comPowerTools;
  private String comProductName;
  private String comProductNumber;
  private Long comQuantityBackingPerYear;
  private Long comQuantityDiscPerYear;
  private String contactAddress1;
  private String contactAddress2;
  private String contactCity;
  private String contactCountry;
  private String contactEmail;
  private String contactEnterprise;
  private String contactName;
  private String contactZip;
  private String clientAddress;
  private String clientContact;
  private Double shopRate;
  private Long timePerDiscChangeover;
  private Double walEndUserPrice;
  private String walOtherPowerTools;
  private String walPowerTools;
  private String walProductTradeName;
  private String walProductNumber;
  private String walProductDiameter;

  private String saleRepImage;
  private String saleRepFirstName;
  private String saleRepLastName;
  private String saleRepEmail;

  private Long annualCuttingRequirements;
  private Double annualRemovalRequirements;
  private Long comAnnualBackingPadsCost;
  private Long comAnnualDiscsCost;
  private Long comAnnualLaborCost;
  private Long comAnnualOperationCost;
  private Long comAnnualOperationTime;
  private Long comAnnualTotalProdCost;
  private Long comAnnualTotalTime;
  private Double comAvgTimePerCut;
  private Long comDurability;
  private Long comNumberCutPerDisc;
  private Long comRemovalRate;
  private String comRemovalRateStr;
  private Long comTimePerWheelChangeOver;
  private Double comTotalMaterialRemoved;
  private String comTotalMaterialRemovedStr;
  private Long laborCostSaving;
  private Long laborCostSavingPercentage;
  private Long prodCostSaving;
  private Long prodCostSavingPercentage;
  private Long totalCostSaving;
  private Long totalCostSavingPercentage;
  private Long walAnnualDiscConsumption;
  private Long walAnnualDiscsCost;
  private Long walAnnualLaborCost;
  private Long walAnnualOperationCost;
  private Long walAnnualOperationTime;
  private Long walAnnualTotalProdCost;
  private Long walAnnualTotalTime;
  private Double walAvgTimePerCut;
  private Long walBackingPadQuantity;
  private Long walDurability;
  private Long walNumberCutPerDisc;
  private Long walRemovalRate;
  private String walRemovalRateStr;
  private Long walTimePerWheelChangeOver;
  private Double walTotalMaterialRemoved;
  private String walTotalMaterialRemovedStr;
  private Long performanceMoreDurable;
  private Long performanceMoreRemoval;
  private Double performanceFaster;
  private Long discsLess;
  private boolean showSaving;
  private Double saving;
  private boolean showReimbursement;
  private Double reimbursement;
  private Double pricePerDisc;
  private Long numberOfPads;
  private Long numberOfDiscs;
  private Long langId;
  private Locale locale;
  private String actionNameEn;
  private String creationDate;
  private Long discCostSaving;
  private Double lessTime;

  /**
   *
   * 0 : Number of cuts
   * 1 : Distance
   * 2 : Total removal
   * 3 : Number of pieces done
   *
   */
  private String methodId;
  private Long nbPiecesDone;
  private Double comAvgTimePiece;
  private Double comDistance;
  private Long comNbPieces;
  private Double comTotalTime;
  private Double walAvgTimePiece;
  private Double walDistance;
  private Long walNbPieces;
  private Double walTotalTime;
  private String distanceUnit;
  private String annualRemovalQuantity;

  public String getHeaderImage() {
    return headerImage;
  }

  public void setHeaderImage(String headerImage) {
    this.headerImage = headerImage;
  }

  public String getHeaderImageSecondPage() {
    return headerImageSecondPage;
  }

  public void setHeaderImageSecondPage(String headerImageSecondPage) {
    this.headerImageSecondPage = headerImageSecondPage;
  }

  public String getIconImageSecondPage() {
    return iconImageSecondPage;
  }

  public void setIconImageSecondPage(String iconImageSecondPage) {
    this.iconImageSecondPage = iconImageSecondPage;
  }

  public String getLogoHeaderImage() {
    return logoHeaderImage;
  }

  public void setLogoHeaderImage(String logoHeaderImage) {
    this.logoHeaderImage = logoHeaderImage;
  }

  public String getLogoHeaderImageSecondPage() {
    return logoHeaderImageSecondPage;
  }

  public void setLogoHeaderImageSecondPage(String logoHeaderImageSecondPage) {
    this.logoHeaderImageSecondPage = logoHeaderImageSecondPage;
  }

  public String getWalterLogo() {
    return walterLogo;
  }

  public void setWalterLogo(String walterLogo) {
    this.walterLogo = walterLogo;
  }

  public String getVsLogo() {
    return vsLogo;
  }

  public void setVsLogo(String vsLogo) {
    this.vsLogo = vsLogo;
  }

  public String getApplicationName() {
    return applicationName;
  }

  public void setApplicationName(String applicationName) {
    this.applicationName = applicationName;
  }

  public String getMaterial() {
    return material;
  }

  public void setMaterial(String material) {
    this.material = material;
  }

  public String getCom() {
    return com;
  }

  public void setCom(String com) {
    this.com = com;
  }

  public String getComBackingNumber() {
    return comBackingNumber;
  }

  public void setComBackingNumber(String comBackingNumber) {
    this.comBackingNumber = comBackingNumber;
  }

  public Double getComBackingPadPrice() {
    return comBackingPadPrice;
  }

  public void setComBackingPadPrice(Double comBackingPadPrice) {
    this.comBackingPadPrice = comBackingPadPrice;
  }

  public Double getComDiameter() {
    return comDiameter;
  }

  public void setComDiameter(Double comDiameter) {
    this.comDiameter = comDiameter;
  }

  public Double getComEndUserPrice() {
    return comEndUserPrice;
  }

  public void setComEndUserPrice(Double comEndUserPrice) {
    this.comEndUserPrice = comEndUserPrice;
  }

  public String getComGrit() {
    return comGrit;
  }

  public void setComGrit(String comGrit) {
    this.comGrit = comGrit;
  }

  public Long getComNumberOfYears() {
    return comNumberOfYears;
  }

  public void setComNumberOfYears(Long comNumberOfYears) {
    this.comNumberOfYears = comNumberOfYears;
  }

  public String getComOtherPowerTools() {
    return comOtherPowerTools;
  }

  public void setComOtherPowerTools(String comOtherPowerTools) {
    this.comOtherPowerTools = comOtherPowerTools;
  }

  public String getComPowerTools() {
    return comPowerTools;
  }

  public void setComPowerTools(String comPowerTools) {
    this.comPowerTools = comPowerTools;
  }

  public String getComProductName() {
    return comProductName;
  }

  public void setComProductName(String comProductName) {
    this.comProductName = comProductName;
  }

  public String getComProductNumber() {
    return comProductNumber;
  }

  public void setComProductNumber(String comProductNumber) {
    this.comProductNumber = comProductNumber;
  }

  public Long getComQuantityBackingPerYear() {
    return comQuantityBackingPerYear;
  }

  public void setComQuantityBackingPerYear(Long comQuantityBackingPerYear) {
    this.comQuantityBackingPerYear = comQuantityBackingPerYear;
  }

  public Long getComQuantityDiscPerYear() {
    return comQuantityDiscPerYear;
  }

  public void setComQuantityDiscPerYear(Long comQuantityDiscPerYear) {
    this.comQuantityDiscPerYear = comQuantityDiscPerYear;
  }

  public String getContactAddress1() {
    return contactAddress1;
  }

  public void setContactAddress1(String contactAddress1) {
    this.contactAddress1 = contactAddress1;
  }

  public String getContactAddress2() {
    return contactAddress2;
  }

  public void setContactAddress2(String contactAddress2) {
    this.contactAddress2 = contactAddress2;
  }

  public String getContactCity() {
    return contactCity;
  }

  public void setContactCity(String contactCity) {
    this.contactCity = contactCity;
  }

  public String getContactCountry() {
    return contactCountry;
  }

  public void setContactCountry(String contactCountry) {
    this.contactCountry = contactCountry;
  }

  public String getContactEmail() {
    return contactEmail;
  }

  public void setContactEmail(String contactEmail) {
    this.contactEmail = contactEmail;
  }

  public String getContactEnterprise() {
    return contactEnterprise;
  }

  public void setContactEnterprise(String contactEnterprise) {
    this.contactEnterprise = contactEnterprise;
  }

  public String getContactName() {
    return contactName;
  }

  public void setContactName(String contactName) {
    this.contactName = contactName;
  }

  public String getContactZip() {
    return contactZip;
  }

  public void setContactZip(String contactZip) {
    this.contactZip = contactZip;
  }

  public String getClientAddress() {
    return clientAddress;
  }

  public void setClientAddress(String clientAddress) {
    this.clientAddress = clientAddress;
  }

  public String getClientContact() {
    return clientContact;
  }

  public void setClientContact(String clientContact) {
    this.clientContact = clientContact;
  }

  public Double getShopRate() {
    return shopRate;
  }

  public void setShopRate(Double shopRate) {
    this.shopRate = shopRate;
  }

  public Long getTimePerDiscChangeover() {
    return timePerDiscChangeover;
  }

  public void setTimePerDiscChangeover(Long timePerDiscChangeover) {
    this.timePerDiscChangeover = timePerDiscChangeover;
  }

  public Double getWalEndUserPrice() {
    return walEndUserPrice;
  }

  public void setWalEndUserPrice(Double walEndUserPrice) {
    this.walEndUserPrice = walEndUserPrice;
  }

  public String getWalOtherPowerTools() {
    return walOtherPowerTools;
  }

  public void setWalOtherPowerTools(String walOtherPowerTools) {
    this.walOtherPowerTools = walOtherPowerTools;
  }

  public String getWalPowerTools() {
    return walPowerTools;
  }

  public void setWalPowerTools(String walPowerTools) {
    this.walPowerTools = walPowerTools;
  }

  public String getWalProductTradeName() {
    return walProductTradeName;
  }

  public void setWalProductTradeName(String walProductTradeName) {
    this.walProductTradeName = walProductTradeName;
  }

  public String getWalProductNumber() {
    return walProductNumber;
  }

  public void setWalProductNumber(String walProductNumber) {
    this.walProductNumber = walProductNumber;
  }

  public String getWalProductDiameter() {
    return walProductDiameter;
  }

  public void setWalProductDiameter(String walProductDiameter) {
    this.walProductDiameter = walProductDiameter;
  }

  public String getSaleRepImage() {
    return saleRepImage;
  }

  public void setSaleRepImage(String saleRepImage) {
    this.saleRepImage = saleRepImage;
  }

  public String getSaleRepFirstName() {
    return saleRepFirstName;
  }

  public void setSaleRepFirstName(String saleRepFirstName) {
    this.saleRepFirstName = saleRepFirstName;
  }

  public String getSaleRepLastName() {
    return saleRepLastName;
  }

  public void setSaleRepLastName(String saleRepLastName) {
    this.saleRepLastName = saleRepLastName;
  }

  public String getSaleRepEmail() {
    return saleRepEmail;
  }

  public void setSaleRepEmail(String saleRepEmail) {
    this.saleRepEmail = saleRepEmail;
  }

  public Long getAnnualCuttingRequirements() {
    return annualCuttingRequirements;
  }

  public void setAnnualCuttingRequirements(Long annualCuttingRequirements) {
    this.annualCuttingRequirements = annualCuttingRequirements;
  }

  public Double getAnnualRemovalRequirements() {
    return annualRemovalRequirements;
  }

  public void setAnnualRemovalRequirements(Double annualRemovalRequirements) {
    this.annualRemovalRequirements = annualRemovalRequirements;
  }

  public Long getComAnnualBackingPadsCost() {
    return comAnnualBackingPadsCost;
  }

  public void setComAnnualBackingPadsCost(Long comAnnualBackingPadsCost) {
    this.comAnnualBackingPadsCost = comAnnualBackingPadsCost;
  }

  public Long getComAnnualDiscsCost() {
    return comAnnualDiscsCost;
  }

  public void setComAnnualDiscsCost(Long comAnnualDiscsCost) {
    this.comAnnualDiscsCost = comAnnualDiscsCost;
  }

  public Long getComAnnualLaborCost() {
    return comAnnualLaborCost;
  }

  public void setComAnnualLaborCost(Long comAnnualLaborCost) {
    this.comAnnualLaborCost = comAnnualLaborCost;
  }

  public Long getComAnnualOperationCost() {
    return comAnnualOperationCost;
  }

  public void setComAnnualOperationCost(Long comAnnualOperationCost) {
    this.comAnnualOperationCost = comAnnualOperationCost;
  }

  public Long getComAnnualOperationTime() {
    return comAnnualOperationTime;
  }

  public void setComAnnualOperationTime(Long comAnnualOperationTime) {
    this.comAnnualOperationTime = comAnnualOperationTime;
  }

  public Long getComAnnualTotalProdCost() {
    return comAnnualTotalProdCost;
  }

  public void setComAnnualTotalProdCost(Long comAnnualTotalProdCost) {
    this.comAnnualTotalProdCost = comAnnualTotalProdCost;
  }

  public Long getComAnnualTotalTime() {
    return comAnnualTotalTime;
  }

  public void setComAnnualTotalTime(Long comAnnualTotalTime) {
    this.comAnnualTotalTime = comAnnualTotalTime;
  }

  public Double getComAvgTimePerCut() {
    return comAvgTimePerCut;
  }

  public void setComAvgTimePerCut(Double comAvgTimePerCut) {
    this.comAvgTimePerCut = comAvgTimePerCut;
  }

  public Long getComDurability() {
    return comDurability;
  }

  public void setComDurability(Long comDurability) {
    this.comDurability = comDurability;
  }

  public Long getComNumberCutPerDisc() {
    return comNumberCutPerDisc;
  }

  public void setComNumberCutPerDisc(Long comNumberCutPerDisc) {
    this.comNumberCutPerDisc = comNumberCutPerDisc;
  }

  public Long getComRemovalRate() {
    return comRemovalRate;
  }

  public void setComRemovalRate(Long comRemovalRate) {
    this.comRemovalRate = comRemovalRate;
  }

  public String getComRemovalRateStr() {
    return comRemovalRateStr;
  }

  public void setComRemovalRateStr(String comRemovalRateStr) {
    this.comRemovalRateStr = comRemovalRateStr;
  }

  public Long getComTimePerWheelChangeOver() {
    return comTimePerWheelChangeOver;
  }

  public void setComTimePerWheelChangeOver(Long comTimePerWheelChangeOver) {
    this.comTimePerWheelChangeOver = comTimePerWheelChangeOver;
  }

  public Double getComTotalMaterialRemoved() {
    return comTotalMaterialRemoved;
  }

  public void setComTotalMaterialRemoved(Double comTotalMaterialRemoved) {
    this.comTotalMaterialRemoved = comTotalMaterialRemoved;
  }

  public String getComTotalMaterialRemovedStr() {
    return comTotalMaterialRemovedStr;
  }

  public void setComTotalMaterialRemovedStr(String comTotalMaterialRemovedStr) {
    this.comTotalMaterialRemovedStr = comTotalMaterialRemovedStr;
  }

  public Long getLaborCostSaving() {
    return laborCostSaving;
  }

  public void setLaborCostSaving(Long laborCostSaving) {
    this.laborCostSaving = laborCostSaving;
  }

  public Long getLaborCostSavingPercentage() {
    return laborCostSavingPercentage;
  }

  public void setLaborCostSavingPercentage(Long laborCostSavingPercentage) {
    this.laborCostSavingPercentage = laborCostSavingPercentage;
  }

  public Long getProdCostSaving() {
    return prodCostSaving;
  }

  public void setProdCostSaving(Long prodCostSaving) {
    this.prodCostSaving = prodCostSaving;
  }

  public Long getProdCostSavingPercentage() {
    return prodCostSavingPercentage;
  }

  public void setProdCostSavingPercentage(Long prodCostSavingPercentage) {
    this.prodCostSavingPercentage = prodCostSavingPercentage;
  }

  public Long getTotalCostSaving() {
    return totalCostSaving;
  }

  public void setTotalCostSaving(Long totalCostSaving) {
    this.totalCostSaving = totalCostSaving;
  }

  public Long getTotalCostSavingPercentage() {
    return totalCostSavingPercentage;
  }

  public void setTotalCostSavingPercentage(Long totalCostSavingPercentage) {
    this.totalCostSavingPercentage = totalCostSavingPercentage;
  }

  public Long getWalAnnualDiscConsumption() {
    return walAnnualDiscConsumption;
  }

  public void setWalAnnualDiscConsumption(Long walAnnualDiscConsumption) {
    this.walAnnualDiscConsumption = walAnnualDiscConsumption;
  }

  public Long getWalAnnualDiscsCost() {
    return walAnnualDiscsCost;
  }

  public void setWalAnnualDiscsCost(Long walAnnualDiscsCost) {
    this.walAnnualDiscsCost = walAnnualDiscsCost;
  }

  public Long getWalAnnualLaborCost() {
    return walAnnualLaborCost;
  }

  public void setWalAnnualLaborCost(Long walAnnualLaborCost) {
    this.walAnnualLaborCost = walAnnualLaborCost;
  }

  public Long getWalAnnualOperationCost() {
    return walAnnualOperationCost;
  }

  public void setWalAnnualOperationCost(Long walAnnualOperationCost) {
    this.walAnnualOperationCost = walAnnualOperationCost;
  }

  public Long getWalAnnualOperationTime() {
    return walAnnualOperationTime;
  }

  public void setWalAnnualOperationTime(Long walAnnualOperationTime) {
    this.walAnnualOperationTime = walAnnualOperationTime;
  }

  public Long getWalAnnualTotalProdCost() {
    return walAnnualTotalProdCost;
  }

  public void setWalAnnualTotalProdCost(Long walAnnualTotalProdCost) {
    this.walAnnualTotalProdCost = walAnnualTotalProdCost;
  }

  public Long getWalAnnualTotalTime() {
    return walAnnualTotalTime;
  }

  public void setWalAnnualTotalTime(Long walAnnualTotalTime) {
    this.walAnnualTotalTime = walAnnualTotalTime;
  }

  public Double getWalAvgTimePerCut() {
    return walAvgTimePerCut;
  }

  public void setWalAvgTimePerCut(Double walAvgTimePerCut) {
    this.walAvgTimePerCut = walAvgTimePerCut;
  }

  public Long getWalBackingPadQuantity() {
    return walBackingPadQuantity;
  }

  public void setWalBackingPadQuantity(Long walBackingPadQuantity) {
    this.walBackingPadQuantity = walBackingPadQuantity;
  }

  public Long getWalDurability() {
    return walDurability;
  }

  public void setWalDurability(Long walDurability) {
    this.walDurability = walDurability;
  }

  public Long getWalNumberCutPerDisc() {
    return walNumberCutPerDisc;
  }

  public void setWalNumberCutPerDisc(Long walNumberCutPerDisc) {
    this.walNumberCutPerDisc = walNumberCutPerDisc;
  }

  public Long getWalRemovalRate() {
    return walRemovalRate;
  }

  public void setWalRemovalRate(Long walRemovalRate) {
    this.walRemovalRate = walRemovalRate;
  }

  public String getWalRemovalRateStr() {
    return walRemovalRateStr;
  }

  public void setWalRemovalRateStr(String walRemovalRateStr) {
    this.walRemovalRateStr = walRemovalRateStr;
  }

  public Long getWalTimePerWheelChangeOver() {
    return walTimePerWheelChangeOver;
  }

  public void setWalTimePerWheelChangeOver(Long walTimePerWheelChangeOver) {
    this.walTimePerWheelChangeOver = walTimePerWheelChangeOver;
  }

  public Double getWalTotalMaterialRemoved() {
    return walTotalMaterialRemoved;
  }

  public void setWalTotalMaterialRemoved(Double walTotalMaterialRemoved) {
    this.walTotalMaterialRemoved = walTotalMaterialRemoved;
  }

  public String getWalTotalMaterialRemovedStr() {
    return walTotalMaterialRemovedStr;
  }

  public void setWalTotalMaterialRemovedStr(String walTotalMaterialRemovedStr) {
    this.walTotalMaterialRemovedStr = walTotalMaterialRemovedStr;
  }

  public Long getPerformanceMoreDurable() {
    return performanceMoreDurable;
  }

  public void setPerformanceMoreDurable(Long performanceMoreDurable) {
    this.performanceMoreDurable = performanceMoreDurable;
  }

  public Long getPerformanceMoreRemoval() {
    return performanceMoreRemoval;
  }

  public void setPerformanceMoreRemoval(Long performanceMoreRemoval) {
    this.performanceMoreRemoval = performanceMoreRemoval;
  }

  public Double getPerformanceFaster() {
    return performanceFaster;
  }

  public void setPerformanceFaster(Double performanceFaster) {
    this.performanceFaster = performanceFaster;
  }

  public Long getDiscsLess() {
    return discsLess;
  }

  public void setDiscsLess(Long discsLess) {
    this.discsLess = discsLess;
  }

  public boolean isShowSaving() {
    return showSaving;
  }

  public void setShowSaving(boolean showSaving) {
    this.showSaving = showSaving;
  }

  public Double getSaving() {
    return saving;
  }

  public void setSaving(Double saving) {
    this.saving = saving;
  }

  public boolean isShowReimbursement() {
    return showReimbursement;
  }

  public void setShowReimbursement(boolean showReimbursement) {
    this.showReimbursement = showReimbursement;
  }

  public Double getReimbursement() {
    return reimbursement;
  }

  public void setReimbursement(Double reimbursement) {
    this.reimbursement = reimbursement;
  }

  public Double getPricePerDisc() {
    return pricePerDisc;
  }

  public void setPricePerDisc(Double pricePerDisc) {
    this.pricePerDisc = pricePerDisc;
  }

  public Long getNumberOfPads() {
    return numberOfPads;
  }

  public void setNumberOfPads(Long numberOfPads) {
    this.numberOfPads = numberOfPads;
  }

  public Long getNumberOfDiscs() {
    return numberOfDiscs;
  }

  public void setNumberOfDiscs(Long numberOfDiscs) {
    this.numberOfDiscs = numberOfDiscs;
  }

  public Long getLangId() {
    return langId;
  }

  public void setLangId(Long langId) {
    this.langId = langId;
  }

  public Locale getLocale() {
    return locale;
  }

  public void setLocale(Locale locale) {
    this.locale = locale;
  }

  public String getActionNameEn() {
    return actionNameEn;
  }

  public void setActionNameEn(String actionNameEn) {
    this.actionNameEn = actionNameEn;
  }

  public String getCreationDate() {
    return creationDate;
  }

  public void setCreationDate(String creationDate) {
    this.creationDate = creationDate;
  }

  public Long getDiscCostSaving() {
    return discCostSaving;
  }

  public void setDiscCostSaving(Long discCostSaving) {
    this.discCostSaving = discCostSaving;
  }

  public Double getLessTime() {
    return lessTime;
  }

  public void setLessTime(Double lessTime) {
    this.lessTime = lessTime;
  }

  public String getMethodId() {
    return methodId;
  }

  public void setMethodId(String methodId) {
    this.methodId = methodId;
  }

  public Long getNbPiecesDone() {
    return nbPiecesDone;
  }

  public void setNbPiecesDone(Long nbPiecesDone) {
    this.nbPiecesDone = nbPiecesDone;
  }

  public Double getComAvgTimePiece() {
    return comAvgTimePiece;
  }

  public void setComAvgTimePiece(Double comAvgTimePiece) {
    this.comAvgTimePiece = comAvgTimePiece;
  }

  public Double getComDistance() {
    return comDistance;
  }

  public void setComDistance(Double comDistance) {
    this.comDistance = comDistance;
  }

  public Long getComNbPieces() {
    return comNbPieces;
  }

  public void setComNbPieces(Long comNbPieces) {
    this.comNbPieces = comNbPieces;
  }

  public Double getComTotalTime() {
    return comTotalTime;
  }

  public void setComTotalTime(Double comTotalTime) {
    this.comTotalTime = comTotalTime;
  }

  public Double getWalAvgTimePiece() {
    return walAvgTimePiece;
  }

  public void setWalAvgTimePiece(Double walAvgTimePiece) {
    this.walAvgTimePiece = walAvgTimePiece;
  }

  public Double getWalDistance() {
    return walDistance;
  }

  public void setWalDistance(Double walDistance) {
    this.walDistance = walDistance;
  }

  public Long getWalNbPieces() {
    return walNbPieces;
  }

  public void setWalNbPieces(Long walNbPieces) {
    this.walNbPieces = walNbPieces;
  }

  public Double getWalTotalTime() {
    return walTotalTime;
  }

  public void setWalTotalTime(Double walTotalTime) {
    this.walTotalTime = walTotalTime;
  }

  public String getDistanceUnit() {
    return distanceUnit;
  }

  public void setDistanceUnit(String distanceUnit) {
    this.distanceUnit = distanceUnit;
  }

  public String getAnnualRemovalQuantity() {
    return annualRemovalQuantity;
  }

  public void setAnnualRemovalQuantity(String annualRemovalQuantity) {
    this.annualRemovalQuantity = annualRemovalQuantity;
  }


}