/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import javax.persistence.*;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "ER_PICTURE_TXT", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "ErPictureTxt.findAll", query = "SELECT e FROM ErPictureTxt e"),
    @NamedQuery(name = "ErPictureTxt.findByPictureId", query = "SELECT e FROM ErPictureTxt e WHERE e.erPictureTxtPK.pictureId = :pictureId"),
    @NamedQuery(name = "ErPictureTxt.findByLangId", query = "SELECT e FROM ErPictureTxt e WHERE e.erPictureTxtPK.langId = :langId"),
    @NamedQuery(name = "ErPictureTxt.findByPictureTxt", query = "SELECT e FROM ErPictureTxt e WHERE e.pictureTxt = :pictureTxt")})
public class ErPictureTxt implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected ErPictureTxtPK erPictureTxtPK;
    @Size(max = 500)
    @Column(name = "PICTURE_TXT", length = 500)
    private String pictureTxt;
    @JoinColumn(name = "PICTURE_ID", referencedColumnName = "PICTURE_ID", nullable = false, insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private ErPicture erPicture;

    public ErPictureTxt() {
    }

    public ErPictureTxt(ErPictureTxtPK erPictureTxtPK) {
        this.erPictureTxtPK = erPictureTxtPK;
    }

    public ErPictureTxt(long pictureId, long langId) {
        this.erPictureTxtPK = new ErPictureTxtPK(pictureId, langId);
    }

    public ErPictureTxtPK getErPictureTxtPK() {
        return erPictureTxtPK;
    }

    public void setErPictureTxtPK(ErPictureTxtPK erPictureTxtPK) {
        this.erPictureTxtPK = erPictureTxtPK;
    }

    public String getPictureTxt() {
        return pictureTxt;
    }

    public void setPictureTxt(String pictureTxt) {
        this.pictureTxt = pictureTxt;
    }

    public ErPicture getErPicture() {
        return erPicture;
    }

    public void setErPicture(ErPicture erPicture) {
        this.erPicture = erPicture;
    }

    @PrePersist
    private void prePersist() {
        if (erPicture != null && erPictureTxtPK != null) {
            erPictureTxtPK.setPictureId(erPicture.getPictureId());
        }
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (erPictureTxtPK != null ? erPictureTxtPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ErPictureTxt)) {
            return false;
        }
        ErPictureTxt other = (ErPictureTxt) object;
        if ((this.erPictureTxtPK == null && other.erPictureTxtPK != null) || (this.erPictureTxtPK != null && !this.erPictureTxtPK.equals(other.erPictureTxtPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.ErPictureTxt[ erPictureTxtPK=" + erPictureTxtPK + " ]";
    }
}
