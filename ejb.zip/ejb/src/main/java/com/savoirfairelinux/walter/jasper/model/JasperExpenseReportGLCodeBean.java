/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.jasper.model;

import java.io.Serializable;

/**
 *
 * @author jsgill
 */
public class JasperExpenseReportGLCodeBean implements Serializable {

  private String glCode;
  private String amount;

  public JasperExpenseReportGLCodeBean(String glCode, String amount) {
    this.glCode = glCode;
    this.amount = amount;
  }

  public String getGlCode() {
    return glCode;
  }

  public void setGlCode(String glCode) {
    this.glCode = glCode;
  }

  public String getAmount() {
    return amount;
  }

  public void setAmount(String amount) {
    this.amount = amount;
  }



}
