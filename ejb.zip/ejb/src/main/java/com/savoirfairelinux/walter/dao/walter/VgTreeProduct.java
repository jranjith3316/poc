/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.walter;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "VG_TREE_PRODUCT", catalog = "", schema = DatabaseConstants.WALTER_SCHEMA)
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "VgTreeProduct.findAll", query = "SELECT v FROM VgTreeProduct v"),
  @NamedQuery(name = "VgTreeProduct.findByVgTreeCode", query = "SELECT v FROM VgTreeProduct v WHERE v.vgTreeProductPK.vgTreeCode = :vgTreeCode"),
  @NamedQuery(name = "VgTreeProduct.findByItemId", query = "SELECT v FROM VgTreeProduct v WHERE v.vgTreeProductPK.itemId = :itemId"),
  @NamedQuery(name = "VgTreeProduct.findByProductId", query = "SELECT v FROM VgTreeProduct v WHERE v.vgTreeProductPK.productId = :productId"),
  @NamedQuery(name = "VgTreeProduct.findByFranchiseguid", query = "SELECT v FROM VgTreeProduct v WHERE v.franchiseguid = :franchiseguid"),
  @NamedQuery(name = "VgTreeProduct.findByTradenameguid", query = "SELECT v FROM VgTreeProduct v WHERE v.tradenameguid = :tradenameguid"),
  @NamedQuery(name = "VgTreeProduct.findByCreatorUserName", query = "SELECT v FROM VgTreeProduct v WHERE v.creatorUserName = :creatorUserName"),
  @NamedQuery(name = "VgTreeProduct.findByCreationDate", query = "SELECT v FROM VgTreeProduct v WHERE v.creationDate = :creationDate"),
  @NamedQuery(name = "VgTreeProduct.findByCancelUserName", query = "SELECT v FROM VgTreeProduct v WHERE v.cancelUserName = :cancelUserName"),
  @NamedQuery(name = "VgTreeProduct.findByCancelDate", query = "SELECT v FROM VgTreeProduct v WHERE v.cancelDate = :cancelDate")})
public class VgTreeProduct implements Serializable {
  private static final long serialVersionUID = 1L;
  @EmbeddedId
  protected VgTreeProductPK vgTreeProductPK;
  @Size(max = 50)
  @Column(name = "FRANCHISEGUID")
  private String franchiseguid;
  @Size(max = 50)
  @Column(name = "TRADENAMEGUID")
  private String tradenameguid;
  @Size(max = 256)
  @Column(name = "CREATOR_USER_NAME")
  private String creatorUserName;
  @Column(name = "CREATION_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date creationDate;
  @Size(max = 256)
  @Column(name = "CANCEL_USER_NAME")
  private String cancelUserName;
  @Column(name = "CANCEL_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date cancelDate;
  @JoinColumns({
    @JoinColumn(name = "VG_TREE_CODE", referencedColumnName = "VG_TREE_CODE", insertable = false, updatable = false),
    @JoinColumn(name = "ITEM_ID", referencedColumnName = "ITEM_ID", insertable = false, updatable = false)})
  @ManyToOne(optional = false)
  private VgTreeItem vgTreeItem;

  public VgTreeProduct() {
  }

  public VgTreeProduct(VgTreeProductPK vgTreeProductPK) {
    this.vgTreeProductPK = vgTreeProductPK;
  }

  public VgTreeProduct(String vgTreeCode, int itemId, int productId) {
    this.vgTreeProductPK = new VgTreeProductPK(vgTreeCode, itemId, productId);
  }

  public VgTreeProductPK getVgTreeProductPK() {
    return vgTreeProductPK;
  }

  public void setVgTreeProductPK(VgTreeProductPK vgTreeProductPK) {
    this.vgTreeProductPK = vgTreeProductPK;
  }

  public String getFranchiseguid() {
    return franchiseguid;
  }

  public void setFranchiseguid(String franchiseguid) {
    this.franchiseguid = franchiseguid;
  }

  public String getTradenameguid() {
    return tradenameguid;
  }

  public void setTradenameguid(String tradenameguid) {
    this.tradenameguid = tradenameguid;
  }

  public String getCreatorUserName() {
    return creatorUserName;
  }

  public void setCreatorUserName(String creatorUserName) {
    this.creatorUserName = creatorUserName;
  }

  public Date getCreationDate() {
    return creationDate;
  }

  public void setCreationDate(Date creationDate) {
    this.creationDate = creationDate;
  }

  public String getCancelUserName() {
    return cancelUserName;
  }

  public void setCancelUserName(String cancelUserName) {
    this.cancelUserName = cancelUserName;
  }

  public Date getCancelDate() {
    return cancelDate;
  }

  public void setCancelDate(Date cancelDate) {
    this.cancelDate = cancelDate;
  }

  public VgTreeItem getVgTreeItem() {
    return vgTreeItem;
  }

  public void setVgTreeItem(VgTreeItem vgTreeItem) {
    this.vgTreeItem = vgTreeItem;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (vgTreeProductPK != null ? vgTreeProductPK.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof VgTreeProduct)) {
      return false;
    }
    VgTreeProduct other = (VgTreeProduct) object;
    if ((this.vgTreeProductPK == null && other.vgTreeProductPK != null) || (this.vgTreeProductPK != null && !this.vgTreeProductPK.equals(other.vgTreeProductPK))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.walter.VgTreeProduct[ vgTreeProductPK=" + vgTreeProductPK + " ]";
  }
  
}
