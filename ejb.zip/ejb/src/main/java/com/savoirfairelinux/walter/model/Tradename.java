package com.savoirfairelinux.walter.model;

import java.io.Serializable;
import java.math.BigDecimal;

public class Tradename implements Serializable {

	private String tradenameId;
	private Franchise franchise;
	private String description;
  private String size;
  private String format;
  private String productNumber;
  private BigDecimal listPrice;
  private String tradename;

  public Tradename(String tradenameId, String description, String size, String format, String productNumber, BigDecimal listPrice, String tradename) {
    this.tradenameId = tradenameId;
    this.description = description;
    this.size = size;
    this.format = format;
    this.productNumber = productNumber;
    this.listPrice = listPrice;
    this.tradename = tradename;
  }

	public Tradename(String tradenameId, Franchise franchise, String description) {
		this.tradenameId = tradenameId;
		this.franchise = franchise;
		this.description = description;
	}

	public String getTradenameId() {
		return tradenameId;
	}

	public void setTradenameId(String tradenameId) {
		this.tradenameId = tradenameId;
	}

	public Franchise getFranchise() {
		return franchise;
	}

	public void setFranchise(Franchise franchise) {
		this.franchise = franchise;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

  public String getSize() {
    return size;
  }

  public void setSize(String size) {
    this.size = size;
  }

  public String getFormat() {
    return format;
  }

  public void setFormat(String format) {
    this.format = format;
  }

  public String getProductNumber() {
    return productNumber;
  }

  public void setProductNumber(String productNumber) {
    this.productNumber = productNumber;
  }

  public BigDecimal getListPrice() {
    return listPrice;
  }

  public void setListPrice(BigDecimal listPrice) {
    this.listPrice = listPrice;
  }

  public String getTradename() {
    return tradename;
  }

  public void setTradename(String tradename) {
    this.tradename = tradename;
  }

  @Override
  public int hashCode() {
      int hash = (tradenameId != null ? tradenameId.hashCode() : 0);
      return hash;
  }

	@Override
	public boolean equals(Object obj) {
		Tradename tradename = (Tradename) obj;
		if (obj == null) {
			return false;
		} else if (this == obj) {
			return true;
		} else if (tradenameId.equals(tradename.getTradenameId())) {
			return true;
		}
		return false;
	}
}
