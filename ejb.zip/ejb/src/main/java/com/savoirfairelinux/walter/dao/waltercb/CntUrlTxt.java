/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "CNT_URL_TXT", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CntUrlTxt.findAll", query = "SELECT c FROM CntUrlTxt c"),
    @NamedQuery(name = "CntUrlTxt.findByUrlId", query = "SELECT c FROM CntUrlTxt c WHERE c.cntUrlTxtPK.urlId = :urlId"),
    @NamedQuery(name = "CntUrlTxt.findByLangId", query = "SELECT c FROM CntUrlTxt c WHERE c.cntUrlTxtPK.langId = :langId"),
    @NamedQuery(name = "CntUrlTxt.findByUrlTxt", query = "SELECT c FROM CntUrlTxt c WHERE c.urlTxt = :urlTxt")})
public class CntUrlTxt implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected CntUrlTxtPK cntUrlTxtPK;
    @Size(max = 100)
    @Column(name = "URL_TXT")
    private String urlTxt;
    @JoinColumn(name = "URL_ID", referencedColumnName = "URL_ID", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private CntUrl cntUrl;

    public CntUrlTxt() {
    }

    public CntUrlTxt(CntUrlTxtPK cntUrlTxtPK) {
        this.cntUrlTxtPK = cntUrlTxtPK;
    }

    public CntUrlTxt(short urlId, long langId) {
        this.cntUrlTxtPK = new CntUrlTxtPK(urlId, langId);
    }

    public CntUrlTxtPK getCntUrlTxtPK() {
        return cntUrlTxtPK;
    }

    public void setCntUrlTxtPK(CntUrlTxtPK cntUrlTxtPK) {
        this.cntUrlTxtPK = cntUrlTxtPK;
    }

    public String getUrlTxt() {
        return urlTxt;
    }

    public void setUrlTxt(String urlTxt) {
        this.urlTxt = urlTxt;
    }

    public CntUrl getCntUrl() {
        return cntUrl;
    }

    public void setCntUrl(CntUrl cntUrl) {
        this.cntUrl = cntUrl;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cntUrlTxtPK != null ? cntUrlTxtPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CntUrlTxt)) {
            return false;
        }
        CntUrlTxt other = (CntUrlTxt) object;
        if ((this.cntUrlTxtPK == null && other.cntUrlTxtPK != null) || (this.cntUrlTxtPK != null && !this.cntUrlTxtPK.equals(other.cntUrlTxtPK))) {
            return false;
        }
        return true;
    }
    
    @PrePersist
    private void prePersist() {
    	if (cntUrl != null && cntUrlTxtPK != null) {
    		cntUrlTxtPK.setUrlId(cntUrl.getUrlId());
    	}
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.CntUrlTxt[ cntUrlTxtPK=" + cntUrlTxtPK + " ]";
    }
    
}
