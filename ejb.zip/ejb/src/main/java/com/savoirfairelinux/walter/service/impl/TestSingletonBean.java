/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.service.impl;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author mgubaidullin
 */
@Startup
@Singleton
@LocalBean
@TransactionManagement(TransactionManagementType.CONTAINER)
public class TestSingletonBean {

    @EJB
    WalterBean walterBean;
    @EJB
    SolutionReportBean solutionReportBean;
    @EJB
    SingletonBean singletonBean;
    @EJB
    NotificationBean notificationBean;
    @EJB
    PhotoGalleryBean photoGalleryBean;
    @EJB
    NewIdeaBean newIdeaBean;
    @PersistenceContext(unitName = "waltershare")
    EntityManager entityManager;
    @EJB
    ProductivityReportBean productivityReportBean;

    @PostConstruct
    @TransactionAttribute(TransactionAttributeType.MANDATORY)
    public void init() {
        try {
//            Cnt cnt = solutionReportBean.getSolutionReport(21705L, "Walter");
//            solutionReportBean.validate(cnt);
//
//            List<Company> companies = CompanyLocalServiceUtil.getCompanies();
//            User creator = UserLocalServiceUtil.getUserByScreenName(companies.get(0).getCompanyId(), cnt.getCreatorUserName().toLowerCase());
//
//            creator.setMiddleName("TEST2");
//            UserLocalServiceUtil.updateUser(creator);
        } catch (Exception ex) {
          System.out.println("error: " + ex.getMessage());
        }
    }
}
