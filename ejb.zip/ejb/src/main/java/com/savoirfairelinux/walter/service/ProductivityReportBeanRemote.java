/*
 * Copyright 2012 Savoir-faire Linux
 *
 * This file is part of Walter-Portal.
 *
 * Walter-Portal is free software: you can redistribute it and/or modify it under the terms of the
 * GNU General Public License as published by the Free Software Foundation, either version 3
 * of the License, or (at your option) any later version.
 *
 * Walter-Portal is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with Walter-Portal.
 * If not, see http://www.gnu.org/licenses/.
 */
package com.savoirfairelinux.walter.service;

import com.savoirfairelinux.walter.dao.waltercb.PrResult;
import com.savoirfairelinux.walter.dao.waltercb.ProductivityReport;
import com.savoirfairelinux.walter.dao.waltercb.UCompetitor;
import com.savoirfairelinux.walter.dao.waltercb.UCompetitorProduct;
import com.savoirfairelinux.walter.dao.waltercb.UMaterial;
import com.savoirfairelinux.walter.dao.walterproductivity.Orders;
import com.savoirfairelinux.walter.dao.walterproductivity.Reports;
import com.savoirfairelinux.walter.jasper.model.JasperMobileProductivityReportBean;
import com.savoirfairelinux.walter.model.PrApplication;
import com.savoirfairelinux.walter.model.PrWalterProduct;
import com.savoirfairelinux.walter.model.SearchProductivityReport;
import com.savoirfairelinux.walter.model.SearchProductivityResult;
import java.util.List;
import javax.ejb.Remote;

/**
 * @author jderuere
 */
@Remote
public interface ProductivityReportBeanRemote {

    ProductivityReport save(ProductivityReport report);

    void remove(ProductivityReport report);

    void remove(PrResult prResult);

    List<ProductivityReport> getMyUnsubmitReports(String screenName, Long langId, String languageAbbreviation,String webSiteCountryName);

    List<ProductivityReport> getMySubmittedReports(String screenName, Long langId, String languageAbbreviation, String webSiteCountryName);

    List<ProductivityReport> getMyPublishedReports(String screenName, Long langId, String languageAbbreviation, String webSiteCountryName);

    UCompetitor loadCompetitor(UCompetitor competitor);

    List<ProductivityReport> search(SearchProductivityReport form, Long langId, String languageAbbreviation, String webSiteCountryName) throws Exception;

    List<PrResult> search(SearchProductivityResult form, String userName, String organization, Long langId, String webSiteCountryName, Boolean readOnly) throws Exception;

    String submit(ProductivityReport report);

    ProductivityReport getProductivityReport(Long id, String languageAbbreviation, String webSiteCountryName, Long langId) throws Exception;

    List<ProductivityReport> getSubmitReports(Long langId, String languageAbbreviation, String webSiteCountryName);

    ProductivityReport publish(ProductivityReport report);

    PrResult getCompetitorResult(UCompetitorProduct product, Long materialId, Long langId);

    PrResult getWalterResult(String productNumber, Long materialId, Long langId);

    PrResult getResult(Long id, String languageAbbreviation, String webSiteCountryName, Long langId) throws Exception;

    List<PrWalterProduct> getWalterProducts(String webSiteCountryName);

    /***
     * @param countryCode
     * @param langCode
     * @return Product abrasive in action Grinding, Cutting, Blending, Sanding, Finishing
     */
    public List<PrWalterProduct> getWalterProducts(String countryCode, String langCode);

    /***
     * @param countryCode
     * @param langCode
     * @return All products
     */
    public List<PrWalterProduct> getAllWalterProducts(String countryCode, String langCode);

    PrWalterProduct loadWalterProduct(PrWalterProduct product, String languageAbbreviation);

    PrWalterProduct getWalterProduct(String productNumber, String webSiteCountryName, String languageAbbreviation);

    List<PrApplication> getApplications(String languageAbbreviation);

    PrApplication getApplication(String applicationGUID, String languageAbbreviation);

    List<String> getTypes();

    List<String> getGrits();

    PrResult save(PrResult result);

    void remove(UCompetitorProduct product);

    void publishCompetitor(PrResult result);

    void publishWalter(PrResult result);

    boolean existPublishedReport(UCompetitorProduct product);

    List<UMaterial> getMaterialList(Long langId);

    public PrWalterProduct getProductByGuid(String productVersionGuid, String countryCode, String langCode);

    public UMaterial getMaterial(long materialId, long langId);

    public JasperMobileProductivityReportBean MobileProductivitySendEmail(Reports report);

    public List<Reports> getMobileProductivityReportReadyEmail();

    public List<Orders> getMobileProductivityOrderEmail();
}
