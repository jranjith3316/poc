/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "CNT_COUNTER", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CntCounter.findAll", query = "SELECT c FROM CntCounter c"),
    @NamedQuery(name = "CntCounter.findByCntId", query = "SELECT c FROM CntCounter c WHERE c.cntCounterPK.cntId = :cntId"),
    @NamedQuery(name = "CntCounter.findByUserName", query = "SELECT c FROM CntCounter c WHERE c.cntCounterPK.userName = :userName"),
    @NamedQuery(name = "CntCounter.findByCounter", query = "SELECT c FROM CntCounter c WHERE c.counter = :counter"),
    @NamedQuery(name = "CntCounter.findByLastRead", query = "SELECT c FROM CntCounter c WHERE c.lastRead = :lastRead"),
    @NamedQuery(name = "CntCounter.findByFirstRead", query = "SELECT c FROM CntCounter c WHERE c.firstRead = :firstRead"),
    @NamedQuery(name = "CntCounter.findByLastIdSession", query = "SELECT c FROM CntCounter c WHERE c.lastIdSession = :lastIdSession")})
public class CntCounter implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected CntCounterPK cntCounterPK;
    @Column(name = "COUNTER")
    private Long counter;
    @Column(name = "LAST_READ")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastRead;
    @Column(name = "FIRST_READ")
    @Temporal(TemporalType.TIMESTAMP)
    private Date firstRead;
    @Column(name = "LAST_ID_SESSION")
    private BigInteger lastIdSession;
    @JoinColumn(name = "CNT_ID", referencedColumnName = "CNT_ID", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Cnt cnt;

    public CntCounter() {
    }

    public CntCounter(CntCounterPK cntCounterPK) {
        this.cntCounterPK = cntCounterPK;
    }

    public CntCounter(long cntId, String userName) {
        this.cntCounterPK = new CntCounterPK(cntId, userName);
    }

    public CntCounterPK getCntCounterPK() {
        return cntCounterPK;
    }

    public void setCntCounterPK(CntCounterPK cntCounterPK) {
        this.cntCounterPK = cntCounterPK;
    }

    public Long getCounter() {
        return counter;
    }

    public void setCounter(Long counter) {
        this.counter = counter;
    }

    public Date getLastRead() {
        return lastRead;
    }

    public void setLastRead(Date lastRead) {
        this.lastRead = lastRead;
    }

    public Date getFirstRead() {
        return firstRead;
    }

    public void setFirstRead(Date firstRead) {
        this.firstRead = firstRead;
    }

    public BigInteger getLastIdSession() {
        return lastIdSession;
    }

    public void setLastIdSession(BigInteger lastIdSession) {
        this.lastIdSession = lastIdSession;
    }

    public Cnt getCnt() {
        return cnt;
    }

    public void setCnt(Cnt cnt) {
        this.cnt = cnt;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cntCounterPK != null ? cntCounterPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CntCounter)) {
            return false;
        }
        CntCounter other = (CntCounter) object;
        if ((this.cntCounterPK == null && other.cntCounterPK != null) || (this.cntCounterPK != null && !this.cntCounterPK.equals(other.cntCounterPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.CntCounter[ cntCounterPK=" + cntCounterPK + " ]";
    }
    
}
