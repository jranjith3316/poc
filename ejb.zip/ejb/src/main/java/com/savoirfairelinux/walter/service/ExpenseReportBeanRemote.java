package com.savoirfairelinux.walter.service;

import com.liferay.portal.model.User;
import java.math.BigDecimal;
import java.util.List;

import javax.ejb.Remote;

import com.savoirfairelinux.walter.dao.walter.ExpenseRpt;
import com.savoirfairelinux.walter.dao.walter.ExpenseRptD;
import com.savoirfairelinux.walter.dao.walter.ExpenseTxt;
import com.savoirfairelinux.walter.dao.walter.Loan;
import com.savoirfairelinux.walter.dao.walter.LoanD;
import com.savoirfairelinux.walter.dao.walter.UPerson;
import com.savoirfairelinux.walter.dao.waltercb.CbFranchiseTxt;
import com.savoirfairelinux.walter.dao.waltercb.Country;
import com.savoirfairelinux.walter.dao.waltercb.CountryStateTxt;
import com.savoirfairelinux.walter.model.GLCode;
import com.savoirfairelinux.walter.model.SearchExpenseReport;
import java.util.Date;

@Remote
public interface ExpenseReportBeanRemote {

    public List<ExpenseRpt> getExpenseRptUnsubmittedList(String userName) throws Exception;

    public List<ExpenseRpt> getExpenseRptSubmittedList(String userName) throws Exception;

    public List<ExpenseRpt> getExpenseRptApprovedList(String userName) throws Exception;

    public List<ExpenseRpt> getExpenseRptValidatedList(String userName) throws Exception;

    public List<UPerson> getMgrAndExternalUser(String currentUser);
    
    public List<ExpenseRpt> getExpenseRptMgrUserList(String currentUser, String employeeName, String reportStatus, Long expenseRptId, Date fromDate, Date toDate) throws Exception;

    public BigDecimal getAmtPaid(Long expenseRptId) throws Exception;

    public ExpenseRpt getExpenseRpt(Long expenseRptId) throws Exception;

    public Country getCountry(Long countryId) throws Exception;

    public List<CountryStateTxt> getCountryStateTxtList(Long countryId, Long langId) throws Exception;

    public CountryStateTxt getCountryStateTxt(Long countryId, String stateCode, Long langId) throws Exception;

    public List<ExpenseTxt> getExpenseTypeList(Long countryId, Long langId) throws Exception;

    public ExpenseTxt getExpenseType(Long countryId, Long expenseId, Long langId) throws Exception;

    public BigDecimal getUserAmtPerDistanceUnit(String userName) throws Exception;

    public BigDecimal getInternetAllowence(String userName) throws Exception;

    public BigDecimal getHotelAllowence(String userName) throws Exception;

    public ExpenseRptD getLastExpenseRptD(long expenseRptId) throws Exception;
    
    public ExpenseRptD getExpenseRptD(long expenseRptId, short lineNum) throws Exception;

    public List<ExpenseRptD> getExpenseRptDDeletedList(Long expenseRptId) throws Exception;

    public List<ExpenseRptD> getExpenseRptDList(Long expenseRptId) throws Exception;

    public List<ExpenseRptD> getExpenseRptDList(Long expenseRptId, Long expenseId) throws Exception;

    public void saveExpenseReport(ExpenseRpt expenseRpt) throws Exception;

    public void saveExpenseReportD(ExpenseRptD expenseRptd) throws Exception;

    public void deleteExpenseReportD(long expenseRptId, short lineNum) throws Exception;

    public List<Object[]> getTaxList(ExpenseRptD expenseRptD) throws Exception;

    public BigDecimal getTaxAmt(ExpenseRptD expenseRptD, String taxField) throws Exception;

    public Short getExpenseRptDLineNumber(Long expenseRptId) throws Exception;

    public List<ExpenseRpt> getExpenseRptApprovedList(long countryId, long expenseRptId) throws Exception;

    public List<ExpenseRpt> getExpenseRptValidatedList(long countryId, long expenseRptId) throws Exception;

    public List<ExpenseRpt> getExpenseRptSubmittedList(long countryId, long expenseRptId) throws Exception;

    public List<Object[]> getExpenseRptTypeList(Long expenseRptId) throws Exception;

    public List<Object[]> getGlCodeTotalList(Long expenseRptId) throws Exception;

    public List<Object[]> getGlCodeTaxList(Long expenseRptId, Long langId) throws Exception;

    public List<ExpenseRptD> getHotelNightList(Long expenseRptId, long countryId) throws Exception;

    public List<ExpenseRptD> getCareServiceHotelNightList(Long expenseRptId, long countryId) throws Exception;
    
    public List<GLCode> getGlCodeList(long countryId) throws Exception;
    //public Boolean getUserAccess(String userName, String role);

    public BigDecimal getPerDiem(Long expenseRptId) throws Exception;

    public List<Loan> getLoanList(Integer countryId) throws Exception;

    public List<Object[]> getLoanDetailList(Long loanId) throws Exception;

    public List<Loan> getUserLoanAvailable(String userName, Long expenseRptId) throws Exception;

    public LoanD getLoanD(Long loanId, Long expenseRptId) throws Exception;

    public void deleteLoanD(LoanD loanD) throws Exception;

    public BigDecimal getSumLoanPaid(Long expenseRptId) throws Exception;

    public boolean isModifyByAccounting(Long expenseRptId) throws Exception;
    
    public boolean isLoanAvailable(String userName) throws Exception;

    public float getUserLoanAvailable(String userName) throws Exception;
    
    public List<ExpenseTxt> getSearchExpenseTxt(SearchExpenseReport form) throws Exception;
    
    public List<ExpenseRptD> getSearchExpenseRptD(SearchExpenseReport form) throws Exception;
    
    public List<UPerson> getAllUserForCurrentCountry(Long countryId);

    public BigDecimal getCareTechPerDiem(String userName) throws Exception;

    public BigDecimal getCareTechPerDiemBonus(String userName) throws Exception;

    public BigDecimal getCareTechOutZone(String userName) throws Exception;

    public BigDecimal getCareTechNewMachine(String userName) throws Exception;

}
