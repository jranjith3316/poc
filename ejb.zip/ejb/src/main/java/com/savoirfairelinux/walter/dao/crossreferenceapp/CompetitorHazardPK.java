/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.crossreferenceapp;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author jsgill
 */
@Embeddable
public class CompetitorHazardPK implements Serializable {
  @Basic(optional = false)
  @NotNull
  @Column(name = "COMPETITOR_ID")
  private long competitorId;
  @Basic(optional = false)
  @NotNull
  @Column(name = "BRAND_ID")
  private long brandId;
  @Basic(optional = false)
  @NotNull
  @Column(name = "PRODUCT_ID")
  private long productId;
  @Basic(optional = false)
  @NotNull
  @Column(name = "COUNTRY_ID")
  private long countryId;
  @Basic(optional = false)
  @NotNull
  @Size(min = 1, max = 255)
  @Column(name = "CLASSNAME")
  private String classname;
  @Basic(optional = false)
  @NotNull
  @Size(min = 1, max = 255)
  @Column(name = "INSTANCEGUID")
  private String instanceguid;

  public CompetitorHazardPK() {
  }

  public CompetitorHazardPK(long competitorId, long brandId, long productId, long countryId, String classname, String instanceguid) {
    this.competitorId = competitorId;
    this.brandId = brandId;
    this.productId = productId;
    this.countryId = countryId;
    this.classname = classname;
    this.instanceguid = instanceguid;
  }

  public long getCompetitorId() {
    return competitorId;
  }

  public void setCompetitorId(long competitorId) {
    this.competitorId = competitorId;
  }

  public long getBrandId() {
    return brandId;
  }

  public void setBrandId(long brandId) {
    this.brandId = brandId;
  }

  public long getProductId() {
    return productId;
  }

  public void setProductId(long productId) {
    this.productId = productId;
  }

  public long getCountryId() {
    return countryId;
  }

  public void setCountryId(long countryId) {
    this.countryId = countryId;
  }

  public String getClassname() {
    return classname;
  }

  public void setClassname(String classname) {
    this.classname = classname;
  }

  public String getInstanceguid() {
    return instanceguid;
  }

  public void setInstanceguid(String instanceguid) {
    this.instanceguid = instanceguid;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (int) competitorId;
    hash += (int) brandId;
    hash += (int) productId;
    hash += (int) countryId;
    hash += (classname != null ? classname.hashCode() : 0);
    hash += (instanceguid != null ? instanceguid.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof CompetitorHazardPK)) {
      return false;
    }
    CompetitorHazardPK other = (CompetitorHazardPK) object;
    if (this.competitorId != other.competitorId) {
      return false;
    }
    if (this.brandId != other.brandId) {
      return false;
    }
    if (this.productId != other.productId) {
      return false;
    }
    if (this.countryId != other.countryId) {
      return false;
    }
    if ((this.classname == null && other.classname != null) || (this.classname != null && !this.classname.equals(other.classname))) {
      return false;
    }
    if ((this.instanceguid == null && other.instanceguid != null) || (this.instanceguid != null && !this.instanceguid.equals(other.instanceguid))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.crossreferenceapp.CompetitorHazardPK[ competitorId=" + competitorId + ", brandId=" + brandId + ", productId=" + productId + ", countryId=" + countryId + ", classname=" + classname + ", instanceguid=" + instanceguid + " ]";
  }

}
