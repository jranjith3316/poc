/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.crossreferenceapp.model;

import java.io.Serializable;
import java.util.List;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;

/**
 *
 * @author jsgill
 */
public class CompetitorProductModel implements Serializable {
  private static final long serialVersionUID = 3511338233023397895L;
  private long competitorId;
  private long brandId;
  private long productId;
  private String description;
  private String productNumber;
  private String upc;
  private String format;
  private String metricSize;
  private String imperialSize;
  private String imperialTemperature;
  private String metricTemperature;
  private String voc;
  private String ph;
  private DocumentModel sdsDocument;
  private DocumentModel tdsDocument;
  private boolean elementFlame;
  private boolean elementGasCylinder;
  private boolean elementCorrosion;
  private boolean elementExclamation;
  private boolean elementHealth;
  private boolean elementEnvironment;
  private boolean elementSkull;
  private boolean elementFlameCircle;
  private boolean elementExplodingBomb;
  private String prop65;
  private String diluation;
  private List<String> materials;
  private List<HazardModel> physicalHazards;
  private List<HazardModel> healthHazards;
  private List<HazardModel> environmentalHazards;
  private List<String> certifications;
  private List<CompetitorWalterProductModel> competitorWalterProducts;
  private String productImage;
  private List<String> applications;
  private String dateVerified;

  public long getCompetitorId() {
    return competitorId;
  }

  public void setCompetitorId(long competitorId) {
    this.competitorId = competitorId;
  }

  public long getBrandId() {
    return brandId;
  }

  public void setBrandId(long brandId) {
    this.brandId = brandId;
  }

  public long getProductId() {
    return productId;
  }

  public void setProductId(long productId) {
    this.productId = productId;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getProductNumber() {
    return productNumber;
  }

  public void setProductNumber(String productNumber) {
    this.productNumber = productNumber;
  }

  public String getUpc() {
    return upc;
  }

  public void setUpc(String upc) {
    this.upc = upc;
  }

  public String getFormat() {
    return format;
  }

  public void setFormat(String format) {
    this.format = format;
  }

  public String getMetricSize() {
    return metricSize;
  }

  public void setMetricSize(String metricSize) {
    this.metricSize = metricSize;
  }

  public String getImperialSize() {
    return imperialSize;
  }

  public void setImperialSize(String imperialSize) {
    this.imperialSize = imperialSize;
  }

  public String getImperialTemperature() {
    return imperialTemperature;
  }

  public void setImperialTemperature(String imperialTemperature) {
    this.imperialTemperature = imperialTemperature;
  }

  public String getMetricTemperature() {
    return metricTemperature;
  }

  public void setMetricTemperature(String metricTemperature) {
    this.metricTemperature = metricTemperature;
  }

  public String getVoc() {
    return voc;
  }

  public void setVoc(String voc) {
    this.voc = voc;
  }

  public String getPh() {
    return ph;
  }

  public void setPh(String ph) {
    this.ph = ph;
  }

  public DocumentModel getSdsDocument() {
    return sdsDocument;
  }

  public void setSdsDocument(DocumentModel sdsDocument) {
    this.sdsDocument = sdsDocument;
  }

  public DocumentModel getTdsDocument() {
    return tdsDocument;
  }

  public void setTdsDocument(DocumentModel tdsDocument) {
    this.tdsDocument = tdsDocument;
  }

  public boolean isElementFlame() {
    return elementFlame;
  }

  public void setElementFlame(boolean elementFlame) {
    this.elementFlame = elementFlame;
  }

  public boolean isElementGasCylinder() {
    return elementGasCylinder;
  }

  public void setElementGasCylinder(boolean elementGasCylinder) {
    this.elementGasCylinder = elementGasCylinder;
  }

  public boolean isElementCorrosion() {
    return elementCorrosion;
  }

  public void setElementCorrosion(boolean elementCorrosion) {
    this.elementCorrosion = elementCorrosion;
  }

  public boolean isElementExclamation() {
    return elementExclamation;
  }

  public void setElementExclamation(boolean elementExclamation) {
    this.elementExclamation = elementExclamation;
  }

  public boolean isElementHealth() {
    return elementHealth;
  }

  public void setElementHealth(boolean elementHealth) {
    this.elementHealth = elementHealth;
  }

  public boolean isElementEnvironment() {
    return elementEnvironment;
  }

  public void setElementEnvironment(boolean elementEnvironment) {
    this.elementEnvironment = elementEnvironment;
  }

  public boolean isElementSkull() {
    return elementSkull;
  }

  public void setElementSkull(boolean elementSkull) {
    this.elementSkull = elementSkull;
  }

  public boolean isElementFlameCircle() {
    return elementFlameCircle;
  }

  public void setElementFlameCircle(boolean elementFlameCircle) {
    this.elementFlameCircle = elementFlameCircle;
  }

  public boolean isElementExplodingBomb() {
    return elementExplodingBomb;
  }

  public void setElementExplodingBomb(boolean elementExplodingBomb) {
    this.elementExplodingBomb = elementExplodingBomb;
  }

  public String getProp65() {
    return prop65;
  }

  public void setProp65(String prop65) {
    this.prop65 = prop65;
  }

  public String getDiluation() {
    return diluation;
  }

  public void setDiluation(String diluation) {
    this.diluation = diluation;
  }

  @XmlElementWrapper
  @XmlElement(name="material")
  public List<String> getMaterials() {
    return materials;
  }

  public void setMaterials(List<String> materials) {
    this.materials = materials;
  }

  @XmlElementWrapper
  @XmlElement(name="physicalHazard")
  public List<HazardModel> getPhysicalHazards() {
    return physicalHazards;
  }

  public void setPhysicalHazards(List<HazardModel> physicalHazards) {
    this.physicalHazards = physicalHazards;
  }

  @XmlElementWrapper
  @XmlElement(name="healthHazard")
  public List<HazardModel> getHealthHazards() {
    return healthHazards;
  }

  public void setHealthHazards(List<HazardModel> healthHazards) {
    this.healthHazards = healthHazards;
  }

  @XmlElementWrapper
  @XmlElement(name="environmentalHazard")
  public List<HazardModel> getEnvironmentalHazards() {
    return environmentalHazards;
  }

  public void setEnvironmentalHazards(List<HazardModel> environmentalHazards) {
    this.environmentalHazards = environmentalHazards;
  }

  @XmlElementWrapper
  @XmlElement(name="certification")
  public List<String> getCertifications() {
    return certifications;
  }

  public void setCertifications(List<String> certifications) {
    this.certifications = certifications;
  }

  @XmlElementWrapper
  @XmlElement(name="competitorWalterProduct")
  public List<CompetitorWalterProductModel> getCompetitorWalterProducts() {
    return competitorWalterProducts;
  }

  public void setCompetitorWalterProducts(List<CompetitorWalterProductModel> competitorWalterProducts) {
    this.competitorWalterProducts = competitorWalterProducts;
  }

  public String getProductImage() {
    return productImage;
  }

  public void setProductImage(String productImage) {
    this.productImage = productImage;
  }

  @XmlElementWrapper
  @XmlElement(name="application")
  public List<String> getApplications() {
    return applications;
  }

  public void setApplications(List<String> applications) {
    this.applications = applications;
  }

  public String getDateVerified() {
    return dateVerified;
  }

  public void setDateVerified(String dateVerified) {
    this.dateVerified = dateVerified;
  }


}
