/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.idb;

import com.savoirfairelinux.walter.dao.DatabaseConstants;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "WALTER_PRODUCTS_DOCUMENTS", catalog = "", schema = DatabaseConstants.IDB_SCHEMA)
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "WalterProductsDocuments.findAll", query = "SELECT w FROM WalterProductsDocuments w"),
  @NamedQuery(name = "WalterProductsDocuments.findByProductdocumentguid", query = "SELECT w FROM WalterProductsDocuments w WHERE w.productdocumentguid = :productdocumentguid"),
  @NamedQuery(name = "WalterProductsDocuments.findByFilename", query = "SELECT w FROM WalterProductsDocuments w WHERE w.filename = :filename"),
  @NamedQuery(name = "WalterProductsDocuments.findByType", query = "SELECT w FROM WalterProductsDocuments w WHERE w.type = :type"),
  @NamedQuery(name = "WalterProductsDocuments.findByFormat", query = "SELECT w FROM WalterProductsDocuments w WHERE w.format = :format"),
  @NamedQuery(name = "WalterProductsDocuments.findByAdddatetime", query = "SELECT w FROM WalterProductsDocuments w WHERE w.adddatetime = :adddatetime"),
  @NamedQuery(name = "WalterProductsDocuments.findByDeletedatetime", query = "SELECT w FROM WalterProductsDocuments w WHERE w.deletedatetime = :deletedatetime"),
  @NamedQuery(name = "WalterProductsDocuments.findByUpdatedatetime", query = "SELECT w FROM WalterProductsDocuments w WHERE w.updatedatetime = :updatedatetime")})
public class WalterProductsDocuments implements Serializable {
  private static final long serialVersionUID = 1L;
  @Id
  @Basic(optional = false)
  @NotNull
  @Size(min = 1, max = 255)
  @Column(name = "PRODUCTDOCUMENTGUID")
  private String productdocumentguid;
  @Size(max = 255)
  @Column(name = "FILENAME")
  private String filename;
  @Size(max = 255)
  @Column(name = "TYPE")
  private String type;
  @Size(max = 255)
  @Column(name = "FORMAT")
  private String format;
  @Column(name = "ADDDATETIME")
  @Temporal(TemporalType.TIMESTAMP)
  private Date adddatetime;
  @Column(name = "DELETEDATETIME")
  @Temporal(TemporalType.TIMESTAMP)
  private Date deletedatetime;
  @Column(name = "UPDATEDATETIME")
  @Temporal(TemporalType.TIMESTAMP)
  private Date updatedatetime;
  @JoinColumn(name = "URLGUID", referencedColumnName = "URLGUID")
  @ManyToOne
  private WalterUrl urlguid;
  @JoinColumn(name = "PRODUCTVERSIONGUID", referencedColumnName = "PRODUCTVERSIONGUID")
  @ManyToOne
  private WalterProductsVersions productversionguid;
  @JoinColumn(name = "PRODUCTPRESENTATIONGUID", referencedColumnName = "PRODUCTPRESENTATIONGUID")
  @ManyToOne
  private WalterProductsPresentations productpresentationguid;
  @JoinColumn(name = "PRODUCTCOUNTRYGUID", referencedColumnName = "PRODUCTCOUNTRYGUID")
  @ManyToOne(optional = false)
  private WalterProductsCountries productcountryguid;
  @JoinColumn(name = "PRODUCTGUID", referencedColumnName = "PRODUCTGUID")
  @ManyToOne(optional = false)
  private WalterProducts productguid;
  @JoinColumn(name = "FILEGUID", referencedColumnName = "FILEGUID")
  @ManyToOne
  private WalterFiles fileguid;
  @JoinColumn(name = "COUNTRYGUID", referencedColumnName = "INSTANCEGUID")
  @ManyToOne(optional = false)
  private OoInstances countryguid;
  @JoinColumn(name = "LANGUAGEGUID", referencedColumnName = "INSTANCEGUID")
  @ManyToOne(optional = false)
  private OoInstances languageguid;
  @JoinColumn(name = "PRODUCTDOCUMENTGUID", referencedColumnName = "INSTANCEGUID", insertable = false, updatable = false)
  @OneToOne(optional = false)
  private OoInstances ooInstances;
  @JoinColumn(name = "PRESENTATIONGUID", referencedColumnName = "INSTANCEGUID")
  @ManyToOne
  private OoInstances presentationguid;

  public WalterProductsDocuments() {
  }

  public WalterProductsDocuments(String productdocumentguid) {
    this.productdocumentguid = productdocumentguid;
  }

  public String getProductdocumentguid() {
    return productdocumentguid;
  }

  public void setProductdocumentguid(String productdocumentguid) {
    this.productdocumentguid = productdocumentguid;
  }

  public String getFilename() {
    return filename;
  }

  public void setFilename(String filename) {
    this.filename = filename;
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public String getFormat() {
    return format;
  }

  public void setFormat(String format) {
    this.format = format;
  }

  public Date getAdddatetime() {
    return adddatetime;
  }

  public void setAdddatetime(Date adddatetime) {
    this.adddatetime = adddatetime;
  }

  public Date getDeletedatetime() {
    return deletedatetime;
  }

  public void setDeletedatetime(Date deletedatetime) {
    this.deletedatetime = deletedatetime;
  }

  public Date getUpdatedatetime() {
    return updatedatetime;
  }

  public void setUpdatedatetime(Date updatedatetime) {
    this.updatedatetime = updatedatetime;
  }

  public WalterUrl getUrlguid() {
    return urlguid;
  }

  public void setUrlguid(WalterUrl urlguid) {
    this.urlguid = urlguid;
  }

  public WalterProductsVersions getProductversionguid() {
    return productversionguid;
  }

  public void setProductversionguid(WalterProductsVersions productversionguid) {
    this.productversionguid = productversionguid;
  }

  public WalterProductsPresentations getProductpresentationguid() {
    return productpresentationguid;
  }

  public void setProductpresentationguid(WalterProductsPresentations productpresentationguid) {
    this.productpresentationguid = productpresentationguid;
  }

  public WalterProductsCountries getProductcountryguid() {
    return productcountryguid;
  }

  public void setProductcountryguid(WalterProductsCountries productcountryguid) {
    this.productcountryguid = productcountryguid;
  }

  public WalterProducts getProductguid() {
    return productguid;
  }

  public void setProductguid(WalterProducts productguid) {
    this.productguid = productguid;
  }

  public WalterFiles getFileguid() {
    return fileguid;
  }

  public void setFileguid(WalterFiles fileguid) {
    this.fileguid = fileguid;
  }

  public OoInstances getCountryguid() {
    return countryguid;
  }

  public void setCountryguid(OoInstances countryguid) {
    this.countryguid = countryguid;
  }

  public OoInstances getLanguageguid() {
    return languageguid;
  }

  public void setLanguageguid(OoInstances languageguid) {
    this.languageguid = languageguid;
  }

  public OoInstances getOoInstances() {
    return ooInstances;
  }

  public void setOoInstances(OoInstances ooInstances) {
    this.ooInstances = ooInstances;
  }

  public OoInstances getPresentationguid() {
    return presentationguid;
  }

  public void setPresentationguid(OoInstances presentationguid) {
    this.presentationguid = presentationguid;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (productdocumentguid != null ? productdocumentguid.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof WalterProductsDocuments)) {
      return false;
    }
    WalterProductsDocuments other = (WalterProductsDocuments) object;
    if ((this.productdocumentguid == null && other.productdocumentguid != null) || (this.productdocumentguid != null && !this.productdocumentguid.equals(other.productdocumentguid))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.idb.WalterProductsDocuments[ productdocumentguid=" + productdocumentguid + " ]";
  }

}
