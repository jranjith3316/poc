/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.crossreferenceapp;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "DILUENT", catalog = "", schema = "CROSSREFERENCEAPP")
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "Diluent.findAll", query = "SELECT d FROM Diluent d"),
  @NamedQuery(name = "Diluent.findByDiluentId", query = "SELECT d FROM Diluent d WHERE d.diluentId = :diluentId"),
  @NamedQuery(name = "Diluent.findByLangId", query = "SELECT d FROM Diluent d WHERE d.langId = :langId"),
  @NamedQuery(name = "Diluent.findByName", query = "SELECT d FROM Diluent d WHERE d.name = :name"),
  @NamedQuery(name = "Diluent.findByCreatedUserName", query = "SELECT d FROM Diluent d WHERE d.createdUserName = :createdUserName"),
  @NamedQuery(name = "Diluent.findByCreatedDate", query = "SELECT d FROM Diluent d WHERE d.createdDate = :createdDate"),
  @NamedQuery(name = "Diluent.findByUpdatedUserName", query = "SELECT d FROM Diluent d WHERE d.updatedUserName = :updatedUserName"),
  @NamedQuery(name = "Diluent.findByUpdatedDate", query = "SELECT d FROM Diluent d WHERE d.updatedDate = :updatedDate")})
public class Diluent implements Serializable {
  private static final long serialVersionUID = 1L;
  @Id
  @Basic(optional = false)
  @NotNull
  @Column(name = "DILUENT_ID")
  private Long diluentId;
  @Basic(optional = false)
  @NotNull
  @Column(name = "LANG_ID")
  private long langId;
  @Size(max = 30)
  @Column(name = "NAME")
  private String name;
  @Size(max = 255)
  @Column(name = "CREATED_USER_NAME")
  private String createdUserName;
  @Column(name = "CREATED_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date createdDate;
  @Size(max = 255)
  @Column(name = "UPDATED_USER_NAME")
  private String updatedUserName;
  @Column(name = "UPDATED_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date updatedDate;

  public Diluent() {
  }

  public Diluent(Long diluentId) {
    this.diluentId = diluentId;
  }

  public Diluent(Long diluentId, long langId) {
    this.diluentId = diluentId;
    this.langId = langId;
  }

  public Long getDiluentId() {
    return diluentId;
  }

  public void setDiluentId(Long diluentId) {
    this.diluentId = diluentId;
  }

  public long getLangId() {
    return langId;
  }

  public void setLangId(long langId) {
    this.langId = langId;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getCreatedUserName() {
    return createdUserName;
  }

  public void setCreatedUserName(String createdUserName) {
    this.createdUserName = createdUserName;
  }

  public Date getCreatedDate() {
    return createdDate;
  }

  public void setCreatedDate(Date createdDate) {
    this.createdDate = createdDate;
  }

  public String getUpdatedUserName() {
    return updatedUserName;
  }

  public void setUpdatedUserName(String updatedUserName) {
    this.updatedUserName = updatedUserName;
  }

  public Date getUpdatedDate() {
    return updatedDate;
  }

  public void setUpdatedDate(Date updatedDate) {
    this.updatedDate = updatedDate;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (diluentId != null ? diluentId.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof Diluent)) {
      return false;
    }
    Diluent other = (Diluent) object;
    if ((this.diluentId == null && other.diluentId != null) || (this.diluentId != null && !this.diluentId.equals(other.diluentId))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.crossreferenceapp.Diluent[ diluentId=" + diluentId + " ]";
  }

}
