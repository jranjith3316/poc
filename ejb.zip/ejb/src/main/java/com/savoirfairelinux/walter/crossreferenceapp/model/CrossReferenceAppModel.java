/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.crossreferenceapp.model;

import java.io.Serializable;
import java.util.List;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jsgill
 */
@XmlRootElement(name = "crossReferenceAppModel")
public class CrossReferenceAppModel implements Serializable {
  private static final long serialVersionUID = 3511338233023397895L;
  private String countryCode;
  private String langCode;

  private List<CompetitorModel> competitors;

  public String getCountryCode() {
    return countryCode;
  }

  public void setCountryCode(String countryCode) {
    this.countryCode = countryCode;
  }

  public String getLangCode() {
    return langCode;
  }

  public void setLangCode(String langCode) {
    this.langCode = langCode;
  }

  @XmlElementWrapper
  @XmlElement(name="competitor")
  public List<CompetitorModel> getCompetitors() {
    return competitors;
  }

  public void setCompetitors(List<CompetitorModel> competitors) {
    this.competitors = competitors;
  }




}
