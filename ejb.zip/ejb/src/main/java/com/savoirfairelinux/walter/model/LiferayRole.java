package com.savoirfairelinux.walter.model;

public enum LiferayRole {

    // Liferay Roles
    ADMINISTRATOR("Administrator"),
    GUEST("Guest"),
    OWNER("Owner"),
    USER("User"),
    POWER_USER("Power User"),
    ORGANIZATION_ADMINISTRATOR("Organization Administrator"),
    ORGANIZATION_OWNER("Organization Owner"),
    ORGANIZATION_USER("Organization User"),
    SITE_ADMINISTRATOR("Site Administrator"),
    SITE_OWNER("Site Owner"),
    SITE_MEMBER("Site Member");
    
    private String name;

    private LiferayRole(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
