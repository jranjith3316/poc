/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "COUNTRY_EMAIL", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CountryEmail.findAll", query = "SELECT c FROM CountryEmail c"),
    @NamedQuery(name = "CountryEmail.findByCountryId", query = "SELECT c FROM CountryEmail c WHERE c.countryId = :countryId"),
    @NamedQuery(name = "CountryEmail.findByEmailServer", query = "SELECT c FROM CountryEmail c WHERE c.emailServer = :emailServer"),
    @NamedQuery(name = "CountryEmail.findByWebmaster", query = "SELECT c FROM CountryEmail c WHERE c.webmaster = :webmaster"),
    @NamedQuery(name = "CountryEmail.findByWaltershareDest", query = "SELECT c FROM CountryEmail c WHERE c.waltershareDest = :waltershareDest"),
    @NamedQuery(name = "CountryEmail.findByUContactDest", query = "SELECT c FROM CountryEmail c WHERE c.uContactDest = :uContactDest"),
    @NamedQuery(name = "CountryEmail.findByUCommentDest", query = "SELECT c FROM CountryEmail c WHERE c.uCommentDest = :uCommentDest"),
    @NamedQuery(name = "CountryEmail.findByCustProfileDest", query = "SELECT c FROM CountryEmail c WHERE c.custProfileDest = :custProfileDest"),
    @NamedQuery(name = "CountryEmail.findByEmploymentDest", query = "SELECT c FROM CountryEmail c WHERE c.employmentDest = :employmentDest"),
    @NamedQuery(name = "CountryEmail.findByGasClaimDest", query = "SELECT c FROM CountryEmail c WHERE c.gasClaimDest = :gasClaimDest"),
    @NamedQuery(name = "CountryEmail.findByExpenseRptDest", query = "SELECT c FROM CountryEmail c WHERE c.expenseRptDest = :expenseRptDest"),
    @NamedQuery(name = "CountryEmail.findByPerDiemDest", query = "SELECT c FROM CountryEmail c WHERE c.perDiemDest = :perDiemDest"),
    @NamedQuery(name = "CountryEmail.findByMis1", query = "SELECT c FROM CountryEmail c WHERE c.mis1 = :mis1"),
    @NamedQuery(name = "CountryEmail.findByMis2", query = "SELECT c FROM CountryEmail c WHERE c.mis2 = :mis2"),
    @NamedQuery(name = "CountryEmail.findByMis3", query = "SELECT c FROM CountryEmail c WHERE c.mis3 = :mis3"),
    @NamedQuery(name = "CountryEmail.findByMis4", query = "SELECT c FROM CountryEmail c WHERE c.mis4 = :mis4"),
    @NamedQuery(name = "CountryEmail.findByBck1", query = "SELECT c FROM CountryEmail c WHERE c.bck1 = :bck1"),
    @NamedQuery(name = "CountryEmail.findByPresident", query = "SELECT c FROM CountryEmail c WHERE c.president = :president"),
    @NamedQuery(name = "CountryEmail.findByVpSales", query = "SELECT c FROM CountryEmail c WHERE c.vpSales = :vpSales"),
    @NamedQuery(name = "CountryEmail.findByVpFinance", query = "SELECT c FROM CountryEmail c WHERE c.vpFinance = :vpFinance"),
    @NamedQuery(name = "CountryEmail.findByAcct1", query = "SELECT c FROM CountryEmail c WHERE c.acct1 = :acct1"),
    @NamedQuery(name = "CountryEmail.findByMkt1", query = "SELECT c FROM CountryEmail c WHERE c.mkt1 = :mkt1"),
    @NamedQuery(name = "CountryEmail.findByMkt2", query = "SELECT c FROM CountryEmail c WHERE c.mkt2 = :mkt2"),
    @NamedQuery(name = "CountryEmail.findByCsr1", query = "SELECT c FROM CountryEmail c WHERE c.csr1 = :csr1"),
    @NamedQuery(name = "CountryEmail.findByVpRd", query = "SELECT c FROM CountryEmail c WHERE c.vpRd = :vpRd"),
    @NamedQuery(name = "CountryEmail.findByPmAb", query = "SELECT c FROM CountryEmail c WHERE c.pmAb = :pmAb"),
    @NamedQuery(name = "CountryEmail.findByPmCt", query = "SELECT c FROM CountryEmail c WHERE c.pmCt = :pmCt"),
    @NamedQuery(name = "CountryEmail.findByPmTl", query = "SELECT c FROM CountryEmail c WHERE c.pmTl = :pmTl"),
    @NamedQuery(name = "CountryEmail.findByPmPt", query = "SELECT c FROM CountryEmail c WHERE c.pmPt = :pmPt"),
    @NamedQuery(name = "CountryEmail.findByPmSf", query = "SELECT c FROM CountryEmail c WHERE c.pmSf = :pmSf"),
    @NamedQuery(name = "CountryEmail.findByProdMgmt", query = "SELECT c FROM CountryEmail c WHERE c.prodMgmt = :prodMgmt"),
    @NamedQuery(name = "CountryEmail.findByCbshareDest", query = "SELECT c FROM CountryEmail c WHERE c.cbshareDest = :cbshareDest"),
    @NamedQuery(name = "CountryEmail.findByBioRequest", query = "SELECT c FROM CountryEmail c WHERE c.bioRequest = :bioRequest"),
    @NamedQuery(name = "CountryEmail.findBySlxUserValidator", query = "SELECT c FROM CountryEmail c WHERE c.slxUserValidator = :slxUserValidator"),
    @NamedQuery(name = "CountryEmail.findBySlxCrmValidator", query = "SELECT c FROM CountryEmail c WHERE c.slxCrmValidator = :slxCrmValidator"),
    @NamedQuery(name = "CountryEmail.findByMis5", query = "SELECT c FROM CountryEmail c WHERE c.mis5 = :mis5"),
    @NamedQuery(name = "CountryEmail.findByProjectMgr", query = "SELECT c FROM CountryEmail c WHERE c.projectMgr = :projectMgr"),
    @NamedQuery(name = "CountryEmail.findByRdAssistant", query = "SELECT c FROM CountryEmail c WHERE c.rdAssistant = :rdAssistant")})
public class CountryEmail implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "COUNTRY_ID")
    private Long countryId;
    @Size(max = 20)
    @Column(name = "EMAIL_SERVER")
    private String emailServer;
    @Size(max = 80)
    @Column(name = "WEBMASTER")
    private String webmaster;
    @Size(max = 80)
    @Column(name = "WALTERSHARE_DEST")
    private String waltershareDest;
    @Size(max = 80)
    @Column(name = "U_CONTACT_DEST")
    private String uContactDest;
    @Size(max = 80)
    @Column(name = "U_COMMENT_DEST")
    private String uCommentDest;
    @Size(max = 80)
    @Column(name = "CUST_PROFILE_DEST")
    private String custProfileDest;
    @Size(max = 80)
    @Column(name = "EMPLOYMENT_DEST")
    private String employmentDest;
    @Size(max = 80)
    @Column(name = "GAS_CLAIM_DEST")
    private String gasClaimDest;
    @Size(max = 80)
    @Column(name = "EXPENSE_RPT_DEST")
    private String expenseRptDest;
    @Size(max = 80)
    @Column(name = "PER_DIEM_DEST")
    private String perDiemDest;
    @Size(max = 80)
    @Column(name = "MIS1")
    private String mis1;
    @Size(max = 80)
    @Column(name = "MIS2")
    private String mis2;
    @Size(max = 80)
    @Column(name = "MIS3")
    private String mis3;
    @Size(max = 80)
    @Column(name = "MIS4")
    private String mis4;
    @Size(max = 80)
    @Column(name = "BCK1")
    private String bck1;
    @Size(max = 80)
    @Column(name = "PRESIDENT")
    private String president;
    @Size(max = 80)
    @Column(name = "VP_SALES")
    private String vpSales;
    @Size(max = 80)
    @Column(name = "VP_FINANCE")
    private String vpFinance;
    @Size(max = 80)
    @Column(name = "ACCT1")
    private String acct1;
    @Size(max = 80)
    @Column(name = "MKT1")
    private String mkt1;
    @Size(max = 80)
    @Column(name = "MKT2")
    private String mkt2;
    @Size(max = 80)
    @Column(name = "CSR1")
    private String csr1;
    @Size(max = 80)
    @Column(name = "VP_RD")
    private String vpRd;
    @Size(max = 80)
    @Column(name = "PM_AB")
    private String pmAb;
    @Size(max = 80)
    @Column(name = "PM_CT")
    private String pmCt;
    @Size(max = 80)
    @Column(name = "PM_TL")
    private String pmTl;
    @Size(max = 80)
    @Column(name = "PM_PT")
    private String pmPt;
    @Size(max = 80)
    @Column(name = "PM_SF")
    private String pmSf;
    @Size(max = 80)
    @Column(name = "PROD_MGMT")
    private String prodMgmt;
    @Size(max = 80)
    @Column(name = "CBSHARE_DEST")
    private String cbshareDest;
    @Size(max = 80)
    @Column(name = "BIO_REQUEST")
    private String bioRequest;
    @Size(max = 80)
    @Column(name = "SLX_USER_VALIDATOR")
    private String slxUserValidator;
    @Size(max = 80)
    @Column(name = "SLX_CRM_VALIDATOR")
    private String slxCrmValidator;
    @Size(max = 80)
    @Column(name = "MIS5")
    private String mis5;
    @Size(max = 80)
    @Column(name = "PROJECT_MGR")
    private String projectMgr;
    @Size(max = 80)
    @Column(name = "RD_ASSISTANT")
    private String rdAssistant;
    @JoinColumn(name = "COUNTRY_ID", referencedColumnName = "COUNTRY_ID", insertable = false, updatable = false)
    @OneToOne(optional = false)
    private Country country;

    public CountryEmail() {
    }

    public CountryEmail(Long countryId) {
        this.countryId = countryId;
    }

    public Long getCountryId() {
        return countryId;
    }

    public void setCountryId(Long countryId) {
        this.countryId = countryId;
    }

    public String getEmailServer() {
        return emailServer;
    }

    public void setEmailServer(String emailServer) {
        this.emailServer = emailServer;
    }

    public String getWebmaster() {
        return webmaster;
    }

    public void setWebmaster(String webmaster) {
        this.webmaster = webmaster;
    }

    public String getWaltershareDest() {
        return waltershareDest;
    }

    public void setWaltershareDest(String waltershareDest) {
        this.waltershareDest = waltershareDest;
    }

    public String getUContactDest() {
        return uContactDest;
    }

    public void setUContactDest(String uContactDest) {
        this.uContactDest = uContactDest;
    }

    public String getUCommentDest() {
        return uCommentDest;
    }

    public void setUCommentDest(String uCommentDest) {
        this.uCommentDest = uCommentDest;
    }

    public String getCustProfileDest() {
        return custProfileDest;
    }

    public void setCustProfileDest(String custProfileDest) {
        this.custProfileDest = custProfileDest;
    }

    public String getEmploymentDest() {
        return employmentDest;
    }

    public void setEmploymentDest(String employmentDest) {
        this.employmentDest = employmentDest;
    }

    public String getGasClaimDest() {
        return gasClaimDest;
    }

    public void setGasClaimDest(String gasClaimDest) {
        this.gasClaimDest = gasClaimDest;
    }

    public String getExpenseRptDest() {
        return expenseRptDest;
    }

    public void setExpenseRptDest(String expenseRptDest) {
        this.expenseRptDest = expenseRptDest;
    }

    public String getPerDiemDest() {
        return perDiemDest;
    }

    public void setPerDiemDest(String perDiemDest) {
        this.perDiemDest = perDiemDest;
    }

    public String getMis1() {
        return mis1;
    }

    public void setMis1(String mis1) {
        this.mis1 = mis1;
    }

    public String getMis2() {
        return mis2;
    }

    public void setMis2(String mis2) {
        this.mis2 = mis2;
    }

    public String getMis3() {
        return mis3;
    }

    public void setMis3(String mis3) {
        this.mis3 = mis3;
    }

    public String getMis4() {
        return mis4;
    }

    public void setMis4(String mis4) {
        this.mis4 = mis4;
    }

    public String getBck1() {
        return bck1;
    }

    public void setBck1(String bck1) {
        this.bck1 = bck1;
    }

    public String getPresident() {
        return president;
    }

    public void setPresident(String president) {
        this.president = president;
    }

    public String getVpSales() {
        return vpSales;
    }

    public void setVpSales(String vpSales) {
        this.vpSales = vpSales;
    }

    public String getVpFinance() {
        return vpFinance;
    }

    public void setVpFinance(String vpFinance) {
        this.vpFinance = vpFinance;
    }

    public String getAcct1() {
        return acct1;
    }

    public void setAcct1(String acct1) {
        this.acct1 = acct1;
    }

    public String getMkt1() {
        return mkt1;
    }

    public void setMkt1(String mkt1) {
        this.mkt1 = mkt1;
    }

    public String getMkt2() {
        return mkt2;
    }

    public void setMkt2(String mkt2) {
        this.mkt2 = mkt2;
    }

    public String getCsr1() {
        return csr1;
    }

    public void setCsr1(String csr1) {
        this.csr1 = csr1;
    }

    public String getVpRd() {
        return vpRd;
    }

    public void setVpRd(String vpRd) {
        this.vpRd = vpRd;
    }

    public String getPmAb() {
        return pmAb;
    }

    public void setPmAb(String pmAb) {
        this.pmAb = pmAb;
    }

    public String getPmCt() {
        return pmCt;
    }

    public void setPmCt(String pmCt) {
        this.pmCt = pmCt;
    }

    public String getPmTl() {
        return pmTl;
    }

    public void setPmTl(String pmTl) {
        this.pmTl = pmTl;
    }

    public String getPmPt() {
        return pmPt;
    }

    public void setPmPt(String pmPt) {
        this.pmPt = pmPt;
    }

    public String getPmSf() {
        return pmSf;
    }

    public void setPmSf(String pmSf) {
        this.pmSf = pmSf;
    }

    public String getProdMgmt() {
        return prodMgmt;
    }

    public void setProdMgmt(String prodMgmt) {
        this.prodMgmt = prodMgmt;
    }

    public String getCbshareDest() {
        return cbshareDest;
    }

    public void setCbshareDest(String cbshareDest) {
        this.cbshareDest = cbshareDest;
    }

    public String getBioRequest() {
        return bioRequest;
    }

    public void setBioRequest(String bioRequest) {
        this.bioRequest = bioRequest;
    }

    public String getSlxUserValidator() {
        return slxUserValidator;
    }

    public void setSlxUserValidator(String slxUserValidator) {
        this.slxUserValidator = slxUserValidator;
    }

    public String getSlxCrmValidator() {
        return slxCrmValidator;
    }

    public void setSlxCrmValidator(String slxCrmValidator) {
        this.slxCrmValidator = slxCrmValidator;
    }

    public String getMis5() {
        return mis5;
    }

    public void setMis5(String mis5) {
        this.mis5 = mis5;
    }

    public String getProjectMgr() {
        return projectMgr;
    }

    public void setProjectMgr(String projectMgr) {
        this.projectMgr = projectMgr;
    }

    public String getRdAssistant() {
        return rdAssistant;
    }

    public void setRdAssistant(String rdAssistant) {
        this.rdAssistant = rdAssistant;
    }

    public Country getCountry() {
        return country;
    }

    public void setCountry(Country country) {
        this.country = country;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (countryId != null ? countryId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CountryEmail)) {
            return false;
        }
        CountryEmail other = (CountryEmail) object;
        if ((this.countryId == null && other.countryId != null) || (this.countryId != null && !this.countryId.equals(other.countryId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.CountryEmail[ countryId=" + countryId + " ]";
    }
    
}
