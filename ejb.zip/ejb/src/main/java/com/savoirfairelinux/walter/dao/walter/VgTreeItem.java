/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.walter;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import java.util.Date;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author jsgill
 */
@Entity
@Table(name = "VG_TREE_ITEM", catalog = "", schema = DatabaseConstants.WALTER_SCHEMA)
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "VgTreeItem.findAll", query = "SELECT v FROM VgTreeItem v"),
  @NamedQuery(name = "VgTreeItem.findByVgTreeCode", query = "SELECT v FROM VgTreeItem v WHERE v.vgTreeItemPK.vgTreeCode = :vgTreeCode"),
  @NamedQuery(name = "VgTreeItem.findByItemId", query = "SELECT v FROM VgTreeItem v WHERE v.vgTreeItemPK.itemId = :itemId"),
  @NamedQuery(name = "VgTreeItem.findByParentId", query = "SELECT v FROM VgTreeItem v WHERE v.parentId = :parentId"),
  @NamedQuery(name = "VgTreeItem.findByOrderBy", query = "SELECT v FROM VgTreeItem v WHERE v.orderBy = :orderBy"),
  @NamedQuery(name = "VgTreeItem.findByCreatorUserName", query = "SELECT v FROM VgTreeItem v WHERE v.creatorUserName = :creatorUserName"),
  @NamedQuery(name = "VgTreeItem.findByCreationDate", query = "SELECT v FROM VgTreeItem v WHERE v.creationDate = :creationDate"),
  @NamedQuery(name = "VgTreeItem.findByCancelBy", query = "SELECT v FROM VgTreeItem v WHERE v.cancelBy = :cancelBy"),
  @NamedQuery(name = "VgTreeItem.findByCancelDate", query = "SELECT v FROM VgTreeItem v WHERE v.cancelDate = :cancelDate"),
  @NamedQuery(name = "VgTreeItem.findByDisplayTwn", query = "SELECT v FROM VgTreeItem v WHERE v.displayTwn = :displayTwn"),
  @NamedQuery(name = "VgTreeItem.findByDisplayVg", query = "SELECT v FROM VgTreeItem v WHERE v.displayVg = :displayVg"),
  @NamedQuery(name = "VgTreeItem.findByTreeType", query = "SELECT v FROM VgTreeItem v WHERE v.treeType = :treeType"),
  @NamedQuery(name = "VgTreeItem.findByFeatureOrderBy", query = "SELECT v FROM VgTreeItem v WHERE v.featureOrderBy = :featureOrderBy"),
  @NamedQuery(name = "VgTreeItem.findByDefaultCreatedUserName", query = "SELECT v FROM VgTreeItem v WHERE v.defaultCreatedUserName = :defaultCreatedUserName"),
  @NamedQuery(name = "VgTreeItem.findByDefaultCreationDate", query = "SELECT v FROM VgTreeItem v WHERE v.defaultCreationDate = :defaultCreationDate"),
  @NamedQuery(name = "VgTreeItem.findByDefaultCancelUserName", query = "SELECT v FROM VgTreeItem v WHERE v.defaultCancelUserName = :defaultCancelUserName"),
  @NamedQuery(name = "VgTreeItem.findByDefaultCancelDate", query = "SELECT v FROM VgTreeItem v WHERE v.defaultCancelDate = :defaultCancelDate"),
  @NamedQuery(name = "VgTreeItem.findByIsfolder", query = "SELECT v FROM VgTreeItem v WHERE v.isfolder = :isfolder")})
public class VgTreeItem implements Serializable {
  private static final long serialVersionUID = 1L;
  @EmbeddedId
  protected VgTreeItemPK vgTreeItemPK;
  @Column(name = "PARENT_ID")
  private Integer parentId;
  @Column(name = "ORDER_BY")
  private Short orderBy;
  @Size(max = 256)
  @Column(name = "CREATOR_USER_NAME")
  private String creatorUserName;
  @Column(name = "CREATION_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date creationDate;
  @Size(max = 256)
  @Column(name = "CANCEL_BY")
  private String cancelBy;
  @Column(name = "CANCEL_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date cancelDate;
  @Column(name = "DISPLAY_TWN")
  private Character displayTwn;
  @Column(name = "DISPLAY_VG")
  private Character displayVg;
  @Column(name = "TREE_TYPE")
  private Short treeType;
  @Column(name = "FEATURE_ORDER_BY")
  private Integer featureOrderBy;
  @Size(max = 256)
  @Column(name = "DEFAULT_CREATED_USER_NAME")
  private String defaultCreatedUserName;
  @Column(name = "DEFAULT_CREATION_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date defaultCreationDate;
  @Size(max = 256)
  @Column(name = "DEFAULT_CANCEL_USER_NAME")
  private String defaultCancelUserName;
  @Column(name = "DEFAULT_CANCEL_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date defaultCancelDate;
  @Column(name = "ISFOLDER")
  private Character isfolder;
  @JoinColumn(name = "VG_TREE_CODE", referencedColumnName = "VG_TREE_CODE", insertable = false, updatable = false)
  @ManyToOne(optional = false)
  private VgTree vgTree;
  @OneToMany(cascade = CascadeType.ALL, mappedBy = "vgTreeItem")
  private Set<VgTreeProduct> vgTreeProductSet;
  @OneToMany(cascade = CascadeType.ALL, mappedBy = "vgTreeItem")
  private Set<VgTreeItemTxt> vgTreeItemTxtSet;

  public VgTreeItem() {
  }

  public VgTreeItem(VgTreeItemPK vgTreeItemPK) {
    this.vgTreeItemPK = vgTreeItemPK;
  }

  public VgTreeItem(String vgTreeCode, int itemId) {
    this.vgTreeItemPK = new VgTreeItemPK(vgTreeCode, itemId);
  }

  public VgTreeItemPK getVgTreeItemPK() {
    return vgTreeItemPK;
  }

  public void setVgTreeItemPK(VgTreeItemPK vgTreeItemPK) {
    this.vgTreeItemPK = vgTreeItemPK;
  }

  public Integer getParentId() {
    return parentId;
  }

  public void setParentId(Integer parentId) {
    this.parentId = parentId;
  }

  public Short getOrderBy() {
    return orderBy;
  }

  public void setOrderBy(Short orderBy) {
    this.orderBy = orderBy;
  }

  public String getCreatorUserName() {
    return creatorUserName;
  }

  public void setCreatorUserName(String creatorUserName) {
    this.creatorUserName = creatorUserName;
  }

  public Date getCreationDate() {
    return creationDate;
  }

  public void setCreationDate(Date creationDate) {
    this.creationDate = creationDate;
  }

  public String getCancelBy() {
    return cancelBy;
  }

  public void setCancelBy(String cancelBy) {
    this.cancelBy = cancelBy;
  }

  public Date getCancelDate() {
    return cancelDate;
  }

  public void setCancelDate(Date cancelDate) {
    this.cancelDate = cancelDate;
  }

  public Character getDisplayTwn() {
    return displayTwn;
  }

  public void setDisplayTwn(Character displayTwn) {
    this.displayTwn = displayTwn;
  }

  public Character getDisplayVg() {
    return displayVg;
  }

  public void setDisplayVg(Character displayVg) {
    this.displayVg = displayVg;
  }

  public Short getTreeType() {
    return treeType;
  }

  public void setTreeType(Short treeType) {
    this.treeType = treeType;
  }

  public Integer getFeatureOrderBy() {
    return featureOrderBy;
  }

  public void setFeatureOrderBy(Integer featureOrderBy) {
    this.featureOrderBy = featureOrderBy;
  }

  public String getDefaultCreatedUserName() {
    return defaultCreatedUserName;
  }

  public void setDefaultCreatedUserName(String defaultCreatedUserName) {
    this.defaultCreatedUserName = defaultCreatedUserName;
  }

  public Date getDefaultCreationDate() {
    return defaultCreationDate;
  }

  public void setDefaultCreationDate(Date defaultCreationDate) {
    this.defaultCreationDate = defaultCreationDate;
  }

  public String getDefaultCancelUserName() {
    return defaultCancelUserName;
  }

  public void setDefaultCancelUserName(String defaultCancelUserName) {
    this.defaultCancelUserName = defaultCancelUserName;
  }

  public Date getDefaultCancelDate() {
    return defaultCancelDate;
  }

  public void setDefaultCancelDate(Date defaultCancelDate) {
    this.defaultCancelDate = defaultCancelDate;
  }

  public Character getIsfolder() {
    return isfolder;
  }

  public void setIsfolder(Character isfolder) {
    this.isfolder = isfolder;
  }

  public VgTree getVgTree() {
    return vgTree;
  }

  public void setVgTree(VgTree vgTree) {
    this.vgTree = vgTree;
  }

  @XmlTransient
  public Set<VgTreeProduct> getVgTreeProductSet() {
    return vgTreeProductSet;
  }

  public void setVgTreeProductSet(Set<VgTreeProduct> vgTreeProductSet) {
    this.vgTreeProductSet = vgTreeProductSet;
  }

  @XmlTransient
  public Set<VgTreeItemTxt> getVgTreeItemTxtSet() {
    return vgTreeItemTxtSet;
  }

  public void setVgTreeItemTxtSet(Set<VgTreeItemTxt> vgTreeItemTxtSet) {
    this.vgTreeItemTxtSet = vgTreeItemTxtSet;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (vgTreeItemPK != null ? vgTreeItemPK.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof VgTreeItem)) {
      return false;
    }
    VgTreeItem other = (VgTreeItem) object;
    if ((this.vgTreeItemPK == null && other.vgTreeItemPK != null) || (this.vgTreeItemPK != null && !this.vgTreeItemPK.equals(other.vgTreeItemPK))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.walter.VgTreeItem[ vgTreeItemPK=" + vgTreeItemPK + " ]";
  }
  
}
