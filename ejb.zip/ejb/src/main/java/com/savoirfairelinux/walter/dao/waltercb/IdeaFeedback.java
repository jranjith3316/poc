/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Set;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "IDEA_FEEDBACK", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "IdeaFeedback.findAll", query = "SELECT i FROM IdeaFeedback i"),
    @NamedQuery(name = "IdeaFeedback.findByIdeaId", query = "SELECT i FROM IdeaFeedback i WHERE i.idea.ideaId = :ideaId"),
    @NamedQuery(name = "IdeaFeedback.findByFeedbackId", query = "SELECT i FROM IdeaFeedback i WHERE i.feedbackId = :feedbackId"),
    @NamedQuery(name = "IdeaFeedback.findByFeedbackDescription", query = "SELECT i FROM IdeaFeedback i WHERE i.feedbackDescription = :feedbackDescription"),
    @NamedQuery(name = "IdeaFeedback.findByRanking", query = "SELECT i FROM IdeaFeedback i WHERE i.ranking = :ranking"),
    @NamedQuery(name = "IdeaFeedback.findByCreatedDate", query = "SELECT i FROM IdeaFeedback i WHERE i.createdDate = :createdDate"),
    @NamedQuery(name = "IdeaFeedback.findByFeedbackUserName", query = "SELECT i FROM IdeaFeedback i WHERE i.feedbackUserName = :feedbackUserName")})
public class IdeaFeedback implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @GeneratedValue(generator = "IDEA_FEEDBACK_ID_SEQ", strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "IDEA_FEEDBACK_ID_SEQ", sequenceName = "IDEA_FEEDBACK_ID_SEQ", schema = DatabaseConstants.WALTERCB_SCHEMA, allocationSize = 1)
    @Column(name = "FEEDBACK_ID")
    private Long feedbackId;
    @Size(max = 1000)
    @Column(name = "FEEDBACK_DESCRIPTION")
    private String feedbackDescription;
    @Size(max = 255)
    private String ranking;
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;
    @Size(max = 256)
    @Column(name = "FEEDBACK_USER_NAME")
    private String feedbackUserName;
    @JoinColumn(name = "IDEA_ID", referencedColumnName = "IDEA_ID", nullable = false)
    @ManyToOne
    private Idea idea;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "ideaFeedback", fetch = FetchType.EAGER)
    private Set<IdeaFeedbackR> ideaFeedbackRSet;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "ideaFeedback", fetch = FetchType.EAGER)
    private List<IdeaFeedbackFile> ideaFeedbackFileSet;

    public IdeaFeedback() {
    }

    public IdeaFeedback(long feedbackId) {
        this.feedbackId = feedbackId;
    }

    public Long getFeedbackId() {
        return feedbackId;
    }

    public void setFeedbackId(Long feedbackId) {
        this.feedbackId = feedbackId;
    }

    public String getFeedbackDescription() {
        return feedbackDescription;
    }

    public void setFeedbackDescription(String feedbackDescription) {
        this.feedbackDescription = feedbackDescription;
    }

    public String getRanking() {
        return ranking;
    }

    public void setRanking(String ranking) {
        this.ranking = ranking;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getFeedbackUserName() {
        return feedbackUserName;
    }

    public void setFeedbackUserName(String feedbackUserName) {
        this.feedbackUserName = feedbackUserName;
    }

    public Idea getIdea() {
        return idea;
    }

    public void setIdea(Idea idea) {
        this.idea = idea;
    }

    @XmlTransient
    public Set<IdeaFeedbackR> getIdeaFeedbackRSet() {
        return ideaFeedbackRSet;
    }

    public void setIdeaFeedbackRSet(Set<IdeaFeedbackR> ideaFeedbackRSet) {
        this.ideaFeedbackRSet = ideaFeedbackRSet;
    }

    @XmlTransient
    public List<IdeaFeedbackFile> getIdeaFeedbackFileSet() {
        return ideaFeedbackFileSet;
    }

    public void setIdeaFeedbackFileSet(List<IdeaFeedbackFile> ideaFeedbackFileSet) {
        this.ideaFeedbackFileSet = ideaFeedbackFileSet;
    }

    @Override
    public int hashCode() {
        int hash = (feedbackId != null ? feedbackId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof IdeaFeedback)) {
            return false;
        }
        IdeaFeedback other = (IdeaFeedback) object;
        if ((this.feedbackId == null && other.feedbackId != null) || (this.feedbackId != null && !this.feedbackId.equals(other.feedbackId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.IdeaFeedback[ feedbackId=" + feedbackId + " ]";
    }
}