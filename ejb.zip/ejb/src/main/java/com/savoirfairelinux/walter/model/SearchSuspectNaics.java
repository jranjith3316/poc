/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.model;

import com.savoirfairelinux.walter.dao.waltercb.CountryStateTxt;
import java.io.Serializable;

/**
 *
 * @author jsgill
 */
public class SearchSuspectNaics implements Serializable {
  private String naics;
  private String cbNaics;
  private String city;
  private String postalCode;
  private CountryStateTxt countryStateTxt;
  private Long countryId;

  public String getNaics() {
    return naics;
  }

  public void setNaics(String naics) {
    this.naics = naics;
  }

  public String getCbNaics() {
    return cbNaics;
  }

  public void setCbNaics(String cbNaics) {
    this.cbNaics = cbNaics;
  }

  public String getCity() {
    return city;
  }

  public void setCity(String city) {
    this.city = city;
  }

  public String getPostalCode() {
    return postalCode;
  }

  public void setPostalCode(String postalCode) {
    this.postalCode = postalCode;
  }

  public CountryStateTxt getCountryStateTxt() {
    return countryStateTxt;
  }

  public void setCountryStateTxt(CountryStateTxt countryStateTxt) {
    this.countryStateTxt = countryStateTxt;
  }

  public Long getCountryId() {
    return countryId;
  }

  public void setCountryId(Long countryId) {
    this.countryId = countryId;
  }

}
