/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "CNT_PRODUCT", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CntProduct.findAll", query = "SELECT c FROM CntProduct c"),
    @NamedQuery(name = "CntProduct.findByCntId", query = "SELECT c FROM CntProduct c WHERE c.cntProductPK.cntId = :cntId"),
    @NamedQuery(name = "CntProduct.findByFranchiseguid", query = "SELECT c FROM CntProduct c WHERE c.cntProductPK.franchiseguid = :franchiseguid"),
    @NamedQuery(name = "CntProduct.findByTradenameguid", query = "SELECT c FROM CntProduct c WHERE c.cntProductPK.tradenameguid = :tradenameguid")})
public class CntProduct implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected CntProductPK cntProductPK;
    @JoinColumn(name = "CNT_ID", referencedColumnName = "CNT_ID", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Cnt cnt;
    @Transient
    private String franchiseName;
    @Transient
    private String tradeName;

    public CntProduct() {
    }

    public CntProduct(CntProductPK cntProductPK) {
        this.cntProductPK = cntProductPK;
    }

    public CntProduct(long cntId, String franchiseguid, String tradenameguid) {
        this.cntProductPK = new CntProductPK(cntId, franchiseguid, tradenameguid);
    }

    public CntProductPK getCntProductPK() {
        return cntProductPK;
    }

    public void setCntProductPK(CntProductPK cntProductPK) {
        this.cntProductPK = cntProductPK;
    }

    public Cnt getCnt() {
        return cnt;
    }

    public void setCnt(Cnt cnt) {
        this.cnt = cnt;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cntProductPK != null ? cntProductPK.hashCode() : 0);
        return hash;
    }
    
    @PrePersist
    private void prePersist() {
    	if (cnt != null && cntProductPK != null) {
    		cntProductPK.setCntId(cnt.getCntId());
    	}
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CntProduct)) {
            return false;
        }
        CntProduct other = (CntProduct) object;
        if ((this.cntProductPK == null && other.cntProductPK != null) || (this.cntProductPK != null && !this.cntProductPK.equals(other.cntProductPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.CntProduct[ cntProductPK=" + cntProductPK + " ]";
    }

    public String getFranchiseName() {
        return franchiseName;
    }

    public void setFranchiseName(String franchiseName) {
        this.franchiseName = franchiseName;
    }

    public String getTradeName() {
        return tradeName;
    }

    public void setTradeName(String tradeName) {
        this.tradeName = tradeName;
    }
    
}
