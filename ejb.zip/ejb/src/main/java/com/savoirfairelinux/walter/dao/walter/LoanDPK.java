/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.walter;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

/**
 *
 * @author jsgill
 */
@Embeddable
public class LoanDPK implements Serializable {
  @Basic(optional = false)
  @NotNull
  @Column(name = "LOAN_ID")
  private long loanId;
  @Basic(optional = false)
  @NotNull
  @Column(name = "EXPENSE_RPT_ID")
  private long expenseRptId;

  public LoanDPK() {
  }

  public LoanDPK(long loanId, long expenseRptId) {
    this.loanId = loanId;
    this.expenseRptId = expenseRptId;
  }

  public long getLoanId() {
    return loanId;
  }

  public void setLoanId(long loanId) {
    this.loanId = loanId;
  }

  public long getExpenseRptId() {
    return expenseRptId;
  }

  public void setExpenseRptId(long expenseRptId) {
    this.expenseRptId = expenseRptId;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (int) loanId;
    hash += (int) expenseRptId;
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof LoanDPK)) {
      return false;
    }
    LoanDPK other = (LoanDPK) object;
    if (this.loanId != other.loanId) {
      return false;
    }
    if (this.expenseRptId != other.expenseRptId) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.walter.LoanDPK[ loanId=" + loanId + ", expenseRptId=" + expenseRptId + " ]";
  }
  
}
