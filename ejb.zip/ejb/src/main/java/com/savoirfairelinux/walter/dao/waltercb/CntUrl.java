/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.waltercb;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author mgubaidullin
 */
@Entity
@Table(name = "CNT_URL", catalog = "", schema = DatabaseConstants.WALTERCB_SCHEMA)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CntUrl.findAll", query = "SELECT c FROM CntUrl c"),
    @NamedQuery(name = "CntUrl.findByCntId", query = "SELECT c FROM CntUrl c WHERE c.cnt.cntId = :cntId"),
    @NamedQuery(name = "CntUrl.findByUrlId", query = "SELECT c FROM CntUrl c WHERE c.urlId = :urlId"),
    @NamedQuery(name = "CntUrl.findByUrlLink", query = "SELECT c FROM CntUrl c WHERE c.urlLink = :urlLink")})
public class CntUrl implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "URL_ID")
	@GeneratedValue(generator = "CNT_URL_SEQ", strategy = GenerationType.SEQUENCE)
	@SequenceGenerator(name = "CNT_URL_SEQ", sequenceName = "CNT_URL_SEQ", schema = DatabaseConstants.WALTERCB_SCHEMA, allocationSize = 1)
    private Long urlId;
    @Size(max = 200)
    @Column(name = "URL_LINK")
    private String urlLink;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "cntUrl", fetch = FetchType.EAGER)
    private List<CntUrlTxt> cntUrlTxtList;
    @JoinColumn(name = "CNT_ID", referencedColumnName = "CNT_ID")
    @ManyToOne
    private Cnt cnt;

    public CntUrl() {
    }

    public CntUrl(long urlId) {
        this.urlId = urlId;
    }

     public Long getUrlId() {
		return urlId;
	}

	public void setUrlId(Long urlId) {
		this.urlId = urlId;
	}

	public String getUrlLink() {
        return urlLink;
    }

    public void setUrlLink(String urlLink) {
        this.urlLink = urlLink;
    }

    @XmlTransient
    public List<CntUrlTxt> getCntUrlTxtList() {
        return cntUrlTxtList;
    }

    public void setCntUrlTxtList(List<CntUrlTxt> cntUrlTxtList) {
        this.cntUrlTxtList = cntUrlTxtList;
    }

    public Cnt getCnt() {
        return cnt;
    }

    public void setCnt(Cnt cnt) {
        this.cnt = cnt;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (urlId != null ? urlId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof CntUrl)) {
            return false;
        }
        CntUrl other = (CntUrl) object;
        if (this.urlId == null && other.urlId == null) {
        	return this == other;
        } else if ((this.urlId == null && other.urlId != null) || (this.urlId != null && !this.urlId.equals(other.urlId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.savoirfairelinux.walter.dao.waltercb.CntUrl[ cntUrlId=" + urlId + " ]";
    }
}
