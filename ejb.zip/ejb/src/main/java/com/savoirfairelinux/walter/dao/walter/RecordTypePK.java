/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.savoirfairelinux.walter.dao.walter;

import com.savoirfairelinux.walter.dao.DatabaseConstants; import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author jsgill
 */
@Embeddable
public class RecordTypePK implements Serializable {
  @Basic(optional = false)
  @NotNull
  @Size(min = 1, max = 6)
  @Column(name = "RECORD_TYPE")
  private String recordType;
  @Basic(optional = false)
  @NotNull
  @Column(name = "LANG_ID")
  private long langId;

  public RecordTypePK() {
  }

  public RecordTypePK(String recordType, long langId) {
    this.recordType = recordType;
    this.langId = langId;
  }

  public String getRecordType() {
    return recordType;
  }

  public void setRecordType(String recordType) {
    this.recordType = recordType;
  }

  public long getLangId() {
    return langId;
  }

  public void setLangId(long langId) {
    this.langId = langId;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (recordType != null ? recordType.hashCode() : 0);
    hash += (int) langId;
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof RecordTypePK)) {
      return false;
    }
    RecordTypePK other = (RecordTypePK) object;
    if ((this.recordType == null && other.recordType != null) || (this.recordType != null && !this.recordType.equals(other.recordType))) {
      return false;
    }
    if (this.langId != other.langId) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "com.savoirfairelinux.walter.dao.walter.RecordTypePK[ recordType=" + recordType + ", langId=" + langId + " ]";
  }
  
}
