package com.nitish.junit.sample.constants;

/**
 * @author nitishtyagi
 */
public class junitPortletKeys {

	public static final String JUNIT =
		"com_nitish_junit_sample_junitPortlet";

}