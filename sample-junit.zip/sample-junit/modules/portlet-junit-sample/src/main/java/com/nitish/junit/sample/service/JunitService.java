package com.nitish.junit.sample.service;

public interface JunitService {
	
	String getAddtwoString(String first,String Second); 

}
